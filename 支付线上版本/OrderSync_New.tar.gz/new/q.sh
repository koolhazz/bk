#!/bin/sh
echo ORDER_NEW_Q

for ((i = 4501; i <= 4510; i++));
do
	echo [$i]": "`redis-cli -h 192.168.0.117 -p $i llen ORDER_NEW_Q`
done;


