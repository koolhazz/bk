#/bin/sh

cp order_db_sync OrderDbSync_4501/bin/order_db_sync
cp order_db_sync OrderDbSync_4502/bin/order_db_sync
cp order_db_sync OrderDbSync_4503/bin/order_db_sync
cp order_db_sync OrderDbSync_4504/bin/order_db_sync
cp order_db_sync OrderDbSync_4505/bin/order_db_sync
cp order_db_sync OrderDbSync_4506/bin/order_db_sync
cp order_db_sync OrderDbSync_4507/bin/order_db_sync
cp order_db_sync OrderDbSync_4508/bin/order_db_sync
cp order_db_sync OrderDbSync_4509/bin/order_db_sync
cp order_db_sync OrderDbSync_4510/bin/order_db_sync
