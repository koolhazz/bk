#/bin/sh

rm -f log/Log*

bin/order_db_sync NEW
