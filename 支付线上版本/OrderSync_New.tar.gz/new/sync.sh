#!/bin/sh

WORK_DIR=OrderDbSync_

for ((i = 4501; i <= 4510; i++));
do
        cd $WORK_DIR""$i
        pwd
        start.sh
        cd ..
done
