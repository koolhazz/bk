#!/bin/sh

WORK_DIR=OrderSyncClient

for ((i = 4500; i < 4510; i++));
do
	cd $WORK_DIR"_"$i;
	pwd;
	start.sh;
	cd ..;
	pwd;
done




