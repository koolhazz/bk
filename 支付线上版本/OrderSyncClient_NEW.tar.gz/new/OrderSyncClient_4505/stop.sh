#!/bin/sh

killall order_sync_client
