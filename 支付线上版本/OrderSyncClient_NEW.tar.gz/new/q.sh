#!/bin/sh

for ((i = 4500; i < 4510; i++));
do
	echo [$i]": "`redis-cli -h 192.168.0.37 -p $i llen ORDER_NEW_Q`
done;


