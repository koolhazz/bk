#!/bin/sh

ps -eo pid,rss,pcpu,command | grep NEW | grep -v grep
