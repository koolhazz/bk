#!/bin/sh 

cpubind() 
{
	pid=(`p.sh | awk '{print $1;ls -l}'`)
	cpu=2

	for ((i = 0; i < 10; i++));
	do
		echo $i": "${pid[$i]}
		echo "taskset -pc $cpu ${pid[$i]}"
		taskset -pc $cpu ${pid[$i]}
		cpu=$(($cpu+1))
	done
}


cpubind;
