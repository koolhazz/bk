#!/bin/sh

for ((i = 4500;i < 4510; i++))
do
	cp -a OrderSyncClient OrderSyncClient_""$i;
	sed -i "s/4501/$i/g" OrderSyncClient_""$i/etc/server.ini
done;

