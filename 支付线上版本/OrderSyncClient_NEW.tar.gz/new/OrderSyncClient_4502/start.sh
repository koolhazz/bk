#!/bin/sh

rm -f Log*

bin/order_sync_client 4502 NEW

