#!/bin/sh

rm -f Log*

bin/order_sync_client 4508 NEW
