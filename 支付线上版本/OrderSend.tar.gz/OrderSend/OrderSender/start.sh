#!/bin/sh
LD_PROLOAD=libjemalloc.so

#rm -f log/*
bin/order_sender
