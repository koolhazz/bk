#!/bin/sh 

killall order_sender
