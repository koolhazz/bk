#!/bin/sh

rm -fr log/*
valgrind --leak-check=full --show-reachable=yes --tool=memcheck -v bin/order_sender 
