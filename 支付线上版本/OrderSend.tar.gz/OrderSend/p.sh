#!/bin/env sh
ps -eo pid,rss,pcpu,comm | grep order_ --color
