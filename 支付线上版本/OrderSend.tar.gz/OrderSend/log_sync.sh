#write by AustinChen
#!/bin/sh
LOG_DIR=/data/paylog
LOG_DAY_DIR=${LOG_DIR}/`date +%Y%m%d -d yesterday`
LOG_FILE_DIR=/home/AustinChen/OrderSend/OrderLogger/log
TAR="tar Jcvf"
YESTERDAY=`date +%Y%m%d -d yesterday`
SUFFIX="tar.xz"

echo ${LOG_DAY_DIR}

if [ ! -d ${LOG_DAY_DIR} ]; then
	echo "mkdir ${LOG_DAY_DIR}"
	mkdir ${LOG_DAY_DIR}
	chmod a+w ${LOG_DAY_DIR}
fi
#move log file to dir
find ${LOG_FILE_DIR} -name "*`date +%Y%m%d -d yesterday`*" | xargs -I{} mv {} ${LOG_DAY_DIR} 
cd ${LOG_DAY_DIR}
echo "$TAR $YESTERDAY.tar.xz *" | sh
rm -f Log*
