#!/bin/sh
rm -f log/*
bin/UdpLogReport
