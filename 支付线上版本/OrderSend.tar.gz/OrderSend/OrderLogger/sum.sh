#!/bin/sh
egrep "by[+-]?[0-9]+" $1 --color | awk -F= ' {print $6}' | awk 'BEGIN{FS="&"} {print $1}' | awk 'BEGIN{FS="y"} {print $2}' | sort -n | uniq
