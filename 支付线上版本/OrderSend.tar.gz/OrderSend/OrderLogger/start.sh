#!/bin/sh

bin/order_logger

