#!/bin/sh

killall order_logger
