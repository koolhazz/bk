#!/bin/sh

rm -f log/*

bin/order_keeper
