#!/bin/sh 

killall config_sync_client
