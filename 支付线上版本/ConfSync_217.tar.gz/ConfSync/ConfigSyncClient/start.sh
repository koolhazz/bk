#!/bin/sh

rm -f Log*

bin/config_sync_client
