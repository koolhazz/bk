#ifndef __CRYPTO_H_
#define __CRYPTO_H_

#ifdef __cplusplus
extern "C" {
#endif

int
md5(const char* src, char* dest, unsigned short len);
	 

#ifdef __cplusplus
}
#endif


#endif
