#include "HttpRequest.h"
#include "Log.h"

int
HttpRequest::Get(const string& url)
{
	log_debug("HttpRequest::Get begin \n");

	m_curl = curl_easy_init();

    if (m_curl)
    {
		curl_easy_setopt(m_curl, CURLOPT_URL, url.c_str());

		m_res = curl_easy_perform(m_curl);
		printf("m_res=%d\n",m_res);
		if(m_res != CURLE_OK)
		{
//  		fprintf(stderr, "curl_easy_perform() failed: %s\n",
//  				curl_easy_strerror(m_res));

			log_debug("curl_easy_perform() failed: %s\n", curl_easy_strerror(m_res));

			curl_easy_cleanup(m_curl);

			return m_res;
		}
    }

	curl_easy_cleanup(m_curl);

	log_debug("HttpRequest::Get End \n");

    return 0;
}

string&
HttpRequest::Get(const string& url, string& result)
{
    return result;
}

