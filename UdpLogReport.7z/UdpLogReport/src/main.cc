#include "Request.h"
#include "HttpRequest.h"
#include "RedisHelper.h"
#include "Log.h"
#include "ConfigDef.h"
#include "Crypto.h"
#include "UDPClass.h"
#include "json/json.h"

#include <stdio.h>
#include <unistd.h>
#include <libgen.h>
#include <limits.h>
#include <stdlib.h>

using namespace std;
using namespace Json;
using namespace Helper;

static const char* const CONFIG_FILE = "../etc/server.ini";
static const unsigned short SLEEP_TIME = 1000 * 1000; // second

bool is_daemon = false;

static ERedisConf redis_conf;
static EInterfaceConf interface_conf;
static EQueueConf php_queue_conf;
static EQueueConf server_queue_conf;
static EUDPConf UDP_conf;

static
void
print_conf();

static
void 
CDWorkDir(const char * path);

int
main(int argc, char** argv)
{
    CDWorkDir(argv[0]);
	 
#ifdef _DAEMON_
    if (daemon(1, 0) == 0)
    {
        is_daemon = true;
    }
#endif

    char log_name[30] = {0};
	
    snprintf(log_name, 30, "Log_%d", getpid());

    init_log(log_name, "../log");
	 
    printf("server running...\n");
	 	 
    GetRedisConf(&redis_conf, CONFIG_FILE);
    //GetInterfaceConf(&interface_conf, CONFIG_FILE);
    GetPhpQueueConf(&php_queue_conf, CONFIG_FILE);
    //GetServerQueueConf(&server_queue_conf, CONFIG_FILE);
    GetUDPConf(&UDP_conf,CONFIG_FILE);

    print_conf();
	
    HttpRequest request;
    Helper::CRedisHelper redis(redis_conf.host, redis_conf.port);

	CUDP UDPDataSend;
	if(UDPDataSend.UDPCreateSocket()==0)
	{
		UDPDataSend.UDPConnect(UDP_conf.host,UDP_conf.port);
	}

	string json; 
	
	while (1) 
	{
		
	
		if (!redis.IsActived()) 
		{
			printf("redis reconnect.\n");
			redis.Connect();
		}
		
		json = redis.Dequeue(php_queue_conf.name, json);
		
		printf("JSON: %s\n", json.c_str());

		if (json.empty()) 
		{
			usleep(SLEEP_TIME);
			continue;
	    }
		
		if(UDPDataSend.UDPSend((void *)(json.c_str()), json.length()) < 0 )
		{
			if(UDPDataSend.UDPCreateSocket() == 0)
			{
				UDPDataSend.UDPConnect(UDP_conf.host,UDP_conf.port);
			}

			UDPDataSend.UDPSend((void *)(json.c_str()), json.length());
		}

		json.clear();
		
	}

	UDPDataSend.CloseFd();

    return 0;
}

void print_conf()
{
	 printf("----------------------------------------\n");
	 printf("redis->host: %s\n", redis_conf.host);
	 printf("redis->port: %d\n", redis_conf.port);
	 printf("----------------------------------------\n");
	 printf("interface->url: %s\n", interface_conf.url);
	 printf("----------------------------------------\n");
	 printf("php queue->name: %s\n", php_queue_conf.name);
	 printf("----------------------------------------\n");
	 printf("udp->host: %s\n", UDP_conf.host);
	 printf("udp->port: %d\n", UDP_conf.port);
	 printf("----------------------------------------\n");
	 printf("server queue->name: %s\n", server_queue_conf.name);
	 printf("----------------------------------------\n");
}

void CDWorkDir(const char * path)
{
	char* rpath = realpath(path, NULL);

	char* p = dirname(rpath);

	int i = chdir(p);

	free(rpath);
}
