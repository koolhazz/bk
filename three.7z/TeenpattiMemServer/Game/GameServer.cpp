#include "GameServer.h"
#include "CommandType.h"

#ifndef WIN32
#include <time.h>
#include <sys/time.h>

DWORD GetTickCount()
{
	timeval timesnow;
	struct timezone tmpzone;
	gettimeofday(&timesnow,&tmpzone);
	return ((DWORD)(timesnow.tv_sec*1000) + (DWORD)(timesnow.tv_usec/1000));
}

#endif


//������PHP����SERVER�����ݸ�backserver
const int PHP_UPDATE_DATA = 1;
const int SRV_UPDATE_DATA = 1000;


#ifndef WIN32
#include "clib_log.h"
extern clib_log* g_pDebugLog;
extern clib_log* g_pErrorLog;
#endif

#define	UPDATE_DATA_FILE "update_log"
#define UPDATE_MID_FILE "update_mid"

const int UPDATE_MID_FILE_TIMER = 1;

const int USER_ATTR_COUNT = 3;

void GetTime(string& strTm)
{
	time_t now = time(NULL);
	struct tm tm;
	localtime_r(&now, &tm);
	char szTm[100] = {0};
	snprintf(szTm, sizeof(szTm), "[%04d-%02d-%02d %02d:%02d:%02d]", tm.tm_year+1900, tm.tm_mon+1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
	strTm = szTm;
}

int split_str(const char* ps_str , char* ps_sp , vector<std::string> &v_ret)
{    
	char* ps_temp;    
	char* p;    
	int i_len = (int)strlen(ps_str);    
	std::string st_str;    
	ps_temp = new char[i_len+2];    
	snprintf(ps_temp , i_len+1 , "%s" , ps_str);    
	char *last = NULL;    
	p = strtok_r(ps_temp , ps_sp , &last);    
	if(NULL == p)
	{        
		delete ps_temp;        
		return 0;    
	}    
	st_str = (std::string)p;    
	v_ret.push_back(st_str);    
	while( NULL != ( p=strtok_r(NULL , ps_sp , &last) ) )
	{        
		st_str = (std::string)p;        
		v_ret.push_back(st_str);    
	}    
	delete ps_temp;    
	return 0;
}

CGameServer::CGameServer()
{
	m_nServStatus = SERVER_STATUS_UNINIT;
	memset(m_szUpdateLogFile, 0, sizeof(m_szUpdateLogFile));
	memset(m_szUpdateMidFile, 0, sizeof(m_szUpdateMidFile));
	m_bLogUpdateRecord = FALSE;
	m_UpdateLogFd = ACE_INVALID_HANDLE;
	m_UpdateMidFd = ACE_INVALID_HANDLE;
	m_nServerId = -1;
	m_strFilePath = "";
	m_nTimeInteval = 10*60;//10����
	m_UpdateMidFileTimer.SetTimeEventObj(this, UPDATE_MID_FILE_TIMER);
}

CGameServer::~CGameServer()
{
	ACE_OS::close(m_UpdateLogFd);
}

int CGameServer::ProcessClose(SocketHandler* pSocket)
{
	return SocketServer::ProcessClose(pSocket);
}

BOOL CGameServer::InitServer(const char* pMemcacheServer)
{
	//����memcache����
	if(!m_MemcacheClient.Init(pMemcacheServer))
	{
		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D] memcacheClient init failed\r\n")));
		return FALSE;
	}
	else
	{
		ACE_DEBUG((LM_INFO, ACE_TEXT("[%D] memcacheClient init OK\r\n")));
	}

	ICHAT_HTTP_Config ConfigReader;
	int nRet = ConfigReader.Open("config.ini");
	if(nRet == -1)
	{
		ACE_DEBUG((LM_INFO, ACE_TEXT("[%D] Open config.ini failed\r\n")));
		return FALSE;
	}

	ACE_Configuration_Section_Key subkey;
	ConfigReader.OpenSection("FILEPATH", subkey);
	char path[256]={0};
	ConfigReader.get_section_string(subkey, "path", path, sizeof(path));
	m_strFilePath = path;

	char szKey[100]={0};
	snprintf(szKey, sizeof(szKey), "LOGSERVER%d", m_nServerId);
	ConfigReader.OpenSection(szKey, subkey);
	char szIp[128] = {0};
	char szPort[64] = {0};
	ConfigReader.get_section_string(subkey, "HOST", szIp, sizeof(szIp));
	ConfigReader.get_section_string(subkey, "PORT", szPort, sizeof(szPort));
	m_pLogServer = new CLogServer();
	if(m_pLogServer != NULL) 
	{
		m_pLogServer->InitConnect(szIp, szPort);
	}

	memset(szKey, 0, sizeof(szKey));
	memset(szIp, 0, sizeof(szIp));
	memset(szPort, 0, sizeof(szPort));
	snprintf(szKey, sizeof(szKey), "UPDATESERVER%d", m_nServerId);
	ConfigReader.OpenSection(szKey, subkey);
	ConfigReader.get_section_string(subkey, "HOST", szIp, sizeof(szIp));
	ConfigReader.get_section_string(subkey, "PORT", szPort, sizeof(szPort));
	m_pUpdateServer = new CUpdateServer();
	if(m_pUpdateServer != NULL) 
	{
		m_pUpdateServer->InitConnect(szIp, szPort);
	}

	m_nServStatus = SERVER_STATUS_RUNNING;

	//m_UpdateMidFileTimer.StartTimer(m_nTimeInteval);
	ACE_DEBUG((LM_INFO, ACE_TEXT("[%D] InitServer OK\r\n")));
	return TRUE;
}

//��������,���еĿͻ��˷����������ֶ�ͳһ�����ﴦ��
int CGameServer::ProcessPacket(NETInputPacket *pPacket, SocketHandler *pSocket)
{
	short nCmdType = pPacket->GetCmdType();
	switch (nCmdType)
	{
	case CLIENT_COMMAND_CREATE_RECORD:
		return ProcCreateRecord(pPacket, pSocket);
	case CLIENT_COMMAND_UPDATE_MONEY:
		return ProcUpdateMoney(pPacket, pSocket);
	case CLIENT_COMMAND_DELETE_RECORD:
		return ProcDeleteRecord(pPacket, pSocket);
	case CLIENT_COMMAND_GET_RECORD:
		return ProcGetRecord(pPacket, pSocket);
	case SYS_COMMAND_UPDATE_RECORD://server�����û���Ϣ
		return ProcServerUpdateRecord(pPacket, pSocket);
	case SYS_COMMAND_SET_MID_UPDATE_FILE_INTEVAL:
		return ProcessSetMidUpdateFileInteval(pPacket, pSocket);
	case CLIENT_COMMAND_GET_RECORD_NEW:
		return ProcGetRecordNew(pPacket, pSocket);
	default:
		ACE_DEBUG((LM_INFO, ACE_TEXT("[%D] ProcessPacket||Error Cmd, nCmdType:[0x%x]\r\n"), nCmdType));
		break;
	}
	return 0;
}

int CGameServer::ProcessSetMidUpdateFileInteval(NETInputPacket* pPacket, SocketHandler *pSocket)
{
	string key = pPacket->ReadString();
	if(key == "BoyaaGame")
	{
		m_nTimeInteval = pPacket->ReadInt();
	}
	return 0;
}


int CGameServer::ProcCreateRecord(NETInputPacket* pPacket, SocketHandler *pSocket)
{
	int nMid = pPacket->ReadInt();
    long nMoney = pPacket->ReadLong();
    int nWinTimes = pPacket->ReadInt();
    int nLostTimes = pPacket->ReadInt();
	int nRet = 0;
	CGameUser* pOldUser = m_UserManager.GetUser(nMid);
	if (pOldUser != NULL)
	{
		nRet = -1;
	}
	else
	{
		unsigned int nCreateTime = time(NULL);
		CGameUser* pUser = new CGameUser(nMid, nMoney, nWinTimes, nLostTimes, nCreateTime);
		if(pUser != NULL)
		{
			if(m_UserManager.AddUser(nMid, pUser) == -1)
			{
				nRet = -1;
				delete pUser; 
				pUser = NULL;
			}
			else
			{
				//������д��memcache
				string temp = "";
				GetTime(temp);
				temp += " ";
				string strLog = pUser->GetInfoLog();
				temp += strLog;
				temp += "\n";
				SetMemcacheRecord(pUser);
				WriteUpdateLog(temp.c_str());
				
				/*char szMid[20]={0};
				snprintf(szMid, sizeof(szMid), "%d\n", nMid);
				WriteUpdateMid(szMid);*/

				SendUpdateMid(nMid);
			}
		}
		else
		{
			g_pErrorLog->logMsg("ProcCreateRecord||New CGameUser failed, uid:[%d]", nMid);
			nRet = -1;
		}
	}
	//��ͻ��˻�Ӧ�ɹ���Ϣ
	NETOutputPacket OutPkg;
	BuildPackage(&OutPkg, SERVER_COMMAND_CREATE_RECORD, "%d", nRet);
	SendPackageToClient(&OutPkg, pSocket);
	g_pErrorLog->logMsg("-------------- CGameServer::ProcCreateRecord end ------------------");
	return 0;
}

/************************************************************************/
/* ���¼�¼ ����ֵ���� 0:�ɹ� -1ʧ��(֧�ֶ���)                                                                     */
/************************************************************************/
int CGameServer::ProcServerUpdateRecord(NETInputPacket* pPacket, SocketHandler *pSocket)
{
	g_pErrorLog->logMsg("-------------- CGameServer::ProcServerUpdateRecord Begin ------------------");
    int nRet = 0;
    int nMid = pPacket->ReadInt();
    g_pErrorLog->logMsg("uid:[%d]", nMid);
    BYTE nAttrSize = pPacket->ReadByte();
    g_pErrorLog->logMsg("nAttrSize:[%d]", nAttrSize);
    vector<TUserAttr> attrList;

    int nRWintimes=-1, nRLosttime=-1;
   	long nRmoney=0;

    for(BYTE i=0; i<nAttrSize; i++)
    {
		TUserAttr userAttr;
        userAttr.type = pPacket->ReadInt();
        userAttr.value = pPacket->ReadInt();
        g_pErrorLog->logMsg("type:[%d], value:[%d]", userAttr.type, userAttr.value);

        attrList.push_back(userAttr);
    }

	CGameUser* pUser = m_UserManager.GetUser(nMid);
	if (pUser == NULL)
	{
		char key[100]={0};
		snprintf(key, sizeof(key), "%d", nMid);
		string value="";
		m_MemcacheClient.GetRecord(key, value);
		if(strcmp(value.c_str(), "") != 0)
		{
			vector<string> vec;
			split_str(value.c_str(), ",", vec);    //����ַ���
			if(vec.size() != USER_ATTR_COUNT)
			{
				g_pErrorLog->logMsg("ProcServerUpdateRecord||Error mc value, uid:[%d]", nMid);
				nRet = -1;
			}
			else
			{
				long nMoney     = 	atol(vec[0].c_str());
				int nWinTimes  = 	atoi(vec[1].c_str());
				int nLostTimes = 	atoi(vec[2].c_str());
				g_pDebugLog->logMsg("ProcServerUpdateRecord||MC money:[%ld], winTimes:[%d], lostTimes:[%d]", nMoney, nWinTimes, nLostTimes);
				unsigned int nCreateTime = (unsigned)time(NULL);
				pUser = new CGameUser(nMid, nMoney, nWinTimes, nLostTimes, nCreateTime);
				if(pUser == NULL)
				{
					g_pErrorLog->logMsg("ProcServerUpdateRecord||New CGameUser failed, uid:[%d]", nMid);
					nRet = -1;
				}
				else
				{
					m_UserManager.AddUser(nMid, pUser);
				}
			}
		}
		else
		{
			g_pErrorLog->logMsg("ProcUpdateRecord||MC has no record, uid:[%d]", nMid);
			nRet = -1;
		}
	}

	if(pUser != NULL)
	{
		//ȡ��Ӧ����
		if(pUser->UpdateInfo(attrList) == -1)
		{
			g_pErrorLog->logMsg("ProcServerUpdateRecord||UpdateInfo error uid:[%d]", nMid);
			nRet = -1; 
		}
		else
		{
			string temp = "";
			GetTime(temp);
			temp += " ";
			string strLog = pUser->GetInfoLog();
			temp += strLog;
			temp += "\n";

			//����д�����ˮ��־��־
			if (m_pLogServer != NULL)
			{
				if(pUser->m_nTurnMoney)
				{
					SendUserDataNewToBakServer(nMid, pUser->m_nTurnMoney, pUser->m_nMoney, SRV_UPDATE_DATA, "");
				}

			}
			
			WriteUpdateLog(temp.c_str());
			
			SetMemcacheRecord(pUser);
			/*char szMid[20]={0};
			snprintf(szMid, sizeof(szMid), "%d\n", nMid);
			WriteUpdateMid(szMid);*/
			SendUpdateMid(nMid);

          	nRmoney = pUser->m_nMoney;
            nRWintimes = pUser->m_nWintimes;
            nRLosttime = pUser->m_nLosttimes;

		}
	}
	else
	{
		nRet = -1;
	}
	//��ͻ��˻�Ӧ������Ϣ

	if(nRet == -1)
	{
		NETOutputPacket OutPkg;
		OutPkg.Begin(SERVER_COMMAND_UPDATE_RECORD);
		OutPkg.WriteInt(nRet);
		OutPkg.End();
		SendPackageToClient(&OutPkg, pSocket);
	}
	else
	{
		NETOutputPacket OutPkg;
		OutPkg.Begin(SERVER_COMMAND_UPDATE_RECORD);
		OutPkg.WriteInt(nRet);	
		OutPkg.WriteInt(USER_ATTR_COUNT);
		OutPkg.WriteInt(MONEY);
		OutPkg.WriteLong(nRmoney);	
		OutPkg.WriteInt(WINTIMES);
		OutPkg.WriteInt(nRWintimes);
		OutPkg.WriteInt(LOSTTIMES);
		OutPkg.WriteInt(nRLosttime);
		OutPkg.End();
		SendPackageToClient(&OutPkg, pSocket);
	}
	//g_pErrorLog->logMsg("-------------- CGameServer::ProcServerUpdateRecord End ------------------");
	return 0;
}

int CGameServer::ProcUpdateMoney(NETInputPacket* pPacket, SocketHandler *pSocket)
{
	int nRet = 0;
	int nMid = pPacket->ReadInt();
	string strBid = pPacket->ReadString();
    BYTE nAttrSize = pPacket->ReadByte();

    int type = pPacket->ReadInt();
	int value = 0;
	int actId = 0;
	long totalMoney = 0;
	if(type == MONEY)
	{
		value = pPacket->ReadInt();
		actId = pPacket->ReadInt();
	}
	else
	{
		g_pErrorLog->logMsg("ProcUpdateMoney||PHP update invalid attr type:[%d]", type);
		return 0;
	}
    
	CGameUser* pUser = m_UserManager.GetUser(nMid);
	if(pUser == NULL)
	{
		char key[100]={0};
		snprintf(key, sizeof(key), "%d", nMid);
		string value="";
		m_MemcacheClient.GetRecord(key, value);
		if(strcmp(value.c_str(), "") != 0)
		{
			vector<string> vec;
			split_str(value.c_str(), ",", vec);    //����ַ���
			if(vec.size() != USER_ATTR_COUNT)
			{
				g_pErrorLog->logMsg("ProcUpdateMoney||Error mc value, uid:[%d]", nMid);
				nRet = -1;
			}
			else
			{
				long nMoney     = 	atol(vec[0].c_str());
				int nWinTimes  = 	atoi(vec[1].c_str());
				int nLostTimes = 	atoi(vec[2].c_str());
				g_pDebugLog->logMsg("ProcUpdateMoney||MC money:[%ld], winTimes:[%d], lostTimes:[%d]", nMoney, nWinTimes, nLostTimes);
				unsigned int nCreateTime = (unsigned)time(NULL);
				pUser = new CGameUser(nMid, nMoney, nWinTimes, nLostTimes, nCreateTime);
				if(pUser == NULL)
				{
					g_pErrorLog->logMsg("ProcUpdateMoney||New CGameUser failed, uid:[%d]", nMid);
					nRet = -1;
				}
				else
				{
					m_UserManager.AddUser(nMid, pUser);
				}
			}
		}
		else
		{
			g_pErrorLog->logMsg("ProcUpdateMoney||MC has no record, uid:[%d]", nMid);
			nRet = -1;
		}
	}
	
	if(pUser != NULL)
	{
		//ȡ��Ӧ����
		if(pUser->UpdateMoney(value) == -1)
		{
			g_pErrorLog->logMsg("ProcUpdateMoney||UpdateMoney error uid:[%d]", nMid);
			nRet = -1; 
		}
		else
		{
			string temp = "";
			GetTime(temp);
			temp += " ";
			string strLog = pUser->GetInfoLog();
			temp += strLog;
			temp += "\n";
			
			if (m_pLogServer != NULL)
			{
				if(pUser->m_nTurnMoney)
				{
					//֪ͨ����bakServer
					SendUserDataNewToBakServer(nMid, pUser->m_nTurnMoney, pUser->m_nMoney, actId, strBid);
				}
			}
			
			WriteUpdateLog(temp.c_str());
			
          	totalMoney = pUser->m_nMoney;//������ɺ��Ǯ��

			SetMemcacheRecord(pUser);
			/*char szMid[20]={0};
			snprintf(szMid, sizeof(szMid), "%d\n", nMid);
			WriteUpdateMid(szMid);*/
			SendUpdateMid(nMid);
		}
	}
	else
	{
		nRet = -1;
	}
	//��ͻ��˻�Ӧ������Ϣ

	if(nRet == -1)
	{
		NETOutputPacket OutPkg;
		BuildPackage(&OutPkg, SERVER_COMMAND_UPDATE_RECORD, "%d", nRet);
		SendPackageToClient(&OutPkg, pSocket);
	}
	else
	{
		NETOutputPacket OutPkg;
		BuildPackage(&OutPkg, SERVER_COMMAND_UPDATE_RECORD, "%d,%d,%ld", nRet, MONEY, totalMoney);
		SendPackageToClient(&OutPkg, pSocket);
	}
	return 0;
}

int CGameServer::ProcDeleteRecord( NETInputPacket* pPacket, SocketHandler *pSocket)
{
	int nRet = 0;
	int nMid = pPacket->ReadInt();
	CGameUser* pUser = m_UserManager.GetUser(nMid);
	if (pUser == NULL)
	{
		g_pErrorLog->logMsg("ProcDeleteRecord||uid:[%d]", nMid);
		nRet = -1;
	}
	else 
	{
		DelMemcacheRecord(pUser);
		m_UserManager.DelUser(nMid);
		delete pUser; 
		pUser = NULL;
	}
	NETOutputPacket OutPkg;
	BuildPackage(&OutPkg, SERVER_COMMAND_DELETE_RECORD, "%d", nRet);
	SendPackageToClient(&OutPkg, pSocket);
	return 0;
}

int CGameServer::ProcGetRecord( NETInputPacket* pPacket, SocketHandler *pSocket)
{
	int nMid = pPacket->ReadInt();
	int nRet = 0;
	CGameUser* pUser = m_UserManager.GetUser(nMid);
	if(pUser == NULL)
	{
		char key[100]={0};
		snprintf(key, sizeof(key), "%d", nMid);
		string value="";
		m_MemcacheClient.GetRecord(key, value);
		if(strcmp(value.c_str(), "") != 0)
		{
			vector<string> vec;
			split_str(value.c_str(), ",", vec);    //����ַ���
			if(vec.size() != USER_ATTR_COUNT)
			{
				g_pErrorLog->logMsg("ProcUpdateRecord||Error mc value, uid:[%d]", nMid);
				nRet = -1;
			}
			else
			{
				long nMoney     = 	atol(vec[0].c_str());
				int nWinTimes  = 	atoi(vec[1].c_str());
				int nLostTimes = 	atoi(vec[2].c_str());
				g_pDebugLog->logMsg("ProcGetRecord||MC money:[%ld], winTimes:[%d], lostTimes:[%d]", nMoney, nWinTimes, nLostTimes);
				unsigned int nCreateTime = (unsigned)time(NULL);
				pUser = new CGameUser(nMid, nMoney, nWinTimes, nLostTimes, nCreateTime);
				if(pUser == NULL)
				{
					g_pErrorLog->logMsg("ProcGetRecord||New CGameUser failed, uid:[%d]", nMid);
					nRet = -1;
					NETOutputPacket OutPkg;
					BuildPackage(&OutPkg, SERVER_COMMAND_GET_RECORD, "%d", nRet);
					SendPackageToClient(&OutPkg, pSocket);
				}
				else
				{
					m_UserManager.AddUser(nMid, pUser);
					SendUserDataToClient(SERVER_COMMAND_GET_RECORD, pUser, pSocket);
				}
			}
		}
		else
		{
			g_pErrorLog->logMsg("ProcGetRecord||Can not find user uid:[%d]", nMid);
			nRet = -1;
			NETOutputPacket OutPkg;
			BuildPackage(&OutPkg, SERVER_COMMAND_GET_RECORD, "%d", nRet);
			SendPackageToClient(&OutPkg, pSocket);
		}
	}
	else 
	{
		SendUserDataToClient(SERVER_COMMAND_GET_RECORD, pUser, pSocket);
	}
	return 0;
}


int CGameServer::ProcGetRecordNew( NETInputPacket* pPacket, SocketHandler *pSocket)
{
	g_pErrorLog->logMsg("-------------- CGameServer::ProcGetRecordNew Begin--------------- ");
	
	int nMid = pPacket->ReadInt();
	g_pErrorLog->logMsg("uid:[%d]", nMid);
	int nRet = 0;
	CGameUser* pUser = m_UserManager.GetUser(nMid);
	if(pUser == NULL)
	{
		char key[100]={0};
		snprintf(key, sizeof(key), "%d", nMid);
		string value="";
		m_MemcacheClient.GetRecord(key, value);
		if(strcmp(value.c_str(), "") != 0)
		{
			vector<string> vec;
			split_str(value.c_str(), ",", vec);    //����ַ���
			if(vec.size() != USER_ATTR_COUNT)
			{
				g_pErrorLog->logMsg("ProcUpdateRecord||Error mc value, uid:[%d]", nMid);
				nRet = -1;
			}
			else
			{
				long nMoney    = atol(vec[0].c_str());
				int nWinTimes  = atoi(vec[1].c_str());
				int nLostTimes = atoi(vec[2].c_str());
				g_pDebugLog->logMsg("ProcGetRecord||MC money:[%ld], winTimes:[%d], lostTimes:[%d]", nMoney, nWinTimes, nLostTimes);
				unsigned int nCreateTime = (unsigned)time(NULL);
				pUser = new CGameUser(nMid, nMoney, nWinTimes, nLostTimes, nCreateTime);
				if(pUser == NULL)
				{
					g_pErrorLog->logMsg("ProcGetRecord||New CGameUser failed, uid:[%d]", nMid);
					nRet = -1;
					NETOutputPacket OutPkg;
					BuildPackage(&OutPkg, SERVER_COMMAND_GET_RECORD, "%d", nRet);
					SendPackageToClient(&OutPkg, pSocket);
				}
				else
				{
					m_UserManager.AddUser(nMid, pUser);
					SendUserDataToClient(SERVER_COMMAND_GET_RECORD, pUser, pSocket);
				}
			}
		}
		else
		{
			g_pErrorLog->logMsg("ProcGetRecord||Can not find user uid:[%d]", nMid);
			nRet = -1;
			NETOutputPacket OutPkg;
			BuildPackage(&OutPkg, SERVER_COMMAND_GET_RECORD, "%d", nRet);
			SendPackageToClient(&OutPkg, pSocket);
		}
	}
	else 
	{
		g_pErrorLog->logMsg("-------------------- CGameServer::ProcGetRecordNew End 1 ------------");
		g_pErrorLog->logMsg("user info : %s",pUser->GetInfoLog().c_str());
		NETOutputPacket OutPkg;
		BuildPackage(&OutPkg, SERVER_COMMAND_GET_RECORD_NEW, "%d,%s", 0, pUser->GetInfoLog().c_str());
		return SendPackageToClient(&OutPkg, pSocket);
	}
	g_pErrorLog->logMsg("--------------------- CGameServer::ProcGetRecordNew End ------------");
	return 0;
}

int CGameServer::SendUserDataNewToBakServer(int uid, int turnMoney, int money, int actId, string strBid)
{
	NETOutputPacket outPkg;
	BuildPackage(&outPkg, FORWARD_COMMAND_SET_RECORD_NEW, "%d,%d,%d,%d,%s", uid, turnMoney, money, actId, strBid.c_str());
	if(m_pLogServer != NULL)
	{
		return m_pLogServer->TransferPacket(&outPkg);
	}
	return 0;
}

//�����û�����
int CGameServer::SendUserDataToClient(short nCmdType, CGameUser* pUser, SocketHandler *pSocket)
{
	NETOutputPacket OutPkg;
	BuildPackage(&OutPkg, nCmdType, "%d,%s", 0, pUser->GetInfo().c_str());
	return SendPackageToClient(&OutPkg, pSocket);
}


void CGameServer::ResetLogFileName(const char* pszBaseFileName, char* pszFilePath)
{
	char pszPath[256] = {0};
	getcwd(pszPath, 256);
	time_t tnow;
	struct tm tm;
	tnow = time(NULL);
	localtime_r(&tnow, &tm);
	snprintf(pszFilePath, 256, "%s/%s_%d_%04d%02d%02d%02d%02d%02d",  pszPath, pszBaseFileName, m_nServerId, tm.tm_year+1900, tm.tm_mon+1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
}

int CGameServer::SetMemcacheRecord(CGameUser* pUser)
{
	if(pUser == NULL)
	{
		return -1;
	}
	char szKey[256] = {0};
	char szValue[2048] = {0};
	snprintf(szKey, sizeof(szKey), "%d", pUser->m_nUserId);
	snprintf(szValue, sizeof(szValue), "%s", pUser->GetInfo().c_str());

	if(!m_MemcacheClient.SetRecord(szKey, szValue, strlen(szValue), 15*24*3600))
	{
		g_pErrorLog->logMsg("m_MemcacheClient.AddRecord failed, key:[%s], value:[%s]",  szKey, szValue);
		return -1;
	}
	return 0;
}

int CGameServer::DelMemcacheRecord(CGameUser* pUser)
{
	if(pUser == NULL)
	{
		return -1;
	}
	char szKey[256] = {0};
	char szValue[2048] = {0};
	snprintf(szKey, sizeof(szKey), "%d", pUser->m_nUserId);
	snprintf(szValue, sizeof(szValue), "%s", pUser->GetInfo().c_str());

	if(!m_MemcacheClient.DeleteRecord(szKey))
	{
		g_pErrorLog->logMsg("m_MemcacheClient.DeleteRecord failed, key:[%s], value:[%s]",  szKey, szValue);
		return -1;
	}
	return 0;
}


int CGameServer::WriteUpdateLog(const char* pszLog)
{
	if (m_UpdateLogFd == ACE_INVALID_HANDLE)
	{
		memset(m_szUpdateLogFile, 0, sizeof(m_szUpdateLogFile));
		ResetLogFileName(UPDATE_DATA_FILE, m_szUpdateLogFile);
		m_UpdateLogFd = ACE_OS::open(m_szUpdateLogFile, O_RDWR|O_CREAT);
	}
	ACE_OS::write(m_UpdateLogFd, pszLog, strlen(pszLog));
	//ͨ���ļ���С���ļ�
	int len = ACE_OS::filesize(m_UpdateLogFd);
	if (len >= 1024*1024*100)
	{
		if (m_UpdateLogFd != ACE_INVALID_HANDLE)
		{
			ACE_OS::close(m_UpdateLogFd);
			m_UpdateLogFd = ACE_INVALID_HANDLE;
		}
		memset(m_szUpdateLogFile, 0, sizeof(m_szUpdateLogFile));
		ResetLogFileName(UPDATE_DATA_FILE, m_szUpdateLogFile);
		m_UpdateLogFd = ACE_OS::open(m_szUpdateLogFile, O_RDWR|O_CREAT);
	}
	return 0;
}


int CGameServer::WriteUpdateMid(const char* pszLog)
{
	if (m_UpdateMidFd == ACE_INVALID_HANDLE)
	{
		memset(m_szUpdateMidFile, 0, sizeof(m_szUpdateMidFile));
		ResetLogFileName(UPDATE_MID_FILE, m_szUpdateMidFile);
		m_UpdateMidFd = ACE_OS::open(m_szUpdateMidFile, O_RDWR|O_CREAT);
	}
	ACE_OS::write(m_UpdateMidFd, pszLog, strlen(pszLog));
	return 0;
}

int CGameServer::ProcessOnTimerOut(int timerId)
{
	switch(timerId)
	{
	case UPDATE_MID_FILE_TIMER:
		ProcessUpdateMidFile();
		break;
	default:
		break;
	}
	return 0;
}

int CGameServer::ProcessUpdateMidFile()
{
	m_UpdateMidFileTimer.StopTimer();
	m_UpdateMidFileTimer.StartTimer(m_nTimeInteval);
	if (m_UpdateMidFd != ACE_INVALID_HANDLE)
	{
		ACE_OS::close(m_UpdateMidFd);
		m_UpdateMidFd = ACE_INVALID_HANDLE;
		char szCmd[1000]={0};
		snprintf(szCmd, sizeof(szCmd), "chmod 777 %s", m_szUpdateMidFile);
		system(szCmd);
		memset(szCmd, 0, sizeof(szCmd));
		snprintf(szCmd, sizeof(szCmd), "mv %s %s", m_szUpdateMidFile, m_strFilePath.c_str());
		system(szCmd);
	}
	memset(m_szUpdateMidFile, 0, sizeof(m_szUpdateMidFile));
	ResetLogFileName(UPDATE_MID_FILE, m_szUpdateMidFile);
	m_UpdateMidFd = ACE_OS::open(m_szUpdateMidFile, O_RDWR|O_CREAT);
	return 0;
}

int CGameServer::SendUpdateMid(int uid)
{
	if(m_pUpdateServer != NULL)
	{
		NETOutputPacket reqPacket;
		reqPacket.Begin(SYS_COMMAND_UPDATE_MID);
		reqPacket.WriteInt(uid);
		reqPacket.End();
		m_pUpdateServer->TransferPacket(&reqPacket);
	}
	return 0;
}

