#include "LogServer.h"
#include "ICHAT_HTTP_Config.h"

CLogServer::CLogServer():m_SocketHandler(this)
{
}

CLogServer::~CLogServer()
{
}
////////////////////////////////////////////////////////////////////////////////
// ��ʼ��proxy����
////////////////////////////////////////////////////////////////////////////////
int	CLogServer::InitConnect(ACE_INET_Addr &remote, ACE_Reactor *pReactor)
{
	m_Connector.open(pReactor, ACE_NONBLOCK);
	LogSvrSocketHandler *pHandler = &m_SocketHandler;
	pHandler->Addr(remote);    //��������
	int nRet = m_Connector.connect(pHandler, remote, ACE_Synch_Options::synch);
	return nRet;
}

int CLogServer::InitConnect(const char* szHost, const char* szPort)
{
	ACE_INET_Addr userAddr(szPort, szHost);
	InitConnect(userAddr);
	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////
// proxyserver�ر��Զ�����
////////////////////////////////////////////////////////////////////////////////
void CLogServer::Reconnect(void)  //EWOULDBLOCK
{
	LogSvrSocketHandler *pClient = &m_SocketHandler;
	m_Connector.connect(pClient, pClient->Addr(), ACE_Synch_Options::synch);
}

int CLogServer::TransferPacket(NETOutputPacket *pPacket)
{
	if(!IsConnected())
	{
		ACE_DEBUG((LM_INFO, ACE_TEXT("[%D] CLogServer not connect\r\n")));
		return -1;
	}
	m_SocketHandler.Send(pPacket);
	return 0;
}
