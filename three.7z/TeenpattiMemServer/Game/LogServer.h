#ifndef BOYAA_UserServer_H
#define BOYAA_UserServer_H

#include "LogSvrSocketHandler.h"
#include "ACE_Application.h"
#include "CommandType.h"

typedef ACE_Connector<LogSvrSocketHandler, ACE_SOCK_CONNECTOR> LogConnector;

class CLogServer
{
public:
	CLogServer();
	~CLogServer();

	//��ʼ������
	int	InitConnect(ACE_INET_Addr &, ACE_Reactor * = ACE_Reactor::instance());

	//��ʼ������
	int	InitConnect(const char* szHost, const char* szPort);

	void Reconnect(void);
	//��������״̬
	bool IsConnected(void){return m_SocketHandler.IsConnected();}

	int TransferPacket(NETOutputPacket *pPacket);

public:
	LogConnector	m_Connector;
	LogSvrSocketHandler m_SocketHandler;
};
#endif

