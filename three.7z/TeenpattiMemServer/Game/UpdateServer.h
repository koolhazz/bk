#ifndef BOYAA_UpdateServer_H
#define BOYAA_UpdateServer_H

#include "UpdateSocketHandler.h"
#include "ACE_Application.h"
#include "CommandType.h"

typedef ACE_Connector<UpdateSocketHandler, ACE_SOCK_CONNECTOR> UpdateConnector;

class CUpdateServer
{
public:
	CUpdateServer();
	~CUpdateServer();

	//��ʼ������
	int	InitConnect(ACE_INET_Addr &, ACE_Reactor * = ACE_Reactor::instance());

	//��ʼ������
	int	InitConnect(const char* szHost, const char* szPort);

	void Reconnect(void);
	//��������״̬
	bool IsConnected(void){return m_SocketHandler.IsConnected();}

	int TransferPacket(NETOutputPacket *pPacket);

public:
	UpdateConnector	m_Connector;
	UpdateSocketHandler m_SocketHandler;
};
#endif

