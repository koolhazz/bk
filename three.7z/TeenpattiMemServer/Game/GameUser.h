#ifndef __GAME_USER_H
#define __GAME_USER_H

#include "Global.h"
#include <vector>
using std::vector;

enum EUserAttr
{
    MONEY=1,
    WINTIMES,
    LOSTTIMES
};

struct TUserAttr
{
    int type;
    int	value;
};

class CGameUser
{
public:
	CGameUser();
	CGameUser(int nUserId, long nMoney, int nWinTimes, int nLostTimes, unsigned int nCreateTime);
	~CGameUser(void);
public:
    int CreateInfo(string &userinfo);
    int CreateAllInfo(string &userinfo);
	//�����û�����
	int UpdateInfo(vector<TUserAttr>& attrList);
	int UpdateMoney(int value);
	//��ʽ:money,exp,level,wintimes,losttimes
	string GetInfo(void);
	//��ʽ:uid,money,exp,level,wintimes,losttimes
    string GetInfoLog(void);
public:
	int			 m_nUserId;			 //�û�ID
    long		 m_nMoney;           //�û�Ǯ��
    int			 m_nWintimes;        //�û�Ӯ�ľ���
    int			 m_nLosttimes;       //�û���ľ���
    unsigned int m_nUpdatetime;      //����ʱ��
	int          m_nTurnMoney;       //����ʱ��Ǯ��
};
#endif
