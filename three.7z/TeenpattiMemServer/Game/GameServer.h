#ifndef BOYAA_GAME_SERVER_H
#define BOYAA_GAME_SERVER_H

#include "UserManager.h"
#include "SocketServer.h"
#include "MemCacheClient.h"
#include "ICHAT_HTTP_Config.h"
#include "ICHAT_Timer_Handler.h"
#include "TimerOutEvent.h"
#include "LogServer.h"
#include "LogSvrSocketHandler.h"

#include "UpdateServer.h"

enum 
{
	SERVER_STATUS_UNINIT,		
	SERVER_STATUS_RUNNING,	
};

enum
{
	INDENTITY_CLIENT = 1,
	INDENTITY_BAK_SERVER,	
};

enum
{
	OPERATE_CREATE = 1,
	OPERATE_UPDATE,
	OPERATE_DELETE,
};

class CGameServer : public SocketServer, public TimerOutEvent
{
public:
	CGameServer();
	~CGameServer();
public:
	BOOL InitServer(const char* pMemcacheServer);
	int  ProcessPacket(NETInputPacket* pPacket, SocketHandler *pSocket);	
	int  ProcessClose(SocketHandler* pSocket);
//�����ֵĴ���
private:
	int ProcCreateRecord(NETInputPacket* pPacket, SocketHandler *pSocket);
	int ProcUpdateMoney(NETInputPacket* pPacket, SocketHandler *pSocket);
	int ProcServerUpdateRecord(NETInputPacket* pPacket, SocketHandler *pSocket);
	int ProcDeleteRecord(NETInputPacket* pPacket, SocketHandler *pSocket);
	int ProcGetRecord(NETInputPacket* pPacket, SocketHandler *pSocket);
	int ProcGetRecordNew( NETInputPacket* pPacket, SocketHandler *pSocket);
private:
	void ResetLogFileName(const char* pszBaseFileName, char* pszFilePath);
	int  SetMemcacheRecord(CGameUser* pUser);
	int  DelMemcacheRecord(CGameUser* pUser);
	int SendUserDataNewToBakServer(int uid, int turnMoney, int money, int actId, string strBid);
	int SendUserDataToClient(short nCmdType, CGameUser* pUser, SocketHandler *pSocket);
	int WriteUpdateLog(const char* pszLog);
	int WriteUpdateMid(const char* pszLog);
	int SendUpdateMid(int nMid);
private:
	int ProcSwitchLogRecord(NETInputPacket* pPacket, SocketHandler *pSocket);
	int ProcessSetMidUpdateFileInteval(NETInputPacket* pPacket, SocketHandler *pSocket);
	virtual int ProcessOnTimerOut(int timerId);
	int ProcessUpdateMidFile();
public:
	int m_nServerId;
private:
	int m_nServStatus;		//������״̬
	CUserManager m_UserManager;			//�û��б�
	BOOL m_bLogUpdateRecord;
	CMemcacheClient m_MemcacheClient;
private:
	//��־�ļ�
	ACE_HANDLE m_UpdateLogFd;
	char m_szUpdateLogFile[256];
	ACE_HANDLE m_UpdateMidFd;
	char m_szUpdateMidFile[256];
	string m_strFilePath;
	int m_nTimeInteval;//mid������־�ļ����ļ�ʱ����
	ICHAT_Timer_Handler m_UpdateMidFileTimer;

	CLogServer* m_pLogServer;
	CUpdateServer* m_pUpdateServer;
};
#endif
