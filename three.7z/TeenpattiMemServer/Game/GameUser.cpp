#include "GameUser.h"
#include <time.h>

#ifndef WIN32
#include "clib_log.h"
extern clib_log* g_pDebugLog;
extern clib_log* g_pErrorLog;
#endif

CGameUser::CGameUser()
{
}

CGameUser::CGameUser(int nUserId, long nMoney, int nWinTimes, int nLostTimes, unsigned int nCreateTime):
	m_nUserId(nUserId),
	m_nMoney(nMoney),
	m_nWintimes(nWinTimes),
	m_nLosttimes(nLostTimes),
	m_nUpdatetime(nCreateTime)
{	
	m_nTurnMoney = 0;
}

CGameUser::~CGameUser(void)
{
}

int CGameUser::CreateInfo(string &userinfo)
{
	char szData[256] = {0};
	snprintf(szData, sizeof(szData), "%ld", m_nMoney);
	userinfo += szData;
    userinfo += ",";
    memset(szData, 0, sizeof(szData));

    snprintf(szData, sizeof(szData), "%d", m_nWintimes);
	userinfo += szData;
    userinfo += ",";
    memset(szData, 0, sizeof(szData));

    snprintf(szData, sizeof(szData), "%d", m_nLosttimes);
	userinfo += szData;
	return 0;
}

int CGameUser::CreateAllInfo(string &userinfo)
{
	char szData[256] = {0};
	snprintf(szData, sizeof(szData), "%d", m_nUserId);
	userinfo += szData;
    userinfo += ",";
    memset(szData, 0, sizeof(szData));

    snprintf(szData, sizeof(szData), "%ld", m_nMoney);
	userinfo += szData;
    userinfo += ",";
    memset(szData, 0, sizeof(szData));

    snprintf(szData, sizeof(szData), "%d", m_nWintimes);
	userinfo += szData;
    userinfo += ",";
    memset(szData, 0, sizeof(szData));

    snprintf(szData, sizeof(szData), "%d", m_nLosttimes);
	userinfo += szData;
	return 0;
}

string CGameUser::GetInfo(void)
{
    string userinfo;
    CreateInfo(userinfo);
	return userinfo;
}

string CGameUser::GetInfoLog(void)
{
    string userinfo;
    CreateAllInfo(userinfo);
	return userinfo;
}

int CGameUser::UpdateInfo(vector<TUserAttr> &attrList)
{
	m_nTurnMoney = 0;

    for(int i=0; i<(int)attrList.size(); i++)
	{
		switch(attrList[i].type)
        {
        case MONEY:
			{
				g_pErrorLog->logMsg("m_nMoney old [%d], value[%d]", m_nMoney,attrList[i].value);
				if(m_nMoney + attrList[i].value < 0)
				{
					m_nTurnMoney = -m_nMoney;
					m_nMoney = 0;
				}
				else
				{
					m_nTurnMoney = attrList[i].value;
					m_nMoney += attrList[i].value;
				}
				if ( m_nMoney < 0 )
				{
					m_nMoney = 0;
				} 
				g_pErrorLog->logMsg("m_nMoney new [%d]", m_nMoney);
			}
			break;
        case WINTIMES:
			m_nWintimes = attrList[i].value;
			break;
        case LOSTTIMES:
			m_nLosttimes = attrList[i].value;
			break;
        default:
			ACE_DEBUG((LM_INFO, ACE_TEXT("UpdateInfo||Update user attr error! uid:[%d], type:[%d], value:[%d]"), 
				m_nUserId, attrList[i].type, attrList[i].value));
			break;
        }
        m_nUpdatetime = (unsigned)time(NULL);
	}
	return 0;
}

int CGameUser::UpdateMoney(int value)
{
	if(m_nMoney+value < 0)
	{
		m_nTurnMoney = -m_nMoney;
		m_nMoney = 0;
	}
	else
	{
		m_nTurnMoney = value;
		m_nMoney += value;
	}
    m_nUpdatetime = (unsigned)time(NULL);
	return 0;
}


