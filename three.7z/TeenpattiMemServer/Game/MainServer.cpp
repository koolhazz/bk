#include "MainServer.h"
#include "common.h"
#include "GameServer.h"
CGameServer* g_pGameServer;

#ifndef WIN32
#include "clib_log.h"
clib_log* g_pDebugLog;
clib_log* g_pErrorLog;
void InitLog(char* debugFileName, char* errorFileName)
{
	g_pDebugLog = new clib_log();
    g_pDebugLog->set_file(debugFileName);
    g_pDebugLog->set_level(5);
    g_pDebugLog->set_maxfile(10);
    g_pDebugLog->set_maxsize(10240000);
    g_pDebugLog->set_timeformat(CLIB_LOG_TFORMAT_0);

	g_pErrorLog = new clib_log();
    g_pErrorLog->set_file(errorFileName);
    g_pErrorLog->set_level(5);
    g_pErrorLog->set_maxfile(10);
    g_pErrorLog->set_maxsize(10240000);
    g_pErrorLog->set_timeformat(CLIB_LOG_TFORMAT_0);
}
#endif

MainServer::MainServer(void)
{
	m_pSocketSever = new CGameServer;
	g_pGameServer = (CGameServer*)m_pSocketSever;
}

MainServer::~MainServer(void)
{
	if (m_pSocketSever != NULL)
	{
		delete m_pSocketSever;
	}
}

////////////////////////////////////////////////////////////////////////////////
// init
////////////////////////////////////////////////////////////////////////////////
int MainServer::init(int argc, char *argv[])
{
	if (!ParseArgs(argc, argv))						//���������в���ʧ��
	{
		return -1;
	}
	
	if (ACE_Application::init(argc, argv) == -1)	//��������ace_application��init����
	{
		return -1;
	}
	
	if (!((CGameServer*)m_pSocketSever)->InitServer(m_szMemCacheServer))
	{
		return -1;
	}

	return 0;
}

////////////////////////////////////////////////////////////////////////////////
// fini
////////////////////////////////////////////////////////////////////////////////
int MainServer::fini(void)
{
	return 0;
}

////////////////////////////////////////////////////////////////////////////////
// ���������
////////////////////////////////////////////////////////////////////////////////

bool MainServer::ParseArgs(int argc, char* argv[])
{
	if (argc < 7)
	{
		ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT ("Useage:./TexasDataServer -p port -m memcacheserver -s serverId [-d]\n")), false);
	}

	ACE_ARGV  argvEnv(argv);
	ACE_TCHAR szOptions[] = ACE_TEXT (":p:s:m:d::");
	ACE_Get_Opt cmdOpt(argc, argv, szOptions, 1, 1, ACE_Get_Opt::PERMUTE_ARGS, 1);

	int  nOption;
	while ( ( nOption = cmdOpt () )  !=  EOF )
	{
		switch ( nOption ) 
		{
		case 'd':		//���ػ���������
			{
				daemonize();
				ACE_LOG_MSG->priority_mask(LM_INFO | LM_ERROR, ACE_Log_Msg::PROCESS);	//����debug��־
				pid_t pid = ACE_OS::getpid();
				char szLogFile[256] = {0};
				snprintf(szLogFile, sizeof(szLogFile), "MemDataServer.log.%u", pid);
				open_filelog(szLogFile);
#ifndef WIN32
				char szDebugFile[256] = {0};
				snprintf(szDebugFile, sizeof(szDebugFile), "MemDataServer.debug.%u", pid);
				char szErrorFile[256] = {0};
				snprintf(szErrorFile, sizeof(szErrorFile), "MemDataServer.error.%u", pid);
				InitLog(szDebugFile, szErrorFile);
#endif
				break;
			}
		case 'p':		//�����˿�			
			m_nPort = atoi(cmdOpt.opt_arg());
			if (m_nPort <= 0)
			{
				ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT("[%D] port:[%d]\n"), m_nPort), false);
			}
			break;
		case 'm':		//memcache ip port
			strncpy(m_szMemCacheServer, cmdOpt.opt_arg(), sizeof(m_szMemCacheServer));
			break;
		case 's':
			g_pGameServer->m_nServerId = atoi(cmdOpt.opt_arg());
			break;
		default:
			ACE_ERROR_RETURN((LM_ERROR, "", cmdOpt.opt_opt ()), false);
			break;
		}
	}
	return true;
}