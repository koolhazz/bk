#include "LogSvrSocketHandler.h"
#include "CommandType.h"
#include "LogServer.h"
LogSvrSocketHandler::LogSvrSocketHandler(void)
{
    m_ReconnectTimer.SetTimeEventObj(this, 0);
	m_bConntected = false;
}

LogSvrSocketHandler::LogSvrSocketHandler(CLogServer* pUserSvr)
{
    m_ReconnectTimer.SetTimeEventObj(this, 0);
	m_pLogServer = pUserSvr;
}


LogSvrSocketHandler::~LogSvrSocketHandler(void)
{
}


int LogSvrSocketHandler::Send(NETOutputPacket *pPacket, int delete_buffer, int close_flag)
{
	return ICHAT_TCP_Handler<>::Send(pPacket->packet_buf(), pPacket->packet_size(), delete_buffer, close_flag);
}
////////////////////////////////////////////////////////////////////////////////
// OnParser(char *buf, int nLen)
////////////////////////////////////////////////////////////////////////////////
int LogSvrSocketHandler::OnParser(char *buf, int nLen)
{
	return ParsePacket(buf, nLen);
}
////////////////////////////////////////////////////////////////////////////////
// OnPacketComplete ��Ӧ���
////////////////////////////////////////////////////////////////////////////////
int LogSvrSocketHandler::OnPacketComplete(NETInputPacket *pPacket)
{
	return ProcessPacket(pPacket);
}

int LogSvrSocketHandler::ProcessPacket(NETInputPacket* pPacket)
{
	return 0;
}

////////////////////////////////////////////////////////////////////////////////
// OnClose(void)
////////////////////////////////////////////////////////////////////////////////
int LogSvrSocketHandler::OnClose(void)
{
	//����״̬��0 ����������ʱ����
	if(m_bConntected)	
	{
		m_bConntected = false;
		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]:(%P|%t) LogServer close. Trying to reconnect\r\n")));
	}
	m_ReconnectTimer.StopTimer();
    m_ReconnectTimer.StartTimer(1);
	return 1;  //only close , but not remove Reactor
}

////////////////////////////////////////////////////////////////////////////////
int LogSvrSocketHandler::OnConnected(void)
{
	m_bConntected = true;
	m_ReconnectTimer.StopTimer();
	ACE_DEBUG((LM_DEBUG, ACE_TEXT("[%D]:(%P|%t) LogServer Connect ok\r\n")));
	return 0;
}

int LogSvrSocketHandler::OnTimer(const void*)
{
	if(m_pLogServer == NULL)
	{
		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]:(%P|%t) LogServer\r\n")));
		return -1;
	}
	ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]:(%P|%t) Connecting LogServer\r\n")));
 	m_pLogServer->Reconnect();
	return 0;
}

int LogSvrSocketHandler::ProcessOnTimerOut(int timerId)
{
	(void)timerId;
	if(m_pLogServer == NULL)
	{
		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]:(%P|%t) LogServer\r\n")));
		return -1;
	}
	ACE_DEBUG((LM_DEBUG, ACE_TEXT("[%D]:(%P|%t) Connecting LogServer\r\n")));
 	m_pLogServer->Reconnect();
	return 0;
}

