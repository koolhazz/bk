#include "UpdateServer.h"
#include "ICHAT_HTTP_Config.h"

CUpdateServer::CUpdateServer():m_SocketHandler(this)
{
}

CUpdateServer::~CUpdateServer()
{
}
////////////////////////////////////////////////////////////////////////////////
// ��ʼ��proxy����
////////////////////////////////////////////////////////////////////////////////
int	CUpdateServer::InitConnect(ACE_INET_Addr &remote, ACE_Reactor *pReactor)
{
	m_Connector.open(pReactor, ACE_NONBLOCK);
	UpdateSocketHandler *pHandler = &m_SocketHandler;
	pHandler->Addr(remote);    //��������
	int nRet = m_Connector.connect(pHandler, remote, ACE_Synch_Options::synch);
	return nRet;
}

int CUpdateServer::InitConnect(const char* szHost, const char* szPort)
{
	ACE_INET_Addr userAddr(szPort, szHost);
	InitConnect(userAddr);
	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////
// proxyserver�ر��Զ�����
////////////////////////////////////////////////////////////////////////////////
void CUpdateServer::Reconnect(void)  //EWOULDBLOCK
{
	UpdateSocketHandler *pClient = &m_SocketHandler;
	m_Connector.connect(pClient, pClient->Addr(), ACE_Synch_Options::synch);
}

int CUpdateServer::TransferPacket(NETOutputPacket *pPacket)
{
	if(!IsConnected())
	{
		ACE_DEBUG((LM_INFO, ACE_TEXT("[%D] CUpdateServer not connect\r\n")));
		return -1;
	}
	m_SocketHandler.Send(pPacket);
	return 0;
}
