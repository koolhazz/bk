#ifndef BOYAA_UPDATE_SOCKETHANDLER_H
#define BOYAA_UPDATE_SOCKETHANDLER_H

#include "ICHAT_TCP_Handler.h"
#include "ICHAT_Timer_Handler.h"
#include "ICHAT_PacketBase.h"
#include "wtypedef.h"

class CUpdateServer;

class UpdateSocketHandler:public ICHAT_TCP_Handler<>,
	public ICHAT_PacketParser<NETInputPacket>,
    public TimerOutEvent
{ 
public:
	UpdateSocketHandler(void);
    UpdateSocketHandler(CUpdateServer* pUpdateSvr);
	virtual ~UpdateSocketHandler(void);
public:
	int Send(NETOutputPacket *pPacket, int delete_buffer = 0, int close_flag = 0);
	//�ر�
	int OnClose(void);
	//�������
	int OnConnected(void);
	//��Ӧ
	int OnParser(char *buf, int nLen);
	//OnTimer
	int OnTimer(const void *);
	//�Ƿ�����
	bool IsConnected(void)	{return m_bConntected;}
	//�������ӵ�ַ
	ACE_INET_Addr &Addr(void) {return m_remote;}
	void Addr(ACE_INET_Addr &addr) { m_remote = addr;}

	NETInputPacket *GetPacket(void)
	{
		return &m_Packet;
	}

	int  ProcessOnTimerOut(int timerId);
private:
	NETInputPacket m_Packet;
	
	ICHAT_Timer_Handler m_ReconnectTimer;
	//��ַ
	ACE_INET_Addr m_remote;
	//�ص�proxyManager
	CUpdateServer *m_pUpdateServer;
	//����״̬
	bool m_bConntected;
	//packet
	int OnPacketComplete(NETInputPacket *pPacket);

	int ProcessPacket(NETInputPacket* pPacket);
};
#endif



