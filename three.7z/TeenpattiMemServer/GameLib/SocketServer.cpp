#include "SocketServer.h"

SocketServer::SocketServer(void)
{
	m_dwHandlerID = 0;
}

SocketServer::~SocketServer(void)
{
}

////////////////////////////////////////////////////////////////////////////////
// �̳���ICHAT_TCP_Server, ������HANDLERʱ��
////////////////////////////////////////////////////////////////////////////////
ICHAT_TCP_Handler<> * SocketServer::CreateHandler(void)
{
	SocketHandler *pNewHandler;
	ACE_NEW_RETURN(pNewHandler, SocketHandler(++m_dwHandlerID), 0);
	return pNewHandler;
}
////////////////////////////////////////////////////////////////////////////////
// ��ʱ
////////////////////////////////////////////////////////////////////////////////
int 
SocketServer::ProcessOnTimer(DWORD dwHanlerID)
{
	SocketHandler* pHandler = FindHandler(dwHanlerID);
	if (pHandler == NULL)
	{
		return 0;
	}

	if(pHandler->GetChunkStatus() == SocketHandler::CONNECT)
	{
		return -1;
	}
	return 0;
}
////////////////////////////////////////////////////////////////////////////////
// ���������� ����map
////////////////////////////////////////////////////////////////////////////////
int SocketServer::ProcessConnected(SocketHandler *pHandler)
{
	int nRet = m_HandlerMap.bind(pHandler->GetHandlerID(), pHandler);
	//assert(nRet == 0);
	//if(nRet != 0)
	//	ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]SocketServer::ProcessConnected Error %d\r\n"), pHandler->GetHandlerID()));
	return 0;
}
////////////////////////////////////////////////////////////////////////////////
// ����Handler�ر�
////////////////////////////////////////////////////////////////////////////////
int SocketServer::ProcessClose(SocketHandler* pSocket)
{
	int nRet = m_HandlerMap.unbind(pSocket->GetHandlerID());
	//if(nRet != 0)
	//	ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]SocketServer::ProcessClose Error %d\r\n"), dwHanlerID));
	//assert(nRet == 0);
	return 0;
}
////////////////////////////////////////////////////////////////////////////////
// FindHandler
////////////////////////////////////////////////////////////////////////////////
SocketHandler * SocketServer::FindHandler(DWORD dwHandlerID)
{
	SocketHandler *pHandler;
	if(m_HandlerMap.find(dwHandlerID, pHandler) == -1)
	{
		return NULL;
	}
	return pHandler;
}

DWORD SocketServer::GetHandlerID(void)
{
	return ++m_dwHandlerID;
}

//��������ͻ���
int SocketServer::SendCmdToClient(int nCmdType, DWORD dwHanlerID)
{
	NETOutputPacket outPkg;
	BuildPackage(&outPkg, nCmdType);
	SocketHandler* pHandler = FindHandler(dwHanlerID);
	if (pHandler != NULL)
	{
		return pHandler->Send(&outPkg);
	}
	return -1;
}

//�����ݰ����ͻ���
int SocketServer::SendPackageToClient(NETOutputPacket* pPacket, DWORD dwHanlerID)
{
	SocketHandler* pHandler = FindHandler(dwHanlerID);
	if (pHandler != NULL)
	{
		return pHandler->Send(pPacket);
	}
	return -1;	
}

//�����ݰ����ͻ���
int SocketServer::SendPackageToClient(NETOutputPacket* pPacket, SocketHandler* pSocket)
{
	SocketHandler* pHandler = pSocket;
	if (pHandler != NULL)
	{
		return pHandler->Send(pPacket);
	}
	return -1;	
}
//////////////////////////////////////////////////////////////////////////
//ʵ�ֹ���һ��NETOutputPacket���ݰ�,�����ɱ䳤
//֧�ֵ�������int,DWORD,short,char*,
//��Ӧ����Ϊ %d====int, %u====DWORD, %h=====short, %s=====char*
//pszFmtΪ����Ҫ���͵������ֶεĸ�ʽ��ɵ��ַ���,���Բ����ò���,Ҳ���Դ�.��"%d,%u,%h,%s"
//Ҳ���Լ���һЩע����Ϣ,��:"id:%d ntype:%h key:%u name:%s"
//////////////////////////////////////////////////////////////////////////
void SocketServer::BuildPackage(NETOutputPacket* pOutPack, short nCmdType, const char* pszFmt, ...)
{
	pOutPack->Begin(nCmdType);

	if (pszFmt == NULL)	//����Ϊ�յ�,��ֱ�ӹ���һ��ֻ������ͷ�����ݰ�
	{
		pOutPack->End();
		return;
	}

	va_list ap; 
	va_start (ap, pszFmt); 
	const char* p = NULL;

	for (p= pszFmt; *p; p++) 
	{ 
		if (*p != '%') 
		{
			continue; 
		}

		switch (*++p) 
		{ 
		case 'd':	//int
			{
				int nVal= va_arg(ap, int);
				pOutPack->WriteInt(nVal);
				break;
			}
		case 'h':	//short
			{
				short shVal = va_arg(ap, short);
				pOutPack->WriteShort(shVal);
				break;
			}
		case 'u':	//unsigned long
			{
				unsigned long dwVal = va_arg(ap, unsigned long);
				pOutPack->WriteULong(dwVal);
				break;
			}
		case 's':	//char*
			{
				char* pVal = va_arg(ap, char*);
				pOutPack->WriteString(pVal);
				break;
			}
		}
	}
	pOutPack->End();
}
