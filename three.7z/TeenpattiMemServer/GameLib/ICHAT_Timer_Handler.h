#pragma once
#include "ichatlib.h"
//#include "ICHAT_TCP_Handler.h"
#include "ace/Svc_Handler.h"
#include "TimerOutEvent.h"
class TimerOutEvent;
class ICHAT_Timer_Handler:public ACE_Event_Handler
{
public:
	ICHAT_Timer_Handler(void);
	virtual ~ICHAT_Timer_Handler(void);
public:
	//OnTimer

	int handle_timeout(const ACE_Time_Value &time, const void *p);

	void SetTimeEventObj(TimerOutEvent * obj, int id=0);

	////////////////////////////////////////////////////////////////////////////////
	// // 
	////////////////////////////////////////////////////////////////////////////////
	void StartTimer(long nSecond, long interval=0);
	void StopTimer(void);

private:
	int m_nId;
	TimerOutEvent *m_TimeEvent;
};
