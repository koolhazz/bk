#pragma once
#include "ichatlib.h"
#include "ICHAT_TCP_Server.h"
#include "SocketHandler.h"
#include "ICHAT_HashMap.h"

class SocketServer:public ICHAT_TCP_Server
{
public:
	SocketServer(void);
	virtual ~SocketServer(void);

public:
	//*********************************************/
	// Method:    CreateHandler
	// Returns:   ICHAT_TCP_Handler<> *
	// Parameter: void
	// Description: ����һ��Handle����
	//*********************************************/
	ICHAT_TCP_Handler<> * CreateHandler(void);

	//*********************************************/
	// Method:    ProcessConnected
	// Returns:   int
	// Parameter: SocketHandler *
	// Description: ����������
	//*********************************************/
	virtual int ProcessConnected(SocketHandler *);

	//*********************************************/
	// Method:    ProcessClose
	// Returns:   int
	// Parameter: DWORD dwHanlerID
	// Description: ����Handler�ر�
	//*********************************************/
	virtual int ProcessClose(SocketHandler * pSocket);

	//*********************************************/
	// Method:    ProcessOnTimer
	// Returns:   int
	// Parameter: DWORD dwHanlerID
	// Description: ����OnTimer
	//*********************************************/
	virtual int ProcessOnTimer(DWORD dwHanlerID);

	//*********************************************/
	// Method:    ProcessPacket
	// Returns:   int
	// Parameter: NETInputPacket * pPacket
	// Parameter: DWORD dwHanlerID
	// Description: ������ʱ���¼�
	//*********************************************/
	virtual int ProcessPacket(NETInputPacket *pPacket, SocketHandler * pSocket) = 0;

	//*********************************************/
	// Method:    FindHandler
	// Returns:   SocketHandler *
	// Parameter: DWORD
	// Description: ����Handler
	//*********************************************/
	SocketHandler *FindHandler(DWORD);

	//*********************************************/
	// Method:    GetHandlerID
	// Returns:   unsigned int
	// Parameter: void
	// Description: ȡһ��HandlerID
	//*********************************************/
	DWORD GetHandlerID(void);
	
	//*********************************************/
	// Method:    SendCmdToClient
	// Returns:   int
	// Parameter: int nCmdType
	// Parameter: DWORD dwHanlerID
	// Description: ��������ͻ���
	//*********************************************/
	int SendCmdToClient(int nCmdType, DWORD dwHanlerID);

	//*********************************************/
	// Method:    SendPackageToClient
	// Returns:   int
	// Parameter: NETOutputPacket * pPacket
	// Parameter: DWORD dwHanlerID
	// Description: �����ݰ����ͻ���
	//*********************************************/
	int SendPackageToClient(NETOutputPacket* pPacket, DWORD dwHanlerID);
	int SendPackageToClient(NETOutputPacket* pPacket, SocketHandler* pSocket);
	//*********************************************/
	// Method:    BuildPackage
	// Returns:   void
	// Parameter: NETOutputPacket * pOutPack
	// Parameter: short nCmdType
	// Parameter: const char * pszFmt
	// Parameter: ...
	// Description: ����NETOutputPacket���ݰ�,�����ɱ䳤
	//				֧�ֵ�������int,DWORD,short,char*,
	//				��Ӧ����Ϊ %d====int, %u====DWORD, %h=====short, %s=====char*
	//				pszFmtΪ����Ҫ���͵������ֶεĸ�ʽ��ɵ��ַ���,���Բ����ò���,Ҳ���Դ�.��"%d,%u,%h,%s"
	//				Ҳ���Լ���һЩע����Ϣ,��:"id:%d ntype:%h key:%u name:%s"
	//*********************************************/
	void BuildPackage(NETOutputPacket* pOutPack, short nCmdType, const char* pszFmt = NULL, ...);

public:
	DWORD m_dwHandlerID;							//�����Handler��Ψһ��ʶ

protected:
	ICHAT_Hash_Map<int, SocketHandler*> m_HandlerMap; 	//HandlerMap

};
