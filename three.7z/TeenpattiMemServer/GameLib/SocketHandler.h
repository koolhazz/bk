#pragma once
#include "ichatlib.h"
#include "ICHAT_TCP_Handler.h"

#include "ICHAT_PacketBase.h"
#include "ICHAT_PacketParser.h"
#include "wtypedef.h"

class CGameUser;
//���ݰ��ṹ��Ϣ
struct CMD_Info
{
	BYTE cbCheckCode;							//Ч���ֶ�
};
class SocketHandler:public ICHAT_TCP_Handler<>,
					public ICHAT_PacketParser<NETInputPacket>					
{
public:
	SocketHandler(DWORD);
	virtual ~SocketHandler(void);
public:
	//״̬λ
	enum STATUS{CONNECT=0, REQUEST, CLOSE};
	//����״̬
	int GetChunkStatus(void){return m_nStatus;}
	//���·���ID
	DWORD GetHandlerID(void){return m_dwHandlerID;}
	string GetAddr(void){return m_addrremote;}		//���ص��ʮ���Ƶ�IP��ַ
	DWORD  GetPeerAddr(){return m_dwPeerAddr;}		//����32λ��ַ
public:
	int Send(NETOutputPacket *pPacket, int delete_buffer = 0, int close_flag = 0);
public:
	CGameUser *m_pGameUser;
private:
	// Э�����
	int OnParser(char *buf, int nLen);
	//���ӹر�
	int OnClose(void);
	//���ӽ���
	int OnConnected(void);
	//OnTimer
	int OnTimer(const void *);
	//packet
	int OnPacketComplete(NETInputPacket *);

	int SendPacketVarErr(void);

	void GetRemoteAddr(void);

public:
	int m_nHandleType;		//handle������
	int m_nPort;			//�˿�

protected:
	static BYTE	m_SendByteMap[256];		//�ֽ�ӳ���
	static BYTE	m_RecvByteMap[256];		//�ֽ�ӳ���
	WORD EncryptBuffer(NETOutputPacket *pPacket);
	int  CrevasseBuffer(NETInputPacket *pPacket);
	BYTE MapSendByte(BYTE const cbData);
	BYTE MapRecvByte(BYTE const cbData);
private:
	int m_nStatus;			//Handler״̬
	DWORD m_dwHandlerID;	//socket���ID
	string m_addrremote;	//Զ�˵�ַ
	DWORD m_dwPeerAddr;		//32λ��ַ

};
