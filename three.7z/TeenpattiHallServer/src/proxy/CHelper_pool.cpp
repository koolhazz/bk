#include <memcheck.h>
#include <CHelper_pool.h>

HTTP_SVR_NS_BEGIN

CHelperPool::CHelperPool(void)
{	
}

CHelperPool::~CHelperPool(void)
{
}

HTTP_SVR_NS_END

