#include "MainServer.h"
#include "common.h"
#include "GameServer.h"

CGameServer* g_pGameServer = NULL;

MainServer::MainServer(void)
{
	m_pSocketSever = new CGameServer;
	g_pGameServer = (CGameServer*)m_pSocketSever;
}

MainServer::~MainServer(void)
{
	if (m_pSocketSever != NULL)
	{
		delete m_pSocketSever;
	}
}

////////////////////////////////////////////////////////////////////////////////
// init
////////////////////////////////////////////////////////////////////////////////
int MainServer::init(int argc, char *argv[])
{
	if (!ParseArgs(argc, argv))						//���������в���ʧ��
	{
		return -1;
	}
	

	if (ACE_Application::init(argc, argv) == -1)	//��������ace_application��init����
	{
		return -1;
	}
	
	if (!((CGameServer*)m_pSocketSever)->InitServer())
	{
		return -1;
	}
	return 0;
}

////////////////////////////////////////////////////////////////////////////////
// fini
////////////////////////////////////////////////////////////////////////////////
int MainServer::fini(void)
{
	return 0;
}

////////////////////////////////////////////////////////////////////////////////
// ���������
////////////////////////////////////////////////////////////////////////////////

bool MainServer::ParseArgs(int argc, char* argv[])
{
	if (argc < 5)
	{
		ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT ("Useage:./TexasDataServer -p port -l level [-d]\n")), false);
	}

	ACE_ARGV  argvEnv(argv);
	ACE_TCHAR szOptions[] = ACE_TEXT (":p:l:d::");
	ACE_Get_Opt cmdOpt(argc, argv, szOptions, 1, 1, ACE_Get_Opt::PERMUTE_ARGS, 1);

	int  nOption;
	while ( ( nOption = cmdOpt () )  !=  EOF )
	{
		switch ( nOption ) 
		{
		case 'd':		//���ػ���������
			{
				daemonize();
				ACE_LOG_MSG->priority_mask(LM_INFO | LM_ERROR, ACE_Log_Msg::PROCESS);	//����debug��־
				pid_t pid = ACE_OS::getpid();
				char szLogFile[256] = {0};
				sprintf(szLogFile, "LogServer.log.%u", pid);
				open_filelog(szLogFile);
				break;
			}
		case 'p':		//�����˿�			
			m_nPort = atoi(cmdOpt.opt_arg());
			if (m_nPort <= 0)
			{
				ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT("port = %d\n"), m_nPort), false);
			}
			break;
		case 'l':
			g_pGameServer->m_nLevel = atoi(cmdOpt.opt_arg());
			break;
		default:
			ACE_ERROR_RETURN((LM_ERROR, "", cmdOpt.opt_opt ()), false);
			break;
		}
	}
	return true;
}