killall LogServer
