#include "RedisServer.h"

#define REDIS_CONNECT_TIMER 1

#define REDIS_CONNECT_TIMER_LONG	30

CRedisServer::CRedisServer() : m_strIp(""), m_nPort(0), m_pRedisConn(NULL), m_pRedisReply(NULL)
{
	m_ConnectTimer.SetTimeEventObj(this, REDIS_CONNECT_TIMER);
}

CRedisServer::~CRedisServer()
{

}

int CRedisServer::Connect(string & ip, int port)
{
	m_strIp = ip;
	m_nPort = port;
	m_pRedisConn = redisConnect(ip.c_str(), port);
	if(m_pRedisConn->err)
	{
		ACE_DEBUG((LM_ERROR, ACE_TEXT("Connect Redis Server failed, ip:%s, port:%d\r\n"), ip.c_str(), port));
	}
	else 
	{
		ACE_DEBUG((LM_INFO, ACE_TEXT("(%P|%t) Connect Redis Server success, ip:%s, port:%d\n"), ip.c_str(), port));
	}

	m_ConnectTimer.StartTimer(REDIS_CONNECT_TIMER_LONG);
	
	return 0;
}

int CRedisServer::CheckConnect()
{
	m_ConnectTimer.StopTimer();
	m_ConnectTimer.StartTimer(REDIS_CONNECT_TIMER_LONG);
	m_pRedisReply = reinterpret_cast<redisReply *>(redisCommand(m_pRedisConn, "PING"));
	if(m_pRedisReply == NULL || strcmp(m_pRedisReply->str, "PONG") != 0)
	{
		redisFree(m_pRedisConn);
		ACE_DEBUG((LM_INFO, ACE_TEXT("(%P|%t) Reconnect Redis Server\r\n")));
		m_pRedisConn = redisConnect(m_strIp.c_str(), m_nPort);
		if (m_pRedisConn->err)
		{
			ACE_DEBUG((LM_ERROR, ACE_TEXT("Reconnect redis server failed, ip:%s, port:%d\r\n"), m_strIp.c_str(), m_nPort));
		}
		else
		{	
			ACE_DEBUG((LM_INFO, ACE_TEXT("(%P|%t) Reconnect redis serve success,  ip:%s, port:%d\r\n"), m_strIp.c_str(), m_nPort));
		}
	}

	if(m_pRedisReply != NULL)
	{
		freeReplyObject(m_pRedisReply);
	}
	return 0;
}

int CRedisServer::GetData(int key, string & value) 
{
	int ret = -3;

	char szkey[512] = {0};
	 snprintf(szkey,sizeof(szkey),"LANDLORD_LOGINBID|%d",key);
	
	m_pRedisReply = reinterpret_cast<redisReply*>(redisCommand(m_pRedisConn, "EXISTS %s", szkey));
	if(m_pRedisReply != NULL)
	{
		ret = m_pRedisReply->integer;
		freeReplyObject(m_pRedisReply);
	}
	
	if(ret == 1)
	{
		m_pRedisReply = reinterpret_cast<redisReply*>(redisCommand(m_pRedisConn, "GET %s", szkey));
		if(m_pRedisReply != NULL)
		{
			value = m_pRedisReply->str;
			freeReplyObject(m_pRedisReply);
		}
	}
	return 0;
	
}

int CRedisServer::ProcessOnTimerOut(int timerId)
{
	switch(timerId)
	{
	case REDIS_CONNECT_TIMER:
		return CheckConnect();
	default:
		break;
	}
	return 0;
}
