#include <iostream>
#include <stdio.h>
#include <sys/socket.h>
#include <unistd.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <iterator>
#include <map>
#include <netdb.h>

#include "watchdog.h"

namespace DataCenter {

	Watchdog::Watchdog()
	{
		_host = "127.0.0.1";
		_port = 1066;
		_fd = -1;
	}

	Watchdog::Watchdog(string host, int port)
	{
		_host = host;
		_port = port;
		_fd = -1;
	}

	Watchdog::~Watchdog()
	{
		/* if (_fd < -1) { */
		if (_fd > -1) {
			close(_fd);
			_fd = -1;
		}
	}

	int Watchdog::init(string host, int port)
	{
		_host = host;
		_port = port;
		init();
	}

	int Watchdog::init()
	{
		unsigned long inaddr = 0;
		struct hostent *host;
		
		_fd = socket(AF_INET ,SOCK_DGRAM, 0);
		if(_fd == -1) {
			cout << "Failed to socket because of " << strerror(errno) << endl;
			return -1;
		}
		
		memset(&_server_addr,0, sizeof(_server_addr));
		_server_addr.sin_family = AF_INET;
		_server_addr.sin_port = htons(_port);
		inaddr = inet_addr(_host.c_str());
		if (inaddr == INADDR_NONE) {
			// �̷߳ǰ�ȫ
			host = gethostbyname(_host.c_str());
			if (host == NULL) {
				cout << "Failed to gethostbyname because of " << strerror(errno) << endl;
				close(_fd);
				return -1;
			}
			memcpy((char*)&_server_addr.sin_addr, host->h_addr, host->h_length);
		} 
		else
			_server_addr.sin_addr.s_addr = inaddr;
		
		_server_addr_len = sizeof(_server_addr);
		
		return 0;
	}

	int Watchdog::write(string bpid, string act_name, string game_data)
	{
		int ret;
		string data;
		char buf[30];
		
		if	(verify(bpid, act_name, game_data) != 0) {
			return -1;
		}
		
		snprintf(buf, sizeof(buf), "%u", (unsigned int)time(NULL));
		data.append(bpid);
		data.append("|");
		data.append(buf);
		data.append("|");
		data.append(act_name);
		data.append(" ");
		data.append(game_data);
		
		// cout << data << endl;
		ret = sendto(_fd, data.c_str(), data.length(), 0, (struct sockaddr *)&_server_addr, _server_addr_len);
		if(ret < 0) {
			cout << "Failed to sendto because of " << strerror(errno) << endl;
			return -1;
		}
		
		return 0;
	}

	int Watchdog::verify(string &bpid, string &act_name, string &game_data)
	{
		if (bpid.empty()) {
			return -1;
		}

		if (act_name.empty()) {
			return -1;
		}
		
		if (game_data.empty()) {
			return -1;
		}

		return 0;
	}

}

#if 0

int main(int argc, char **argv)
{
	/*  ����json��װ��Ŀǰֻ֧��hash���͵ģ�����֧��array��
		{"a":"1","b":{"L2v1":"1","L2v2":"2","L2v3":{"L1v1":"1","L1v2":"2","L1v3":"3"}},"c":"3","d":"4"}
		OR
		{
			"a": "1",
			"b": {
				"L2v1": "1",
				"L2v2": "2",
				"L2v3": {
					"L1v1": "1",
					"L1v2": "2",
					"L1v3": "3"
				}
			},
			"c": "3",
			"d": "4"
		}
	*/
	DataCenter::Json json1;
	json1.append_string("L1v1", "1");
	json1.append_integer("L1v2", 2);
	json1.append_long("L1v3", 3L);
	
	DataCenter::Json json2;
	json2.append_string("L2v1", "1");
	json2.append_integer("L2v2", 2);
	json2.append_long("L2v3", 3L);
	json2.append_json("L2v3", json1.getJson());
	
	DataCenter::Json *json = new DataCenter::Json();
	json->append_string("a", "1");
	json->append_json("b", json2.getJson());
	json->append_long("c", 3);
	json->append_string("a", "1");
	json->append_long("d", 4L);
	cout << json->getJson() << endl;
	
	DataCenter::Watchdog wd;
	wd.init("127.0.0.1", 7217);
	/*
		111|1331708951|222 {"a":"1","b":{"L2v1":"1","L2v2":"2","L2v3":{"L1v1":"1","L1v2":"2","L1v3":"3"}},"c":"3","d":"4"}
	*/
	wd.write("111", "222", json->getJson());
	
	delete json;
}

#endif
