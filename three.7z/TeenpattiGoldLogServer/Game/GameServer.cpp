#include "GameServer.h"
#include "CommandType.h"

#include "RedisServer.h"

#ifndef WIN32
#include <time.h>
#include <sys/time.h>
#include <stdint.h>
#include <string>
using std::string;

#define  SYS_CTRL_LOCAL_LOG_ON_OFF  "abcd"

DWORD GetTickCount()
{
	timeval timesnow;
	struct timezone tmpzone;
	gettimeofday(&timesnow,&tmpzone);
	return ((DWORD)(timesnow.tv_sec*1000) + (DWORD)(timesnow.tv_usec/1000));
}
#endif

#define UPDATE_DATA_FILE		"poker.log"

//static char * bpid = "E110E8317A931F952D2579647FDC9B82";

static inline long long GetTimeNowInMsec(void) {
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_sec * 1000 + tv.tv_usec/1000;
}


CGameServer::CGameServer()
{
	m_nServStatus = SERVER_STATUS_RUN;
	memset(m_szPokerLogFile, 0, sizeof(m_szPokerLogFile));
	m_PokerLogFd = ACE_INVALID_HANDLE;
	m_nPokerUpdateTime = 0;
	m_nLevel = -1;
	m_strPath = "";
	memset(m_nSeq, 0, sizeof(m_nSeq));

	m_localLogSwitch = 0; 		//switch off by default
}

CGameServer::~CGameServer()
{
	ACE_OS::close(m_PokerLogFd);
}

int CGameServer::ProcessClose(SocketHandler* pSocket)
{
	return SocketServer::ProcessClose(pSocket);
}

BOOL CGameServer::InitServer()
{
	ICHAT_HTTP_Config ConfigReader;
	int nRet = ConfigReader.Open("config.ini");
	if(nRet == -1)
	{
		return FALSE;
	}
	ACE_Configuration_Section_Key key;
	ConfigReader.OpenSection("LOGSERVER", key);
	char szPath[256]={0};
	ConfigReader.get_section_string(key, "PATH", szPath, sizeof(szPath));
	m_strPath = szPath;
	m_nPokerUpdateTime = (int)time(NULL);

	ConfigReader.OpenSection("BIDMEMCACHE", key);
	char szMemcacheServer[256] = {0};
	ConfigReader.get_section_string(key, "MEM", szMemcacheServer, sizeof(szMemcacheServer));
	if(!m_MemcacheClient.Init(szMemcacheServer))
	{
		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D] memcacheClient init failed\r\n")));
		return FALSE;
	}
	else
	{
		ACE_DEBUG((LM_INFO, ACE_TEXT("[%D] memcacheClient init OK\r\n")));
	}	


	ConfigReader.OpenSection("BPIDLIST", key);
	char szCountBuf[256] = {0};
	ConfigReader.get_section_string(key, "BPIDCOUNT", szCountBuf, sizeof(szCountBuf));
	int bpidCount = atoi(szCountBuf);

	for(int i=1; i<=bpidCount; ++i)
	{
		char szBid[256] = {0};
		char szBpid[256] = {0};
		char szBidRet[256] = {0};
		char szBpidRet[256] = {0};

		snprintf(szBid, sizeof(szBid), "BID%d", i);
		snprintf(szBpid, sizeof(szBpid), "BPID%d", i);

		ConfigReader.get_section_string(key, szBid, szBidRet, sizeof(szBidRet));
		ConfigReader.get_section_string(key, szBpid, szBpidRet, sizeof(szBpidRet));

		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D] szBidRet[%s],szBpidRet[%s]\r\n"),szBidRet,szBpidRet));
		m_BpidList[szBidRet] = szBpidRet;
		ACE_DEBUG((LM_INFO, ACE_TEXT("(%P|%t) bid & bpid map conf, bid:[%s] bpid[%s]\r\n"), szBidRet, szBpidRet));
	}

	if(ReadBpidConfigure(&ConfigReader) == FALSE)
	{
		return FALSE;
	}

	ConfigReader.OpenSection("DATACENTER_UDP", key);
	char szHost[256] = {0};
	char szPort[256] = {0};
	ConfigReader.get_section_string(key, "HOST", szHost, sizeof(szHost));
	ConfigReader.get_section_string(key, "PORT", szPort, sizeof(szPort));

	int udp_port = atoi(szPort);
	
	int ret = wd.init(szHost, udp_port);//��ʼ����־����

	ACE_DEBUG((LM_INFO, ACE_TEXT("(%P|%t) path:[%s]\r\n"), m_strPath.c_str()));
	ACE_DEBUG((LM_INFO, ACE_TEXT("(%P|%t) InitServer OK\r\n")));

	//test
	return TRUE;
}

//��������,���еĿͻ��˷�����������ͳһ����
int CGameServer::ProcessPacket(NETInputPacket *pPacket, SocketHandler *pSocket)
{
	short nCmdType = pPacket->GetCmdType();
	//ACE_DEBUG((LM_INFO, "[%D]Receive Client packet nCmdType = 0x%x\n", nCmdType));
	switch (nCmdType)
	{
	case CLIENT_COMMAND_WRITE_GOLDENLOG:
		return ProcReportGoldenLog(pPacket, pSocket);
	case CLIENT_COMMAND_WRITE_GOLDENLOG_NEW:
		return ProcReportGoldenLogNew(pPacket, pSocket);
	case SYS_CMD_LOCAL_SWITCH_ON_OFF:
		return ProcSysCtrlLocalLogSwitch(pPacket, pSocket);
	case SYS_CMD_LOCAL_READ_CONF:
		return ProcSysCtrlLocalReadConfigure(pPacket, pSocket);
	default:
		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]Unkown Cmd, nCmdType = %d\n"), nCmdType));
		break;
	}
	return 0;
}



int CGameServer::ProcReportGoldenLog(NETInputPacket* pPacket, SocketHandler *pSocket)
{
	ACE_DEBUG((LM_INFO, ACE_TEXT("[%D]%s old protocol, drop data!!!\n"), __FUNCTION__));
	return 0;
}


void CGameServer::WriteLog(string bpid, string game_data)
{
	string data;
	data.append(bpid);
	data.append("|");
	data.append(game_data);
	data.append("\n");

	WriteGoldenLog(data.c_str());		
}

int CGameServer::ProcReportGoldenLogNew( NETInputPacket* pPacket, SocketHandler *pSocket)
{
	int mid = pPacket->ReadInt();
	int changeMoney = pPacket->ReadInt();
	int afterChangeMoney = pPacket->ReadInt();
	int actID = pPacket->ReadInt();
	string mpid = pPacket->ReadString();
	
	char szKey[256] = {0};
	snprintf(szKey, sizeof(szKey), "TEENPATTI_LOGINBID|%d", mid);	

	if(mpid == "")
	{
		m_MemcacheClient.GetRecord(szKey, mpid);
	}
	
	if(mpid == "")
	{
		m_pBpidRedisServer->GetData(mid, mpid);
		if(mpid != "")
		{
			m_MemcacheClient.SetRecord(szKey, mpid.c_str(), mpid.length(), 6*3600); //6��Сʱ����
		}
	}

	if(mpid == "")
	{
		ACE_DEBUG((LM_INFO, ACE_TEXT("[%D]%s bid Redis getdata fail, mid=[%d], use default bpid\n"), __FUNCTION__, mid));
	}

	string bpid = "";
	map<string, string>::iterator it = m_BpidList.find(mpid);
	if(it != m_BpidList.end())
	{
		bpid = it->second;
	}
	else
	{
		ACE_DEBUG((LM_INFO, ACE_TEXT("[%D]%s unkown bid(use default bpid):[%s], mid:[%d], changeMoney:[%d], afterChangeMoney:[%d], actID:[%d] \n"),__FUNCTION__, mpid.c_str(), mid, changeMoney, afterChangeMoney, actID));	
		it = m_BpidList.find("");
		if(it != m_BpidList.end())
		{
			bpid = it->second;
		}
		else
		{
			ACE_DEBUG((LM_INFO, ACE_TEXT("[%D] default bpid not exsit!\n")));	
		}
	}


	struct timeval tv;
	gettimeofday(&tv, NULL);
	char time_buf[128] = {0};
	snprintf(time_buf, sizeof(time_buf), "%llu.%03llu", tv.tv_sec, tv.tv_usec/1000);

	char szSeqBuf[128] = {0};
	struct tm * tt = localtime(&(tv.tv_sec));
	
	snprintf(szSeqBuf, sizeof(szSeqBuf), "%04d%02d%02d%02d%08d", tt->tm_year+1900, tt->tm_mon+1, tt->tm_mday, tt->tm_hour, ++m_nSeq[tt->tm_hour]);
	SetSeq(tt->tm_hour);

	
	char szActID[128] = {0};
	snprintf(szActID, sizeof(szActID), "%d", actID);

	int act_type = changeMoney >= 0 ? 1 : 2;

	DataCenter::Json j;
	j.append_integer("uid",mid);
	j.append_string("seq_no", szSeqBuf);
	j.append_string("lts_at", time_buf);
	j.append_string("act_id", szActID);
	j.append_integer("act_type", act_type);
	j.append_integer("act_num", changeMoney);
	j.append_integer("user_gamecoins_num", afterChangeMoney);
	
	int ret = wd.write(bpid, "pb_gamecoins_stream", j.getJson());

	if(m_localLogSwitch != 0)
	{
		WriteLog(bpid, j.getJson());
	}

	if(0 != ret)
	{
		ACE_DEBUG((LM_INFO,ACE_TEXT("[%d] Landlord:write datacenter pb_gamecoins_stream log failed")));
		return 0;
	}

	return 0;

}

int CGameServer::ProcSysCtrlLocalLogSwitch( NETInputPacket* pPacket, SocketHandler *pSocket)
{
	if(pPacket == NULL)
		return 0;

	(void)pSocket;
	
	string str = pPacket->ReadString();
	if(str != SYS_CTRL_LOCAL_LOG_ON_OFF)
	{
		return 0;
	}

	int flag = pPacket->ReadInt();
	if(flag == -1)
		return 0;
	
	m_localLogSwitch = flag;
	ACE_DEBUG((LM_INFO,ACE_TEXT("[%D] sys ctrl local log switch=[%d] (0->off,  !0->on)\n"), m_localLogSwitch));
	return 0;	
}

int CGameServer::ProcSysCtrlLocalReadConfigure(NETInputPacket* pPacket, SocketHandler *pSocket)
{
	if(pPacket == NULL)
		return 0;

	(void)pSocket;

	string str = pPacket->ReadString();
	if(str != SYS_CTRL_LOCAL_LOG_ON_OFF)
	{
		return 0;
	}
	ACE_DEBUG((LM_INFO,ACE_TEXT("[%D] ReSet Configure.\n")));

	if(ReadBpidConfigure() == FALSE)
	{
		ACE_DEBUG((LM_INFO,ACE_TEXT("[%D] ReSet Configure FAIL!\n")));		
	}
	
	return 0;
}

BOOL CGameServer::ReadBpidConfigure(ICHAT_HTTP_Config * pConfiguer)
{
	ICHAT_HTTP_Config configuer;
	if(pConfiguer == NULL)
	{
		pConfiguer = &configuer;
		int nRet = pConfiguer->Open("config.ini");
		if(nRet == -1)
		{
			return FALSE;
		}		
	}

	ACE_Configuration_Section_Key key;
	 pConfiguer->OpenSection("BPIDLIST", key);
	char szCountBuf[256] = {0};
	 pConfiguer->get_section_string(key, "BPIDCOUNT", szCountBuf, sizeof(szCountBuf));
	int bpidCount = atoi(szCountBuf);

	m_BpidList.clear();

	for(int i=1; i<=bpidCount; ++i)
	{
		char szBid[256] = {0};
		char szBpid[256] = {0};
		char szBidRet[256] = {0};
		char szBpidRet[256] = {0};

		snprintf(szBid, sizeof(szBid), "BID%d", i);
		snprintf(szBpid, sizeof(szBpid), "BPID%d", i);

		 pConfiguer->get_section_string(key, szBid, szBidRet, sizeof(szBidRet));
		 pConfiguer->get_section_string(key, szBpid, szBpidRet, sizeof(szBpidRet));

		m_BpidList[szBidRet] = szBpidRet;
		ACE_DEBUG((LM_INFO, ACE_TEXT("(%P|%t) bid & bpid map conf, bid:[%s] bpid[%s]\r\n"), szBidRet, szBpidRet));
	}

	return TRUE;
}

void CGameServer::ResetLogFileName(const char* pszBaseFileName, char* pszFilePath)
{
	char szPath[256] = {0};
	getcwd(szPath, 256);
	time_t now = time(NULL);
	struct tm tm;
	localtime_r(&now, &tm);
	snprintf(pszFilePath, 256, "%s/%s_%d.%04d%02d%02d%02d%02d%02d",  szPath, pszBaseFileName, m_nLevel, tm.tm_year+1900, tm.tm_mon+1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
}

int CGameServer::WriteGoldenLog(const char* pszLog)
{
	if (m_PokerLogFd == ACE_INVALID_HANDLE)
	{
		memset(m_szPokerLogFile, 0, sizeof(m_szPokerLogFile));
		ResetLogFileName(UPDATE_DATA_FILE, m_szPokerLogFile);
		ACE_DEBUG((LM_INFO, ACE_TEXT("(%P|%t) m_szPokerLogFile:[%s]\r\n"), m_szPokerLogFile));
		m_PokerLogFd = ACE_OS::open(m_szPokerLogFile, O_RDWR|O_CREAT);
	}

	ACE_OS::write(m_PokerLogFd, pszLog, strlen(pszLog));
	int len = ACE_OS::filesize(m_PokerLogFd);
	int now = (int)time(NULL);
	if (len>=1024*1024*10 || now-m_nPokerUpdateTime>=10*60)//10M����10����
	{
		if (m_PokerLogFd != ACE_INVALID_HANDLE)
		{
			ACE_OS::close(m_PokerLogFd);
			m_PokerLogFd = ACE_INVALID_HANDLE;
		}
		char szSysCmd[1000]={0};
		snprintf(szSysCmd, sizeof(szSysCmd), "chmod 777 %s", m_szPokerLogFile);
		system(szSysCmd);
		memset(szSysCmd, 0, sizeof(szSysCmd));
		snprintf(szSysCmd, sizeof(szSysCmd), "mv %s %s", m_szPokerLogFile, m_strPath.c_str());
		system(szSysCmd);
		memset(m_szPokerLogFile, 0, sizeof(m_szPokerLogFile));
		ResetLogFileName(UPDATE_DATA_FILE, m_szPokerLogFile);
		m_PokerLogFd = ACE_OS::open(m_szPokerLogFile, O_RDWR|O_CREAT);
		m_nPokerUpdateTime = now;
	}
	return 0;
}

void CGameServer::SetSeq(int hour)
{
	if(hour < 0 || hour > 24)
		return;

	for(int i=0; i<24; ++i)
	{
		if(i != hour)
			m_nSeq[i] = 0;
	}
}


