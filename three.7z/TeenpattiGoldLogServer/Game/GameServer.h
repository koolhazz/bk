#ifndef BOYAA_GAME_SERVER_H
#define BOYAA_GAME_SERVER_H

#include "SocketServer.h"
#include "json.h"
#include "ICHAT_HTTP_Config.h"

#include "RedisServer.h"
#include "MemCacheClient.h"

#include "watchdog.h"

enum 
{
	SERVER_STATUS_STOP,		
	SERVER_STATUS_RUN	
};

class CGameServer:public SocketServer 
{
public:
	CGameServer();
	~CGameServer();
public:
	BOOL InitServer();
	int  ProcessPacket(NETInputPacket* pPacket, SocketHandler *pSocket);	
	int  ProcessClose(SocketHandler* pSocket);
private:
	int ProcReportGoldenLog( NETInputPacket* pPacket, SocketHandler *pSocket);
	int ProcReportGoldenLogNew( NETInputPacket* pPacket, SocketHandler *pSocket);
private:
	void ResetLogFileName(const char* pszBaseFileName, char* pszFilePath);
	int WriteGoldenLog(const char* pszLog);

	int ProcSysCtrlLocalLogSwitch( NETInputPacket* pPacket, SocketHandler *pSocket);
	void WriteLog(string bpid, string game_data);

	BOOL ReadBpidConfigure(ICHAT_HTTP_Config * pConfiguer = NULL);
	int ProcSysCtrlLocalReadConfigure(NETInputPacket* pPacket, SocketHandler *pSocket);

	void SetSeq(int hour);
private:
	//������״̬
	int m_nServStatus;					
private:
	//��־�ļ�
	ACE_HANDLE m_PokerLogFd;
	char m_szPokerLogFile[100];
	string m_strPath;
	int m_nPokerUpdateTime;

	int m_nSeq[24];

	DataCenter::Watchdog wd;

	CMemcacheClient m_MemcacheClient;
	
	map<string, string> m_BpidList;

	int m_localLogSwitch;
	
public:
	int m_nLevel;
};
#endif
