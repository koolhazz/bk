
Port_Start=5000
i=0
while [[ $i -lt 10 ]]
do
i=`expr $i + 1`
port=`expr $Port_Start + $i`
./GLogServer -p $port -l $i -d
done  
