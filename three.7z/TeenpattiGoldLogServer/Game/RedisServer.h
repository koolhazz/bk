#ifndef _REDIS_SERVER_H_15_30_
#define _REDIS_SERVER_H_15_30_

#include "Hiredis.h"
#include "ICHAT_Timer_Handler.h"
#include "TimerOutEvent.h"

#include <string>
using std::string;

class CRedisServer : public TimerOutEvent
{
public:
	CRedisServer();
	~CRedisServer();
	int Connect(string & ip, int port);
	int CheckConnect();
	int GetData(int key, string & value);

	int ProcessOnTimerOut(int timerId);

private:
	string m_strIp;
	int m_nPort;
	redisContext * m_pRedisConn;
	redisReply * m_pRedisReply;
	ICHAT_Timer_Handler m_ConnectTimer;
};


#endif
