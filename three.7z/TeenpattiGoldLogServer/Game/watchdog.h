#ifndef _WATCHDOG_H_
#define _WATCHDOG_H_

/*
	Any bugs reports to rocenting(#)gmail.com
 */

#include <iostream>			// std::cout
#include <string.h> 		// std::string
#include <map> 				// std::map
#include <netinet/in.h> 	// struct sockaddr_in

using namespace std;

/*
	datacenter namespace
 */
namespace DataCenter {

	class Watchdog {
	public:
		Watchdog();
		Watchdog(string host, int port);
		~Watchdog();
		int init();
		int init(string host, int port);
		int write(string bpid, string act_name, string game_data);
		
	private:
		string				_host;
		int					_port;
		int					_fd;
		struct sockaddr_in	_server_addr;
		int					_server_addr_len;
		
		int verify(string &bpid, string &act_name, string &game_data);
	};

	class JsonValue {
	public:
		JsonValue()
		{
		
		}
		
		~JsonValue()
		{
		
		}
		
		void set(string value)
		{
			_value = value;
			_type = 0;
		}
		
		void set(string value, int type)
		{
			_value = value;
			_type = type;
		}
		
		string value()
		{
			return _value;
		}
		
		int type()
		{
			return _type;
		}
		
	private:	
		string _value;
		int _type;
	};

	class Json {
	public:
		Json()
		{
		
		}
		
		~Json()
		{
		
		}
		
		void append_string(string key, string value)
		{
			JsonValue jv;
			jv.set(value);
			
			_kv[key] = jv;
		}
		
		void append_json(string key, string value)
		{
			JsonValue jv;
			jv.set(value, 1);
			
			_kv[key] = jv;
		}
		
		void append_integer(string key, int value)
		{
			char buf[32];
			snprintf(buf, sizeof(buf), "%d", value);
			
			JsonValue jv;
			jv.set(buf);
			
			_kv[key] = jv;
		}
		
		void append_long(string key, long value)
		{
			char buf[32];
			snprintf(buf, sizeof(buf), "%ld", value);
			
			JsonValue jv;
			jv.set(buf);
			
			_kv[key] = jv;
		}
		
		string getJson()
		{
			return map2string();
		}
		
	private:
		map<string, JsonValue> _kv;

		string map2string()
		{
			int i = 0;
			string str = "{";
			
			for (map<string, JsonValue>::iterator iter = _kv.begin() ; iter != _kv.end(); iter++) {
				JsonValue *jv = (JsonValue *)&(iter->second);
				if (i++ == (_kv.size() - 1)) {
					if (jv->type() == 1)
						str += "\"" + iter-> first + "\"" + ":" + jv->value();
					else
						str += "\"" + iter-> first + "\"" + ":" + "\"" + jv->value() + "\"";
				} else {
					if (jv->type() == 1)
						str += "\"" + iter-> first + "\"" + ":" + jv->value() + ",";
					else
						str += "\"" + iter-> first + "\"" + ":" + "\"" + jv->value() + "\"" + ",";
				}
			}
			
			str += "}";
			
			return str;
		}

	};

}

#endif
