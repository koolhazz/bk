#pragma once

class TimerOutEvent
{
public:
	virtual int ProcessOnTimerOut(int Timerid)=0;
};
