#pragma once
#include "ichatlib.h"
#include "ace/SOCK_Stream.h"
#include "ace/Svc_Handler.h"
#include "LoopBuffer.h"

const int MAX_LOOP_BUFFER_LEN = 64*1024;//byte

class ICHAT_TCP_Server;
template <int _buffer_size = ICHAT_TCP_DEFAULT_BUFFER>
class ICHAT_TCP_Handler:public ACE_Svc_Handler<ACE_SOCK_STREAM, ACE_NULL_SYNCH>
{
public:
	ICHAT_TCP_Handler(void)
	{
		m_pServer = NULL;
		m_pSendLoopBuffer = NULL;
	}
	virtual ~ICHAT_TCP_Handler(void)
	{
		if (m_pSendLoopBuffer)
		{
			delete m_pSendLoopBuffer;
		}
		m_pSendLoopBuffer = NULL;

	}

	// �����ӿ�
public:
	////////////////////////////////////////////////////////////////////////////////
	// // ��������
	////////////////////////////////////////////////////////////////////////////////
	int Send(const char *buf, int nLen, int delete_buffer = 0, int close_flag = 0)
	{
		m_pSendLoopBuffer->Put((char *)buf, nLen);

		int nPeekLen = 0;
		int nHaveSendLen = 0;
		do 
		{
			nPeekLen = m_pSendLoopBuffer->Peek(m_pTmpSendBuffer,sizeof(m_pTmpSendBuffer));
			nHaveSendLen = this->peer().send(m_pTmpSendBuffer, nPeekLen, MSG_NOSIGNAL);

			//Send data block
			if(nHaveSendLen < 0 && ACE_OS::last_error() != EWOULDBLOCK && ACE_OS::last_error() != EINTR)
			{
				m_pSendLoopBuffer->Erase(nPeekLen);
				return -1;
				//ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT("[%D]%p\r\n"), ACE_TEXT("Send Data Failed, Socket Error")), -1);
			}
			m_pSendLoopBuffer->Erase(nHaveSendLen);
		} while (nHaveSendLen>0 && m_pSendLoopBuffer->DataCount()>0);
		return 0;
	}
	////////////////////////////////////////////////////////////////////////////////
	// // �������ݺ�ر�����
	////////////////////////////////////////////////////////////////////////////////
	int Send_and_Close(const char *buf, int nLen, int delete_buffer = 0)
	{
		return this->Send(buf, nLen, delete_buffer, 1);
	}
	////////////////////////////////////////////////////////////////////////////////
	// // ��ʼ��ʱ��
	////////////////////////////////////////////////////////////////////////////////
	void StartTimer(long nSecond)
	{
		this->reactor()->schedule_timer(this, 0, ACE_Time_Value(nSecond));
	}
	////////////////////////////////////////////////////////////////////////////////
	// // ֹͣ��ʱ��
	////////////////////////////////////////////////////////////////////////////////
	void StopTimer(void)
	{
		this->reactor()->cancel_timer(this);
	}

	// ��ȡ������server����ָ��
	ICHAT_TCP_Server * server(void)				{return m_pServer;}
	virtual void server(ICHAT_TCP_Server *p)	{m_pServer = p;}
	DWORD GetHandlerID(void)				{return (int)this->get_handle();}
	// ACE_Svc_Handler ���Ӻ���
public:
	////////////////////////////////////////////////////////////////////////////////
	// // ������ʱ����
	////////////////////////////////////////////////////////////////////////////////
	int open(void * = 0)
	{

		//ACE_DEBUG((LM_INFO, ACE_TEXT("[%D]handler open\r\n")));
		if(this->OnConnected() != 0)
			return -1;
		this->water_marks(ACE_IO_Cntl_Msg::SET_HWM, 4 * 1024 * 1024);
		if(base::open() == -1)
			return -1;
		m_pSendLoopBuffer = new CLoopBuffer(MAX_LOOP_BUFFER_LEN);
		this->peer().enable(ACE_NONBLOCK);
		return 0;
	}
	////////////////////////////////////////////////////////////////////////////////
	// 
	////////////////////////////////////////////////////////////////////////////////
	int handle_close(ACE_HANDLE handle = ACE_INVALID_HANDLE,
		ACE_Reactor_Mask close_mask = ACE_Event_Handler::ALL_EVENTS_MASK)
	{
        
		//ACE_DEBUG((LM_INFO, ACE_TEXT("[%D]handler closed!\r\n")));
		ACE_UNUSED_ARG(handle);
		if(close_mask == ACE_Event_Handler::WRITE_MASK)
			return 0;
		this->msg_queue_->close();
		this->StopTimer();
		this->flush();
		if(this->OnClose() == 1) // only close , but not remove Reactor
			this->peer().close();
		else
			this->destroy();
		return 0;
	}
	////////////////////////////////////////////////////////////////////////////////
	// 
	////////////////////////////////////////////////////////////////////////////////
	int handle_input(ACE_HANDLE fd = ACE_INVALID_HANDLE)
	{
        
		//ICHAT_DEBUG_IO((LM_DEBUG, ACE_TEXT("(%P|%t) input!!!!!!!\r\n")));
		ACE_UNUSED_ARG(fd);

		int nRecv = this->peer_.recv(m_pRecvBuffer, _buffer_size, MSG_NOSIGNAL);
		//ICHAT_DEBUG_IO((LM_DEBUG, ACE_TEXT("(%P|%t) Receive data %d, %X, fd=%d\r\n"), nRecv, this, fd));
		if(nRecv <= 0)
		{
			//ACE_DEBUG((LM_DEBUG, ACE_TEXT("(%P|%t) �ͻ��������ر����� %X\r\n"), this));
			return -1;
		}
		return OnParser(m_pRecvBuffer, nRecv);
	}
	////////////////////////////////////////////////////////////////////////////////
	// 
	////////////////////////////////////////////////////////////////////////////////
	int handle_timeout(const ACE_Time_Value &time, const void *p)
	{
		return OnTimer(p);
	}

private:
	ICHAT_TCP_Server *m_pServer;
	char m_pRecvBuffer[_buffer_size];
	typedef ACE_Svc_Handler<ACE_SOCK_STREAM, ACE_NULL_SYNCH> base;
	CLoopBuffer* m_pSendLoopBuffer;
	char m_pTmpSendBuffer[SEND_BUFFER_SIZE];

protected:
	// ICHAT_TCP_Handler �Զ���Hook ����
	virtual int OnClose(void)			{return -1;}	// ���ӶϿ������ ע��:�������1�򲻻�ɾ������ֻ��ر�����
	virtual int OnConnected(void)		{return 0;}	// ���ӳɹ����������
	virtual int OnTimer(const void *)	{return -1;}// ��ʱ������ʱ����
	virtual int OnParser(char *, int)	{return -1;}// ��������ݰ�ʱ����
};
