#include <stdio.h>
#include "ICHAT_PacketBase.h"
#include "socket.h"
using namespace comm::sockcommu;
#include <vector>
using std::vector;
#include <string>
using std::string;

const int SYS_CMD_LOCAL_SWITCH_ON_OFF = 0x0002;
#define  SYS_CTRL_LOCAL_LOG_ON_OFF   "abcd"

static int split_str(const char* ps_str , char* ps_sp , vector<std::string> &v_ret)
{
    char* ps_temp;
    char* p;
    int i_len = (int)strlen(ps_str);
    std::string st_str;

    ps_temp = new char[i_len+2];
    snprintf(ps_temp , i_len+1 , "%s" , ps_str);
    char *last = NULL;
    p = strtok_r(ps_temp , ps_sp , &last);
    if(NULL == p){
        delete ps_temp;
        return 0;
    }
    st_str = (std::string)p;
    v_ret.push_back(st_str);

    while( NULL != ( p=strtok_r(NULL , ps_sp , &last) ) ){
        st_str = (std::string)p;
        v_ret.push_back(st_str);
    }

    delete ps_temp;
    return 0;
}

int main (int argc, char** argv)
{
	if(argc != 2)
	{
		printf("error param 4\n");
		return -1;
	}
	vector<string> vecAddr;
	split_str(argv[1], ":", vecAddr);
	string ip = vecAddr[0];
	int port = atoi(vecAddr[1].c_str());
//	int flag = atoi(argv[2]);
	
	int fd = CSocket::create();
	if(fd < 0)
	{
		printf("create fd error!\n");
		return -1;
	}
	CSocket::set_timeout(fd, 3000);
	if(CSocket::connect(fd, ip, port) < 0)
	{
		CSocket::close(fd);
		printf("Connect ip:[%s],port:[%d] failed\n", ip.c_str(), port);
		return -1;
	}

	NETOutputPacket reqPakcet;
	reqPakcet.Begin(SYS_CMD_LOCAL_SWITCH_ON_OFF);
	reqPakcet.WriteString(SYS_CTRL_LOCAL_LOG_ON_OFF);
//	reqPakcet.WriteInt(flag);
	reqPakcet.End();

	unsigned sentLen;	
	CSocket::send(fd, (const void*)reqPakcet.packet_buf(), reqPakcet.packet_size(), sentLen);
	if((int)sentLen != reqPakcet.packet_size())	
	{
		CSocket::close(fd);
		printf("Send data failed\n");
		return -1;
	}
	CSocket::close(fd);
	return 0;
}

