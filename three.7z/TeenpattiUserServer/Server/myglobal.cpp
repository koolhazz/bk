#include "myglobal.h"

clib_log * TGlobal::g_pFlowLog;
