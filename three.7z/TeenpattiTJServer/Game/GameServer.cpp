#include "GameServer.h"
#include "CommandType.h"

#define REPORT_TIMER 1
const int DATA_REPORT_TIME = 300;

#define SYS_CMD_READ_CONF_STR "sys_cmd_read_conf_str"

CGameServer::CGameServer()
{
	
}

CGameServer::~CGameServer()
{
}

int CGameServer::ProcessClose(DWORD dwHanlerID)
{
	return SocketServer::ProcessClose(dwHanlerID);
}

BOOL CGameServer::InitServer()
{
	ICHAT_HTTP_Config ConfigReader;
	int nRet = ConfigReader.Open("db.ini");
	if(nRet == -1)
	{
		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]Open db.ini failed\n")));
		return FALSE;
	}

	if(!ReadTerminalAndLevelConf(&ConfigReader))
	{
		return FALSE;
	}
	
	char szTemp[256] = {0};
	ACE_Configuration_Section_Key subkey;
	
	DatabaseParam dbParam;
	ConfigReader.OpenSection("DATABASE", subkey);
	memset(szTemp, 0, sizeof(szTemp));
	ConfigReader.get_section_string(subkey, "HOST", szTemp, sizeof(szTemp));
	dbParam.host = szTemp;
	memset(szTemp, 0, sizeof(szTemp));
	ConfigReader.get_section_string(subkey, "USER", szTemp, sizeof(szTemp));
	dbParam.user = szTemp;
	memset(szTemp, 0, sizeof(szTemp));
	ConfigReader.get_section_string(subkey, "PARSSWORD", szTemp, sizeof(szTemp));
	dbParam.password = szTemp;
	memset(szTemp, 0, sizeof(szTemp));
	ConfigReader.get_section_string(subkey, "DB", szTemp, sizeof(szTemp));
	dbParam.db = szTemp;
	memset(szTemp, 0, sizeof(szTemp));
	ConfigReader.get_section_string(subkey, "PORT", szTemp, sizeof(szTemp));
	dbParam.port = ::atoi(szTemp);
	memset(szTemp, 0, sizeof(szTemp));
	ConfigReader.get_section_string(subkey, "SOCKET", szTemp, sizeof(szTemp));
	dbParam.unix_socket = szTemp;

	if(!m_DbPart.ConnectDB(dbParam))
	{
		return FALSE;
	}
	
	m_ReportTimer.SetTimeEventObj(this, REPORT_TIMER);
	m_ReportTimer.StartTimer(10, DATA_REPORT_TIME);
	ACE_DEBUG((LM_INFO, ACE_TEXT("(%P|%t) InitServer OK...\r\n")));
	return TRUE;
}

BOOL CGameServer::ReadTerminalAndLevelConf(ICHAT_HTTP_Config * p)
{
	ICHAT_HTTP_Config config;
	if(p == NULL)
	{
		int nRet = config.Open("db.ini");
		if(nRet == -1)
		{
			ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]ReadTerminalAndLevelConf reset conf.\r\n")));
			return FALSE;
		}
		p = &config;
		ACE_DEBUG((LM_INFO, ACE_TEXT("[%D]ReadTerminalAndLevelConf Reset conf\n")));
	}

	char szTemp[256] = {0};
	ACE_Configuration_Section_Key subkey;
	
	p->OpenSection("GAME_TERMINAL", subkey);
	int count = 0;
	p->get_section_integer(subkey, "COUNT", count, 0, 10000000);
	m_terminalList.clear();
	ACE_DEBUG((LM_INFO, ACE_TEXT("(%P|%t) ReadTerminalAndLevelConf : GAME_TERMINAL count=%d\r\n"), count));
	for(int i=1; i<=count; ++i)
	{
		memset(szTemp, 0, sizeof(szTemp));
		snprintf(szTemp, sizeof(szTemp), "TERMINAL_%d", i);
		int t = 0;
		p->get_section_integer(subkey, szTemp, t, 0, 100000000);
		m_terminalList.push_back((short)t);
		ACE_DEBUG((LM_INFO, ACE_TEXT("(%P|%t) ReadTerminalAndLevelConf : %s=%d\r\n"), szTemp, t));
	}

	memset(szTemp, 0, sizeof(szTemp));
	p->OpenSection("GAME_LEVEL", subkey);	
	count =0;
	p->get_section_integer(subkey, "COUNT", count, 0, 1000000);
	m_levelList.clear();
	ACE_DEBUG((LM_INFO, ACE_TEXT("(%P|%t) ReadTerminalAndLevelConf : GAME_LEVEL count=%d\r\n"), count));
	for(int i=1; i<=count; ++i)
	{
		memset(szTemp, 0, sizeof(szTemp));
		snprintf(szTemp, sizeof(szTemp), "LEVEL_%d", i);
		int L;
		p->get_section_integer(subkey, szTemp, L, 0, 100000);
		m_levelList.push_back((short)L);
		ACE_DEBUG((LM_INFO, ACE_TEXT("(%P|%t) ReadTerminalAndLevelConf : %s=%d\r\n"), szTemp, L));
	}
	
	return TRUE;
}

//��������,���еĿͻ��˷����������ֶ�ͳһ�����ﴦ��
int CGameServer::ProcessPacket(NETInputPacket *pPacket, SocketHandler *pSocket)
{
	(void)pSocket;
	short nCmdType = pPacket->GetCmdType();
	switch (nCmdType)
	{
	case SYS_SYN_DATA:
		ProcessSysSynData(pPacket, pSocket);
		break;
	case SYS_CMD_READ_CONF:
	{
		string str = pPacket->ReadString();
		if(strcmp(str.c_str(), SYS_CMD_READ_CONF_STR) == 0)
		{
			ReadTerminalAndLevelConf();
		}	
	}
		break;
	default:
		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]Unkown Cmd, nCmdType = %d\n"), nCmdType));
		break;
	}
	return 0;
}

CUserServer* CGameServer::GetUserServer(int id)
{
	CUserServer* pUserServer = NULL;
	map<int, CUserServer*>::iterator iter = m_UserServerList.find(id);
	if(iter != m_UserServerList.end())
	{
		pUserServer = iter->second;
	}
	return pUserServer;
}

int CGameServer::ProcessSysSynData(NETInputPacket* pPacket, SocketHandler *pSocket)
{
	ACE_ERROR((LM_ERROR, "[%D]-------------- CGameServer::ProcessSysSynData begin ------------\r\n"));
	int svid = pPacket->ReadInt();
	ACE_ERROR((LM_ERROR, "[%D]svid[%d]\r\n", svid));
	CUserServer* pUserServer = GetUserServer(svid);
	if(pUserServer == NULL)
	{
		pUserServer = new CUserServer(svid);
		if(pUserServer == NULL)
			return 0;
		m_UserServerList.insert(pair<int, CUserServer*>(svid, pUserServer));
	}
	
	int levelCount = pPacket->ReadInt();
	ACE_ERROR((LM_ERROR, "[%D]levelCount[%d]\r\n", levelCount));
	for(int i=0; i<levelCount; i++)
	{
		short level = pPacket->ReadShort();
		LEVELINFO& info = pUserServer->m_LevelMgr[level];
		info.playCount = pPacket->ReadInt();
		info.lookCount = pPacket->ReadInt();
		//int& count = pUserServer->m_LevelMgr[level];
		//count = pPacket->ReadInt();
		//ACE_ERROR((LM_ERROR, "[%D]level[%d],playCount[%d],lookCount[%d]\r\n", levelCount,info.playCount,info.lookCount));
	}

	int typeCount = pPacket->ReadInt();
	ACE_ERROR((LM_ERROR, "[%D]typeCount[%d]\r\n", typeCount));
	for(int i=0; i<typeCount; i++)
	{
		short type = pPacket->ReadShort();
		DATAINFO& info = pUserServer->m_TerminalTypeMgr[type];
		info.onlineCount = pPacket->ReadInt();
		info.onPlayCount = pPacket->ReadInt();
		info.OnLookOnCount = pPacket->ReadInt();
		//ACE_ERROR((LM_ERROR, "[%D]type[%d]onlineCount[%d],onPlayCount[%d],OnLookOnCount[%d]\r\n", type,info.onlineCount,info.onPlayCount,info.OnLookOnCount));
	}

	map<short, LEVELINFO> totalLevelMgr;
	CalLevelCount(totalLevelMgr);
	NETOutputPacket resPacket;
	resPacket.Begin(SYS_SYN_DATA);
	resPacket.WriteInt((int)totalLevelMgr.size());
	//ACE_ERROR((LM_ERROR, "[%D]totalLevel[%d]\r\n", (int)totalLevelMgr.size()));
	map<short, LEVELINFO>::iterator iter = totalLevelMgr.begin();
	for(; iter!=totalLevelMgr.end(); iter++)
	{
		resPacket.WriteShort(iter->first);
		LEVELINFO& info = totalLevelMgr[iter->first];
		resPacket.WriteInt(info.playCount);
		resPacket.WriteInt(info.lookCount);
		//ACE_ERROR((LM_ERROR, "[%D]level first[%d],playCount[%d],lookCount[%d]\r\n", iter->first, info.playCount,info.lookCount));
	}
	resPacket.End();

	if(pSocket != NULL)
	{
		pSocket->Send(&resPacket);
	}

	ACE_ERROR((LM_ERROR, "[%D]-------------- CGameServer::ProcessSysSynData end ------------\r\n"));
	return 0;
}


void CGameServer::CalLevelCount(map<short, LEVELINFO>& totalLevelMgr)
{
	ACE_ERROR((LM_ERROR, "[%D]-------------- CGameServer::CalLevelCount begin ------------\r\n"));
	map<int, CUserServer*>::iterator iterServer = m_UserServerList.begin();
	for(; iterServer!=m_UserServerList.end(); iterServer++)
	{
		CUserServer* pUserServer = iterServer->second;
		if(pUserServer != NULL)
		{
			map<short, LEVELINFO>::iterator iterLevel = pUserServer->m_LevelMgr.begin();
			for(; iterLevel!=pUserServer->m_LevelMgr.end(); iterLevel++)
			{
				LEVELINFO& info = totalLevelMgr[iterLevel->first];
				info.playCount += (iterLevel->second).playCount;
				info.lookCount += (iterLevel->second).lookCount;
				//int& totalCount = totalLevelMgr[iterLevel->first];
				//totalCount += iterLevel->second;
				//ACE_ERROR((LM_ERROR, "[%D]level [%d],playCount[%d],lookCount[%d]\r\n",iterLevel->first,info.playCount,info.lookCount));
			}
		}
	}
	ACE_ERROR((LM_ERROR, "[%D]-------------- CGameServer::CalLevelCount end ------------\r\n"));
}


int CGameServer::ProcessOnTimerOut(int timerId)
{
	switch(timerId)
	{
	case REPORT_TIMER:
		ReportData();
		break;
	default:
		break;
	}
	return 0;
}

void CGameServer::ReportData()
{
	ACE_ERROR((LM_ERROR, "[%D]-------------- CGameServer::ReportData begin ------------\r\n"));
	int totalOnline = 0;
	int totalOnPlay = 0;
	int totalOnLook = 0;
	map<short, LEVELINFO> totalLevelMgr;
	map<short, DATAINFO> totalTypeMgr;
	map<int, CUserServer*>::iterator iterServer = m_UserServerList.begin();
	for(; iterServer!=m_UserServerList.end(); iterServer++)
	{
		CUserServer* pUserServer = iterServer->second;
		if(pUserServer != NULL)
		{
			map<short, LEVELINFO>::iterator iterLevel = pUserServer->m_LevelMgr.begin();
			for(; iterLevel!=pUserServer->m_LevelMgr.end(); iterLevel++)
			{
				//int& totalCount = totalLevelMgr[iterLevel->first];
				//totalCount += iterLevel->second;
				LEVELINFO& info = totalLevelMgr[iterLevel->first];
				info.playCount += (iterLevel->second).playCount;
				info.lookCount += (iterLevel->second).lookCount;
				//ACE_ERROR((LM_ERROR, "[%D]level [%d],playCount[%d],lookCount[%d]\r\n",iterLevel->first,info.playCount,info.lookCount));
			}
			
			map<short, DATAINFO>::iterator iterType = pUserServer->m_TerminalTypeMgr.begin();
			for(; iterType!=pUserServer->m_TerminalTypeMgr.end(); iterType++)
			{
				DATAINFO& info = totalTypeMgr[iterType->first];
				DATAINFO& subInfo = iterType->second;
				info.onlineCount += subInfo.onlineCount;
				info.onPlayCount += subInfo.onPlayCount;
				info.OnLookOnCount += subInfo.OnLookOnCount;
				totalOnline += subInfo.onlineCount;
				totalOnPlay += subInfo.onPlayCount;
				totalOnLook += subInfo.OnLookOnCount;
				//ACE_ERROR((LM_ERROR, "[%D]totalOnline [%d],totalOnPlay[%d],totalOnLook[%d]\r\n",totalOnline,totalOnPlay,totalOnLook));
			}
		}
	}
	//ACE_ERROR((LM_ERROR, "[%D]totalOnlineall [%d],totalOnPlayall[%d],totalOnLook[%d]\r\n",totalOnline,totalOnPlay,totalOnLook));
	m_DbPart.ReportData(totalOnline, totalOnPlay, totalOnLook, totalTypeMgr, totalLevelMgr, m_terminalList, m_levelList);
	//ACE_ERROR((LM_ERROR, "[%D]-------------- CGameServer::ReportData end ------------\r\n"));
}
