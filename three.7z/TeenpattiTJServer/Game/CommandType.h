#ifndef __COMMAND_TYPE_H
#define __COMMAND_TYPE_H

const int SYS_SYN_DATA = 0x050D;//ͬ������

const int SYS_CMD_READ_CONF = 0x0111; 

#endif
