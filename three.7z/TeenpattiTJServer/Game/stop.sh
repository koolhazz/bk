killall TJServer
