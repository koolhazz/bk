ulimit -c unlimited
./TJServer -p 5000 -d
