#pragma once
#include "ichatlib.h"
#include "ACE_Application.h"
#include "SocketServer.h"
#include "ICHAT_HTTP_Config.h"


class MainServer:public ACE_Application
{
public:
	MainServer(void);
	virtual ~MainServer(void);

	//*********************************************/
	// Method:    init
	// Returns:   int
	// Parameter: int argc
	// Parameter: char * argv[]
	// Description: ��ʼ��Server
	//*********************************************/
	int init(int argc, char *argv[]);
	
	//*********************************************/
	// Method:    fini
	// Returns:   int
	// Parameter: void
	// Description: �ͷ�
	//*********************************************/
	int fini(void);

	//*********************************************/
	// Method:    ParseArgs
	// Returns:   bool
	// Parameter: int argc
	// Parameter: char * argv[]
	// Description: ���������в���
	//*********************************************/
	bool ParseArgs(int argc, char* argv[]);
};



