#ifndef BOYAA_GAME_SERVER_H_20090707
#define BOYAA_GAME_SERVER_H_20090707

#include "SocketServer.h"
#include "DbPart.h"
#include "ICHAT_HTTP_Config.h"
#include "UserServer.h"
#include "ICHAT_Timer_Handler.h"
#include "TimerOutEvent.h"

#include <list>
class ICHAT_HTTP_Config;

class CGameServer:public SocketServer , public TimerOutEvent
{
public:
	CGameServer();
	~CGameServer();
public:
	BOOL InitServer();
	int  ProcessPacket(NETInputPacket* pPacket, SocketHandler *pSocket);	
	int  ProcessClose(DWORD dwHanlerID);
private:
	//�����ֵĴ�������
	int ProcessSysSynData(NETInputPacket* pPacket, SocketHandler *pSocket);
	CUserServer* GetUserServer(int id);
	void ReportData();
	void CalLevelCount(map<short, LEVELINFO>& totalLevelMgr);

	BOOL ReadTerminalAndLevelConf(ICHAT_HTTP_Config * = NULL);
public:
	virtual int ProcessOnTimerOut(int timerId);
private:
	CDbPart m_DbPart;
	map<int, CUserServer*> m_UserServerList;
	ICHAT_Timer_Handler m_ReportTimer;

	std::list<short> m_terminalList;
	std::list<short> m_levelList;
};
#endif
