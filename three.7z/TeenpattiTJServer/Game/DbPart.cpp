#include "DbPart.h"
#include "time.h"

CDbPart::CDbPart()
{
	m_pMysqlConn = NULL;
	m_pStore = NULL;
}

CDbPart::~CDbPart()
{
	if (m_pMysqlConn)
	{
		delete m_pMysqlConn;
		m_pMysqlConn = NULL;
	}
}

BOOL CDbPart::ConnectDB(DatabaseParam& dbParam)
{
	try
	{
		m_pMysqlConn = new CMysqlConnect();
		if(!m_pMysqlConn->Connect(dbParam.host, dbParam.user, dbParam.password, dbParam.db, dbParam.port, dbParam.unix_socket, "utf8"))
		{
			ACE_ERROR((LM_ERROR, "[%D]:(%P|%t)ConnectDB! ERROR:%s\r\n", m_pMysqlConn->What().c_str()));
			return FALSE;
		}
		m_pStore = new CMysqlStore();
		m_pStore->SetTransAction(m_pMysqlConn);
		return TRUE;
	}
	catch (...)
	{
		ACE_ERROR((LM_ERROR, "[%D]:(%P|%t)ConnectDB exception:%s\r\n", m_pMysqlConn->What().c_str()));
		return FALSE;
	}

	return FALSE;
}

BOOL CDbPart::CallProcedure(const char * strMysql)
{
	if(strMysql == "")
		return TRUE;
	if (m_pMysqlConn->GetConnect() == NULL)
	{
		m_strError = m_pMysqlConn->What();
		return FALSE;
	}
	ACE_DEBUG((LM_DEBUG, ACE_TEXT("[%D]:(%P|%t) CallProcedure||strMysql:[%s]\r\n"), strMysql));
	if(m_pStore->Exec(strMysql))
	{
		return TRUE;
	}
	m_strError = "ExecErr";
	m_strError += m_pStore->What();
	ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]:(%P|%t) CallProcedure||error:[%s]\r\n"), m_strError.c_str()));
	return FALSE;
}

int CDbPart::ReportData(int totalOnline, int totalOnPlay, int totalOnLook, map<short, DATAINFO>& terminalTypeMgr, map<short, LEVELINFO>& levelMgr, list<short> & terminalList, list<short> & levelList)
{
	unsigned now = (unsigned)time(NULL);
	char szSql[1000] = {0};
#ifndef WIN32
	snprintf(szSql, sizeof(szSql), "insert into bombflower_logonline values ('', 0, -1, %d, %d, %d, %u)", totalOnline, totalOnPlay, totalOnLook, now);
#else
	sprintf_s(szSql, sizeof(szSql), "insert into bombflower_logonline values ('', 0, -1, %d, %d, %d, %u)", totalOnline, totalOnPlay, totalOnLook, now);
#endif
	CallProcedure(szSql);
	ACE_DEBUG((LM_INFO, ACE_TEXT("(%P|%t) totalOnline:[%d], totalOnPlay:[%d], totalOnLook[%d]\r\n"), totalOnline, totalOnPlay, totalOnLook));

	std::list<short>::iterator it = levelList.begin();
	while(it != levelList.end())
	{
		Report(levelMgr, *it, now);
		++ it;
	}
	
	it = terminalList.begin();
	while(it != terminalList.end())
	{
		Report(terminalTypeMgr, *it, now);
		++ it;
	}

	return 0;
}

int CDbPart::Report(map<short, DATAINFO>& terminalTypeMgr, short type, unsigned now)
{
	char szSql[1000] = {0};
	map<short, DATAINFO>::iterator iterType = terminalTypeMgr.find(type);
	if(iterType != terminalTypeMgr.end())
	{
		DATAINFO& info = iterType->second;
#ifndef WIN32
		snprintf(szSql, sizeof(szSql), "insert into bombflower_logonline values ('', -1, %hd, %d, %d, %d, %u)", type, info.onlineCount, info.onPlayCount, info.OnLookOnCount, now);
#else
		sprintf_s(szSql, sizeof(szSql), "insert into bombflower_logonline values ('', -1, %hd, %d, %d, %d, %u)", type, info.onlineCount, info.onPlayCount, info.OnLookOnCount, now);
#endif
		//ACE_DEBUG((LM_INFO, ACE_TEXT("(%P|%t) type:[%d], Online:[%d], OnPlay:[%d]\r\n"), type, info.onlineCount, info.onPlayCount));
	}
	else
	{
#ifndef WIN32
		snprintf(szSql, sizeof(szSql), "insert into bombflower_logonline values ('', -1, %hd, %d, %d, %d, %u)", type, 0, 0, 0, now);
#else
		sprintf_s(szSql, sizeof(szSql), "insert into bombflower_logonline values ('', -1, %hd, %d, %d, %d, %u)", type, 0, 0, 0, now);
#endif		
	}
	
	CallProcedure(szSql);
	return 0;
}

int CDbPart::Report(map<short, LEVELINFO>& levelMgr, short level, unsigned now)
{
	//ACE_ERROR((LM_ERROR, "[%D]-------------- CDbPart::Report begin -------------\r\n"));
	char szSql[1000] = {0};
	map<short, LEVELINFO>::iterator iterLevel = levelMgr.find(level);
	if(iterLevel != levelMgr.end())
	{
		LEVELINFO& info = iterLevel->second;

		//ACE_ERROR((LM_ERROR, "[%D]level [%d],playCount[%d],lookCount[%d]\r\n",iterLevel->first,info.playCount,info.lookCount));
#ifndef WIN32
		snprintf(szSql, sizeof(szSql), "insert into bombflower_logonline values ('', %hd, 1, %d, %d, %d, %u)", level, info.playCount, info.playCount, info.lookCount, now);
#else
		sprintf_s(szSql, sizeof(szSql), "insert into bombflower_logonline values ('', %hd, 1, %d, %d, %d, %u)", level, info.playCount, info.playCount, info.lookCount, now);
#endif	
		//ACE_DEBUG((LM_INFO, ACE_TEXT("(%P|%t) level:[%hd], OnPlay:[%d]\r\n"), level, iterLevel->second));
	}
	else
	{
#ifndef WIN32
		snprintf(szSql, sizeof(szSql), "insert into bombflower_logonline values ('', %hd, 1, %d, %d, %d, %u)", level, 0, 0, 0, now);
#else
		sprintf_s(szSql, sizeof(szSql), "insert into bombflower_logonline values ('', %hd, 1, %d, %d, %d, %u)", level, 0, 0, 0, now);
#endif				
	}

	//ACE_ERROR((LM_ERROR, "[%D]-------------- CDbPart::Report end -------------\r\n"));
	CallProcedure(szSql);
	return 0;
}

