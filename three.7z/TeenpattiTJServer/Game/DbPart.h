#ifndef BOYAA_DBPART_H_20090707
#define BOYAA_DBPART_H_20090707
#include "CommandType.h"
#include <string>
using std::string;

#include <map>
using std::map;

#include "ConnectPool.h"
#include "Global.h"
struct DatabaseParam			//���ݿ����
{
	string host;				//������
	string user;				//�û���
	string password;			//����
	string db;					//���ݿ���
	unsigned int port;			//�˿ڣ�һ��Ϊ0
	string unix_socket;			//�׽��֣�һ��ΪNULL
	unsigned int client_flag;	//һ��Ϊ0
};

#include <list>
using std::list;

class CMysqlStore;
class CConnect;

class CDbPart
{
public:
	CDbPart();
	virtual ~CDbPart();

public:
	BOOL ConnectDB(DatabaseParam& dbParam);
	int ReportData(int totalOnline, int totalOnPlay, int totalOnLook, map<short, DATAINFO>& terminalTypeMgr, map<short, LEVELINFO>& levelMgr, list<short> & terminalList, list<short> & levelList);
private:
	BOOL CallProcedure(const char * strMysql);
	int Report(map<short, DATAINFO>& terminalTypeMgr, short type, unsigned now);
	int Report(map<short, LEVELINFO>& levelMgr, short level, unsigned now);
public:
	string m_strError;
protected:
	CConnect*    m_pMysqlConn;
	CMysqlStore*  m_pStore;

};
#endif
