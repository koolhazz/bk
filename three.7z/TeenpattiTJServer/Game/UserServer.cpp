#include "UserServer.h"

CUserServer::CUserServer(int serverId)
{
	m_nServerId = serverId;
}

CUserServer::~CUserServer()
{
}