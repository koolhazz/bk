#ifndef __USER_SERVER_H
#define __USER_SERVER_H

#include "Global.h"

class CUserServer
{
public:
	CUserServer(int serverId);
	~CUserServer();
public:
	int m_nServerId;
	map<short, LEVELINFO> m_LevelMgr;
	map<short, DATAINFO> m_TerminalTypeMgr;
};
#endif