#include "GameTable.h"
#include "GameUser.h"
#include "GameCmd.h"
#include "GameSeat.h"
#include "GameServer.h"

#include <time.h>

CGameUser::~CGameUser(void)
{	 
}

CGameUser::CGameUser(CGameServer* pServer, CGameTable *pTable, int nUserID, DWORD dwSessionID, string strUserInfo)
{
	m_pGameServer = pServer;
	m_pTable = pTable;
	m_nUserID = nUserID;

	m_dwSessionID = dwSessionID;
	m_strUserInfo = strUserInfo;

	m_pSeat = NULL;
	m_nStatus = USER_STATUS_LOGIN;
	m_pSocket=NULL;
	m_dwPeerIP=0;
}

int CGameUser::ProcessOnTimerOut(int Timerid)
{
	(void)Timerid;
	//��ʱ���¼�ͳһ��CGameServer����
	return 0;
}

void CGameUser::Sit(CGameSeat *pSeat)
{
	m_pSeat = pSeat;
}

void CGameUser::Stand()
{
	m_pSeat = NULL;
	m_nStatus = USER_STATUS_LOGIN;
}

CGameSeat * CGameUser::GetSeat()
{
	return m_pSeat;
}

void CGameUser::Ready()
{
	m_nStatus = USER_STATUS_READY;
}

BYTE CGameUser::GetSeatId()
{
	if (m_pSeat == NULL)
	{
		return INVAILD_SEAT_ID;
	}
	return m_pSeat->m_nSeatID;
}
