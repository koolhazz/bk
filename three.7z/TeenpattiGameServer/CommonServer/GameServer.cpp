#include "GameServer.h"
#include "SocketHandler.h"
#include "common.h"
#include "GameCmd.h"
#include "ICHAT_HTTP_Config.h"
#include "ace/ARGV.h"
#include "ace/Get_Opt.h"
#include "ace/Log_Msg.h"
#include "TeenpattiTable.h"
#include "RedisServer.h"
#include "clib_log.h"
#include "md5.h"
#include "TeenpattiCmd.h"

clib_log* g_pErrorLog;
clib_log* g_pDebugLog;

#include <fstream>
using namespace std;

int GetDelayTime1()
{
	time_t timep;
	struct tm *p;
	int delaytime = 0;
	time(&timep);
	p=localtime(&timep);
	delaytime = 86400- p->tm_hour*3600 - p->tm_min*60 - p->tm_sec;
	return delaytime;
}

int GetNowDay()
{
	time_t now;
	now = time(NULL);
	struct tm tm;
	localtime_r(&now, &tm);
	return tm.tm_mday;
}

int split_str(const char* ps_str , char* ps_sp , vector<std::string> &v_ret)
{    
	char* ps_temp;    
	char* p;    
	int i_len = (int)strlen(ps_str);    
	std::string st_str;    
	ps_temp = new char[i_len+2];    
	snprintf(ps_temp , i_len+1 , "%s" , ps_str);    
	char *last = NULL;    
	p = strtok_r(ps_temp , ps_sp , &last);    
	if(NULL == p)
	{        
		delete ps_temp;        
		return 0;    
	}    
	st_str = (std::string)p;    
	v_ret.push_back(st_str);    
	while( NULL != ( p=strtok_r(NULL , ps_sp , &last) ) )
	{        
		st_str = (std::string)p;        
		v_ret.push_back(st_str);    
	}    
	delete ps_temp;    
	return 0;
}

////////////////////////////////////////////////////////////////////////////////
// open_filelog
////////////////////////////////////////////////////////////////////////////////
void open_filelog(char *filename)
{
	ACE_OSTREAM_TYPE *output = new std::ofstream(filename);
	ACE_LOG_MSG->msg_ostream(output, 1);
	ACE_LOG_MSG->set_flags(ACE_Log_Msg::OSTREAM);
	ACE_LOG_MSG->clr_flags(ACE_Log_Msg::STDERR);
}

void InitLog(char *debugLogName, char *errorLogName)
{
	g_pDebugLog = new clib_log();
    g_pDebugLog->set_file(debugLogName);
    g_pDebugLog->set_level(5);
    g_pDebugLog->set_maxfile(5);
    g_pDebugLog->set_maxsize(10240000);
    g_pDebugLog->set_timeformat(CLIB_LOG_TFORMAT_0);

	g_pErrorLog = new clib_log();
    g_pErrorLog->set_file(errorLogName);
    g_pErrorLog->set_level(5);
    g_pErrorLog->set_maxfile(5);
    g_pErrorLog->set_maxsize(10240000);
    g_pErrorLog->set_timeformat(CLIB_LOG_TFORMAT_0);
}

CGameServer::CGameServer(void)
{
	m_nPort = 0;
	m_nServerID = 0;
	m_nLevel = 0;
	m_pSendPacket = NULL;
	m_pCreator = NULL;
	m_pProcessPacket = NULL;
	m_ServerUserList.clear();
	m_DisconnectUserList.clear();
	memset(chIP, 0, sizeof(chIP));
	m_nMaxTableCount = 0;
}

CGameServer::~CGameServer(void)
{
	//��������ʱ�Ѵ���serverֹͣ,���Բ�����������
	TableIdMap::iterator iter ;
	for (iter=m_TableList.begin(); iter!=m_TableList.end(); ++iter)
	{
		CGameTable* pTable = iter->second;
		if (pTable)
		{
			delete pTable;
			pTable = NULL;
		}
	}
	m_TableList.clear();
}

BOOL CGameServer::ParseArgs(int argc, char* argv[])
{
	if (argc < 9)
	{
		ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT ("Useage:./ServerName -p port -s sid -l level [-d]\n")), FALSE);
	}

	ACE_ARGV  argvEnv(argv);
	ACE_TCHAR szOptions[] = ACE_TEXT (":p:s:h:l:d::"); //:p:s:h:l:d::
	ACE_Get_Opt cmdOpt(argc, argv, szOptions, 1, 1, ACE_Get_Opt::PERMUTE_ARGS, 1);

	int nOption;
	while ((nOption = cmdOpt()) != EOF)
	{
		switch ( nOption ) 
		{
		case 'd':		//���ػ���������
			{
				daemonize();
				ACE_LOG_MSG->priority_mask(LM_INFO | LM_ERROR |LM_DEBUG, ACE_Log_Msg::PROCESS);	//����debug��־
				pid_t pid = ACE_OS::getpid();
				char szLogFile[256] = {0};
				sprintf(szLogFile, "GameServer.log.%u", pid);
				open_filelog(szLogFile);
				char szDebugLog[256] = {0};
				sprintf(szDebugLog, "GameServer.debug.%u", pid);
				char szErrorLog[256] = {0};
				sprintf(szErrorLog, "GameServer.error.%u", pid);
				InitLog(szDebugLog, szErrorLog);
				break;
			}
		case 'p':		//�����˿�			
			m_nPort = atoi(cmdOpt.opt_arg());
			if (m_nPort <= 0)
			{
				ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT("port = %d\n"), m_nPort), FALSE);
			}
			break;
		case 'h':
			strcpy(chIP,cmdOpt.opt_arg());
			if ( chIP == NULL )
			{
				ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT("IP = %s\n"), chIP), FALSE);
			}
			break;
		case 's':		//server Id
			m_nServerID = atoi(cmdOpt.opt_arg());
			if (m_nServerID <= 0)
			{
				ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT("sid=%d\n"), m_nServerID), FALSE);
			}
			break; 
		case 'l':
			m_nLevel = atoi(cmdOpt.opt_arg());
			if (m_nLevel < 0)
			{
				ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT("level=%d\n"), m_nLevel), FALSE);
			}
			break;
		default:
			ACE_ERROR_RETURN((LM_ERROR, "", cmdOpt.opt_opt ()), FALSE);
			break;
		}
	}
	return TRUE;
}

BOOL CGameServer::ReadCommonConf(const char* pszConfPath)
{
	ICHAT_HTTP_Config ConfigReader;
	int nRet = ConfigReader.Open(pszConfPath);
	if(nRet == -1)
	{
		return FALSE;
	}

	ACE_Configuration_Section_Key subkey;
	ConfigReader.OpenSection("ServerConf", subkey);
	ConfigReader.get_section_integer(subkey, "MAX_ROOM_USER_COUNT", m_nTableMaxUserCount, 0, 100);
	ConfigReader.get_section_integer(subkey, "MAX_TABLE_COUNT", m_nMaxTableCount, 0, 1000);

	char szOnlineMC[100]={0};
	ConfigReader.get_section_string(subkey, "MC_ONLINE", szOnlineMC, sizeof(szOnlineMC));
	//ACE_DEBUG((LM_INFO, ACE_TEXT("[%D] szOnlineMC data [%s]\r\n"), szOnlineMC));
	m_pOnlineMCClient = new CMemcacheClient();
	if(m_pOnlineMCClient != NULL)
	{
		if(m_pOnlineMCClient->Init(szOnlineMC))
		{
			ACE_DEBUG((LM_INFO, ACE_TEXT("[%D] Init mc success, szOnlineMC:[%s]\r\n"), szOnlineMC));
		}
	}
	
	char szActiveMC[100]={0};
	ConfigReader.get_section_string(subkey, "MC_ACTIVE", szActiveMC, sizeof(szActiveMC));
	m_pActiveMCClient = new CMemcacheClient();
	if(m_pActiveMCClient != NULL)
	{
		if(m_pActiveMCClient->Init(szActiveMC))
		{
			ACE_DEBUG((LM_INFO, ACE_TEXT("[%D] Init mc success, szActiveMC:[%s]\r\n"), szActiveMC));
		}
	}

	char szTemp[100] = {0};
	memset(szTemp, 0, sizeof(szTemp));
	snprintf(szTemp, sizeof(szTemp), "LOGSERVER%d", m_nLevel);
	ConfigReader.OpenSection(szTemp, subkey);
	char szLogHost[30]={0};
	char szLogPort[10]={0};
	ConfigReader.get_section_string(subkey, "HOST", szLogHost, sizeof(szLogHost));
	ConfigReader.get_section_string(subkey, "PORT", szLogPort, sizeof(szLogPort));
	m_pLogServer = new CLogServer();
	if(m_pLogServer != NULL)
	{	
		m_pLogServer->InitConnect(szLogHost, szLogPort);
	}

	ConfigReader.OpenSection("MemDataServer", subkey);
	char szMemBuf[100]={0};
	ConfigReader.get_section_string(subkey, "ServerCount", szMemBuf, sizeof(szMemBuf));
	int memServerCount = atoi(szMemBuf);
	char szKey[100];
	for(int i=0; i<memServerCount; i++)
	{
		memset(szKey, 0, sizeof(szKey));
		memset(szMemBuf, 0, sizeof(szMemBuf));
		snprintf(szKey, sizeof(szKey), "MemDataServer_%d", i);
		ConfigReader.get_section_string(subkey, szKey, szMemBuf, sizeof(szMemBuf));
		vector<string> v;
		split_str(szMemBuf, ":", v);
		CMemDataServer *pServer = new CMemDataServer();
		if(pServer != NULL)
		{
			pServer->InitConnect(v[1].c_str(), v[0].c_str());
			m_MemDataServerMap[i] = pServer;
		}
	}

	return TRUE;
}

BOOL CGameServer::ReadRobotConf(const char* pszConfPath )
{
	ICHAT_HTTP_Config ConfigReader;
	int nRet = ConfigReader.Open(pszConfPath);
	if(nRet == -1)
	{
		return FALSE;
	}

	ACE_Configuration_Section_Key subkey;
	ConfigReader.OpenSection("ROBOTINFOCONF", subkey);
	int nCount = 0;
	ConfigReader.get_section_integer(subkey, "COUNT", nCount, 0, 9999);
	g_pDebugLog->logMsg(" nCount %d",nCount);
	for( int i = 1; i <= nCount; i++)
	{
		char szKey[128] = {0};
		int  nUserId = 0;
		snprintf(szKey, sizeof(szKey), "USERID%d", i);
		ConfigReader.get_section_integer(subkey, szKey, nUserId, 1, 9999);
		g_pDebugLog->logMsg("key[%s] uid [%d]", szKey,nUserId);
		snprintf(szKey, sizeof(szKey), "ROBORINFO%d", i);
		char szUserInfo[1024] = {0};
		ConfigReader.get_section_string( subkey, szKey, szUserInfo, sizeof(szUserInfo));
		g_pDebugLog->logMsg("key[%s] userinfo [%s]", szKey,szUserInfo);
		string strUserInfo = szUserInfo;
		m_RobotConf.mRobotInfo[nUserId] = strUserInfo;
	}

	g_pErrorLog->logMsg("m_RobotConf begin");

	map<int, string>::iterator iter;

	for ( iter=m_RobotConf.mRobotInfo.begin(); iter!=m_RobotConf.mRobotInfo.end(); ++iter)
	{
		g_pErrorLog->logMsg("m_RobotConf first [%d], m_RobotConf second [%s]",iter->first, (iter->second).c_str());
	}

	g_pErrorLog->logMsg("m_RobotConf end");

	return TRUE;
}

CMemDataServer* CGameServer::GetMemDataServer(int id)
{
	CMemDataServer *pServer = NULL;
	MemDataServerMap::iterator iter = m_MemDataServerMap.find(id);
	if(iter != m_MemDataServerMap.end())
	{
		pServer = iter->second;
	}
	return pServer;
}

BOOL CGameServer::InitServer(CCreator* pCreator, CTeenpattiHallServer* pHallServer, CActivityServer * pActivityServer, int argc, char* argv[])
{	
	if (!ParseArgs(argc, argv))						//���������в���ʧ��
	{
		ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT("ParseArgs failed\n")), FALSE);
	}

	if(!ReadCommonConf())							//��ȡ�����ļ�
	{
		ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT("ReadCommonConf failed\n")), FALSE);
	}
	m_pCreator = pCreator;
	m_pHallServer = pHallServer;
	m_pActivityServer = pActivityServer;

	m_pSendPacket = m_pCreator->CreateSendPacket(m_ServerUserList, this);
	m_pProcessPacket = m_pCreator->CreateProcessPacket(this);
	
	m_nServStatus = GAME_SERVER_RUNNING;

	ACE_DEBUG((LM_INFO, ACE_TEXT("[%D]InitServer OK...\r\n")));
	
	return InitServerEx();
}

int CGameServer::GetTableMaxUserCount()
{
	return m_nTableMaxUserCount;
}

int CGameServer::GetListenPort()
{
	return m_nPort;
}


int CGameServer::ProcessPacket(NETInputPacket *pPacket, SocketHandler *pHandler, DWORD dwSessionID)
{
	return m_pProcessPacket->ProcessPacket(pPacket, pHandler, dwSessionID);
}

//�����û���½����
int CGameServer::ProcUserLogin(int tid, int uid, string strInfo, SocketHandler *pSocket, DWORD dwSessionID, BYTE byOffline)
{

	if( !CheckAndAddTable(tid) )			//���Ӳ�����
	{
		g_pDebugLog->logMsg("------ CGameServer::ProcUserLogin error 1 ---------- uid %d: ", uid);
		m_pSendPacket->SendLoginError(pSocket, ERROR_TABLE_NOT_EXIST);
		return 0;
	}

	CGameTable* pTable = GetTable(tid);
	CGameUser*	pUser = NULL;
	USERDATA data;

	BYTE nRet = CheckUser(uid, pTable, data);

	switch(nRet)
	{
	case SUCCESS_NEWCONNECT:		//���ӳɹ�	
		return ProcCheckUserSuccess(pTable, uid, strInfo, pSocket, dwSessionID, data, byOffline);
	case SUCCESS_RECONNECT:
		return ProcUserReconnect(pUser, uid, pSocket);;
	case SUCCESS_KICK_OTHER_USER:	//�߳��û�
		pUser = GetUserByUserID(uid);
		return ProcUserKick(pUser, pSocket, dwSessionID);
	default://��½����
		g_pDebugLog->logMsg("------ CGameServer::ProcUserLogin end ---------- uid : %d", uid);
		m_pHallServer->UpdateRoomUserCount((CTeenpattiTable*)pTable);
		return m_pSendPacket->SendLoginError(pSocket, nRet);
	}
	return 0;
}

int CGameServer::ProcCheckUserSuccess(CGameTable* pTable, int nUserId, string strInfo, SocketHandler *pSocket, DWORD dwSessionID, USERDATA& data, BYTE byOffline)
{
	g_pDebugLog->logMsg("--------------------- CGameServer::ProcCheckUserSuccess begin ------------------ ");
	CGameUser* pUser = NULL;

	if (( pUser = AddNewUser(pTable, nUserId, strInfo, pSocket, dwSessionID, data, byOffline )) == NULL )
	{
		g_pDebugLog->logMsg("----------- CGameServer::ProcCheckUserSuccess end 1 --------------");
		return 0;
	}

	m_pHallServer->UpdateRoomUserCount((CTeenpattiTable*)pTable); //��½�ɹ�������������ϱ���������

	m_pHallServer->ReportEnterRoom(nUserId, pTable->GetID());

	int nCount = ((CTeenpattiTable*)pTable)->GetSitUserCount();
	g_pDebugLog->logMsg("pTable->GetSitUserCount %d",nCount);
	if (  nCount >= 5 )
	{
		((CTeenpattiUser*)pUser)->m_bLooker = TRUE;
		m_pHallServer->ReportStandRoom(nUserId, pTable->GetID());
	}
	
	//������mcд�û�����id��serverId
	UpdateTidAndSvid(nUserId, pTable->GetID(), m_nServerID, m_nLevel, chIP, m_nPort);

	((CTeenpattiUser*)pUser)->m_bOnline = TRUE;

	//������ӵ������û��㲥�û����뷿����Ϣ
	m_pSendPacket->BroadcastUserLogin(pTable, pUser);
	m_pSendPacket->SendUserLoginSuccess(pSocket, pUser);
	g_pDebugLog->logMsg("--------------------- CGameServer::ProcCheckUserSuccess end------------------ ");
	return 0;
}


int CGameServer::ProcUserKick(CGameUser* pUser, SocketHandler *pSocket, DWORD dwSessionID)
{
	g_pErrorLog->logMsg("----------- CGameServer::ProcUserKick begin ------------");
	if(pUser != NULL)
	{
		//�߳���һ���û�
		if(pUser->m_pSocket)
		{
			m_pSendPacket->SendErrResponse(pUser->m_pSocket);
			pUser->GetHandler()->SetUser(NULL, dwSessionID);
			pUser->SetHandler(NULL);
		}
		m_DisconnectUserList[pUser->GetUserId()] = pUser;
		CTeenpattiUser *pLandUser = (CTeenpattiUser*)pUser;
		UpdateActiveTime(pLandUser->GetUserId(), pLandUser->m_nActimeTime);
		pLandUser->m_nActimeTime = 0;
		g_pErrorLog->logMsg("----------- CGameServer::ProcUserKick end 1------------");
		return ProcUserReconnect(pUser, pUser->GetUserId(), pSocket);	//���û���������������
	}
	g_pErrorLog->logMsg("----------- CGameServer::ProcUserKick end ------------");
	return 0;
}

int CGameServer::UpdateActiveTime(int uid, int activeTime)
{
	char szUid[100]={0};
	snprintf(szUid, sizeof(szUid), "CTEENPATTI_ACTIVETIME|%d", uid);
	uint64_t value; 
	if(!m_pActiveMCClient->increment(szUid, activeTime, value))
	{
		char szValue[20]={0};
		snprintf(szValue, sizeof(szValue), "%d", activeTime);
		m_pActiveMCClient->SetRecord(szUid, szValue, strlen(szValue), GetDelayTime1());
	}
	return 0;
}


int CGameServer::UpdateTidAndSvid(int uid, int tid, short svid, int level, char ip[], int port)
{
	char szUid[100]={0};
	snprintf(szUid, sizeof(szUid), "%d", uid);
	char szValue[100]={0};
	snprintf(szValue, sizeof(szValue), "%d,%hd,%d,%s,%d", tid, svid,level,ip, port);
	m_pOnlineMCClient->SetRecord(szUid, szValue, strlen(szValue), 3600);
	return 0;
}

int CGameServer::ProcUserReconnect(CGameUser* pUser, int nUserId, SocketHandler *pSocket)
{
	(void)pUser;
	(void)nUserId;
	(void)pSocket;
	return 0;
}

//�û������˳�
int CGameServer::ProcUserLogout(CGameUser *pUser)
{
	g_pDebugLog->logMsg("----------- CGameServer::ProcUserLogout begin ---------------");
	if (pUser == NULL)
	{
		return 0;
	}

	CTeenpattiUser* pLandlordUser = dynamic_cast<CTeenpattiUser*>(pUser);

	int nUserId  = pUser->GetUserId();
	g_pDebugLog->logMsg("uid %d ",nUserId);
	m_pSendPacket->SendCmdToClient(SERVER_COMMAND_LOGOUT_SUCCESS, pUser->GetHandler());
	CGameTable* pTable = pUser->GetTable();

	if ( pLandlordUser->m_bLooker == TRUE )
	{
		g_pDebugLog->logMsg("----------- CGameServer::ProcUserLogout end 3 ---------------");
		m_pHallServer->StandTableLeaveRoom(nUserId);
	}
	
	pLandlordUser->StopKickUserTimer();
	if (pTable != NULL)
	{
		m_pSendPacket->BroadcastUserLogout(pTable, pUser);
		g_pDebugLog->logMsg("[%s %u][%s] user[%d] logout",__FILE__,__LINE__,__FUNCTION__,pUser->GetUserId());
	}

	if ( !pLandlordUser->m_bRobot )
	{
		g_pDebugLog->logMsg("----------- CGameServer::ProcUserLogout end 4 ---------------");
		m_pHallServer->ReportLeaveRoom(nUserId);
	}

	UpdateTidAndSvid(nUserId, 0, 0, 0, "", 0);
	
	DeleteUser(pUser);	//ɾ���û�,�����û���ص�map��������û�
	g_pDebugLog->logMsg("----------- CGameServer::ProcUserLogout end ---------------");
	return 0;
}

int	CGameServer::ProcUserRequireLogout(CGameUser *pUser)
{
	(void)pUser;
	return 0;
}

//�����û�����
int CGameServer::ProcessClose(SocketHandler *pHandler)
{
	g_pDebugLog->logMsg("------------- CGameServer::ProcessClose begin --------------- ");
	ProcUserLogout(pHandler->GetUser());
	g_pDebugLog->logMsg("------------- CGameServer::ProcessClose end --------------- ");
	return SocketServer::ProcessClose(pHandler);//��ʱֱ�ӶϿ�
}

//�����û�����
int CGameServer::ProcUserChat(CGameUser *pUser, string &strMsg)
{
	g_pDebugLog->logMsg("------------- CGameServer::ProcUserChat begin --------------- ");

	if ( pUser == NULL )
	{
		g_pDebugLog->logMsg("------------- CGameServer::ProcUserChat end 1 --------------- ");
		return 0;
	}

	CGameTable* pTable = pUser->GetTable();

	if ( pTable == NULL )
	{
		g_pDebugLog->logMsg("------------- CGameServer::ProcUserChat end 2 --------------- ");
		return 0;
	}
	
	m_pSendPacket->BroadcastClientChat(pUser->GetUserId(), strMsg, pTable);

	g_pDebugLog->logMsg("------------- CGameServer::ProcUserChat end --------------- ");
	return 0;
}

//�û����ͱ���
int CGameServer::ProcUserSendFace(CGameUser *pUser, int nType)
{
	if (pUser == NULL)
	{
		return 0;
	}	 

	g_pDebugLog->logMsg("------------- CGameServer::ProcUserSendFace begin --------------- ");

	if ( pUser == NULL )
	{
		g_pDebugLog->logMsg("------------- CGameServer::ProcUserSendFace end 1 --------------- ");
		return 0;
	}

	CGameTable* pTable = pUser->GetTable();

	if ( pTable == NULL )
	{
		g_pDebugLog->logMsg("------------- CGameServer::ProcUserSendFace end 2 --------------- ");
		return 0;
	}
	
	m_pSendPacket->BroadcastClientSendFace(pUser->GetUserId(), nType, pTable);

	g_pDebugLog->logMsg("------------- CGameServer::ProcUserSendFace end --------------- ");
	return 0;
}

//ֹͣ������
int CGameServer::ProcSysCmdStopServer(void)
{
	return 0;
}

//�㲥ϵͳ����
int CGameServer::ProcSysCmdBroadcastCmd(string &strMsg)
{
	return m_pSendPacket->BroadcastSysCmdMsg(strMsg);
}

//������
int CGameServer::ProcSysCmdResetConfig(void)
{
	return 0;
}

int CGameServer::ProcSysCmdCtrlServer(int state)
{
	(void)state;
	m_nServStatus = GAME_SERVER_PAUSE;
	return 0;
}

int CGameServer::ProcSysCmdDebugLog(int state)
{
	int nEnable = state;
	if (nEnable == 1)
	{
		ACE_LOG_MSG->priority_mask(LM_INFO | LM_ERROR | LM_DEBUG, ACE_Log_Msg::PROCESS);	//����debug��־
	}
	else
	{
		ACE_LOG_MSG->priority_mask(LM_INFO | LM_ERROR, ACE_Log_Msg::PROCESS);	//����debug��־
	}
	return 0;
}

BYTE CGameServer::CheckUser(int nUserId, CGameTable* pTable, USERDATA& data)
{	
	g_pDebugLog->logMsg("------------------ CGameServer::CheckUser begin ---------------  ");
	if( IsUserOnline(nUserId) )				//�û�������,Ҫ�ߵ�֮ǰ��½���˺�.
	{
		g_pErrorLog->logMsg("%s||SUCCESS_KICK_OTHER_USER, uid:[%d]", __FUNCTION__, nUserId);
		return SUCCESS_KICK_OTHER_USER;
	}

	if ( IsDisconnectedUserExit(nUserId) )	//���������������û��Ƿ񻹴���
	{
		g_pErrorLog->logMsg("%s||SUCCESS_RECONNECT, nUserId:[%d]", __FUNCTION__, nUserId);
		return SUCCESS_RECONNECT;
	}

	int memServerId = nUserId%(int)m_MemDataServerMap.size();
	CMemDataServer *pMemServer = GetMemDataServer(memServerId);
	if(pMemServer == NULL)
	{
		return ERROR_USERINFO_NOTFOUND;
	}

	if (pMemServer->GetUserInfo(nUserId, data) < 0)
	{
		g_pErrorLog->logMsg("%s||UserJoinTable err, uid:[%d]", __FUNCTION__, nUserId);
		return ERROR_USERINFO_NOTFOUND;
	}	

	g_pErrorLog->logMsg("user count:[%d]", pTable->GetUserCount());
	if(pTable->GetUserCount() >= GetTableMaxUserCount()) //���������ﵽ����������.���ܽ�����
	{
		g_pErrorLog->logMsg("ERROR_TABLE_MAX_COUNT, uid:[%d]", nUserId);
		return ERROR_TABLE_MAX_COUNT;
	}
	g_pDebugLog->logMsg("------------------ CGameServer::CheckUser end ---------------  ");
	return SUCCESS_NEWCONNECT;
}

CGameUser* CGameServer::AddNewUser(CGameTable* pTable, int nUserId, string strInfo, SocketHandler *pSocket, DWORD dwSessionID, USERDATA& data, BYTE nFlag)
{
	(void)nFlag;
	g_pDebugLog->logMsg("------------------ CGameServer::AddNewUser begin ---------------  ");
    CGameUser* pNewUser = m_pCreator->CreateUser(this, pTable, nUserId, dwSessionID, strInfo);
	pNewUser->m_nMoney = data.money;
	pNewUser->m_nWinTimes = data.wintimes;
	pNewUser->m_nLoseTimes = data.losetimes;				

	//���뵽������
	pTable->AddNewUser(pNewUser);

	//���������û��б���
	m_ServerUserList[nUserId] = pNewUser;	

	pNewUser->SetHandler(pSocket);
	pSocket->SetUser(pNewUser, dwSessionID);
	pNewUser->SetStatus(USER_STATUS_LOGIN);
	g_pDebugLog->logMsg("------------------ CGameServer::AddNewUser end ---------------  ");
	return pNewUser;
}

int CGameServer::DeleteUser(CGameUser* pUser)
{
	g_pDebugLog->logMsg("------------------ CGameServer::DeleteUser begin ---------------  ");
	CGameTable* pTable = pUser->GetTable();

	if (pUser->m_pSocket != NULL)
	{
		pUser->m_pSocket->SetUser(NULL, pUser->m_dwSessionID);
	}
	pUser->m_pSocket = NULL;
	if (pTable != NULL)
	{
		pTable->RemoveUser(pUser);							//��������ӵ��û�
		m_pHallServer->UpdateRoomUserCount((CTeenpattiTable*)pTable);
	}
	else
	{
		for(TableIdMap::iterator iter=m_TableList.begin(); iter!= m_TableList.end();iter++)
		{
			CTeenpattiTable* pTable = (CTeenpattiTable*)iter->second;
			if ( pTable != NULL )
			{
				for ( int i=0; i<USER_PLAY_COUNT; i++ )
				{
					if ( pTable->m_SeatList[i]->m_pUser == pUser )
					{
						pTable->m_SeatList[i]->m_pUser = NULL;
					}
				}
				map<int, CGameUser*>::iterator iter = pTable->m_UserManager.find(pUser->GetUserId());
				if(iter != pTable->m_UserManager.end())
				{
					pTable->m_UserManager.erase(iter);
				}
				pTable->m_nUserCount = (int)pTable->m_UserManager.size();
			}
		}
	}
	m_ServerUserList.erase(pUser->GetUserId());			//ɾ�������û��б��ĸ��û�
	m_DisconnectUserList.erase(pUser->GetUserId());		//ɾ�������߱��ĸ��û�,��һ����
	delete pUser;
	pUser = NULL;
	g_pDebugLog->logMsg("------------------ CGameServer::DeleteUser end ---------------  ");
	return 0;
}

BOOL CGameServer::IsUserOnline(int nUserId)
{
	UserIdMap::iterator iter = m_DisconnectUserList.find(nUserId);	//������ڵ����û��б���,�Ų������û��б�
	if (iter == m_DisconnectUserList.end())
	{
		CGameUser* pOnlineUser = GetUserByUserID(nUserId);
		if (pOnlineUser)
		{
			return TRUE;
		}
	}
	return FALSE;
}

BOOL CGameServer::IsDisconnectedUserExit(int nUserId)
{
	UserIdMap::iterator iter = m_DisconnectUserList.find(nUserId);	
	if (iter == m_DisconnectUserList.end())
	{
		return FALSE;
	}
	return TRUE;
}

CGameUser* CGameServer::GetUserByUserID(int nUserId)		//����userId��ȡCGameUser,���ص�pUser���п���ΪNULL��,���û����߳�ʱ�������,���û���ɾ��,�ͻ����
{
	CGameUser *pUser = NULL;
	UserIdMap::iterator iter = m_ServerUserList.find(nUserId);
	if (iter != m_ServerUserList.end())
	{
		pUser = iter->second;
	}
	return pUser;
}

CGameTable* CGameServer::GetTable(int nTableId)
{
	if (nTableId <= 0)
	{
		g_pErrorLog->logMsg("%s:Table error, tid:[%d]", __FUNCTION__, nTableId);
		return NULL;
	}

	if (m_TableList.find(nTableId) == m_TableList.end())
	{
		g_pErrorLog->logMsg("%s:Table not exist", __FUNCTION__);
		return NULL;
	}

	return m_TableList[nTableId];
}

BOOL CGameServer::CheckAndAddTable(int nTableId, int nTableType, int nBaseChips, string sRoomName, string sPassword)
{
	g_pDebugLog->logMsg("------------------ CGameServer::CheckAndAddTable begin ---------------  ");
	if((nTableId>>16) != m_nServerID)
	{
		g_pErrorLog->logMsg("CheckAndAddTable||Check error, tid:[%d], serverId:[%d]",nTableId, m_nServerID);
		return FALSE;
	}
		
	if(m_TableList.find(nTableId) == m_TableList.end()) 
	{
		TableData tableData;
		tableData.nGamePlayerCount = m_LandlordServConf.nGamePlayerCount;
		tableData.nTableLevel = m_LandlordServConf.nLevel;
		if (nBaseChips == 0)
		{
			tableData.nBaseChips = m_LandlordServConf.nBaseChips;
			tableData.nRequireChips = m_LandlordServConf.nRequireChips;
			tableData.nMaxUserChips = m_LandlordServConf.nMaxUserChips;
		}
		else	//�Զ����ע,
		{
			tableData.nBaseChips = nBaseChips;
			tableData.nRequireChips = m_LandlordServConf.nRequireChips;
			tableData.nMaxUserChips = m_LandlordServConf.nMaxUserChips;
			strcpy(tableData.pszRoomName, sRoomName.c_str());
			strcpy(tableData.pszPassword,  sPassword.c_str());
		}

		CGameTable* pTable = m_pCreator->CreateTable(this, &tableData, nTableId);
		
		if(pTable != NULL)
		{
			g_pErrorLog->logMsg("CreateTable OK");
			m_TableList[nTableId] = pTable;
		}
		else
		{
			g_pErrorLog->logMsg("CreateTable Error");
			return FALSE;
		}
	}
	else if(nBaseChips != 0)	//�޸ķ����ע
	{
		CTeenpattiTable* pTable = (CTeenpattiTable*)m_TableList[nTableId];
		pTable->m_nTableType = nTableType;
		pTable->m_nRequireChips = m_LandlordServConf.nRequireChips;
		pTable->m_nMaxUserChips = m_LandlordServConf.nMaxUserChips;
		pTable->m_nBaseChip = nBaseChips;
		strcpy(pTable->m_pszPassword, sPassword.c_str());
		strcpy(pTable->m_pszRoomName, sRoomName.c_str());
	}
	g_pDebugLog->logMsg("------------------ CGameServer::CheckAndAddTable end ---------------  ");
	return TRUE;
}

int CGameServer::CreateNewTable()
{
	g_pDebugLog->logMsg("-------------- CGameServer::CreateNewTable begin ------------");
	if((int)m_TableList.size() >= m_nMaxTableCount)
	{
		return 0;
	}
	
	int nTableId = (m_nServerID<<16) + (int)m_TableList.size();

	TableIdMap::iterator iter;
	for(;;nTableId++)
	{
		iter = m_TableList.find(nTableId);
		if(iter == m_TableList.end())
			break;
	}

	TableData tableData;
	tableData.nGamePlayerCount = m_LandlordServConf.nGamePlayerCount;
	tableData.nTableLevel = m_LandlordServConf.nLevel;
	tableData.nBaseChips = m_LandlordServConf.nBaseChips;
	tableData.nRequireChips = m_LandlordServConf.nRequireChips;
	tableData.nMaxUserChips = m_LandlordServConf.nMaxUserChips;
	CGameTable* pTable = m_pCreator->CreateTable(this, &tableData, nTableId);

	if(pTable != NULL)
	{
		m_TableList[nTableId] = pTable;
		//return pTable;
	}
	g_pDebugLog->logMsg("-------------- CGameServer::CreateNewTable end ------------");
	return 0;
}

int CGameServer::ProcSetClientIP(CGameUser* pUser,int uid,unsigned int dwIP)
{
	if(pUser!= NULL && pUser->GetUserId() == uid )
	{
		pUser->SetIP(dwIP);
	}
	else
	{
		g_pErrorLog->logMsg("%s||Set Client IP Error, pUser->uid:[%d], uid:[%d], dwIP:[%u]", __FUNCTION__, (pUser ? pUser->GetUserId() : 0),uid,dwIP);	
	}
	return 0;
}

