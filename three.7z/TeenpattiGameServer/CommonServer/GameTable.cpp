#include "GameUser.h"
#include "GameTable.h"
#include "GameServer.h"
#include "ICHAT_PacketParser.h"

#include "clib_log.h"
extern clib_log* g_pDebugLog;
extern clib_log* g_pErrorLog;

CGameTable::CGameTable(CGameServer* pServer, TableData *info, int nId)
{
	m_nUserCount = 0;
	m_ChatMsgList.clear();

	m_pGameServer = pServer;
	m_pTableInfo = info;
	m_nTableId = nId;
	m_nTableType = m_pTableInfo->nTableType;
	m_nTableLevel = m_pTableInfo->nTableLevel;
	m_nGamePlayerCount = m_pTableInfo->nGamePlayerCount;
	strcpy(m_pszRoomName, m_pTableInfo->pszRoomName);
	strcpy(m_pszPassword, m_pTableInfo->pszPassword);
	
	for(BYTE i = 0; i<m_nGamePlayerCount; i++)
	{
		CGameSeat *seat = new CGameSeat(i);
		m_SeatList.push_back(seat);
	}
}

CGameTable::~CGameTable(void)
{
  
}

int CGameTable::AddNewUser(CGameUser *pUser)
{
	m_UserManager[pUser->GetUserId()] = pUser;
	m_nUserCount = (int)m_UserManager.size();
	return 0;
}

int CGameTable::RemoveUser(CGameUser *pUser) 
{
	g_pErrorLog->logMsg("------------ CGameTable::RemoveUser begin ------------");
	UserStand(pUser->GetSeatId());

	map<int, CGameUser*>::iterator iter = m_UserManager.find(pUser->GetUserId());
	if(iter != m_UserManager.end())
	{
		m_UserManager.erase(iter);
	}
	m_nUserCount = (int)m_UserManager.size();
	g_pErrorLog->logMsg("------------ CGameTable::RemoveUser end ------------");
	return 0;
}

bool CGameTable::UserSit(BYTE nSeatId, CGameUser* pUser)
{
	if ( m_SeatList[nSeatId]->m_pUser )
	{
		g_pErrorLog->logMsg("------------ CGameTable::UserSit end 1 ----------");
		return false;
	}
	else
	{
		m_SeatList[nSeatId]->m_pUser = pUser;
		pUser->Sit(m_SeatList[nSeatId]);
		g_pErrorLog->logMsg("------------ CGameTable::UserSit end 2 ----------");
		return true;
	}
}

void CGameTable::UserStand(BYTE nSeatId)
{
	g_pErrorLog->logMsg("------------ CGameTable::UserStand seatid [%d]",nSeatId);
	if (nSeatId < 0 || nSeatId >= m_nGamePlayerCount)
	{
		g_pErrorLog->logMsg("------------ CGameTable::UserStand end 1 ----------");
		return;
	}

	if (m_SeatList[nSeatId]->m_pUser != NULL)
	{
		m_SeatList[nSeatId]->m_pUser->Stand();
		m_SeatList[nSeatId]->m_pUser = NULL;
	}
	g_pErrorLog->logMsg("------------ CGameTable::UserStand end ----------");
}

void CGameTable::AddChatMsg(int nId, const char* pszMsg)
{
	TChatData userchat;
	userchat.nUserId = nId;
	userchat.strMsg  = pszMsg;

	if(m_ChatMsgList.size() >= MAX_CHAT_COUNT)
		m_ChatMsgList.pop_front();
	m_ChatMsgList.push_back(userchat);
}

int CGameTable::GetGamePlayerCount()	
{
	return m_nGamePlayerCount;
}

int CGameTable::GetTableType()
{
	return m_nTableType;
}

CGameUser* CGameTable::GetUserBySeatId(BYTE nSeatId)
{
	if (nSeatId < 0 || nSeatId >= m_nGamePlayerCount)
	{
		return NULL;
	}
	return m_SeatList[nSeatId]->m_pUser;
}

CGameUser* CGameTable::GetUserByUserId(int nUserId)
{
	map<int, CGameUser*>::iterator iter = m_UserManager.find(nUserId);
	if(iter != m_UserManager.end())
	{
		return iter->second;
	}
	return NULL;
}

TableData* CGameTable::GetTableData()
{
	return m_pTableInfo;
}

int CGameTable::GetUserCount(void)
{
	return m_nUserCount;
}

int CGameTable::GetID(void)
{
	return m_nTableId;
}

