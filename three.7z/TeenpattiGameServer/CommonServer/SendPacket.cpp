#include "SendPacket.h"
#include "GameCmd.h"
#include "SocketHandler.h"
#include "GameServer.h"
#include "json.h"
#include "TeenpattiCmd.h"

#include "clib_log.h"
extern clib_log* g_pErrorLog;
extern clib_log* g_pDebugLog;


int CSendPacket::SendUserLoginSuccess(SocketHandler* pHandler, CGameUser* pUser)
{
	CGameTable* pTable = pUser->GetTable();
	CTeenpattiTable *pTStable = (CTeenpattiTable *)pTable;

	NETOutputPacket response; 
	response.Begin(SERVER_COMMAND_LOGIN_SUCCESS);
	response.WriteInt(pTable->m_nTableId);
	response.WriteInt(m_pGameServer->m_LandlordServConf.nBaseChips);
	response.WriteInt(m_pGameServer->m_LandlordServConf.nMaxHandBet);
	response.WriteInt(m_pGameServer->m_LandlordServConf.nMaxTableChip);
	response.WriteByte(m_pGameServer->m_LandlordServConf.nMinCompare);
	response.WriteByte(m_pGameServer->m_LandlordServConf.nMaxCallTimes);
	response.WriteInt(m_pGameServer->m_LandlordServConf.nCallCardTimeout);
	response.WriteString(m_pGameServer->m_LandlordServConf.strName);
	response.WriteByte(pTStable->GetGameStatus());

	CTeenpattiUser *pTSUser = (CTeenpattiUser *)pUser;

	if ( pTStable->GetGameStatus() == STATUS_PLAY )
	{
		response.WriteLong(pTStable->m_nHandBet);
		response.WriteInt(pTable->GetUserBySeatId(pTStable->m_nCurCallSeatId)->GetUserId());
		int nLeftTime = m_pGameServer->m_LandlordServConf.nCallCardTimeout - ((GetTickCount() - pTStable->m_dwGameTickCount)/1000);
		response.WriteByte(nLeftTime);

		if (( !pTSUser->m_bDisCard ) && ( pTSUser->m_bWatchCard ))
		{
			response.WriteByte(3);
			for (int i = 0; i < 3; ++i)
			{
				response.WriteByte(pTSUser->m_byHandCardData[i]);
			}
		}
		else
		{
			response.WriteByte(0);
		}
	}

	BYTE byPlayCount = pTStable->GetSitUserCount();

	response.WriteByte(byPlayCount);

	for ( BYTE i=0; i<USER_PLAY_COUNT; i++ )
	{
		CGameUser *pUser = pTable->GetUserBySeatId(i);

		if ( pUser )
		{
			CTeenpattiUser *pTUser = (CTeenpattiUser *)pUser;
			response.WriteInt(pUser->GetUserId());
			response.WriteLong(pUser->m_nMoney);
			response.WriteInt(0);
			response.WriteString(pUser->m_strUserInfo);
			response.WriteByte(i);
			response.WriteLong(pTUser->m_nCostForTable);
			response.WriteByte(pUser->m_nStatus);
			BYTE byCallStatus = pTUser->m_bCallDownUser == TRUE ? 1 : 0;
			response.WriteByte(byCallStatus);
		}
	}

	response.End();
	return SendPackage(&response, pHandler);
}

int CSendPacket::SendLoginError(SocketHandler* pHandler, BYTE nErrNo)
{
	NETOutputPacket OutPkg;
	OutPkg.Begin(SERVER_COMMAND_LOGIN_ERR);
	OutPkg.WriteByte(nErrNo);
	OutPkg.End();
	return SendPackage(&OutPkg, pHandler);
}

int CSendPacket::SendErrResponse(SocketHandler* pSocket)
{
	NETOutputPacket OutPkg;
	OutPkg.Begin(SERVER_COMMAND_REPEAT_LOGIN_ERR);
	OutPkg.End();

	return SendPackage(&OutPkg, pSocket);
}

int CSendPacket::BroadcastUserLogin(CGameTable* pTable, CGameUser* pUser)
{	
	NETOutputPacket response;
	BuildPackage(&response, SERVER_BROADCAST_USER_LOGIN, "%d,%s", pUser->GetUserId(),  pUser->m_strUserInfo.c_str());
	BroadcastTablePackage(pTable, &response, pUser);
	return 0;
}

int CSendPacket::BroadcastUserLogout(CGameTable* pTable, CGameUser* pUser)
{	
	NETOutputPacket response;	
	BuildPackage(&response, SERVER_BROADCAST_USER_LOGOUT, "%d", pUser->GetUserId());
	BroadcastTablePackage(pTable, &response, pUser);
	return 0;
}

int CSendPacket::BroadcastClientChat(int nUserId, string strMsg, CGameTable* pTable)
{
	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_USER_CHAT);
	response.WriteInt(nUserId);
	response.WriteString(strMsg.c_str());
	response.End();

	return BroadcastTablePackage(pTable, &response, NULL);
}

int CSendPacket::BroadcastClientSendFace(int nUserId, int nType, CGameTable* pTable)
{
	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_USER_SENDFACE);
	response.WriteInt(nUserId);
	response.WriteInt(nType);
	response.End();

	return BroadcastTablePackage(pTable, &response, NULL);
}

int CSendPacket::BroadcastSysCmdMsg(string &strMsg)
{
	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_SYSMSG);
	response.WriteString(strMsg.c_str());
	response.End();
	return BroadcastAllPackage(&response, NULL);

}

int CSendPacket::SendCmdToClient(int nCmdType, SocketHandler *pHandler)
{
	NETOutputPacket outPkg;
	BuildPackage(&outPkg, nCmdType);
	if (pHandler != NULL)
	{
		return pHandler->Send(&outPkg);
	}
	return -1;
}

int CSendPacket::SendCmdToClient(SocketHandler *pHandler,short nCmdType,const char* pszFmt, ...)
{
	NETOutputPacket outPkg;

	outPkg.Begin(nCmdType);

	if (pszFmt == NULL)	//����Ϊ�յ�,��ֱ�ӹ���һ��ֻ������ͷ�����ݰ�
	{
		outPkg.End();
		return -1;
	}

	va_list ap; 
	va_start (ap, pszFmt); 
	const char* p = NULL;

	for (p= pszFmt; *p; p++) 
	{ 
		if (*p != '%') 
		{
			continue; 
		}

		switch (*++p) 
		{ 
		case 'd':	//int
			{
				int nVal= va_arg(ap, int);
				outPkg.WriteInt(nVal);
				break;
			}
		case 'h':	//short
			{
				short shVal = va_arg(ap, int);
				outPkg.WriteShort(shVal);
				break;
			}
		case 'u':	//unsigned long
			{
				unsigned long dwVal = va_arg(ap, unsigned long);
				outPkg.WriteULong(dwVal);
				break;
			}
		case 's':	//char*
			{
				char* pVal = va_arg(ap, char*);
				outPkg.WriteString(pVal);
				break;
			}
		}
	}
	outPkg.End();

	if (pHandler != NULL)
	{
		return pHandler->Send(&outPkg);
	}

	return -1;
}



//*********************************************/
// Method:    SendPackage
// Returns:   int
// Parameter: NETOutputPacket * pPackage
// Parameter: SocketHandler * pHandler
// Description: ���͵��û�,����socket ���ӷ�
//*********************************************/
int CSendPacket::SendPackage(NETOutputPacket* pPackage, SocketHandler* pHandler)
{
	if (pHandler == NULL)
	{
		return -1;
	}
	return pHandler->Send(pPackage);
}

//*********************************************/
// Method:    SendPackage
// Returns:   int
// Parameter: NETOutputPacket * pPackage
// Parameter: CGameUser * pUser
// Description: ���͵��û�,����user��
//*********************************************/
int CSendPacket::SendPackage(NETOutputPacket* pPackage, CGameUser* pUser)
{
	if (pUser == NULL)
	{
		return -1;
	}
	if (pUser->GetHandler()== NULL)
	{
		return -1;
	}

	return pUser->GetHandler()->Send(pPackage);
}

//*********************************************/
// Method:    BroadcastTablePackage
// Returns:   int
// Parameter: CGameTable * pTable
// Parameter: NETOutputPacket * pPackage
// Parameter: CGameUser * pUser
// Description: �㲥ĳ���ӵ��û�
//*********************************************/
int CSendPacket::BroadcastTablePackage(CGameTable* pTable, NETOutputPacket* pPackage, CGameUser* pUser)
{
	int nCount = 0;
	map<int, CGameUser*>::iterator iter;
	for(iter = pTable->m_UserManager.begin(); iter != pTable->m_UserManager.end(); iter++)
	{
		CGameUser *p = (*iter).second;
		if(p != NULL && p != pUser && p->GetTable() == pTable )
		{
			SendPackage(pPackage, p);
			nCount++;
		}
	}

	return nCount;
}

//*********************************************/
// Method:    BroadcastAllPackage
// Returns:   int
// Parameter: NETOutputPacket * pPackage
// Parameter: CGameUser * pUser
// Description: �㲥��Ϣ�ܵ�ǰ�����û������pUser��Ϊ�գ���㲥ʱpUser����
//*********************************************/
int CSendPacket::BroadcastAllPackage(NETOutputPacket* pPackage, CGameUser* pUser)
{
	int nCount = 0;
	UserIdMap::iterator iter;
	for(iter = m_ServerUserList.begin(); iter != m_ServerUserList.end(); iter++)
	{
		CGameUser *p = (*iter).second;
		if(p != NULL && p != pUser)
		{
			CGameUser *p = (*iter).second;
			if(p != NULL && p != pUser)
			{
				SendPackage(pPackage, p);
				nCount++;
			}
		}
	}
	return nCount;
}

//////////////////////////////////////////////////////////////////////////
//ʵ�ֹ���һ��NETOutputPacket���ݰ�,�����ɱ䳤
//֧�ֵ�������int,DWORD,short,char*,
//��Ӧ����Ϊ %d====int, %u====DWORD, %h=====short, %s=====char*
//pszFmtΪ����Ҫ���͵������ֶεĸ�ʽ��ɵ��ַ���,���Բ����ò���,Ҳ���Դ�.��"%d,%u,%h,%s"
//Ҳ���Լ���һЩע����Ϣ,��:"id:%d ntype:%h key:%u name:%s"
//////////////////////////////////////////////////////////////////////////
void CSendPacket::BuildPackage(NETOutputPacket* pOutPack, short nCmdType, const char* pszFmt, ...)
{
	pOutPack->Begin(nCmdType);

	if (pszFmt == NULL)	//����Ϊ�յ�,��ֱ�ӹ���һ��ֻ������ͷ�����ݰ�
	{
		pOutPack->End();
		return;
	}

	va_list ap; 
	va_start (ap, pszFmt); 
	const char* p = NULL;

	for (p= pszFmt; *p; p++) 
	{ 
		if (*p != '%') 
		{
			continue; 
		}

		switch (*++p) 
		{ 
		case 'd':	//int
			{
				int nVal= va_arg(ap, int);
				pOutPack->WriteInt(nVal);
				break;
			}
		case 'h':	//short
			{
				short shVal = va_arg(ap, int);
				pOutPack->WriteShort(shVal);
				break;
			}
		case 'u':	//unsigned long
			{
				unsigned long dwVal = va_arg(ap, unsigned long);
				pOutPack->WriteULong(dwVal);
				break;
			}
		case 's':	//char*
			{
				char* pVal = va_arg(ap, char*);
				pOutPack->WriteString(pVal);
				break;
			}
		}
	}
	pOutPack->End();
}

