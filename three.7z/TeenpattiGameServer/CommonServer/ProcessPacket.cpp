#include "SocketHandler.h"
#include "ProcessPacket.h"
#include "GameCmd.h"
#include "GameServer.h"
#include "SystemCmd.h"
#include "TeenpattiServer.h"

#include "clib_log.h"
extern clib_log* g_pErrorLog;
extern clib_log* g_pDebugLog;

int  CProcessPacket::ProcessPacket(NETInputPacket *pPackage, SocketHandler *pSocket, DWORD dwSessionID)
{

	short nCmdType = pPackage->GetCmdType();
	g_pDebugLog->logMsg("nCmdType [0x%x]", nCmdType);
	if(pSocket->GetUser() == NULL)
	{	// ��֤Socket�Ƿ�������û���¼

		g_pDebugLog->logMsg("user is null");

		if(nCmdType>SYS_COMMAND_END || nCmdType < SYS_COMMAND_BEN)
		{
			g_pDebugLog->logMsg("user ------------");
			if(nCmdType == CLIENT_COMMAND_LOGIN) 
			{
				g_pDebugLog->logMsg("user login");
				return OnUserLogin(pPackage, pSocket, dwSessionID);
			} 
			else
			{	
				if( SERVER_CMD_SET_IP == nCmdType) 
				{
					return 0;
				}
				ICHAT_DEBUG_IO((LM_DEBUG, ACE_TEXT("(%P|%t) cmd no login Err\r\n")));
				ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]%s: ProcessPacket nCmdType 0x%x ERROR\r\n"),__FUNCTION__,nCmdType));
				return -1;
			}
		}
	}
	int nRet = 0;
	switch (nCmdType)
	{
	case CLIENT_COMMAND_LOGOUT:				//�˳�����
		nRet = OnUserLogout(pPackage, pSocket);
		break;
	case CLIENT_COMMAND_CHAT:				//��������
		nRet = OnUserChat(pPackage, pSocket);
		break;
	case CLIENT_COMMAND_SEND_FACE:			//�û����ͱ���
		nRet = OnUserSendFace(pPackage, pSocket);
		break;
	case SYS_COMMAND_SERVERKILL:			//ϵͳ��������:�رշ�����
		nRet = OnSysCmdStopServer(pPackage, pSocket);
		break;
	case SYS_COMMAND_MSG:					//ϵͳ��������:�㲥����
		nRet = OnSysCmdBroadcastCmd(pPackage, pSocket);
		break;
	case SYS_COMMAND_RESET_CONFIG:			//ϵͳ��������:���¼�������
		nRet = OnSysCmdResetConfig(pPackage, pSocket);
		break;
	case SYS_COMMAND_CTRL_SERVER:			//ϵͳ��������:������������ͣ�뿪��
		nRet = OnSysCmdCtrlServer(pPackage, pSocket);
		break;
	case SYS_COMMAND_DEBUG_LOG:				//ϵͳ��������:�����ر�debug��־
		nRet = OnSysCmdDebugLog(pPackage, pSocket);
		break;
	case SERVER_CMD_SET_IP:
		nRet = OnSetClientInfo(pPackage,pSocket);
		break;
	default:
		nRet = ProcExtendCmd(pPackage, pSocket);
		break;
	}
	
	return nRet;
}

int CProcessPacket::OnUserLogin(NETInputPacket *pPackage, SocketHandler *pSocket, DWORD dwSessionID)
{
	int nTableId = pPackage->ReadInt();
	int nUserId = pPackage->ReadInt();
	string strInfo = pPackage->ReadString();
	BYTE byOffline = pPackage->ReadByte();			//���ߺ���������

	g_pDebugLog->logMsg("CProcessPacket::OnUserLogin tid [%d], uid[%d], strInfo[%s], byOffline[%d] : ", nTableId, nUserId, strInfo.c_str(),byOffline);

	if ( strInfo.length()<3 || nTableId<=0)
	{
		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]%s:nTableId:[%d], nUserId:[%d]\n"),__FUNCTION__, nTableId, nUserId));
		return 0;
	}

	return m_pGameServer->ProcUserLogin(nTableId, nUserId, strInfo, pSocket, dwSessionID, byOffline);
}

int CProcessPacket::OnUserLogout(NETInputPacket *, SocketHandler *pSocket)
{
	return m_pGameServer->ProcUserRequireLogout(pSocket->GetUser());
}

int CProcessPacket::OnUserChat(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	string msg = pPackage->ReadString();
	return m_pGameServer->ProcUserChat(pSocket->GetUser(), msg);
}

int CProcessPacket::OnUserSendFace(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	int nType = pPackage->ReadInt();
	return m_pGameServer->ProcUserSendFace(pSocket->GetUser(), nType);
}

int CProcessPacket::OnSysCmdStopServer(NETInputPacket *pPackage, SocketHandler *)
{
	if(pPackage->ReadString() == SERVERKEY)
	{
		return m_pGameServer->ProcSysCmdStopServer();
	}
	return -1;
}

int CProcessPacket::OnSysCmdBroadcastCmd(NETInputPacket *pPackage, SocketHandler *)
{
	if(pPackage->ReadString() == SERVERKEY)
	{
		string msg = pPackage->ReadString();
		return m_pGameServer->ProcSysCmdBroadcastCmd(msg);
	}
	return -1;
}

int CProcessPacket::OnSysCmdResetConfig(NETInputPacket *pPackage, SocketHandler *)
{
	if(pPackage->ReadString() == SERVERKEY)
	{
		return ((CTeenpattiServer*)m_pGameServer)->ProcSysCmdResetConfig();
	}
	return -1;
}

int CProcessPacket::OnSysCmdCtrlServer(NETInputPacket *pPackage, SocketHandler *)
{
	if(pPackage->ReadString() == SERVERKEY)
	{
		int state = pPackage->ReadInt();
		return m_pGameServer->ProcSysCmdCtrlServer(state);
	}
	return -1;
}

int CProcessPacket::OnSysCmdDebugLog(NETInputPacket *pPackage, SocketHandler *)
{
	if(pPackage->ReadString() == SERVERKEY)
	{
		int state = pPackage->ReadInt();
		return m_pGameServer->ProcSysCmdDebugLog(state);
	}
	return -1;
}

int CProcessPacket::OnSetClientInfo(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	int tid=pPackage->ReadInt(); 
	int uid=pPackage->ReadInt();
	unsigned int dwIP=pPackage->ReadInt();
	return m_pGameServer->ProcSetClientIP(pSocket->GetUser(),uid,dwIP);
}


