#include "ServerManager.h"
#include "ACE_Application.h"


int StartServer(CGameServer* pServer, CTeenpattiHallServer* pHallServer, CActivityServer * pActivityServer, CCreator* pCreator, int argc, char* argv[])
{
	if (pServer == NULL)
	{
		return -1;
	}

	ACE_Application server(pServer);
	server.init();

	if (!pServer->InitServer(pCreator, pHallServer, pActivityServer, argc, argv))
	{
		ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT("InitServer failed\n")), -1);
	}
	
	int nPort = pServer->GetListenPort();
	if (nPort <= 0)
	{
		return -1;
	}
	
	if(server.run(nPort) == -1)
	{
		return -1 ;
	}

	pHallServer->InitConnect();
	//pCoreServer->InitConnect();
	pActivityServer->InitConnect();
	return server.waitForShutdown();
}

