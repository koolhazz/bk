#include "MemDataServer.h"
#include "ICHAT_HTTP_Config.h"
#include "clib_log.h"
extern clib_log* g_pDebugLog;
extern clib_log* g_pErrorLog;

CMemDataServer::CMemDataServer():
	m_SocketHandler(this)
{

}

CMemDataServer::~CMemDataServer()
{

}
////////////////////////////////////////////////////////////////////////////////
// ��ʼ��proxy����
////////////////////////////////////////////////////////////////////////////////
int	CMemDataServer::InitConnect(ACE_INET_Addr &remote, ACE_Reactor *pReactor)
{
	m_Connector.open(pReactor, ACE_NONBLOCK);
	MemSvrSocketHandler *pHandler = &m_SocketHandler;
	pHandler->Addr(remote);    //��������
	int nRet = m_Connector.connect(pHandler, remote, ACE_Synch_Options::synch);
	return nRet;
}

int CMemDataServer::InitConnect(const char* port, const char* host)
{
	ACE_INET_Addr hallAddr(port, host);
	InitConnect(hallAddr);
	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////
// proxyserver�ر��Զ�����
////////////////////////////////////////////////////////////////////////////////
void CMemDataServer::Reconnect(void)  //EWOULDBLOCK
{
	MemSvrSocketHandler *pClient = &m_SocketHandler;
	m_Connector.connect(pClient, pClient->Addr(), ACE_Synch_Options::synch);
}

int CMemDataServer::GetUserInfo(int uid, USERDATA &data)
{
	g_pErrorLog->logMsg("----------- CMemDataServer::GetUserInfo Begin ----------------");
	if(!IsConnected())
	{
		g_pErrorLog->logMsg("MemDataServer not connect");
		return -1;
	}

	MemNETOutputPacket reqPacket;
	reqPacket.Begin(CLIENT_COMMAND_GET_RECORD);
	reqPacket.WriteInt(uid);
	reqPacket.End();
	m_SocketHandler.Send(&reqPacket);

	
    char pRecvBuffer[ICHAT_TCP_DEFAULT_BUFFER];
    ACE_Time_Value tv(2);
	int nRecv = m_SocketHandler.peer().recv(pRecvBuffer, ICHAT_TCP_DEFAULT_BUFFER, &tv);
	if(nRecv <= 0)
	{
		g_pErrorLog->logMsg("GetUserInfo m_SocketHandler.peer().recv nRecv<=0");
		return -1;
	}
	
	string userInfo = "";
	int ret = m_SocketHandler.OnParser(pRecvBuffer, nRecv); 
	if(ret == 0)
	{
		MemNETInputPacket resPacket;
		resPacket.Copy(pRecvBuffer, nRecv);
		if(resPacket.GetCmdType() == SERVER_COMMAND_GET_RECORD)
		{
			int val = resPacket.ReadInt();
			if(val == 0)
			{
				userInfo = resPacket.ReadString();
				//g_pDebugLog->logMsg("GetUserInfo userInfo:[%s]", userInfo.c_str());
			}
			else
			{
				g_pErrorLog->logMsg("GetUserInfo ERR, uid=[%d]", uid);
				return -1;
			}
		}
		else
		{
			g_pErrorLog->logMsg("GetUserInfo userInfo Invalid cmd, uid=[%d]", uid);
			return -1;
		}
	}
	else
	{
		g_pErrorLog->logMsg("GetUserInfo parse ERROR");
		return -1;
	}

	if(userInfo != "")
	{
		char* tok;
		char c_info[1000]={0};
		snprintf(c_info,sizeof(c_info),"%s",userInfo.c_str());
		tok = strtok(c_info, ",");
		int i = 1;
		while(tok != NULL)
		{
			switch(i)
			{
			case MONEY:
				data.money = atol(tok);
				g_pErrorLog->logMsg("MONEY [%ld]", data.money);
				break;
			case WINTIMES:
				data.wintimes = atoi(tok);
				g_pErrorLog->logMsg("WINTIMES, [%d]", data.wintimes);
				break;
			case LOSTTIMES:
				data.losetimes = atoi(tok);
				g_pErrorLog->logMsg("LOSTTIMES, [%d]", data.losetimes);
				break;
			default:
				break;
			}
			i++;
			tok = strtok(NULL, ",");
		}
	}

	g_pErrorLog->logMsg("----------- CMemDataServer::GetUserInfo End ----------------");
	return 0;
}

void CMemDataServer::UpdateUserInfo(CTeenpattiUser *pLandlordUser)
{
	g_pErrorLog->logMsg("----------- CMemDataServer::UpdateUserInfo Begin ----------------");
	if(!IsConnected())
		return;
	int nUserId = pLandlordUser->GetUserId();
//	ʹ�� user������̨��
	int nMoney = pLandlordUser->m_nUpdateMoney;

	if ( nMoney == 0 )
	{
		g_pErrorLog->logMsg("----------- CMemDataServer::UpdateUserInfo End 1 ----------------");
		return 0;
	}

	g_pErrorLog->logMsg("nUserId:[%d],nMoney:[%d]",nUserId,nMoney);

    MemNETOutputPacket outPkg;
    outPkg.Begin(SYS_COMMAND_UPDATE_RECORD);
    outPkg.WriteInt(nUserId);
    outPkg.WriteByte(3);
    outPkg.WriteInt(MONEY);
    outPkg.WriteInt(nMoney);
    g_pErrorLog->logMsg("money : %d", nMoney);
    outPkg.WriteInt(WINTIMES);
    outPkg.WriteInt(pLandlordUser->m_nWinTimes);
    g_pErrorLog->logMsg("m_nWinTimes : %d", pLandlordUser->m_nWinTimes);
    outPkg.WriteInt(LOSTTIMES);
    outPkg.WriteInt(pLandlordUser->m_nLoseTimes);
    g_pErrorLog->logMsg("m_nLoseTimes : %d", pLandlordUser->m_nLoseTimes);
    outPkg.End();
    pLandlordUser->m_nUpdateMoney = 0;
    m_SocketHandler.Send(&outPkg);
    g_pErrorLog->logMsg("----------- CMemDataServer::UpdateUserInfo End ----------------");
	GetRet();
}

void CMemDataServer::GetRet()
{
	char pRecvBuffer[ICHAT_TCP_DEFAULT_BUFFER];
    ACE_Time_Value tv(2);
	int nRecv = m_SocketHandler.peer().recv(pRecvBuffer, ICHAT_TCP_DEFAULT_BUFFER, &tv);
	if(nRecv <= 0)
	{
		g_pErrorLog->logMsg("GetRet nRecv<=0");
		return;
	}

	int ret = m_SocketHandler.OnParser(pRecvBuffer, nRecv);
	if(ret == 0)
	{
		MemNETInputPacket resPacket;
		resPacket.Copy(pRecvBuffer, nRecv);
		if(resPacket.GetCmdType()==SYS_COMMAND_UPDATE_RECORD || resPacket.GetCmdType()==SERVER_COMMAND_UPDATE_RECORD)
		{
			int val = resPacket.ReadInt();
			if(val == -1)
			{
				g_pErrorLog->logMsg("Update userinfo err");
			}
		}
		else
		{
			g_pErrorLog->logMsg("GetRet invalid cmd:[%d]", resPacket.GetCmdType());
		}
	}
}

