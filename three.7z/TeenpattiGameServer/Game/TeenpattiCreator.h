#ifndef BOYAA_LANDLORD_H_20091111
#define BOYAA_LANDLORD_H_20091111

#include "Creator.h"
#include "TeenpattiTable.h"
#include "TeenpattiUser.h"
#include "TeenpattiSendPacket.h"
#include "TeenpattiParsePacket.h"

class CLandlordCreator : public CCreator
{
public:
	virtual ~CLandlordCreator(){}
	virtual CGameTable* CreateTable(CGameServer* pServer, TableData *pInfo, int nId)
	{
		return new CTeenpattiTable(pServer, pInfo, nId);
	}

	virtual CGameUser* CreateUser(CGameServer* pServer, CGameTable *pTable, int nUserID,  DWORD dwSessionID, string strUserInfo)
	{
		return new CTeenpattiUser(pServer, pTable, nUserID, dwSessionID, strUserInfo);
	}
	
	virtual CSendPacket* CreateSendPacket(UserIdMap &list, CGameServer* pServer)
	{
		return new CTeenpattiSendPacket(list, pServer);
	}

	virtual CProcessPacket* CreateProcessPacket(CGameServer* pServer)
	{
		return new CLandlordParsePacket(pServer);
	}
};
#endif

