#include "ActivityServerHandler.h"
#include "ActivityServer.h"
#include "TeenpattiCmd.h"
#include "GameCmd.h"

CActivityServerHandler::CActivityServerHandler(void)
{
	m_bConntected = false;
}

CActivityServerHandler::CActivityServerHandler(CActivityServer* pActivityServer)
{
	m_pActivityServer = pActivityServer;
}

CActivityServerHandler::~CActivityServerHandler(void)
{
}


int CActivityServerHandler::Send(ActivityServerOutputPacket *pPacket, int delete_buffer, int close_flag)
{
	return ICHAT_TCP_Handler<>::Send(pPacket->packet_buf(), pPacket->packet_size(), delete_buffer, close_flag);
}
////////////////////////////////////////////////////////////////////////////////
// OnParser(char *buf, int nLen)
////////////////////////////////////////////////////////////////////////////////
int CActivityServerHandler::OnParser(char *buf, int nLen)
{
	(void)buf;
	(void)nLen;
	return 0;
}
////////////////////////////////////////////////////////////////////////////////
// OnPacketComplete ��Ӧ���
////////////////////////////////////////////////////////////////////////////////
int CActivityServerHandler::OnPacketComplete(ActivityServerInputPacket *pPacket)
{
	return ProcessPacket(pPacket);
}

int CActivityServerHandler::ProcessPacket(ActivityServerInputPacket* pPacket)
{
	(void)pPacket;
	return 0;
}

////////////////////////////////////////////////////////////////////////////////
// OnClose(void)
////////////////////////////////////////////////////////////////////////////////
int CActivityServerHandler::OnClose(void)
{
	//����״̬��0 ����������ʱ����
	if(m_bConntected)	
	{
		m_bConntected = false;
		ACE_DEBUG((LM_DEBUG, ACE_TEXT("[%D]:(%P|%t) ActivityServer close.Trying to reconnect\r\n")));
	}	
	this->StopTimer();
	this->StartTimer(1);
	return 1;  //only close , but not remove Reactor
}

////////////////////////////////////////////////////////////////////////////////
// OnConnected(void)
////////////////////////////////////////////////////////////////////////////////
int CActivityServerHandler::OnConnected(void)
{
	m_bConntected = true;
	this->StopTimer();
	ACE_DEBUG((LM_DEBUG, ACE_TEXT("[%D]:(%P|%t) ActivityServer Connect ok\r\n")));
	return 0;
}

int CActivityServerHandler::OnTimer(const void *)
{
	if(m_pActivityServer == NULL)
	{
		ACE_DEBUG((LM_DEBUG, ACE_TEXT("[%D]:(%P|%t) ActivityServer\r\n")));
		return -1;
	}
	ACE_DEBUG((LM_DEBUG, ACE_TEXT("[%D]:(%P|%t) connecting ActivityServer\r\n")));
	m_pActivityServer->Reconnect();
	return 0;
}

