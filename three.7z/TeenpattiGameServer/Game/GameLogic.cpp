#include "GameLogic.h"
#include "TeenpattiRandom.h"
//////////////////////////////////////////////////////////////////////////
//��̬����

#include "clib_log.h"
extern clib_log* g_pErrorLog;
extern clib_log* g_pDebugLog;

//�˿�����
const BYTE	CGameLogic::m_bCardListData[CARD_COUNT]=
{
	0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,	//���� A - K (14,15,3,4,5,...13)
	0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,0x19,0x1A,0x1B,0x1C,0x1D,	//÷�� A - K (14,15,3,4,5,...13)
	0x21,0x22,0x23,0x24,0x25,0x26,0x27,0x28,0x29,0x2A,0x2B,0x2C,0x2D,	//���� A - K (14,15,3,4,5,...13)
	0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x3A,0x3B,0x3C,0x3D,	//���� A - K (14,15,3,4,5,...13)
};

//////////////////////////////////////////////////////////////////////////

//���캯��
CGameLogic::CGameLogic()
{
	srand((unsigned)time(0));
}

//��������
CGameLogic::~CGameLogic()
{
}

//��ȡ����
BYTE CGameLogic::GetCardType(const BYTE bCardData[], BYTE bCardCount)
{
	if( bCardCount != USERCARD_MAX_COUNT) 
	{
		g_pErrorLog->logMsg("----------- GetCardType end 1 ---------------");
		return CT_INVALID;
	}
	
	SortCardList((BYTE*)bCardData, bCardCount);

	for (int i = 0; i < 3; ++i)
	{
		g_pErrorLog->logMsg("card bCardValue : %d",GetCardLogicValue(bCardData[i]));
		g_pErrorLog->logMsg("card bCardColor : %d",GetCardColor(bCardData[i]));
	}

	if ( GetCardLogicValue(bCardData[0]) == GetCardLogicValue(bCardData[1]) && 
		GetCardLogicValue(bCardData[0]) == GetCardLogicValue(bCardData[2]) )
	{
		g_pErrorLog->logMsg("----------- GetCardType end 2 ---------------");
		return CT_THREE;
	}

	if (( GetCardLogicValue(bCardData[0]) == GetCardLogicValue(bCardData[1]) ||
		GetCardLogicValue(bCardData[0]) == GetCardLogicValue(bCardData[2]) ) || 
		(GetCardLogicValue(bCardData[1]) == GetCardLogicValue(bCardData[2])) )
	{
		g_pErrorLog->logMsg("----------- GetCardType end 3 ---------------");
		return CT_DOUBLE;
	}

	if ( GetCardColor(bCardData[0]) == GetCardColor(bCardData[1]) && 
		GetCardColor(bCardData[0]) == GetCardColor(bCardData[2]) )
	{
		if (GetCardLogicValue(bCardData[0]) == 14)			// A 2 3 ��ͬ��˳
		{
			if ( ( GetCardLogicValue(bCardData[1]) == 3 )
				&& ( GetCardLogicValue(bCardData[2]) == 2 ) )
			{
				g_pErrorLog->logMsg("----------- GetCardType end 4 ---------------");
				return CT_TEENPATTI_LINE;
			}
			else if ( ( GetCardLogicValue(bCardData[1]) == 13 )   // A K Q ��ͬ��˳
				&& ( GetCardLogicValue(bCardData[2]) == 12 ) )
			{
				g_pErrorLog->logMsg("----------- GetCardType end 5 ---------------");
				return CT_TEENPATTI_LINE;
			}
			else
			{
				g_pErrorLog->logMsg("----------- GetCardType end 6 ---------------");
				return CT_TEENPATTI;
			}

		}
		else if (  (GetCardLogicValue(bCardData[0]) == GetCardLogicValue(bCardData[1]) + 1)  //�������͵�ͬ��˳
			&& (GetCardLogicValue(bCardData[1]) == GetCardLogicValue(bCardData[2]) + 1) )
		{
			g_pErrorLog->logMsg("----------- GetCardType end 7 ---------------");
			return CT_TEENPATTI_LINE;
		}
		else
		{
			g_pErrorLog->logMsg("----------- GetCardType end 8 ---------------");
			return CT_TEENPATTI;
		}
	}
	else
	{
		if (GetCardLogicValue(bCardData[0]) == 14)			// A 2 3 ��˳��
		{
			if ( ( GetCardLogicValue(bCardData[1]) == 3 )
				&& ( GetCardLogicValue(bCardData[2]) == 2 ) )
			{
				g_pErrorLog->logMsg("----------- GetCardType end 9 ---------------");
				return CT_ONE_LINE;
			}
			else if ( ( GetCardLogicValue(bCardData[1]) == 13 )		 // A K Q ��˳��
				&& ( GetCardLogicValue(bCardData[2]) == 12 ) )
			{
				g_pErrorLog->logMsg("----------- GetCardType end 10 ---------------");
				return CT_ONE_LINE;
			}
			else
			{
				g_pErrorLog->logMsg("----------- GetCardType end 11 ---------------");
				return CT_SINGLE;
			}
		}
		else if ( (GetCardLogicValue(bCardData[0]) == GetCardLogicValue(bCardData[1]) + 1)  //�������͵�˳��
			&& (GetCardLogicValue(bCardData[1]) == GetCardLogicValue(bCardData[2]) + 1) )
		{
			g_pErrorLog->logMsg("----------- GetCardType end 12 ---------------");
			return CT_ONE_LINE;
		}
		else
		{
			if ( GetCardLogicValue(bCardData[0]) == 5 && GetCardLogicValue(bCardData[1]) == 3 && 
			 	GetCardLogicValue(bCardData[2]) == 2 )
			{
				g_pErrorLog->logMsg("----------- GetCardType end 13 ---------------");
				return CT_SPECIAL;
			}
			else
			{
				g_pErrorLog->logMsg("----------- GetCardType end 14 ---------------");
				return CT_SINGLE;
			}
		}
	}

	g_pErrorLog->logMsg("----------- GetCardType end ---------------");

	return CT_INVALID;
}

//�����˿�(�Ӵ�С)
void CGameLogic::SortCardList(BYTE bCardData[], BYTE bCardCount)
{
	//ת����ֵ
	BYTE bLogicVolue[USERCARD_MAX_COUNT];
	for (BYTE i=0;i<bCardCount;i++)	bLogicVolue[i]=GetCardLogicValue(bCardData[i]);

	//�������
	bool bSorted=true;
	BYTE bTempData,bLast=bCardCount-1;
	do
	{
		bSorted=true;
		for (BYTE i=0;i<bLast;i++)
		{
			if ((bLogicVolue[i]<bLogicVolue[i+1])||
			   ((bLogicVolue[i]==bLogicVolue[i+1])&&(bCardData[i]<bCardData[i+1])))
			{
				//����λ��
				bTempData=bCardData[i];
				bCardData[i]=bCardData[i+1];
				bCardData[i+1]=bTempData;
				bTempData=bLogicVolue[i];
				bLogicVolue[i]=bLogicVolue[i+1];
				bLogicVolue[i+1]=bTempData;
				bSorted=false;
			}	
		}
		bLast--;
	} while(bSorted==false);

	return;
}

//�����˿�
void CGameLogic::RandCardList(BYTE bCardBuffer[], BYTE bBufferCount)
{
	//����׼��
	BYTE bCardData[sizeof(m_bCardListData)];
	CopyMemory(bCardData,m_bCardListData,sizeof(m_bCardListData));

	//�����˿�
	BYTE bRandCount=0,bPosition=0;
	do
	{
		bPosition=rand()%(bBufferCount-bRandCount);
		bCardBuffer[bRandCount++]=bCardData[bPosition];
		bCardData[bPosition]=bCardData[bBufferCount-bRandCount];
	} while (bRandCount<bBufferCount);

	return;
}

//�߼���ֵ
BYTE CGameLogic::GetCardLogicValue(BYTE bCardData)
{
	//�˿�����
	BYTE bCardValue=GetCardValue(bCardData);

	//ת����ֵ
	return (bCardValue<2 && bCardValue>0)?(bCardValue+13):bCardValue;
}

//�Ա��˿�
BYTE CGameLogic::CompareCard(BYTE bFirstList[], BYTE bNextList[], BYTE bFirstCount, BYTE bNextCount)
{
	//first > next return true or false
	//��ȡ����
	BYTE bNextType=GetCardType(bNextList,bNextCount);
	BYTE bFirstType=GetCardType(bFirstList,bFirstCount);

	SortCardList(bFirstList, bFirstCount);
	SortCardList(bNextList, bNextCount);

	BYTE byComResult = 0;	

	//�����ж�
	if (bFirstType==CT_INVALID) 
	{
		g_pErrorLog->logMsg("----------- CGameLogic CompareCard end 1 ---------------");
		return 1;						//first < next
	}
		

	if ( bFirstType == bNextType )
	{
		if ( ( bFirstType == CT_SINGLE ) || ( bFirstType == CT_TEENPATTI ) )
		{
			g_pErrorLog->logMsg("----------- CGameLogic CompareCard end 2 ---------------");
			return CompareSingl( bFirstList, bNextList);
		}

		if ( bFirstType == CT_DOUBLE )
		{
			g_pErrorLog->logMsg("----------- CGameLogic CompareCard end 3 ---------------");
			return CompareDouble( bFirstList, bNextList);
		}
		
		if ( ( bFirstType == CT_ONE_LINE ) || ( bFirstType == CT_TEENPATTI_LINE ))  //������ͬ���
		{
			g_pErrorLog->logMsg("----------- CGameLogic CompareCard end 4 ---------------");
			return CompareLine(bFirstList, bNextList);
		}

		if ( GetCardLogicValue(bFirstList[0]) > GetCardLogicValue(bNextList[0]) )
		{
			g_pErrorLog->logMsg("----------- CGameLogic CompareCard end 5 ---------------");
			return 2;   //first > next
		}
		else if ( GetCardLogicValue(bFirstList[0]) == GetCardLogicValue(bNextList[0]) )
		{
			g_pErrorLog->logMsg("----------- CGameLogic CompareCard end 6 ---------------");
			return 3;
		}
		else
		{
			g_pErrorLog->logMsg("----------- CGameLogic CompareCard end 7 ---------------");
			return 1;
		}
	}
	else
	{
		if (  ( IsThreeA(bFirstList, 3) ) && ( bNextType == CT_SPECIAL ) )
		{
			g_pErrorLog->logMsg("----------- CGameLogic CompareCard end 8 ---------------");
			return 1;
		}

		if ( ( bFirstType == CT_SPECIAL ) && ( IsThreeA(bNextList, 3) ) )
		{
			g_pErrorLog->logMsg("----------- CGameLogic CompareCard end 9 ---------------");
			return 2;
		}

		if ( bFirstType > bNextType )
		{
			g_pErrorLog->logMsg("----------- CGameLogic CompareCard end 10 ---------------");
			return 2;
		}
		else
		{
			g_pErrorLog->logMsg("----------- CGameLogic CompareCard end 11 ---------------");
			return 1;
		}
	}
}

bool CGameLogic::IsThreeA(const BYTE byCardList[], const BYTE byCardCount)
{
	g_pErrorLog->logMsg("----------- CGameLogic IsThreeA Begin ---------------");
	int nCardCount = 0;

	for (int i = 0; i < byCardCount; ++i)
	{
		if ( GetCardLogicValue(byCardList[i]) == 14 )
		{
			nCardCount++;
		}
	}

	if ( nCardCount == 3 )
	{
		g_pErrorLog->logMsg("----------- CGameLogic IsThreeA end 1 ---------------");
		return true;
	}

	g_pErrorLog->logMsg("----------- CGameLogic IsThreeA end  ---------------");
	return false;
}

BYTE CGameLogic::CompareSingl( const BYTE bFirstList[], const BYTE bNextList[] )
{
	if ( GetCardLogicValue(bFirstList[0]) == GetCardLogicValue(bNextList[0]) )
	{
		if ( GetCardLogicValue(bFirstList[1]) > GetCardLogicValue(bNextList[1]) )
		{
			g_pErrorLog->logMsg("----------- CGameLogic CompareSingl end 1 ---------------");
			return 2;
		}
		else if ( GetCardLogicValue(bFirstList[1]) < GetCardLogicValue(bNextList[1]) )
		{
			g_pErrorLog->logMsg("----------- CGameLogic CompareSingl end 2 ---------------");
			return 1;
		}
		else
		{
			if ( GetCardLogicValue(bFirstList[2]) > GetCardLogicValue(bNextList[2]) )
			{
				g_pErrorLog->logMsg("----------- CGameLogic CompareSingl end 3 ---------------");
				return 2;
			}
			else if ( GetCardLogicValue(bFirstList[2]) < GetCardLogicValue(bNextList[2]) )
			{
				g_pErrorLog->logMsg("----------- CGameLogic CompareSingl end 4 ---------------");
				return 1;
			}
			else
			{
				g_pErrorLog->logMsg("----------- CGameLogic CompareSingl end 5 ---------------");
				return 3;
			}
		}
	}
	else if ( GetCardLogicValue(bFirstList[0]) > GetCardLogicValue(bNextList[0]) )
	{
		g_pErrorLog->logMsg("----------- CGameLogic CompareSingl end 6 ---------------");
		return 2;
	}
	else
	{
		g_pErrorLog->logMsg("----------- CGameLogic CompareSingl end 7 ---------------");
		return 1;
	}
}

BYTE CGameLogic::CompareDouble(const BYTE bFirstList[], const BYTE bNextList[])
{
	g_pErrorLog->logMsg("----------- CGameLogic::CompareDouble Begin ---------------");

	BYTE byFirstCard = GetSameCard(bFirstList);
	BYTE byNextCard = GetSameCard(bNextList);

	if ( GetCardLogicValue(byFirstCard) > GetCardLogicValue(byNextCard) )
	{
		g_pErrorLog->logMsg("----------- CGameLogic::CompareDouble end 1 ---------------");
		return 2;
	}
	else if ( GetCardLogicValue(byFirstCard) < GetCardLogicValue(byNextCard))
	{
		g_pErrorLog->logMsg("----------- CGameLogic::CompareDouble end 2 ---------------");
		return 1;
	}
	else
	{
		BYTE byFirst = GetDiffCard(bFirstList, byFirstCard);
		BYTE byNext = GetDiffCard(bNextList, byNextCard);

		if ( GetCardLogicValue(byFirst) > GetCardLogicValue(byNext) )
		{
			g_pErrorLog->logMsg("----------- CGameLogic::CompareDouble end 3 ---------------");
			return 2;
		}
		else if ( GetCardLogicValue(byFirst) < GetCardLogicValue(byNext) )
		{
			g_pErrorLog->logMsg("----------- CGameLogic::CompareDouble end 4 ---------------");
			return 1;
		}
		else
		{
			g_pErrorLog->logMsg("----------- CGameLogic::CompareDouble end 5 ---------------");
			return 3;
		}
	}

	g_pErrorLog->logMsg("----------- CGameLogic::CompareDouble end ---------------");
}

bool CGameLogic::IsSmallLine(const BYTE bCardList[])			
{
	g_pErrorLog->logMsg("----------- CGameLogic CompareLine begin ---------------");

	if ( ( GetCardLogicValue(bCardList[0]) == 14 ) && 
		( GetCardLogicValue(bCardList[1]) == 3 ) && 
		( GetCardLogicValue(bCardList[2]) == 2 ) )
	{
		g_pErrorLog->logMsg("----------- CGameLogic CompareLine end 1 ---------------");
		return true;
	}
	g_pErrorLog->logMsg("----------- CGameLogic CompareLine end ---------------");
	return false;
}

BYTE CGameLogic::CompareLine(const BYTE bFirstList[], const BYTE bNextList[])
{
	g_pErrorLog->logMsg("----------- CGameLogic CompareCard begin ---------------");

	if ( IsSmallLine(bFirstList) &&  IsSmallLine(bNextList) )
	{
		g_pErrorLog->logMsg("----------- CGameLogic CompareCard end 1 ---------------");
		return 3;
	}

	if ( IsSmallLine(bFirstList) )
	{
		g_pErrorLog->logMsg("----------- CGameLogic CompareCard end 2 ---------------");
		return 1;
	}

	if ( IsSmallLine(bNextList) )
	{
		g_pErrorLog->logMsg("----------- CGameLogic CompareCard end 3 ---------------");
		return 2;
	}

	if  ( GetCardLogicValue(bFirstList[0]) > GetCardLogicValue(bNextList[0]) ) 
	{
		g_pErrorLog->logMsg("----------- CGameLogic CompareLine end 5 ---------------");
		return 2;
	}
	else if ( GetCardLogicValue(bFirstList[0]) < GetCardLogicValue(bNextList[0]) ) 
	{
		g_pErrorLog->logMsg("----------- CGameLogic CompareLine end 6 ---------------");
		return 1;
	}
	else
	{
		g_pErrorLog->logMsg("----------- CGameLogic CompareCard end 7 ---------------");
		return 3;
	}

	g_pErrorLog->logMsg("----------- CGameLogic CompareCard end ---------------");
}

BYTE CGameLogic::GetSameCard(const BYTE bCardList[])
{
	g_pErrorLog->logMsg("----------- CGameLogic::GetSameCard Begin ---------------");

	BYTE byCard = bCardList[0];
	int nSame = 0;

	for ( BYTE i=1; i<3; i++ )
	{
		if ( GetCardLogicValue(byCard) == GetCardLogicValue(bCardList[i]) )
		{
			nSame ++;
		}
	}

	g_pErrorLog->logMsg("nSame : %d",nSame);

	if ( nSame > 0 )
	{
		return byCard;
	}
	else
	{
		return bCardList[1];
	}

	g_pErrorLog->logMsg("----------- CGameLogic::GetSameCard end ---------------");
}

BYTE CGameLogic::GetDiffCard(const BYTE bCardList[], const BYTE byCard)
{
	g_pErrorLog->logMsg("----------- CGameLogic::GetDiffCard Begin ---------------");

	for ( BYTE i=0; i<3; i++ )
	{
		if ( GetCardLogicValue(byCard) != GetCardLogicValue(bCardList[i]) )
		{
			return bCardList[i];
		}
	}

	g_pErrorLog->logMsg("----------- CGameLogic::GetDiffCard end ---------------");
	
	return CT_INVALID;
}

bool CGameLogic::IsSingleLowJ(const BYTE bCardList[])
{
	g_pErrorLog->logMsg("----------- CGameLogic IsSingleLowJ begin ---------------");

	SortCardList(bCardList, 3);

	for (int i = 0; i < 3; ++i)
	{
		g_pErrorLog->logMsg("bCardList [0x%x]",bCardList[i]);
	}
	
	if ( GetCardLogicValue(bCardList[0]) <= 11 ) 
	{
		g_pErrorLog->logMsg("----------- CGameLogic IsSingleLowJ end 1 ---------------");
		return true;
	}
	g_pErrorLog->logMsg("----------- CGameLogic IsSingleLowJ end ---------------");
	return false;
}
	
bool CGameLogic::IsSingleBigQ(const BYTE bCardList[])
{
	g_pErrorLog->logMsg("----------- CGameLogic IsSingleBigQ begin ---------------");

	SortCardList(bCardList, 3);

	for (int i = 0; i < 3; ++i)
	{
		g_pErrorLog->logMsg("bCardList [0x%x]",bCardList[i]);
	}
	
	if ( GetCardLogicValue(bCardList[0]) >= 12 ) 
	{
		g_pErrorLog->logMsg("----------- CGameLogic IsSingleBigQ end 1 ---------------");
		return true;
	}
	g_pErrorLog->logMsg("----------- CGameLogic IsSingleBigQ end ---------------");
	return false;
}

bool CGameLogic::IsDoubleLowA(const BYTE bCardList[])
{
	g_pErrorLog->logMsg("----------- CGameLogic IsDoubleLowA begin ---------------");

	for (int i = 0; i < 3; ++i)
	{
		g_pErrorLog->logMsg("bCardList [0x%x]",bCardList[i]);
	}
	
	BYTE byCard = GetSameCard(bCardList);

	g_pErrorLog->logMsg("byCard [0x%x]",byCard);

	if ( GetCardLogicValue(byCard) <= 10 ) 
	{
		g_pErrorLog->logMsg("----------- CGameLogic IsDoubleLowA end 1 ---------------");
		return true;
	}
	g_pErrorLog->logMsg("----------- CGameLogic IsDoubleLowA end ---------------");
	return false;
}
