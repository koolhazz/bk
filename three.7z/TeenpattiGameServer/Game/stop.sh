sudo killall LandlordServer
