#ifndef BOYAA_LANDLORD_HALLSERVER_H_20100430
#define BOYAA_LANDLORD_HALLSERVER_H_20100430

#include "HallSocketHandler.h"
#include "ACE_Application.h"
#include "TeenpattiTable.h"


typedef ACE_Connector<HallSocketHandler, ACE_SOCK_CONNECTOR> HallServerConnector;

class CTeenpattiServer;
class CTeenpattiHallServer
{
public:
	CTeenpattiHallServer(CTeenpattiServer* pServer);
	~CTeenpattiHallServer();

	//��ʼ������
	int	InitConnect(ACE_INET_Addr &, ACE_Reactor * = ACE_Reactor::instance());

	//��ʼ������
	int	InitConnect(const char * strPath = "GameServer.ini");

	//hallserver�ر��Զ�����
	void Reconnect(void);
	//��������״̬
	bool IsConnected(void){return m_SocketHandler.IsConnected();}

	void ReportServerData();
	void SendPortIPToHall();
	void SendRetireToHall(int nRetire);
	int ReportSelfRetireStatus();

	void UpdateRoomUserCount(CTeenpattiTable* pLandlordTable);

	void ReportEnterRoom(int uid, int tid);
	void ReportLeaveRoom(int uid);
	void ReportStandRoom(int uid, int tid);
	void StandTableLeaveRoom(int nUserId);

	int CreatePrivateRoom(int nRoomId, int nRoomType, int nBaseChip, string sRoomName, string sPassword);

private:
	HallServerConnector	m_Connector;
	HallSocketHandler m_SocketHandler;
	CTeenpattiServer* m_pLandlordServer;
};
#endif

