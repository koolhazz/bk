#include "SocketHandler.h"
#include "TeenpattiParsePacket.h"
#include "TeenpattiServer.h"
#include "SystemCmd.h"

#include <arpa/inet.h>

#include "clib_log.h"
extern clib_log* g_pDebugLog;
extern clib_log* g_pErrorLog;

CLandlordParsePacket::CLandlordParsePacket(CGameServer* pServer):CProcessPacket(pServer)
{
	m_pLandlordServer= dynamic_cast<CTeenpattiServer *>(pServer);
}

CLandlordParsePacket::~CLandlordParsePacket()
{

}

int CLandlordParsePacket::ProcExtendCmd(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	short nCmdType = pPackage->GetCmdType();
	switch (nCmdType)
	{
	case CLIENT_COMMAND_SIT:						//�������
		return OnUserSit(pPackage, pSocket);
	case CLIENT_COMMAND_WATCH_CARD:
		return OnUserWatchCard(pPackage, pSocket);
	case CLIENT_COMMAND_DISCARD:
		return OnUserDisCard(pPackage, pSocket);
	case CLIENT_COMMAND_CINGL:
		return OnUserCingl(pPackage, pSocket);
	case CLIENT_COMMAND_ADD_CINGL:
		return OnUserAddCingl(pPackage, pSocket);
	case CLIENT_COMMAND_COMPARE_CARD:
		return OnUserCompareCard(pPackage, pSocket);
	case CLIENT_COMMAND_SEND_BOX:
		return OnWriteActivetime(pPackage, pSocket);
	case CLIENT_COMMAND_SEND_WRITETIME:
		return OnWriteTime(pPackage,pSocket);
	case CLIENT_COMMAND_CALL_DOWN:
		return OnUserCallDown(pPackage, pSocket);
	case CLINET_COMMAND_UPDATE_USERINFO:
		return OnUserUpdateUserInfo(pPackage, pSocket);
	case CLIENT_COMMAND_ALL_IN:
		return OnUserAllIn(pPackage, pSocket);
	case CLIENT_COMMAND_STAND:
		return OnUserStand(pPackage, pSocket);
	case CLIENT_COMMAND_BREAK_TIME:
		return OnUserSendBreakTime(pPackage, pSocket);
	case CLINET_COMMAND_UPDATE_USER_MONEY:
		return OnUserUpdateUserMoney(pPackage, pSocket);
	case CLINET_COMMAND_ALLIN_MONEY:
		return OnUserAllInMoney(pPackage, pSocket);
	case CLINET_COMMAND_ACCEPT_ALLIN:
		return OnUserAcceptAllInMoney(pPackage, pSocket);
	case CLINET_COMMAND_OPER_ALLIN:
		return OnUserAcceptOperAllIn(pPackage, pSocket);
	default:
		g_pErrorLog->logMsg("Unkown Cmd, nCmdType:[0x%x]", nCmdType);
		break;
	}
	return 0;
}

int CLandlordParsePacket::OnUserSit(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	BYTE bySeatId = pPackage->ReadByte();
	return m_pLandlordServer->ProcUserSit(pSocket->GetUser(), bySeatId);
}

int CLandlordParsePacket::OnUserUpdateUserInfo(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	string strUserInfo = pPackage->ReadString();
	return m_pLandlordServer->ProcUpdateUserInfo(pSocket->GetUser(), strUserInfo);
}

int CLandlordParsePacket::OnUserWatchCard(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	(void)pPackage;
	return m_pLandlordServer->ProcUserWatchCard(pSocket->GetUser());
}

int CLandlordParsePacket::OnUserDisCard(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	(void)pPackage;
	return m_pLandlordServer->ProcUserDisCard(pSocket->GetUser());
}

int CLandlordParsePacket::OnUserCingl(NETInputPacket *pPackage, SocketHandler *pSocket)
{
   	long nMoney = pPackage->ReadLong();
	
	return m_pLandlordServer->ProcUserCingl(pSocket->GetUser(), nMoney);
}

int CLandlordParsePacket::OnWriteActivetime(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	(void)pPackage;
	return m_pLandlordServer->ProcWriteActivetime(pSocket->GetUser());
}

int CLandlordParsePacket::OnWriteTime(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	(void)pPackage;
	return m_pLandlordServer->ProcUserTime(pSocket->GetUser());
}

int CLandlordParsePacket::OnUserAddCingl(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	long nAddMoney = pPackage->ReadLong();
	return m_pLandlordServer->ProcUserAddCingl(pSocket->GetUser(), nAddMoney);
}

int CLandlordParsePacket::OnUserCompareCard( NETInputPacket *pPackage, SocketHandler *pSocket )
{
	int nComparedId = pPackage->ReadInt();
	return m_pLandlordServer->ProcUserCompareCard(pSocket->GetUser(), nComparedId);
}

int CLandlordParsePacket::OnUserCallDown(NETInputPacket* pPackage, SocketHandler *pSocket)
{
	BYTE byType = pPackage->ReadByte();
	return m_pLandlordServer->ProcUserCallDown(pSocket->GetUser(), byType);
}

int CLandlordParsePacket::OnUserAllIn(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	(void)pPackage;
	(void)pSocket;
	return 0;
}

int CLandlordParsePacket::OnUserStand(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	(void)pPackage;
	(void)pSocket;
	return m_pLandlordServer->ProcUserStand(pSocket->GetUser());
}

int CLandlordParsePacket::OnUserSendBreakTime(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	(void)pPackage;
	return m_pLandlordServer->ProcUserBreakTime(pSocket->GetUser());
}

int CLandlordParsePacket::OnUserUpdateUserMoney(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	int nUserId = pPackage->ReadInt();
	g_pErrorLog->logMsg("nUserId:%d",nUserId);
	return m_pLandlordServer->ProcUserUpdateMoney(nUserId);
}

int CLandlordParsePacket::OnUserAllInMoney(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	return m_pLandlordServer->ProcUserAllInMoney(pSocket->GetUser());
}

int CLandlordParsePacket::OnUserAcceptAllInMoney(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	BYTE byAccpt = pPackage->ReadByte();
	return m_pLandlordServer->ProcAcceptAllInMoney(pSocket->GetUser(), byAccpt);
}

int CLandlordParsePacket::OnUserAcceptOperAllIn(NETInputPacket *pPackage, SocketHandler *pSocket)
{
	BYTE byOperAllIn = pPackage->ReadByte();
	return m_pLandlordServer->ProcAcceptOperAllIn(pSocket->GetUser(), byOperAllIn);
}