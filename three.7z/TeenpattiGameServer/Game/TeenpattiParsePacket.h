#ifndef BOYAA_LANDLORD_PARSE_PACKET_H_20091111
#define BOYAA_LANDLORD_PARSE_PACKET_H_20091111

#include "ProcessPacket.h"
#include "TeenpattiCmd.h"

class CTeenpattiServer;
class CLandlordParsePacket:public CProcessPacket
{
public:
	CLandlordParsePacket(CGameServer* pServer);
	~CLandlordParsePacket();

	virtual int ProcExtendCmd(NETInputPacket *pPackage, SocketHandler *pSocket);

	int OnUserSit(NETInputPacket *pPackage, SocketHandler *pSocket);
	int OnUserWatchCard(NETInputPacket *pPackage, SocketHandler *pSocket);
	int OnUserDisCard(NETInputPacket *pPackage, SocketHandler *pSocket);
	int OnUserCingl(NETInputPacket *pPackage, SocketHandler *pSocket);
	int OnUserAddCingl(NETInputPacket *pPackage, SocketHandler *pSocket);
	int OnUserAllIn(NETInputPacket *pPackage, SocketHandler *pSocket);
	int OnUserStand(NETInputPacket *pPackage, SocketHandler *pSocket);
	int OnUserSendBreakTime(NETInputPacket *pPackage, SocketHandler *pSocket);
	int OnUserUpdateUserMoney(NETInputPacket *pPackage, SocketHandler *pSocket);

	int OnUserCompareCard(NETInputPacket *pPackage, SocketHandler *pSocket);
	int OnWriteActivetime(NETInputPacket *pPackage, SocketHandler *pSocket);
	int OnWriteTime(NETInputPacket *pPackage, SocketHandler *pSocket); 
	int OnUserCallDown(NETInputPacket* pPackage, SocketHandler *pSocket);
	int OnUserUpdateUserInfo(NETInputPacket *pPackage, SocketHandler *pSocket);
	int OnUserAllInMoney(NETInputPacket *pPackage, SocketHandler *pSocket);
	int OnUserAcceptAllInMoney(NETInputPacket *pPackage, SocketHandler *pSocket);
	int OnUserAcceptOperAllIn(NETInputPacket *pPackage, SocketHandler *pSocket);

	int OnProcUpdateUserMoneyInfo(NETInputPacket *pPackage, SocketHandler *pSocket);
private:
	CTeenpattiServer* m_pLandlordServer;
};

#endif

