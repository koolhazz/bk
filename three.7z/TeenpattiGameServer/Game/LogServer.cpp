#include "LogServer.h"
#include "ICHAT_HTTP_Config.h"
#include "GameCmd.h"
#include "GameServer.h"
#include "TeenpattiServer.h"
#include <stdio.h>
#include <time.h>

#include "clib_log.h"
extern clib_log* g_pErrorLog;
extern clib_log* g_pDebugLog;

CLogServer::CLogServer():m_SocketHandler(this)
{
}

CLogServer::~CLogServer()
{
}
////////////////////////////////////////////////////////////////////////////////
// ��ʼ��proxy����
////////////////////////////////////////////////////////////////////////////////
int	CLogServer::InitConnect(ACE_INET_Addr &remote, ACE_Reactor *pReactor)
{
	m_Connector.open(pReactor, ACE_NONBLOCK);
	LogSvrSocketHandler *pHandler = &m_SocketHandler;
	pHandler->Addr(remote);    //��������
	int nRet = m_Connector.connect(pHandler, remote, ACE_Synch_Options::synch);
	return nRet;
}

int CLogServer::InitConnect(const char* szHost, const char* szPort)
{
	ACE_INET_Addr userAddr(szPort, szHost);
	InitConnect(userAddr);
	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////
// proxyserver�ر��Զ�����
////////////////////////////////////////////////////////////////////////////////
void CLogServer::Reconnect(void)  //EWOULDBLOCK
{
	LogSvrSocketHandler *pClient = &m_SocketHandler;
	m_Connector.connect(pClient, pClient->Addr(), ACE_Synch_Options::synch);
}

int CLogServer::TransferPacket(NETOutputPacket *pPacket)
{
	if(!IsConnected())
	{
		ACE_DEBUG((LM_INFO, ACE_TEXT("[%D] CLogServer not connect\r\n")));
		return -1;
	}
	m_SocketHandler.Send(pPacket);
	return 0;
}

void CLogServer::ReportPokerLog(CTeenpattiTable* pLandTable)
{
	g_pErrorLog->logMsg("-------------  CLogServer::ReportPokerLog begin ---------------");
	if (!IsConnected())
	{
		g_pErrorLog->logMsg("-------------- CLogServer::ReportPokerLog end 1 ------------");
		return;
	}


	if(pLandTable == NULL)
	{
		g_pErrorLog->logMsg("-------------- CLogServer::ReportPokerLog end 2 ------------");
		return;
	}
		
	
	NETOutputPacket pkg;
	pkg.Begin(LOGSERVER_COMMAND_WRITE_POCKERLOG);
	pkg.WriteString(pLandTable->m_szPokerLog);
	pkg.WriteInt(pLandTable->GetID());
	pkg.WriteShort(pLandTable->m_nTableType);
	pkg.WriteInt(pLandTable->m_nBaseChip);
	pkg.WriteLongLog(pLandTable->m_nPotTotal);

	g_pErrorLog->logMsg("pokerlog[%s],tid[%d],tabletype[%d],basechip[%d],m_nPotTotal[%ld]",pLandTable->m_szPokerLog,pLandTable->GetID(),
		pLandTable->m_nTableType,pLandTable->m_nBaseChip,pLandTable->m_nPotTotal);

	CGameServer * pServer = pLandTable->m_pGameServer;
	if(pServer != NULL)
	{
		pkg.WriteInt(pServer->m_nLevel);
	}
	else
	{
		pkg.WriteInt(-1);
	}

	BYTE byUserCount = pLandTable->GetPlaySitUserCount();
	pkg.WriteByte(byUserCount);

	for (BYTE i=0; i<GAME_PLAYER_COUNT; i++)
	{
		CTeenpattiUser *pUser = (CTeenpattiUser *)pLandTable->GetUserBySeatId(i);
		
		if ( ( pUser != NULL ) && ( pUser->m_nStatus == USER_STATUS_PALY ))
		{
			pkg.WriteInt(pUser->GetUserId());
			pkg.WriteLongLog(pUser->m_nMoney);
			pkg.WriteInt(pUser->m_nWinTimes);
			pkg.WriteInt(pUser->m_nLoseTimes);
			pkg.WriteLongLog(pUser->m_nCostForTable);
			pkg.WriteInt(pUser->m_nTax);
			g_pErrorLog->logMsg("UserId[%d],Money[%d],WinTimes[%d],LoseTimes[%d],CostForTable[%d],Tax[%d]",pUser->GetUserId(),
				pUser->m_nMoney,pUser->m_nWinTimes,pUser->m_nLoseTimes,pUser->m_nCostForTable,pUser->m_nTax);
		}
	}

	pkg.End();
	m_SocketHandler.Send(&pkg);

	g_pErrorLog->logMsg("-------------  CLogServer::ReportPokerLog end ---------------");
}

void CLogServer::ReportDBCenterLog(CTeenpattiTable * pTable)
{
	g_pErrorLog->logMsg("------------- CLogServer::ReportDBCenterLog begin ---------------");
	if(!IsConnected())
	{
		g_pErrorLog->logMsg("------------- CLogServer::ReportDBCenterLog end 1 -------------");
		return;
	}
		
	if(pTable == NULL)
	{
		g_pErrorLog->logMsg("------------- CLogServer::ReportDBCenterLog end 2 -------------");
		return;
	}
		
	
	CTeenpattiServer * pServer = (CTeenpattiServer *)(pTable->m_pGameServer);
	if(pServer == NULL)
	{
		g_pErrorLog->logMsg("------------ CLogServer::ReportDBCenterLog end 3 -------------");
		return;
	}
	

	BYTE byUserCount = pTable->GetPlaySitUserCount();

	for(int i=0; i<GAME_PLAYER_COUNT; ++i)
	{
		CTeenpattiUser * pUser = (CTeenpattiUser *)pTable->GetUserBySeatId(i);
		if ( ( pUser != NULL ) && ( pUser->m_nStatus == USER_STATUS_PALY ))
		{
			NETOutputPacket pkg;
			pkg.Begin(LOGSERVER_COMMAND_WRITE_DBCENTER);
			pkg.WriteInt(pUser->GetUserId());
			pkg.WriteInt(pTable->GetID());
			pkg.WriteInt(pTable->m_nPlayGameTimes);
			pkg.WriteByte(byUserCount);
			pkg.WriteInt(pTable->m_nStartTime);
			pkg.WriteInt(pTable->m_nStopTime);
			pkg.WriteLongLog(pUser->m_nCostForTable);
			pkg.WriteLongLog(pUser->m_nMoney);
			pkg.WriteInt(pUser->m_nTax);
			pkg.WriteInt(pServer->m_nLevel);
			pkg.WriteInt(pTable->m_nBaseChip);
			pkg.WriteInt(pServer->m_LandlordServConf.nRequireChips);
			pkg.WriteInt(pTable->m_nGameWinnerSeatId == i ? 1 : 0);
			g_pErrorLog->logMsg("UserId[%d],tid[%d],GameTimes[%d],UserCount[%d],StartTime[%d],StopTime[%d],CostForTable[%ld],Money[%ld],Tax[%d],Level[%d],basechip[%d],RequireChip[%d],WinnerSeatId[%d]",
			pUser->GetUserId(),pTable->GetID(),pTable->m_nPlayGameTimes,
			byUserCount,pTable->m_nStartTime,pTable->m_nStopTime,pUser->m_nCostForTable,pUser->m_nMoney,pUser->m_nTax,pServer->m_nLevel,
			pTable->m_nBaseChip,pServer->m_LandlordServConf.nRequireChips,pTable->m_nGameWinnerSeatId);
			pkg.End();

			m_SocketHandler.Send(&pkg);	
		}
	}

	g_pErrorLog->logMsg("---------------- CLogServer::ReportDBCenterLog end -------------");
}
