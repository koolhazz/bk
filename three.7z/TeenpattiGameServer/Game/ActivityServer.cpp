#include "ActivityServer.h"
#include "TeenpattiServer.h"
#include "GameCmd.h"
#include "ICHAT_HTTP_Config.h"

CActivityServer::CActivityServer(CTeenpattiServer* pServer):m_SocketHandler(this), m_pLandServer(pServer)
{

}

CActivityServer::~CActivityServer()
{

}
////////////////////////////////////////////////////////////////////////////////
// ��ʼ��proxy����
////////////////////////////////////////////////////////////////////////////////
int	CActivityServer::InitConnect(ACE_INET_Addr &remote, ACE_Reactor *pReactor)
{
	m_Connector.open(pReactor, ACE_NONBLOCK);
	CActivityServerHandler *pHandler = &m_SocketHandler;
	pHandler->Addr(remote);    //��������
	int nRet = m_Connector.connect(pHandler, remote, ACE_Synch_Options::synch);
	return nRet;
}

int CActivityServer::InitConnect( const char * strPath /*= "GameServer.ini"*/ )
{
	ICHAT_HTTP_Config ConfigReader;
	int nRet = ConfigReader.Open(strPath);
	if(nRet == -1)
	{
		return FALSE;
	}

	ACE_Configuration_Section_Key subkey;
	char chActivityServer[32] = {0};
	sprintf(chActivityServer, "ACTIVITYSERVER%d", m_pLandServer->m_nLevel);
	ConfigReader.OpenSection(chActivityServer, subkey);
	char strHost[256] = {0};
	ConfigReader.get_section_string(subkey, "HOST", strHost, 256);
	char strPort[256] = {0};
	ConfigReader.get_section_string(subkey, "PORT", strPort, 256);

	ACE_DEBUG((LM_DEBUG, "%D Connect ActivityServer, HOST:[%s], PORT:[%s]\n", strHost, strPort));

	ACE_INET_Addr hallAddr(strPort, strHost);

	InitConnect(hallAddr);

	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////
// proxyserver�ر��Զ�����
////////////////////////////////////////////////////////////////////////////////
void CActivityServer::Reconnect(void)  //EWOULDBLOCK
{
	CActivityServerHandler *pClient = &m_SocketHandler;
	m_Connector.connect(pClient, pClient->Addr(), ACE_Synch_Options::synch); 
}

void CActivityServer::ReportInfo2ActivityServer(int uid, int win, int lost, int win_money, int lost_money, int active_time) 
{
	if(!m_SocketHandler.IsConnected())
	{
		return;
	}
    NETOutputPacket OutPkg;
    OutPkg.Begin(REPORT_INFO_2_ACTIVITY_SERVER);
    OutPkg.WriteInt(uid);
    OutPkg.WriteInt(win);
    OutPkg.WriteInt(lost);
    OutPkg.WriteInt(win_money);
    OutPkg.WriteInt(lost_money);
    OutPkg.WriteInt(time(0));
    OutPkg.WriteInt(active_time);
    OutPkg.WriteInt(m_pLandServer->m_nLevel);
    OutPkg.End();
    m_SocketHandler.Send(&OutPkg);
}
