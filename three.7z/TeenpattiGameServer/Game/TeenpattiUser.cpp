#include "TeenpattiUser.h"
#include "TeenpattiServer.h"
#include "RedisServer.h"
#include "clib_log.h"

extern clib_log* g_pErrorLog;
extern clib_log* g_pDebugLog;

CTeenpattiUser::CTeenpattiUser(CGameServer* pServer, CGameTable *pTable, int nUserID,  DWORD dwSessionID, string strUserInfo):CGameUser(pServer, pTable, nUserID, dwSessionID, strUserInfo)
{
	m_nActimeTime = 0;
	m_nUnixTime = 0;
	m_nMidTime = 0;
	iTempTime = 0;
	m_bOnline = TRUE;
	m_bRobot = FALSE;
	m_bLooker = FALSE;
	m_nTimoutCall = 0;
	m_KickUserTimer.SetTimeEventObj(this, KICK_USER_TIMER);
	m_RobotSendFaceTimer.SetTimeEventObj(this, SEND_FACE_TIMER);
	m_KickBankruptTimer.SetTimeEventObj(this, KICK_BANKRUPT_TIMER);
	m_RobotAllMoneyTimer.SetTimeEventObj(this, ROBOT_ALL_MONEY);
	ResetUser();
}

CTeenpattiUser::~CTeenpattiUser(void)
{
	ResetUser();
}

void CTeenpattiUser::ResetUser()
{
	m_bCallDownUser = FALSE;
	m_byHandCardCount = 0;
	memset(m_byHandCardData, 0, USER_CARD_COUNT);
	m_KickUserTimer.StopTimer();
	m_bWatchCard = FALSE;
	m_bDisCard = FALSE;				//刚刚进入游戏，做没有弃牌处理
	m_nCostForTable = 0;
	m_nAttr = 0;
	m_nHandMoney = 0;
	m_nStartGameTime = 0;
	m_nTax = 0;
	m_nUpdateMoney = 0;
	m_RobotAllMoneyTimer.StopTimer();
}

void CTeenpattiUser::StartKickUserTimer()
{
	m_KickUserTimer.StartTimer(KICK_USER_TIMEOUT);
}

void CTeenpattiUser::StopKickUserTimer()
{
	m_KickUserTimer.StopTimer();
}

void CTeenpattiUser::ResetKickUserTimer()
{
	StopKickUserTimer();
	StartKickUserTimer();
}

void CTeenpattiUser::StartKickBankruptTimer()
{
	m_KickBankruptTimer.StartTimer(2);
}

void CTeenpattiUser::StartSendFaceTimer()
{
	int nRand = random(30)+20;

	g_pErrorLog->logMsg("StartSendFaceTimer nRand : %d",nRand);
	m_RobotSendFaceTimer.StartTimer(nRand);
}

void CTeenpattiUser::StopSendFaceTimer()
{
	m_RobotSendFaceTimer.StopTimer();
}

void CTeenpattiUser::StartRobotAllMoney()
{
	m_RobotAllMoneyTimer.StartTimer(2);
}

void CTeenpattiUser::StopRobotAllMoney()
{
	m_RobotAllMoneyTimer.StopTimer();
}

int CTeenpattiUser::ProcessOnTimerOut(int Timerid)
{
	CTeenpattiServer* pLandServer = (CTeenpattiServer*)(m_pGameServer);
	switch (Timerid)
	{
	case KICK_USER_TIMER:
		return pLandServer->PocTimeoutKickUser(this);
	case SEND_FACE_TIMER:
		return pLandServer->PocTimeoutRobotSendFace(this);
	case KICK_BANKRUPT_TIMER:
		return pLandServer->PocTimeoutKickBankrupt(this);
	case ROBOT_ALL_MONEY:
		return pLandServer->PocTimeoutRobotAllMoney(this);
	default:
		break;
	}
	return 0;
}
