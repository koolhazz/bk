#ifndef BOYAA_LANDLORD_SEND_PACKET_H_20091111
#define BOYAA_LANDLORD_SEND_PACKET_H_20091111

#include "SendPacket.h"
#include "TeenpattiCmd.h"
#include "TeenpattiTable.h"

#ifndef WIN32
DWORD GetTickCount2();
#endif

class CTeenpattiSendPacket:public CSendPacket
{
public:
	CTeenpattiSendPacket(UserIdMap &list, CGameServer* pServer);
	~CTeenpattiSendPacket(void);
public:
	int SendUserLoginSuccess(SocketHandler* pHandler, CGameUser* pUser);
	int BroadcastUserLogin(CGameTable* pTable, CGameUser* pUser);

	//���´���
	int SendUserSitError(SocketHandler* pHandler, BYTE nErrType, long nMoney);
	int BroadcastUserSitSuccess(CTeenpattiTable* pTable, CGameUser* pUser);

	//����
	int SendDealCard(CTeenpattiTable* pLandTable);

	//���ƴ���
	int SendUserWatchCardError(SocketHandler* pHandler, BYTE nErrType);
	int SendUserWatchCardResult(SocketHandler* pHandler, BYTE * m_byCardData);
	int SendUserWatchCard(CTeenpattiTable *pLandTable, int nUserId);

	//����
	int SendUserDisCardError(SocketHandler* pHandler, BYTE nErrType);
	int SendUserDisCard(CTeenpattiTable *pLandTable, int nUserId, int nNextId, short byCallTimes);

	//��ע����
	int SendUserCinglError(SocketHandler* pHandler, BYTE nErrType);
	int BroadcastUserCingl(CGameTable* pTable, int nUserId, long nMoney, BYTE IsFull, int nNextOutUserId, short byCallTimes);

	//��ע����
	int SendUserAddCinglError(SocketHandler* pHandler, BYTE nErrType);
	int BroadcastUserAddCingl(CGameTable* pTable, int nUserId, long nMoney, BYTE IsFull, int nNextOutUserId, short byCallTimes);

	//���ƴ���
	int SendUserCompareCardError(SocketHandler* pHandler, BYTE nErrType);
	int BroadcastUserCompared(CTeenpattiTable *pLandTable, int nLargerId, int nLessId, int nNextId, long nMoney, int CurId);

	//�����״���
	int SendUserCallDownError(SocketHandler* pHandler, BYTE nErrType);
	int BroadcastUserCallDown(CTeenpattiTable *pLandTable, int nUserId, BYTE byType);

	//����վ��
	int SendUserStandError(SocketHandler* pHandler, BYTE nErrType);
	int BroadcastUserStand(CTeenpattiTable *pLandTable, int nUserId);

	//�˳�����
	int SendUserLogoutError(SocketHandler* pHandler, BYTE nErrType);

	int SendUserAllInError(SocketHandler* pHandler, BYTE nErrType);

	//�Ʋ�����
	int SendUserBankbruck(SocketHandler* pHandler);

	//�㲥��ʼ��Ϸ
	int BroadcastStartGame(CGameTable* pTable);

	//�㲥��ʼ����
	int BroadcastStartPlayCard(CGameTable* pTable, int nStartCallUserId);

	int BroadcastGameOver(CTeenpattiTable* pTable);

	int BroadcastUserMoney(CTeenpattiTable* pTable, int nUserId, long nMoney);

	int BroadcastUserAllInMoney(CTeenpattiTable* pTable, int nActiveUserId, int nUserId);

	int BroadcastAcceptAllInMoney(CTeenpattiTable* pTable, int nUserId, BYTE byAccpt, long nMoney);

	int BroadcastUserOperAllIn(CTeenpattiTable* pTable, int nUserId, BYTE byOperAllIn);

	//���·�����
	int BroadcastGameUpdate(CTeenpattiTable* pLandTable);

	int SendUserTimoutStand(SocketHandler* pHandler);

	//��������Ӧ�ͻ���������
	int ServerSendBreakTime(SocketHandler* pHandle, short nTime);
};

#endif

