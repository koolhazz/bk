#include "TeenpattiTable.h"
#include "TeenpattiCmd.h"
#include "TeenpattiServer.h"
#include "RedisServer.h"
#include <math.h>

#include "clib_log.h"
extern clib_log* g_pErrorLog;
extern clib_log* g_pDebugLog;

#ifndef WIN32
#include <time.h>
#include <sys/time.h>
#include "json.h"

DWORD GetTickCount()
{
	timeval timesnow;
	struct timezone tmpzone;
	gettimeofday(&timesnow,&tmpzone);
	return ((DWORD)(timesnow.tv_sec*1000) + (DWORD)(timesnow.tv_usec/1000));
}
int Getunixtime()
{
	timeval timesnow;
	struct timezone tmpzone;
	gettimeofday(&timesnow,&tmpzone);
	return ((int)(timesnow.tv_sec));
}
#else
#include<stdlib.h>
int Getunixtime()
{
	DWORD start = GetTickCount();
	int time = (int)start / 1000;
	return time;
}
#endif


CTeenpattiTable::CTeenpattiTable(CGameServer* pServer, TableData *pInfo, int nId):CGameTable(pServer, pInfo, nId)
{
	m_nCurCallSeatId = INVAILD_SEAT_ID;
	m_nStartCallSeatId = INVAILD_SEAT_ID;
	ResetTable();
	m_CallCardTimer.SetTimeEventObj(this, CALL_CARD_TIMER);
	m_StartGameTimer.SetTimeEventObj(this, START_GAME_TIMER);
	m_WaitStartGameTimer.SetTimeEventObj(this, WAIT_GAME_START);
	m_CreateRobotTimer.SetTimeEventObj(this, CREAT_ROBOT_TIMER);
	m_RobotCallTimer.SetTimeEventObj(this, CALL_ROBOT_TIMER);
	m_RobotKickTimer.SetTimeEventObj(this, KICK_ROBOT_TIMER);
	m_RobotOperTimer.SetTimeEventObj(this, OPER_ROBOT_TIMER);
	m_nBaseChip = pInfo->nBaseChips;
	m_nRequireChips = pInfo->nRequireChips;
	m_nMaxUserChips = pInfo->nMaxUserChips;
	m_nTableType = pInfo->nTableType;
	m_nTableLevel = pInfo->nTableLevel;
    m_nReadyUserCout = 0;
    m_nGameWinnerSeatId = INVAILD_SEAT_ID;
    m_nPlayGameTimes = 0;
    m_nRobotCount=0;
    m_bComapre = FALSE;
    vec_RobotList.clear();
	strcpy(m_pszPassword, pInfo->pszPassword);
	strcpy(m_pszRoomName, pInfo->pszRoomName);
}

CTeenpattiTable::~CTeenpattiTable(void)
{
	
}

void CTeenpattiTable::StandTable(CGameUser* pLandUser)
{
	g_pErrorLog->logMsg("------------ CTeenpattiTable::StandTable begin ----------");
	UserStand(pLandUser->GetSeatId());
	if ( m_nReadyUserCout > 0 )
	{
		m_nReadyUserCout --;
	}
	pLandUser->Stand();
	g_pErrorLog->logMsg("------------ CTeenpattiTable::StandTable end  ----------");
}

int CTeenpattiTable::GetNextCallUserId()
{
	g_pErrorLog->logMsg("------------ CTeenpattiTable::GetNextCallUserId begin ----------");
	for (int i = 0; i<USER_PLAY_COUNT; i++)
	{
		m_nCurCallSeatId = (++m_nCurCallSeatId) % GAME_PLAYER_COUNT;

		g_pErrorLog->logMsg(" m_nCurCallSeatId [%d], m_nStartCallSeatId [%d]",m_nCurCallSeatId, m_nStartCallSeatId);

		if ( m_nCurCallSeatId == m_nStartCallSeatId )
		{
			m_nCinglTimes ++;
		}

		CTeenpattiUser* pUser = (CTeenpattiUser*)GetUserBySeatId(m_nCurCallSeatId);
		if ( pUser != NULL )
		{
			if ( ( pUser->m_nStatus == USER_STATUS_PALY ) && ( !pUser->m_bDisCard ) )
			{
				g_pErrorLog->logMsg("------------ CTeenpattiTable::GetNextCallUserId end 1 ----------");
				g_pErrorLog->logMsg("nUserId : [%d], m_nStartCallSeatId:[%d]",pUser->GetUserId(),m_nStartCallSeatId);
				return pUser->GetUserId();		
			}
		}
	}
	g_pErrorLog->logMsg("------------ CTeenpattiTable::GetNextCallUserId end ----------");
	return 0;
}

int CTeenpattiTable::GetAllInNextUserId()
{
	g_pErrorLog->logMsg("------------ CTeenpattiTable::GetAllInNextUserId begin ----------");
	for (int i = 0; i<USER_PLAY_COUNT; i++)
	{
		m_nCurCallSeatId = (++m_nCurCallSeatId) % GAME_PLAYER_COUNT;

		g_pErrorLog->logMsg(" m_nCurCallSeatId [%d], m_nStartCallSeatId [%d]",m_nCurCallSeatId, m_nStartCallSeatId);

		CTeenpattiUser* pUser = (CTeenpattiUser*)GetUserBySeatId(m_nCurCallSeatId);
		if ( pUser != NULL )
		{
			if ( ( pUser->m_nStatus == USER_STATUS_PALY ) && ( !pUser->m_bDisCard ) )
			{
				g_pErrorLog->logMsg("------------ CTeenpattiTable::GetAllInNextUserId end 1 ----------");
				g_pErrorLog->logMsg("nUserId : [%d], m_nStartCallSeatId:[%d]",pUser->GetUserId(),m_nStartCallSeatId);
				return pUser->GetUserId();		
			}
		}
	}
	g_pErrorLog->logMsg("------------ CTeenpattiTable::GetAllInNextUserId end ----------");
	return 0;
}

BOOL CTeenpattiTable::StartGame()
{
	g_pErrorLog->logMsg("------------------ CTeenpattiTable::StartGame begin --------------------");
	m_nGameWinnerSeatId = INVAILD_SEAT_ID;
	m_TableStatus = STATUS_PLAY;

	m_GameLogic.RandCardList(m_byCardBuffer, CARD_COUNT);
/*
	BYTE bycard0[3] = {0x22, 0x23, 0x31};
	BYTE bycard1[3] = {0x24, 0x03, 0x02};
	BYTE bycard2[3] = {0x01, 0x33, 0x32};
	BYTE bycard3[3] = {0x15, 0x12, 0x13};
	//BYTE bycard4[3] = {0x21, 0x22, 0x23};
*/

	int nSkipCardCount = 0;
	int nMaxPlayerCount = GetGamePlayerCount();	
	g_pErrorLog->logMsg("nMaxPlayerCount %d",nMaxPlayerCount);
	for (BYTE i=0; i<nMaxPlayerCount; i++)
	{
		CTeenpattiUser* pLandUser = (CTeenpattiUser*)GetUserBySeatId(i);
		if (pLandUser == NULL)
		{
			continue;
		}
		
		(GetUserBySeatId(i))->m_nStatus = USER_STATUS_PALY;
		pLandUser->m_nUnixTime = Getunixtime();
		pLandUser->m_nMidTime = Getunixtime();
		pLandUser->m_nStartGameTime = Getunixtime();

		pLandUser->m_nAttr = 1;
		pLandUser->m_nCostForTable = m_nBaseChip;
		
		pLandUser->m_nMoney -= m_nBaseChip;
		m_nPotTotal += m_nBaseChip;
		m_nHandBet = m_nBaseChip;
		pLandUser->m_nHandMoney = m_nBaseChip;

		g_pErrorLog->logMsg("m_nHandBet %ld， pLandUser->m_nCostForTable %d",m_nHandBet,pLandUser->m_nCostForTable);
/*
		if ( i== 0)
		{
			CopyMemory(pLandUser->m_byHandCardData, bycard0, USERCARD_MAX_COUNT);
			m_GameLogic.SortCardList(pLandUser->m_byHandCardData, USERCARD_MAX_COUNT);
			pLandUser->m_byHandCardCount = USERCARD_MAX_COUNT;
		}
		else if ( i == 1 )
		{
			CopyMemory(pLandUser->m_byHandCardData, bycard1, USERCARD_MAX_COUNT);
			m_GameLogic.SortCardList(pLandUser->m_byHandCardData, USERCARD_MAX_COUNT);
			pLandUser->m_byHandCardCount = USERCARD_MAX_COUNT;
		}
		else if ( i == 2 )
		{
			CopyMemory(pLandUser->m_byHandCardData, bycard2, USERCARD_MAX_COUNT);
			m_GameLogic.SortCardList(pLandUser->m_byHandCardData, USERCARD_MAX_COUNT);
			pLandUser->m_byHandCardCount = USERCARD_MAX_COUNT;
		}
		else if ( i == 3 )
		{
			CopyMemory(pLandUser->m_byHandCardData, bycard3, USERCARD_MAX_COUNT);
			m_GameLogic.SortCardList(pLandUser->m_byHandCardData, USERCARD_MAX_COUNT);
			pLandUser->m_byHandCardCount = USERCARD_MAX_COUNT;
		}
		//else if ( i == 4 )
		//{
		//	CopyMemory(pLandUser->m_byHandCardData, bycard4, USERCARD_MAX_COUNT);
		//	m_GameLogic.SortCardList(pLandUser->m_byHandCardData, USERCARD_MAX_COUNT);
		//	pLandUser->m_byHandCardCount = USERCARD_MAX_COUNT;
		//}
		else
		{
			CopyMemory(pLandUser->m_byHandCardData, m_byCardBuffer+nSkipCardCount, USERCARD_MAX_COUNT);
			pLandUser->m_byHandCardCount = USERCARD_MAX_COUNT;
			m_GameLogic.SortCardList(pLandUser->m_byHandCardData, USERCARD_MAX_COUNT);
			nSkipCardCount += USERCARD_MAX_COUNT;	
		}
*/
		CopyMemory(pLandUser->m_byHandCardData, m_byCardBuffer+nSkipCardCount, USERCARD_MAX_COUNT);
		pLandUser->m_byHandCardCount = USERCARD_MAX_COUNT;
		m_GameLogic.SortCardList(pLandUser->m_byHandCardData, USERCARD_MAX_COUNT);
		nSkipCardCount += USERCARD_MAX_COUNT;
		m_bPockerLogType = 0;		
		LogRecord(pLandUser->GetUserId(), m_bPockerLogType, pLandUser->m_byHandCardData, m_nBaseChip);
	}
	g_pErrorLog->logMsg("m_nStartCallSeatId %d",m_nStartCallSeatId);

	//WaitStopGameTimer();
	m_nStartTime = time(NULL);
	m_nPlayGameTimes ++;

 	if ( m_nStartCallSeatId == INVAILD_SEAT_ID )
 	{
 		while ( true )
 		{
 			BYTE bySeatid = rand() % GAME_PLAYER_COUNT;
 			g_pErrorLog->logMsg("CTeenpattiTable::StartGame bySeatid %d",bySeatid);
 			CGameUser *pUser =  GetUserBySeatId(bySeatid);
 			if ( pUser )
 			{
 				m_nCurCallSeatId = bySeatid;
				m_nStartCallSeatId = bySeatid;
				g_pErrorLog->logMsg("CTeenpattiTable::StartGame end 2");
				return TRUE;
 			}
 		}
 	}

 	g_pErrorLog->logMsg("------------------ CTeenpattiTable::StartGame end --------------------");
	return TRUE;
}

BOOL CTeenpattiTable::StopGame()
{
	g_pErrorLog->logMsg("------------- CTeenpattiTable::StopGame begin --------------");
	ResetTable();
	
	if (GetGameStatus() == STATUS_PLAY || GetGameStatus() == STATUS_STOP)
	{
		int nMaxPlayerCount = GetGamePlayerCount();
		for (int i=0; i<nMaxPlayerCount; i++)
		{
			CTeenpattiUser* pLandUser = (CTeenpattiUser*)GetUserBySeatId(i);
			if (pLandUser == NULL)
			{
				continue;
			}
			pLandUser->ResetUser();
		}	
	}
	g_pErrorLog->logMsg("m_nGameWinnerSeatId [%d], GetSitUserCount[%d]",m_nGameWinnerSeatId,GetSitUserCount());
	m_nStartCallSeatId = m_nGameWinnerSeatId;
	m_nCurCallSeatId = m_nStartCallSeatId;

	int nTime = 0;
	if ( m_bComapre )
	{
		g_pErrorLog->logMsg("------------- CTeenpattiTable::StopGame end 1 --------------");
		m_bComapre = FALSE;
		nTime = ((CTeenpattiServer*)m_pGameServer)->m_LandlordServConf.nWaitGameTimeout + START_COMPARE_TIMEOUT;
	}
	else
	{
		g_pErrorLog->logMsg("------------- CTeenpattiTable::StopGame end 2 --------------");
		nTime = ((CTeenpattiServer*)m_pGameServer)->m_LandlordServConf.nWaitGameTimeout;
	}
	
	g_pErrorLog->logMsg("nTime : [%d]",nTime);
	
	ResetStartGameTimer(nTime);
	StopCallCardTimer();
	StopGameTimer();
	StopRobotCall();
	g_pErrorLog->logMsg("------------- CTeenpattiTable::StopGame end --------------");
	return TRUE;
}

BOOL CTeenpattiTable::UserReady(CTeenpattiUser* pLandUser)
{
	m_nReadyUserCout++;
	((CGameUser*)pLandUser)->Ready();
	return TRUE;
}

void CTeenpattiTable::AllCompareCard()
{
	g_pDebugLog->logMsg("-------- CTeenpattiTable::AllCompareCard begin ----------");
	for ( int i = 0; i < USER_PLAY_COUNT; i++ )
	{
		CTeenpattiUser *pLandUser = (CTeenpattiUser*)GetUserBySeatId(i);

		if ( pLandUser )
		{
			if ( !pLandUser->m_bDisCard )
			{
				BYTE byCardType = m_GameLogic.GetCardType(pLandUser->m_byHandCardData, pLandUser->m_byHandCardCount);
				CardType ct;
				ct.nId = i;
				ct.nType = byCardType;
				vec_CardType.push_back(ct);
			}
		}
	}

	m_nGameWinnerSeatId = GetTurnningBigType();
	g_pDebugLog->logMsg("m_nGameWinnerSeatId : %d",m_nGameWinnerSeatId);
	g_pDebugLog->logMsg("-------- CTeenpattiTable::AllCompareCard end ----------");
}

bool greatermark(const CardType& s1, const CardType& s2)         
{
   	return s1.nType > s2.nType;
}

BYTE CTeenpattiTable::GetTurnningBigType()
{
	sort( vec_CardType.begin(), vec_CardType.end(), greatermark);

	int nFirstType = vec_CardType[0].nType;

	int nCount = 0;

	for ( int i=1; i<vec_CardType.size(); i++ )
	{
		if ( nFirstType == vec_CardType[i].nType )
		{
			nCount ++;
		}
	}
	g_pDebugLog->logMsg("nCount : %d",nCount);
	if ( nCount > 0 )
	{
		return UserSameCardType(nCount, nFirstType, vec_CardType[0].nId);
	}
	else
	{
		return vec_CardType[0].nId;
	}
}

bool CTeenpattiTable::GetUserSpecialType(BYTE &bySeatid)
{
	for ( int i = 0; i < USER_PLAY_COUNT; i++ )
	{
		CTeenpattiUser *pLandUser = (CTeenpattiUser*)GetUserBySeatId(i);

		if ( pLandUser )
		{
			if ( !pLandUser->m_bDisCard )
			{
				BYTE byCardType = m_GameLogic.GetCardType(pLandUser->m_byHandCardData,pLandUser->m_byHandCardCount);

				if ( byCardType == CT_SPECIAL )
				{
					bySeatid = i;
					return true;
				}
			}
		}
	}

	return false;
}

BYTE CTeenpattiTable::UserSameCardType(int nCount, BYTE byType, BYTE bySeatId)
{
	g_pDebugLog->logMsg("-------- CTeenpattiTable::UserSameCardType begin ----------");
	g_pErrorLog->logMsg("byType:[%d]",byType);
	CTeenpattiUser *pUser = NULL;

	BYTE byMaxSeatId = bySeatId;

	sort( vec_CardType.begin(), vec_CardType.end(), greatermark);

	for ( BYTE i=1; i<=nCount; i++ )
	{
		CTeenpattiUser *pLandUser = (CTeenpattiUser*)GetUserBySeatId(vec_CardType[i].nId);
		if ( pLandUser )
		{
			g_pDebugLog->logMsg("byMaxSeatId:[%d], nid:[%d]",byMaxSeatId,vec_CardType[i].nId);
			if ( !pLandUser->m_bDisCard  )
			{
				pUser = (CTeenpattiUser*)GetUserBySeatId(byMaxSeatId);

				if ( pUser )
				{
					BYTE byCompResult = m_GameLogic.CompareCard(pUser->m_byHandCardData, pLandUser->m_byHandCardData, 
					pUser->m_byHandCardCount, pLandUser->m_byHandCardCount);
					g_pDebugLog->logMsg("byCompResult:[%d]",byCompResult);
					if ( byCompResult == 1 )
					{
						vec_UserWinList.clear();
						vec_UserWinList.push_back(pLandUser->GetUserId());
						byMaxSeatId = vec_CardType[i].nId;
					}
					else if ( byCompResult == 2 )
					{
						vec_UserWinList.clear();
						vec_UserWinList.push_back(pUser->GetUserId());
					}
					else if ( byCompResult == 3 )
					{
						byMaxSeatId = vec_CardType[i].nId;
						vec_UserWinList.push_back(pUser->GetUserId());
						vec_UserWinList.push_back(pLandUser->GetUserId());
					}
				}		
			}
		}
	}

	for( int i=0; i<vec_UserWinList.size(); i++ )
		g_pErrorLog->logMsg("vec_UserWinList begin %d ",vec_UserWinList[i]);

	vector<int>::iterator iter = unique(vec_UserWinList.begin(),vec_UserWinList.end());
	vec_UserWinList.erase(iter,vec_UserWinList.end());

	for( int i=0; i<vec_UserWinList.size(); i++ )
		g_pErrorLog->logMsg("vec_UserWinList end %d ",vec_UserWinList[i]);
	
	g_pDebugLog->logMsg("byMaxSeatId:[%d]",byMaxSeatId);
	g_pDebugLog->logMsg("-------- CTeenpattiTable::UserSameCardType end ----------");
	return byMaxSeatId;
}

void CTeenpattiTable::CalUserCurTime(CTeenpattiUser* pCTUser)
{	
	g_pErrorLog->logMsg("m_nUnixTime:[%d],iTempTime[%d],m_nMidTime[%d]",pCTUser->m_nUnixTime, pCTUser->iTempTime,pCTUser->m_nMidTime);
	pCTUser->m_nUnixTime = Getunixtime() - pCTUser->m_nUnixTime - pCTUser->iTempTime;
	g_pErrorLog->logMsg("m_nUnixTime:[%d],m_nActimeTime[%d]",pCTUser->m_nUnixTime,pCTUser->m_nActimeTime);
	pCTUser->m_nActimeTime = pCTUser->m_nActimeTime +  Getunixtime()- pCTUser->m_nMidTime;
	g_pErrorLog->logMsg("m_nActimeTime:[%d]",pCTUser->m_nActimeTime);
	pCTUser->iTempTime = pCTUser->iTempTime + Getunixtime() - pCTUser->m_nMidTime;
	g_pErrorLog->logMsg("iTempTime:[%d]",pCTUser->iTempTime);
}

void CTeenpattiTable::StartCallCardTimer(int nTime)
{
	m_CallCardTimer.StartTimer(nTime+2);
	m_dwGameTickCount = GetTickCount();
}

void CTeenpattiTable::StopCallCardTimer()
{
	m_CallCardTimer.StopTimer();
}

void CTeenpattiTable::ResetCallTimer(int nTime)
{
	StopCallCardTimer();
	StartCallCardTimer(nTime);
}

void CTeenpattiTable::WaitStartGameTimer(int nTime)
{
	m_WaitStartGameTimer.StartTimer(nTime);
	m_dwWaitStartTickCount = GetTickCount();
	m_bWaitStart = TRUE;
}

void CTeenpattiTable::WaitStopGameTimer()
{
	m_WaitStartGameTimer.StopTimer();
	m_bWaitStart = FALSE;
}

void CTeenpattiTable::StartGameTimer()
{
	m_StartGameTimer.StartTimer(START_GAME_TIMEOUT);
}

void CTeenpattiTable::StopGameTimer()
{
	m_StartGameTimer.StopTimer();
}

void CTeenpattiTable::StartCreateRobotTimer(int nTime)
{
	m_CreateRobotTimer.StartTimer(nTime);
}

void CTeenpattiTable::StopCreateRobotTimer()
{
	m_CreateRobotTimer.StopTimer();
}

void CTeenpattiTable::ResetCreateRobotTimer(int nTime)
{
	StopCreateRobotTimer();
	StartCreateRobotTimer(nTime);
}

void CTeenpattiTable::StartRobotOperTimer()
{
	m_RobotOperTimer.StartTimer(1);
}

void CTeenpattiTable::StopRobotOperTimer()
{
	m_RobotOperTimer.StopTimer();
}

void CTeenpattiTable::ResetStartGameTimer(int nTime)
{
	WaitStopGameTimer();
	WaitStartGameTimer(nTime);
}

void CTeenpattiTable::StartRobotCall()
{
	StopCallCardTimer();
	m_RobotCallTimer.StartTimer(2);
}

void CTeenpattiTable::StopRobotCall()
{
	m_RobotCallTimer.StopTimer();
}

void CTeenpattiTable::StartKickRobotTimer()
{
	int nRand = random(2)+1;

	g_pErrorLog->logMsg("StartKickRobotTimer nRand : %d",nRand);
	m_RobotKickTimer.StartTimer(nRand);
}

int CTeenpattiTable::ProcessOnTimerOut(int nTimerId)
{
	g_pErrorLog->logMsg("ProcessOnTimerOut : %d",nTimerId);
	CTeenpattiServer* pLandServer = (CTeenpattiServer*)m_pGameServer;
	switch (nTimerId)
	{
	case CALL_CARD_TIMER:
		return pLandServer->ProcTimeoutCall(this);
	case START_GAME_TIMER:
		return pLandServer->ProcTimeoutStartGame(this);
	case WAIT_GAME_START:
		return pLandServer->ProcTimeoutWaitGame(this);
	case CREAT_ROBOT_TIMER:
		return pLandServer->ProcTimeoutCreateRobot(this);
	case CALL_ROBOT_TIMER:
		return pLandServer->ProcTimeoutRobotCall(this);
	case KICK_ROBOT_TIMER:
		return pLandServer->ProcLogoutRobot(this);
	case OPER_ROBOT_TIMER:
		return pLandServer->ProcTimeoutCall(this);
	default:
		break;
	}
	return 0;
}

void CTeenpattiTable::CalcTurningScore()
{
	g_pDebugLog->logMsg("-------- CTeenpattiTable::CalcTurningScore begin ----------");
	if ( m_nCalType == ALL_COMPARE )
	{
		AllCompareCard();
	}

	CGameUser *pUser = NULL;

	g_pDebugLog->logMsg("m_nGameWinnerSeatId %d, m_nPotTotal[%d]",m_nGameWinnerSeatId,m_nPotTotal);

	CTeenpattiServer* pLandServer = (CTeenpattiServer*)m_pGameServer;

	int nWinCount = vec_UserWinList.size();
	g_pErrorLog->logMsg("win nCount %d",nWinCount);

	for ( BYTE i=0; i<USER_PLAY_COUNT; i++)
	{
		pUser = GetUserBySeatId(i);
		if ( pUser )
		{
			if ( pUser->m_nStatus == USER_STATUS_PALY )
			{
				CTeenpattiUser *CTUser = (CTeenpattiUser *)pUser;
				
				if ( nWinCount <= 1 )
				{
					if ( i == m_nGameWinnerSeatId )
					{
						CTUser->m_nTax = (int)((m_nPotTotal*pLandServer->m_LandlordServConf.nExp)/100);
						g_pErrorLog->logMsg("m_nTax 1 : [%d], exp[%d]",CTUser->m_nTax,pLandServer->m_LandlordServConf.nExp);
						CTUser->m_nUpdateMoney = m_nPotTotal - CTUser->m_nTax - CTUser->m_nCostForTable;
						CTUser->m_nCostForTable = m_nPotTotal - CTUser->m_nTax;
						CTUser->m_nMoney += CTUser->m_nCostForTable;
						g_pErrorLog->logMsg("CTUser->m_nCostForTable 1 win %d",CTUser->m_nCostForTable);
					}
					else
					{
						CTUser->m_nCostForTable = -(CTUser->m_nCostForTable);
						CTUser->m_nUpdateMoney = CTUser->m_nCostForTable;
						g_pErrorLog->logMsg("CTUser->m_nCostForTable 1 lose %d",CTUser->m_nCostForTable);
					}
				}
				else
				{
					if ( IsInWinList(CTUser->GetUserId()) )
					{
						CTUser->m_nTax = (int)(((m_nPotTotal/nWinCount)*pLandServer->m_LandlordServConf.nExp)/100);
						g_pErrorLog->logMsg("m_nTax 2 : [%d],exp[%d]",CTUser->m_nTax,pLandServer->m_LandlordServConf.nExp);
						CTUser->m_nUpdateMoney = (int)(m_nPotTotal/nWinCount) - CTUser->m_nTax - CTUser->m_nCostForTable;
						CTUser->m_nCostForTable = ((int)(m_nPotTotal/nWinCount) - CTUser->m_nTax);
						CTUser->m_nMoney += CTUser->m_nCostForTable;
						g_pErrorLog->logMsg("CTUser->m_nCostForTable 2 win %d",CTUser->m_nCostForTable);
					}
					else
					{
						CTUser->m_nCostForTable = -(CTUser->m_nCostForTable);
						CTUser->m_nUpdateMoney = CTUser->m_nCostForTable;
						g_pErrorLog->logMsg("CTUser->m_nCostForTable 2 lose %d",CTUser->m_nCostForTable);
					}

				}
			}
		}
	}

	g_pDebugLog->logMsg("-------- CTeenpattiTable::CalcTurningScore end ----------");
}

bool CTeenpattiTable::IsInWinList(int nUserId)
{
	g_pDebugLog->logMsg("-------- CTeenpattiTable::IsInWinList begin ----------");
	g_pErrorLog->logMsg("nUserId : [%d]",nUserId);

	for (int i = 0; i < vec_UserWinList.size(); ++i)
	{
		g_pDebugLog->logMsg("vec_UserWinList[i] : [%d]",vec_UserWinList[i]);
		if ( vec_UserWinList[i] == nUserId )
		{
			return true;
		}
	}

	g_pDebugLog->logMsg("-------- CTeenpattiTable::IsInWinList end ----------");
	return false;
}

void CTeenpattiTable::LogRecord(int nUserId, BYTE byPockerType, BYTE byCard[], int nMoney, int nActiveId, int nPassiveId)
{
	char szUserId[128]={0};
	char str[50] = {0};
	char* ipaddr = NULL;
	in_addr inaddr;

	if ( nUserId == 0 )
	{
		sprintf(szUserId, "%d:", nUserId);
	}
	if ( byPockerType == 0 )
	{
		int iOffset=0;
		if ( nUserId != 0 )
		{
			CGameUser * pUser = GetUserByUserId(nUserId);
			if ( pUser == NULL )
			{
				return ;
			}
			DWORD dwPeerAddr = pUser->GetIP();
			SocketHandler* pHandle = pUser->GetHandler();
			if ( 0 == dwPeerAddr && pHandle == NULL )
			{
				ipaddr = "0.0.0.0";
			}
			else 
			{
				if(0==dwPeerAddr)
				{
					dwPeerAddr = pHandle->GetPeerAddr(); 
				}
				u_long lIP = htonl(dwPeerAddr);
				inaddr.s_addr = lIP;
				ipaddr = inet_ntoa(inaddr);
			}
	
			int ipaddrLen = strlen(ipaddr);
			int minLen = (sizeof(str)-1) < ipaddrLen ? (sizeof(str)-1) : ipaddrLen;
			strncpy( str,ipaddr, minLen);
		
			iOffset = strlen(str);
			memmove(szUserId+iOffset, szUserId, strlen(szUserId));
			iOffset += strlen(szUserId);
			sprintf(szUserId, "%d-%s:",nUserId, str);
		}
	}
	else
	{
		sprintf(szUserId, "%d:", nUserId);
	}
	

	int nOffset = strlen(m_szPokerLog);
	memcpy(m_szPokerLog+nOffset, szUserId, strlen(szUserId));
	nOffset += strlen(szUserId);

	if ( byPockerType == 0 )						//记录玩家手牌
	{
		for (int i=0; i<3; i++)
		{
			char szTmp[8] = {0};
			if(i < 2)
			{
				sprintf(szTmp, "%x,", byCard[i]);
			}
			else
			{
				sprintf(szTmp, "%x", byCard[i]);		
			}
			memcpy(m_szPokerLog+nOffset, szTmp, strlen(szTmp));
			nOffset += strlen(szTmp);
		}
		char szData[128] = {0};
		sprintf(szData, ":%d", nMoney);
		memcpy(m_szPokerLog+nOffset, szData, strlen(szData));
		nOffset += strlen(szData);
		memcpy(m_szPokerLog+nOffset, "|", 1);
	}
	else if ( byPockerType == 1 )						//玩家看牌
	{
		memcpy(m_szPokerLog+nOffset, "1", 1);
		nOffset += 1;
		memcpy(m_szPokerLog+nOffset, "|", 1);
	}
	else if ( byPockerType == 2 )						//玩家弃牌
	{
		memcpy(m_szPokerLog+nOffset, "2", 1);
		nOffset += 1;
		memcpy(m_szPokerLog+nOffset, "|", 1);
	}
	else if ( byPockerType == 3 )						//玩家比牌
	{
		memcpy(m_szPokerLog+nOffset, "3:", 2);
		nOffset += 2;
		char szData[128] = {0};
		sprintf(szData, "%d:%d:%d", nActiveId,nPassiveId,nMoney);
		memcpy(m_szPokerLog+nOffset, szData, strlen(szData));
		nOffset += strlen(szData);
		memcpy(m_szPokerLog+nOffset, "|", 1);
	}
	else if ( byPockerType == 4 )						//玩家跟注
	{
		char szData[128] = {0};
		sprintf(szData, "4:%d", nMoney);
		memcpy(m_szPokerLog+nOffset, szData, strlen(szData));
		nOffset += strlen(szData);
		memcpy(m_szPokerLog+nOffset, "|", 1);
	}
	else if ( byPockerType == 5 )						//玩家加注
	{
		char szData[128] = {0};
		sprintf(szData, "5:%d", nMoney);
		memcpy(m_szPokerLog+nOffset, szData, strlen(szData));
		nOffset += strlen(szData);
		memcpy(m_szPokerLog+nOffset, "|", 1);
	}
	else if ( byPockerType == 6 )						//玩家游戏中站起
	{
		memcpy(m_szPokerLog+nOffset, "6", 1);
		nOffset += 1;
		memcpy(m_szPokerLog+nOffset, "|", 1);
	}
	else if ( byPockerType == 7 )						//玩家结束
	{
		memcpy(m_szPokerLog+nOffset, "7", 1);
		nOffset += 1;
		memcpy(m_szPokerLog+nOffset, "|", 1);
	}

	g_pErrorLog->logMsg("m_szPokerLog size %d",strlen(m_szPokerLog));
}

BYTE CTeenpattiTable::UserCompareCard(CTeenpattiUser* pLandUser, CTeenpattiUser* pComparedUser)
{
	return m_GameLogic.CompareCard(pLandUser->m_byHandCardData, pComparedUser->m_byHandCardData, 3, 3);
}

bool CTeenpattiTable::IsGameOver()
{
	g_pErrorLog->logMsg("------------  CTeenpattiTable::IsGameOver begin ----------");
	int nPlayUser = 0;

	for (int i=0; i<USER_PLAY_COUNT; i++)
	{
		CTeenpattiUser* pLandlordUser = (CTeenpattiUser*)GetUserBySeatId(i);

		if ( pLandlordUser )
		{
			g_pErrorLog->logMsg("CTeenpattiTable::IsGameOver uid %d", pLandlordUser->GetUserId());

			if ( ( pLandlordUser->m_nStatus == USER_STATUS_PALY ) && ( !pLandlordUser->m_bDisCard ))
			{
				nPlayUser ++;
			}
		}
	}

	g_pErrorLog->logMsg("CTeenpattiTable::IsGameOver nPlayUser %d", nPlayUser);

	if ( nPlayUser > 1 )
	{
		return false;
		g_pErrorLog->logMsg("------------ CTeenpattiTable::IsGameOver end 1 ----------");
	}
	else
	{
		return true;
		g_pErrorLog->logMsg("------------ CTeenpattiTable::IsGameOver end 2 ----------");
	}

}

void CTeenpattiTable::GetWinner()
{

	for (int i=0; i<USER_PLAY_COUNT; i++)
	{
		CTeenpattiUser* pLandlordUser = (CTeenpattiUser*)GetUserBySeatId(i);

		if ( pLandlordUser )
		{
			g_pErrorLog->logMsg("CTeenpattiTable::GetWinner uid %d", pLandlordUser->GetUserId());

			if ( ( pLandlordUser->m_nStatus == USER_STATUS_PALY ) && (!pLandlordUser->m_bDisCard ))
			{
				g_pErrorLog->logMsg("CTeenpattiTable::GetWinner SeatId %d", pLandlordUser->GetSeatId());
				m_nGameWinnerSeatId = pLandlordUser->GetSeatId();
			}
		}
	}

	m_nCalType = SINGLE_COMPARE;
}

int CTeenpattiTable::GetNextUserBySeatId(BYTE bySeatId)
{
	g_pErrorLog->logMsg("CTeenpattiTable::GetNextUserBySeatId bySeatId %d",bySeatId);
	CGameUser *pUser = GetUserBySeatId(bySeatId);

	if ( bySeatId == 100 )
	{
		bySeatId = 0;
	}
	
	for ( BYTE i=bySeatId+1; i<bySeatId+USER_PLAY_COUNT;  i++)
	{
		BYTE temp = i % USER_PLAY_COUNT;
		g_pErrorLog->logMsg("CTeenpattiTable::GetNextUserBySeatId temp %d",temp);
		pUser = GetUserBySeatId(temp);
		if ( pUser )
		{
			if ( pUser->m_nStatus == USER_STATUS_PALY )
			{
				g_pErrorLog->logMsg("------------ CTeenpattiTable::GetNextUserBySeatId end 1 ----------");
				return pUser->GetUserId();
			}
		}
	}

	if ( pUser )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiTable::GetNextUserBySeatId end 2 ----------");
		return pUser->GetUserId();
	}

	g_pErrorLog->logMsg("------------ CTeenpattiTable::GetNextUserBySeatId end 3 ----------");
	return 0;
}

BYTE CTeenpattiTable::GetPlaySitUserCount()
{
	g_pErrorLog->logMsg(" -------------- CTeenpattiTable::GetPlaySitUserCount begin ---------------");

	BYTE byUserCount = 0;

	for ( BYTE i=0; i<USER_PLAY_COUNT; i++)
	{
		CGameUser *pUser = GetUserBySeatId(i);
		if ( pUser )
		{
			if ( pUser->m_nStatus == USER_STATUS_PALY )
			{
				byUserCount ++;
			}
		}
	}

	g_pErrorLog->logMsg("byUserCount : %d",byUserCount);
	g_pErrorLog->logMsg(" -------------- CTeenpattiTable::GetPlaySitUserCount end ---------------");

	return byUserCount;
}

int CTeenpattiTable::GetSitUserCount()
{
	g_pErrorLog->logMsg(" -------------- CTeenpattiTable::GetSitUserCount begin ---------------");

	int byUserCount = 0;

	for ( BYTE i=0; i<USER_PLAY_COUNT; i++)
	{
		CGameUser *pUser = GetUserBySeatId(i);
		if ( pUser )
		{
			if ( ( pUser->m_nStatus == USER_STATUS_PALY ) || ( pUser->m_nStatus == USER_STATUS_READY ) )
			{
				byUserCount ++;
			}
		}
	}

	g_pErrorLog->logMsg("byUserCount : %d",byUserCount);
	g_pErrorLog->logMsg(" -------------- CTeenpattiTable::GetSitUserCount end ---------------");

	return byUserCount;
}

void CTeenpattiTable::GetRankPlayUser(int nUserId, int &nComparedId)
{
	g_pErrorLog->logMsg(" -------------- CTeenpattiTable::GetRankPlayUser begin ---------------");

	for ( BYTE i=0; i<USER_PLAY_COUNT; i++)
	{
		CTeenpattiUser *pUser = (CTeenpattiUser*)GetUserBySeatId(i);
		if ( pUser )
		{
			if ( ( pUser->m_nStatus == USER_STATUS_PALY ) && ( pUser->GetUserId() != nUserId ) && ( !pUser->m_bDisCard ) )
			{
				nComparedId = pUser->GetUserId();
			}
		}
	}

	g_pErrorLog->logMsg(" -------------- CTeenpattiTable::GetRankPlayUser end ---------------");
}

BYTE CTeenpattiTable::GetTableEmptySeat()
{
	g_pErrorLog->logMsg(" -------------- CTeenpattiTable::GetTableEmptySeat begin ---------------");

	BYTE byUserCount = INVAILD_SEAT_ID;

	for ( BYTE i=0; i<USER_PLAY_COUNT; i++)
	{
		CGameUser *pUser = GetUserBySeatId(i);
		if ( !pUser )
		{
			g_pErrorLog->logMsg("byUserCount : %d",byUserCount);
			byUserCount = i;
			return byUserCount;
		}
	}

	g_pErrorLog->logMsg(" -------------- CTeenpattiTable::GetTableEmptySeat end ---------------");

	return byUserCount;
}

BYTE CTeenpattiTable::GetOnlookerCount()
{
	g_pErrorLog->logMsg(" -------------- CTeenpattiTable::GetOnlookerCount begin ---------------");

	m_nUserCount = (int)m_UserManager.size();

	g_pErrorLog->logMsg("m_nUserCount : %d, GetSitUserCount : %d", m_nUserCount, GetSitUserCount());
	g_pErrorLog->logMsg(" -------------- CTeenpattiTable::GetOnlookerCount end ---------------");

	return m_nUserCount - GetSitUserCount();
}

int CTeenpattiTable::ProcRobotCallCard(CTeenpattiUser* pUser)
{
	g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard begin ---------------");
	g_pErrorLog->logMsg("pUser %d",pUser->GetUserId());

	CTeenpattiServer* pLandServer = (CTeenpattiServer*)m_pGameServer;

	BYTE byCardType = m_GameLogic.GetCardType(pUser->m_byHandCardData, pUser->m_byHandCardCount);
	g_pErrorLog->logMsg("byCardType %d",byCardType);
	g_pErrorLog->logMsg("m_nCinglTimes %d",m_nCinglTimes);

	if ( ( byCardType == CT_SINGLE ) || ( byCardType == CT_SPECIAL ) || ( byCardType == CT_INVALID ) ) 
	{
		if ( m_GameLogic.IsSingleLowJ( pUser->m_byHandCardData ) )
		{
			g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 1 ---------------");
			pLandServer->ProcUserWatchCard(pUser);
			StartRobotOperTimer();
		}
		else if ( m_GameLogic.IsSingleBigQ( pUser->m_byHandCardData ) )
		{
			if ( m_nCinglTimes >= 3 )
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 2 ---------------");
				pLandServer->ProcUserWatchCard(pUser);
				int nComparedId = 0;
				GetRankPlayUser(pUser->GetUserId(), nComparedId);
				g_pErrorLog->logMsg("nComparedId %d",nComparedId);
				return pLandServer->ProcUserCompareCard(pUser, nComparedId);
			}
		}
	}
	else if ( byCardType == CT_DOUBLE )
	{
		if ( m_GameLogic.IsDoubleLowA( pUser->m_byHandCardData ) )		//小于等于10
		{
			if ( m_nCinglTimes == 5 )
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 3 ---------------");
				pLandServer->ProcUserWatchCard(pUser);
				GetUserCinglMoney(pUser);
				return pLandServer->ProcUserCingl(pUser, pUser->m_nHandMoney);
			}
			else if ( m_nCinglTimes == 10 )
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 4 ---------------");
				g_pErrorLog->logMsg("pUser->m_nHandMoney %d", pUser->m_nHandMoney);

				pUser->m_nHandMoney = GetCallMoney(pUser);

				OperRobotCall(pUser);
			}
			else if ( m_nCinglTimes >= 15 )
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 5 ---------------");
				int nComparedId = 0;
				GetRankPlayUser(pUser->GetUserId(), nComparedId);
				g_pErrorLog->logMsg("nComparedId %d",nComparedId);
				return pLandServer->ProcUserCompareCard(pUser, nComparedId);
			}
			else
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 6 ---------------");
				GetUserCinglMoney(pUser);
				return pLandServer->ProcUserCingl(pUser, pUser->m_nHandMoney);
			}
		}
		else 		//大于等于J
		{
			if ( m_nCinglTimes == 5 )
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 7 ---------------");
				g_pErrorLog->logMsg("pUser->m_nHandMoney %d", pUser->m_nHandMoney);
				pLandServer->ProcUserWatchCard(pUser);

				pUser->m_nHandMoney = GetCallMoney(pUser);
				OperRobotCall(pUser);
			}
			else if ( m_nCinglTimes == 10 )
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 8 ---------------");
				g_pErrorLog->logMsg("pUser->m_nHandMoney %d", pUser->m_nHandMoney);

				pUser->m_nHandMoney = GetCallMoney(pUser);
				OperRobotCall(pUser);
			}
			else if ( m_nCinglTimes >= 20 )
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 9 ---------------");
				int nComparedId = 0;
				GetRankPlayUser(pUser->GetUserId(), nComparedId);
				g_pErrorLog->logMsg("nComparedId %d",nComparedId);
				return pLandServer->ProcUserCompareCard(pUser, nComparedId);
			}
			else
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 10 ---------------");
				GetUserCinglMoney(pUser);
				return pLandServer->ProcUserCingl(pUser, pUser->m_nHandMoney);
			}
		}
	}
	else if ( byCardType == CT_ONE_LINE )
	{
		if ( m_nCinglTimes == 10 )
		{
			g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 11 ---------------");
			pLandServer->ProcUserWatchCard(pUser);
			g_pErrorLog->logMsg("pUser->m_nHandMoney %d", pUser->m_nHandMoney);
			pUser->m_nHandMoney = GetCallMoney(pUser);
			OperRobotCall(pUser);
		}
		else if ( ( m_nCinglTimes == 15 ) || ( m_nCinglTimes == 20 ) || ( m_nCinglTimes == 30 ) )
		{
			g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 12 ---------------");
			g_pErrorLog->logMsg("pUser->m_nHandMoney %d", pUser->m_nHandMoney);

			pUser->m_nHandMoney = GetCallMoney(pUser);
			OperRobotCall(pUser);
/*			
			if ( ( pUser->m_nHandMoney == pLandServer->m_LandlordServConf.nMaxHandBet ) ||
				( pUser->m_nHandMoney == m_nHandBet * 2 ) )
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 50 ---------------");
				return pLandServer->ProcUserCingl(pUser, pUser->m_nHandMoney);
			}
			else
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 51 ---------------");
				return pLandServer->ProcUserAddCingl(pUser, pUser->m_nHandMoney);
			}
			*/
		}
		else if ( m_nCinglTimes >= 60 )
		{
			g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 13 ---------------");
			int nComparedId = 0;
			GetRankPlayUser(pUser->GetUserId(), nComparedId);
			g_pErrorLog->logMsg("nComparedId %d",nComparedId);
			return pLandServer->ProcUserCompareCard(pUser, nComparedId);
		}
		else
		{
			g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 14 ---------------");
			GetUserCinglMoney(pUser);
			return pLandServer->ProcUserCingl(pUser, pUser->m_nHandMoney);
		}
	}
	else if ( byCardType == CT_TEENPATTI )
	{
		if  ( ( m_nCinglTimes == 5 ) || ( m_nCinglTimes == 10 ) )
		{
			g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 15 ---------------");
			g_pErrorLog->logMsg("pUser->m_nHandMoney %d", pUser->m_nHandMoney);
			pUser->m_nHandMoney = GetCallMoney(pUser);

			OperRobotCall(pUser);
		}
		else if ( m_nCinglTimes >= 11 ) 
		{
			g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 16 ---------------");
			g_pErrorLog->logMsg("pUser->m_nHandMoney %d", pUser->m_nHandMoney);
			
			if ( m_nCinglTimes >= 20 )
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 17 ---------------");
				int nComparedId = 0;
				GetRankPlayUser(pUser->GetUserId(), nComparedId);
				g_pErrorLog->logMsg("nComparedId %d",nComparedId);
				return pLandServer->ProcUserCompareCard(pUser, nComparedId);
			}

			if ( m_nCinglTimes == 11 )
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 18 ---------------");
				pLandServer->ProcUserWatchCard(pUser);
			}
				
			pUser->m_nHandMoney = GetCallMoney(pUser);

			OperRobotCall(pUser);
		}
		else
		{
			g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 19 ---------------");
			GetUserCinglMoney(pUser);
			return pLandServer->ProcUserCingl(pUser, pUser->m_nHandMoney);
		}
	}
	else if ( byCardType == CT_TEENPATTI_LINE )
	{
		if  ( m_nCinglTimes >= 5 ) 
		{
			 if ( m_nCinglTimes == 10 ) 
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 20 ---------------");
				g_pErrorLog->logMsg("pUser->m_nHandMoney %d", pUser->m_nHandMoney);
				pLandServer->ProcUserWatchCard(pUser);
				GetUserCinglMoney(pUser);
				return pLandServer->ProcUserCingl(pUser, pUser->m_nHandMoney);
			}
			else if ( m_nCinglTimes >= 20 )
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 21 ---------------");
				int nComparedId = 0;
				GetRankPlayUser(pUser->GetUserId(), nComparedId);
				g_pErrorLog->logMsg("nComparedId %d",nComparedId);
				return pLandServer->ProcUserCompareCard(pUser, nComparedId);
			}
			else
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 22 ---------------");
				g_pErrorLog->logMsg("pUser->m_nHandMoney %d", pUser->m_nHandMoney);

				pUser->m_nHandMoney = GetCallMoney(pUser);

				OperRobotCall(pUser);
			}
		}
		else
		{
			g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 23 ---------------");
			GetUserCinglMoney(pUser);
			return pLandServer->ProcUserCingl(pUser, pUser->m_nHandMoney);
		}
	}
	else if ( byCardType == CT_THREE )
	{
		if  ( m_nCinglTimes >= 3 ) 
		{
			 if ( m_nCinglTimes == 20 ) 
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 24 ---------------");
				g_pErrorLog->logMsg("pUser->m_nHandMoney %d", pUser->m_nHandMoney);
				pLandServer->ProcUserWatchCard(pUser);

				pUser->m_nHandMoney = GetCallMoney(pUser);

				OperRobotCall(pUser);
			}
			else if ( m_nCinglTimes >= 30 )
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 25 ---------------");
				int nComparedId = 0;
				GetRankPlayUser(pUser->GetUserId(), nComparedId);
				g_pErrorLog->logMsg("nComparedId %d",nComparedId);
				return pLandServer->ProcUserCompareCard(pUser, nComparedId);
			}
			else
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end 26 ---------------");
				g_pErrorLog->logMsg("pUser->m_nHandMoney %d", pUser->m_nHandMoney);

				pUser->m_nHandMoney = GetCallMoney(pUser);

				OperRobotCall(pUser);
			}
		}
	}

	g_pErrorLog->logMsg("------------- CTeenpattiTable::ProcRobotCallCard end ---------------");
}

int CTeenpattiTable::OperRobotCall(CTeenpattiUser* pUser)
{
	g_pErrorLog->logMsg("------------- CTeenpattiTable::OperRobotCall begin ---------------");

	CTeenpattiServer* pLandServer = (CTeenpattiServer*)m_pGameServer;

	if ( m_nHandBet == pLandServer->m_LandlordServConf.nMaxHandBet )
	{
		g_pErrorLog->logMsg("------------- CTeenpattiTable::OperRobotCall end 1 ---------------");
		return pLandServer->ProcUserCingl(pUser, pUser->m_nHandMoney);
	}
	else
	{
		g_pErrorLog->logMsg("------------- CTeenpattiTable::OperRobotCall end 2 ---------------");
		return pLandServer->ProcUserAddCingl(pUser, pUser->m_nHandMoney);
	}
}


int CTeenpattiTable::GetUserCinglMoney( CTeenpattiUser* pUser )
{
	int nCinglMoney = m_nHandBet;
	if ( pUser->m_bWatchCard )
	{
		nCinglMoney = 2 * m_nHandBet;
	}
	if ( pUser->m_nHandMoney < nCinglMoney )
	{
		pUser->m_nHandMoney = nCinglMoney;
	}
	if ( pUser->m_nHandMoney > pUser->m_nMoney )
	{
		pUser->m_nHandMoney = pUser->m_nMoney;
	}
	return 0;
}

int CTeenpattiTable::GetCurCallTime()
{
	CTeenpattiServer* pLandServer = (CTeenpattiServer*)m_pGameServer;
	g_pErrorLog->logMsg("m_nHandBet [%ld]",m_nHandBet);
	int nTimes = 0;
	nTimes = (int)m_nHandBet / pLandServer->m_LandlordServConf.nBaseChips;
	g_pErrorLog->logMsg("nTimes [%d]",nTimes);
	if ( nTimes == 1 )
	{
		return 4;
	}
	else if ( nTimes == 4 )
	{
		return 8;
	}
	else if ( nTimes == 8 )
	{
		return 12;
	}
	else if ( nTimes == 12 )
	{
		return 16;
	}
	else if ( nTimes == 16 )
	{
		return 20;
	}
	return 20;
}

int CTeenpattiTable::GetCallMoney(CTeenpattiUser* pUser)
{
	g_pErrorLog->logMsg("------------- CTeenpattiTable::GetCallMoney begin ---------------");
	g_pErrorLog->logMsg("nUserId:[%d], m_nMoney[%d]",pUser->GetUserId(),pUser->m_nMoney);

	CTeenpattiServer* pLandServer = (CTeenpattiServer*)m_pGameServer;

	pUser->m_nHandMoney = pLandServer->m_LandlordServConf.nBaseChips * GetCurCallTime();

	int nServerConf = pLandServer->m_LandlordServConf.nMaxHandBet;
	if ( pUser->m_bWatchCard )
	{
		pUser->m_nHandMoney *= 2;
		nServerConf *= 2;
	}

	if ( pUser->m_nHandMoney > pUser->m_nMoney )
	{

		if ( pUser->m_nMoney > nServerConf )
		{
			g_pErrorLog->logMsg("------------- CTeenpattiTable::GetCallMoney end 1 ---------------");
			return pLandServer->m_LandlordServConf.nMaxHandBet;
		}
		else
		{
			g_pErrorLog->logMsg("------------- CTeenpattiTable::GetCallMoney end 2 ---------------");
			return pUser->m_nMoney;
		}
	}
	else
	{
		/*if ( pUser->m_bWatchCard )
		{
			if ( pUser->m_nHandMoney <= 2* pLandServer->m_LandlordServConf.nMaxHandBet )
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::GetCallMoney end 3 ---------------");
				return pUser->m_nHandMoney;
			}
			else
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::GetCallMoney end 4 ---------------");
				return 2 * pLandServer->m_LandlordServConf.nMaxHandBet;
			}
		}
		else
		{
			*/
			if ( pUser->m_nHandMoney <= nServerConf )
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::GetCallMoney end 5 ---------------");
				return pUser->m_nHandMoney;
			}
			else
			{
				g_pErrorLog->logMsg("------------- CTeenpattiTable::GetCallMoney end 6 ---------------");
				return pLandServer->m_LandlordServConf.nMaxHandBet;
			}
		//}
		
	}

	g_pErrorLog->logMsg("------------- CTeenpattiTable::GetCallMoney end ---------------");
}

BOOL CTeenpattiTable::RobotInRobotIdList(int nUserId)
{
	g_pErrorLog->logMsg("------------- CTeenpattiTable::RobotInRobotIdList begin -------------");
	g_pErrorLog->logMsg("nUserId : [%d]",nUserId);

	for(int i=0; i<(int)vec_RobotList.size(); i++)
	{
		if ( nUserId == vec_RobotList[i] )
		{
			g_pErrorLog->logMsg("------------ CTeenpattiServer::RobotInRobotIdList end 1 ------------");
			return TRUE;
		}
	} 

	g_pErrorLog->logMsg("------------ CTeenpattiServer::RobotInRobotIdList end ------------");
	return FALSE;
}

int CTeenpattiTable::DeleteRobotIdInList(int nUserId)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::DeleteRobotIdInList begin ------------");
	g_pErrorLog->logMsg("nUserId : [%d]",nUserId);

	for (int i = 0; i < (int)vec_RobotList.size(); ++i)
	{
		if ( nUserId == vec_RobotList[i] )
		{
			g_pErrorLog->logMsg("------------ CTeenpattiServer::DeleteRobotIdInList success -------------");
			vec_RobotList.erase(vec_RobotList.begin() + i);
			m_nRobotCount --;
		}
	}

	g_pErrorLog->logMsg("------------ CTeenpattiServer::DeleteRobotIdInList end ------------");
	return 0;
}