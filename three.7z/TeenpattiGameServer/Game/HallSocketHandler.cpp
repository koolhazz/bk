#include "HallSocketHandler.h"
#include "TeenpattiHallServer.h"
#include "TeenpattiCmd.h"

HallSocketHandler::HallSocketHandler(void)
{
    m_reconnect_timer.SetTimeEventObj(this,0);
	m_bConntected = false;
}

HallSocketHandler::HallSocketHandler(CTeenpattiHallServer* pHallServer)
{
	m_reconnect_timer.SetTimeEventObj(this,0);
	m_pHallServer = pHallServer;
}

HallSocketHandler::~HallSocketHandler(void)
{
}


int HallSocketHandler::Send(HallOutputPacket *pPacket, int delete_buffer, int close_flag)
{
	return ICHAT_TCP_Handler<>::Send(pPacket->packet_buf(), pPacket->packet_size(), delete_buffer, close_flag);
}
////////////////////////////////////////////////////////////////////////////////
// OnParser(char *buf, int nLen)
////////////////////////////////////////////////////////////////////////////////
int HallSocketHandler::OnParser(char *buf, int nLen)
{
	return ParsePacket(buf, nLen);
}
////////////////////////////////////////////////////////////////////////////////
// OnPacketComplete ��Ӧ���
////////////////////////////////////////////////////////////////////////////////
int HallSocketHandler::OnPacketComplete(HallInputPacket *pPacket)
{
	return ProcessPacket(pPacket);
}

int HallSocketHandler::ProcessPacket(HallInputPacket* pPacket)
{
	switch (pPacket->GetCmdType())
	{
	case CREATE_PRIVATE_ROOM:		//hall server ���󴴽�����
		{
			int nRoomId = pPacket->ReadInt();
			int nRoomType = pPacket->ReadInt();
			int nBaseChip = pPacket->ReadInt();
			string sRoomName = pPacket->ReadString();
			string sPassword = pPacket->ReadString();
			m_pHallServer->CreatePrivateRoom(nRoomId, nRoomType, nBaseChip, sRoomName, sPassword);
			break;
		}
	case SERVER_SEND_RETIRE:
		{
			int nRetire = pPacket->ReadShort();
			m_pHallServer->SendRetireToHall(nRetire);
			ACE_DEBUG((LM_DEBUG, ACE_TEXT("%s||Server Retired[%d]\n"), __FUNCTION__, nRetire));
			break;
		}
	case SERVER_CMD_SYNC:
		{
			HallOutputPacket OutPkg;
			OutPkg.Begin(CLIENT_CMD_SYNC);
			OutPkg.End();
			Send(&OutPkg);
			break;
		}
	default:
		return 0;
	}
	return 0;
}

////////////////////////////////////////////////////////////////////////////////
// OnClose(void)
////////////////////////////////////////////////////////////////////////////////
int HallSocketHandler::OnClose(void)
{
	//����״̬��0 ����������ʱ����
	if(m_bConntected)	
	{
		m_bConntected = false;
		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D] AllocServer close, trying to reconnect\r\n")));
	}
	m_reconnect_timer.StopTimer();
    m_reconnect_timer.StartTimer(1);
	return 1;  //only close , but not remove Reactor
}

////////////////////////////////////////////////////////////////////////////////
// OnConnected(void)
////////////////////////////////////////////////////////////////////////////////
int HallSocketHandler::OnConnected(void)
{
	m_bConntected = true;
	m_reconnect_timer.StopTimer();
	ACE_DEBUG((LM_DEBUG, ACE_TEXT("[%D] AllocServer Connect ok\r\n")));
	m_pHallServer->ReportServerData();
	m_pHallServer->SendPortIPToHall();
	m_pHallServer->ReportSelfRetireStatus();
	return 0;
}

int HallSocketHandler::OnTimer(const void *)
{
	if(m_pHallServer == NULL)
	{
		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D] AllocServer == NULL\r\n")));
		return -1;
	}
	ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D] Reconnecting AllocServer\r\n")));
 	m_pHallServer->Reconnect();
	return 0;
}

int HallSocketHandler::ProcessOnTimerOut(int Timerid)
{
	(void)Timerid;
	if(m_pHallServer == NULL)
	{
		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]:(%P|%t) HallServer\r\n")));
		return -1;
	}
	ACE_DEBUG((LM_DEBUG, ACE_TEXT("[%D]:(%P|%t) Reconnecting AllocServer\r\n")));
 	m_pHallServer->Reconnect();
	return 0;
}

