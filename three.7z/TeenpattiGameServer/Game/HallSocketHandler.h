#ifndef BOYAA_LANDLORD_HALLSOCKETHANDLER_H_20100430
#define BOYAA_LANDLORD_HALLSOCKETHANDLER_H_20100430

#include "ICHAT_TCP_Handler.h"
#include "ICHAT_Timer_Handler.h"
#include "ICHAT_PacketBase.h"
#include "wtypedef.h"

typedef InputPacket<ICHAT_TCP_DEFAULT_BUFFER>	HallInputPacket;
typedef OutputPacket<ICHAT_TCP_DEFAULT_BUFFER>	HallOutputPacket;



class CTeenpattiHallServer;

class HallSocketHandler:public ICHAT_TCP_Handler<>,
	public ICHAT_PacketParser<HallInputPacket>,
    public TimerOutEvent
{ 
public:
	HallSocketHandler(void);
	HallSocketHandler(CTeenpattiHallServer* pHallServer);

	virtual ~HallSocketHandler(void);
public:
	int Send(HallOutputPacket *pPacket, int delete_buffer = 0, int close_flag = 0);
	//�ر�
	int OnClose(void);
	//�������
	int OnConnected(void);
	//��Ӧ
	int OnParser(char *buf, int nLen);
	//OnTimer
	int OnTimer(const void *);
	//�Ƿ�����
	bool IsConnected(void)	{return m_bConntected;}
	//�������ӵ�ַ
	ACE_INET_Addr &Addr(void) {return m_remote;}
	void Addr(ACE_INET_Addr &addr) { m_remote = addr;}

	HallInputPacket *GetPacket(void)
	{
		return &m_Packet;
	}

	int  ProcessOnTimerOut(int Timerid);
private:
	HallInputPacket m_Packet;
	
	ICHAT_Timer_Handler m_reconnect_timer;//����������ʱ��
	//��ַ
	ACE_INET_Addr m_remote;
	//�ص�proxyManager
	CTeenpattiHallServer *m_pHallServer;
	//����״̬
	bool m_bConntected;
	//packet
	int OnPacketComplete(HallInputPacket *);

	int ProcessPacket(HallInputPacket* pPacket);
};

#endif

