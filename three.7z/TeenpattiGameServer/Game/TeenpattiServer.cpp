#include "SocketHandler.h"
#include "TeenpattiServer.h"
#include "TeenpattiCreator.h"
#include "TeenpattiCmd.h"
#include "ICHAT_HTTP_Config.h"
#include "GameCmd.h"
#include "RedisServer.h"
#include "GameServer.h"

#include <math.h>

#include "clib_log.h"
extern clib_log* g_pErrorLog;
extern clib_log* g_pDebugLog;

extern int Getunixtime();

#ifndef WIN32
#include <time.h>
#include <sys/time.h>

#define   REPORT_ON_OFF_LINE_TIMER		1
#define   REPORT_ON_OFF_LINE_TIMEOUT	60

#define   CLEAR_SAME_USER_TIMER			2
#define	  CLEAR_SAME_USER_TIMEOUT		600

#define	  REPORT_ONLINE_COUNT			3
#define   REPORT_ONLINE_TIMEROUT		300

DWORD GetTickCount1()
{
	timeval timesnow;
	struct timezone tmpzone;
	gettimeofday(&timesnow,&tmpzone);
	return ((DWORD)(timesnow.tv_sec*1000) + (DWORD)(timesnow.tv_usec/1000));
}
int Getunixtime1()
{
	timeval timesnow;
	struct timezone tmpzone;
	gettimeofday(&timesnow,&tmpzone);
	return ((int)(timesnow.tv_sec));
}
#else
#include<stdlib.h>
int Getunixtime1()
{
	DWORD start = GetTickCount1();
	int time = (int)start / 1000;
	return time;
}
#endif

CTeenpattiServer::CTeenpattiServer(void)
{
	m_pLandSendPacket = NULL;
	nRetire = 0;
	nRobotCount = 0;
}

CTeenpattiServer::~CTeenpattiServer(void)
{

}

BOOL CTeenpattiServer::InitServerEx()
{
	m_pLandSendPacket = dynamic_cast<CTeenpattiSendPacket *>(m_pSendPacket);
	if (m_pLandSendPacket == NULL)
	{
		return FALSE;
	}

	ICHAT_HTTP_Config ConfigReader;
	int nRet = ConfigReader.Open(TEENPATTI_SERVER_CONF_PATH);
	if(nRet == -1)
	{
		ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT("ReadLandlordConfig failed\n")), FALSE);
		return FALSE;
	}
	ACE_Configuration_Section_Key subkey;
	ConfigReader.OpenSection("LandlordServerConf", subkey);
	ConfigReader.get_section_integer(subkey, "NEXT_ROUND_TIMEOUT", m_LandlordServConf.nNextRoundTimeout, 1, 60);
	ConfigReader.get_section_integer(subkey, "LAND_BREAK_TIMEOUT", m_LandlordServConf.nLandBreakTimeout, 1, 60);
	ConfigReader.get_section_integer(subkey, "USER_BANKBRUCK_CHIP", m_LandlordServConf.nUserBankbruckChip, 500, 10000);

	char szLevel[32] = {0};
	sprintf(szLevel, "Level%d", m_nLevel);
	ConfigReader.OpenSection(szLevel, subkey);
	ConfigReader.get_section_integer(subkey, "BASE_CHIPS", m_LandlordServConf.nBaseChips, 0, 1000000000);
	ConfigReader.get_section_integer(subkey, "REQUIRE_CHIPS", m_LandlordServConf.nRequireChips, 0, 1000000000);
	ConfigReader.get_section_integer(subkey, "MAXUSER_CHIPS", m_LandlordServConf.nMaxUserChips, 0, 1000000000);	
	ConfigReader.get_section_integer(subkey, "START_GAME_TIMEOUT", m_LandlordServConf.nWaitGameTimeout, 1, 60);
	ConfigReader.get_section_integer(subkey, "CALL_CARD_TIMEOUT", m_LandlordServConf.nCallCardTimeout, 1, 60);
	ConfigReader.get_section_integer(subkey, "MAX_HAND_BET", m_LandlordServConf.nMaxHandBet, 0 ,999999999);
	ConfigReader.get_section_integer(subkey, "MAX_CALL_TIME", m_LandlordServConf.nMaxCallTimes, 0 ,999999999);
	ConfigReader.get_section_integer(subkey, "MAX_TABLE_CHIP", m_LandlordServConf.nMaxTableChip, 0 ,999999999);
	ConfigReader.get_section_string(subkey, "TABLENAME", m_LandlordServConf.strName, sizeof(m_LandlordServConf.strName));
	ConfigReader.get_section_integer(subkey, "EXPEND", m_LandlordServConf.nExp, 5, 100);
	ConfigReader.get_section_integer(subkey, "MIN_COMPARE", m_LandlordServConf.nMinCompare, 1, 100);
	ConfigReader.get_section_integer(subkey, "MAX_ALLIN", m_LandlordServConf.nAllIn, 1, 999999999);
	ConfigReader.get_section_integer(subkey, "CREAT_ROBOT_TIMEOUT", m_RobotConf.nCreateRobotTimeout, 1, 10);
	ConfigReader.get_section_long(subkey, "ROBOTMONEY", m_RobotConf.nCreatRobotMoney, 1, 1000000000000);
	ConfigReader.get_section_long(subkey, "ROBOTMONEYLOW", m_RobotConf.nCreateRobotLowMoney, 1, 1000000000000);
	ConfigReader.get_section_long(subkey, "ROBOTMONEYHIGH", m_RobotConf.nCreateRobotHighMoney, 1, 1000000000000);
	ConfigReader.get_section_integer(subkey, "ROBOT_MAX_COUNT", m_RobotConf.nCreateRobotMaxCount, 1, 50);

	int nCount = 0;
	ConfigReader.get_section_integer(subkey, "COUNT", nCount, 0, 9999);
	g_pErrorLog->logMsg(" nCount %d",nCount);
	for( int i = 1; i <= nCount; i++)
	{
		char szKey[128] = {0};
		int  nUserId = 0;
		snprintf(szKey, sizeof(szKey), "USERID%d", i);
		ConfigReader.get_section_integer(subkey, szKey, nUserId, 1, 9999);
		g_pErrorLog->logMsg("key[%s] uid [%d]", szKey,nUserId);
		snprintf(szKey, sizeof(szKey), "ROBORINFO%d", i);
		char szUserInfo[1024] = {0};
		ConfigReader.get_section_string( subkey, szKey, szUserInfo, sizeof(szUserInfo));
		g_pErrorLog->logMsg("key[%s] userinfo [%s]", szKey,szUserInfo);
		string strUserInfo = szUserInfo;
		m_RobotConf.mRobotInfo[nUserId] = strUserInfo;
	}
	
	g_pErrorLog->logMsg("m_RobotConf begin");

	map<int, string>::iterator iter;

	for ( iter=m_RobotConf.mRobotInfo.begin(); iter!=m_RobotConf.mRobotInfo.end(); ++iter)
	{
		g_pErrorLog->logMsg("m_RobotConf first [%d], m_RobotConf second [%s]",iter->first, (iter->second).c_str());
	}

	g_pErrorLog->logMsg("m_RobotConf end");

	m_LandlordServConf.nGamePlayerCount = 5;
	m_LandlordServConf.nLevel = m_nLevel;

	int nTableCount = (int)m_TableList.size();
	g_pDebugLog->logMsg("nTableCount %d , m_nMaxTableCount %d",nTableCount,m_nMaxTableCount);
	while ( nTableCount < m_nMaxTableCount )
	{
		CreateNewTable();
		nTableCount ++ ;

		if ( m_nLevel == 1 )
		{
			if ( nTableCount < 6 )
			{
				int nTableId = (m_nServerID<<16) + (int)m_TableList.size() - 1;

				vecRobotTid.push_back(nTableId);

				CGameTable* pTable = m_TableList[nTableId];

				if ( pTable )
				{
					ProcTimeoutCreateRobot(pTable);
					ProcTimeoutCreateRobot(pTable);
				}
			}
		}
	}

	if ( m_nLevel == 2 )
	{
		int nTableId = (m_nServerID<<16) + (int)m_TableList.size() - 1;

		CGameTable* pTable = m_TableList[nTableId];

		vecRobotTid.push_back(nTableId);

		if ( pTable )
		{
			ProcTimeoutCreateRobot(pTable);
			ProcTimeoutCreateRobot(pTable);
			ProcTimeoutCreateRobot(pTable);
		}

		nTableId = (m_nServerID<<16) + (int)m_TableList.size() - 2;

		pTable = m_TableList[nTableId];

		vecRobotTid.push_back(nTableId);

		if ( pTable )
		{
			ProcTimeoutCreateRobot(pTable);
			ProcTimeoutCreateRobot(pTable);
			ProcTimeoutCreateRobot(pTable);
		}

		nTableId = (m_nServerID<<16) + (int)m_TableList.size() - 3;

		pTable = m_TableList[nTableId];

		vecRobotTid.push_back(nTableId);

		if ( pTable )
		{
			ProcTimeoutCreateRobot(pTable);
			ProcTimeoutCreateRobot(pTable);
		}

		nTableId = (m_nServerID<<16) + (int)m_TableList.size() - 4;

		pTable = m_TableList[nTableId];

		vecRobotTid.push_back(nTableId);

		if ( pTable )
		{
			ProcTimeoutCreateRobot(pTable);
			ProcTimeoutCreateRobot(pTable);
		}

		nTableId = (m_nServerID<<16) + (int)m_TableList.size() - 5;

		pTable = m_TableList[nTableId];

		vecRobotTid.push_back(nTableId);

		if ( pTable )
		{
			ProcTimeoutCreateRobot(pTable);
		}
	}

	return TRUE;
}

int CTeenpattiServer::ProcessClose(SocketHandler *pHandler)
{
	CGameUser *pUser = pHandler->GetUser();
	if(pUser!=NULL && pUser->GetHandler() == pHandler)
	{
		g_pDebugLog->logMsg("CTeenpattiServer::ProcessClose ");
		ProcUserLogout(pUser);
	}
	return SocketServer::ProcessClose(pHandler);
}

int	CTeenpattiServer::ProcUserRequireLogout(CGameUser *pUser)
{
	g_pDebugLog->logMsg("-------- CTeenpattiServer::ProcUserRequireLogout begin ----------");
	if ( !pUser )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserRequireLogout end 1 ----------");
		return m_pLandSendPacket->SendUserLogoutError(pUser->GetHandler(), LOUGOUT_USER_NOT_FOUND);
	}

	CTeenpattiTable *pLandTable = (CTeenpattiTable*)pUser->GetTable();

	if ( !pLandTable )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserRequireLogout end 2 ----------");
		CGameServer::ProcUserLogout(pUser);
		return 0;
	}

	if ( pUser->GetSeatId() != INVAILD_SEAT_ID )
	{
		ProcUserStand(pUser);
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserRequireLogout end 3 ----------");
	}
		

	CTeenpattiUser *pLandUser = (CTeenpattiUser*)pUser;

	if ( pLandUser->m_nStatus == USER_STATUS_PALY )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserRequireLogout end 4 [%d]----",pUser->GetUserId());
		return m_pLandSendPacket->SendUserLogoutError(pUser->GetHandler(), LOUGOUT_USER_STATUS_ERROR);
	}
	
	CGameServer::ProcUserLogout(pLandUser);
	m_pHallServer->UpdateRoomUserCount(pLandTable);
	g_pDebugLog->logMsg("------------- CTeenpattiServer::ProcUserRequireLogout end ---------");
	return 0;
}

int CTeenpattiServer::ProcUserLogout(CGameUser *pUser)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserLogout begin ----------");
 	CTeenpattiUser *pLandUser = (CTeenpattiUser*)pUser;

	if(pLandUser == NULL)
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserLogout end 1 ----------");
		return 0;
	}

	CTeenpattiTable *pLandTable = (CTeenpattiTable*)pLandUser->GetTable();

	if(pLandTable == NULL)
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserLogout end 2 ----------");
		CGameServer::ProcUserLogout(pLandUser);
		return 0;
	}

	if ( ( pLandTable->GetGameStatus() != STATUS_STOP) && ( pLandUser->m_nStatus == USER_STATUS_PALY ) )
	{
		g_pDebugLog->logMsg("ProcUserLogout||User[%d] OffLine", pLandUser->GetUserId());
		  
		if (pUser->m_pSocket != NULL)
		{
			pUser->m_pSocket->SetUser(NULL, pUser->m_dwSessionID);
		}
		pLandUser->m_pSocket = NULL;
		pLandUser->m_bOnline = FALSE;
		m_DisconnectUserList[pLandUser->GetUserId()] = pLandUser;
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserLogout end 3 ----------");
		return 0;
	}

	if ( pLandTable->GetGameStatus() == STATUS_STOP )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserLogout end 4 ----------");
		pLandTable->m_bWaitStart = FALSE;
	}

	if ( pUser->GetSeatId() != INVAILD_SEAT_ID )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserLogout end 5 ----------");
		pLandTable->StandTable(pUser);
	}
		
	CGameServer::ProcUserLogout(pLandUser);
	m_pHallServer->UpdateRoomUserCount(pLandTable);

	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserLogout end ----------");
	return 0;
}

int CTeenpattiServer::ProcUserReconnect(CGameUser* pUser, int nUserId, SocketHandler *pSocket)
{
	g_pErrorLog->logMsg("----------- CTeenpattiServer::ProcUserReconnect begin ------------");
	UserIdMap::iterator iter = m_DisconnectUserList.find(nUserId);
	if (iter == m_DisconnectUserList.end())
	{
		g_pErrorLog->logMsg("%s:CTeenpattiServer::ProcUserReconnect can not find uid:[%d]", __FUNCTION__, nUserId);
		return 0;
	}

	pUser = m_DisconnectUserList[nUserId];
	m_DisconnectUserList.erase(nUserId);
	pSocket->SetUser(pUser);
	pUser->m_pSocket = pSocket;

	CTeenpattiUser* pLandUser = (CTeenpattiUser*)pUser;

	pLandUser->m_bOnline = TRUE;

	CTeenpattiTable* pLandTable = (CTeenpattiTable*)(pUser->GetTable());
	if (pLandTable == NULL)
	{
		g_pErrorLog->logMsg("%s:CTeenpattiServer::ProcUserReconnect pLandTable==NULL, uid:[%d]", __FUNCTION__, nUserId);
		return 0;
	}

	m_pHallServer->UpdateRoomUserCount(pLandTable);	

	m_pLandSendPacket->SendUserLoginSuccess(pSocket, pUser);
	g_pErrorLog->logMsg("----------- CTeenpattiServer::ProcUserReconnect end ------------");
	return 0;
}

int CTeenpattiServer::ProcSysCmdResetConfig(void)
{
	ICHAT_HTTP_Config ConfigReader;
	int nRet = ConfigReader.Open(TEENPATTI_SERVER_CONF_PATH);
	if(nRet == -1)
	{
		ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT("ReadLandlordConfig failed\n")), 0);
	}
	ACE_Configuration_Section_Key subkey;
	ConfigReader.OpenSection("LandlordServerConf", subkey);
	ConfigReader.get_section_integer(subkey, "NEXT_ROUND_TIMEOUT", m_LandlordServConf.nNextRoundTimeout, 1, 60);
	ConfigReader.get_section_integer(subkey, "LAND_BREAK_TIMEOUT", m_LandlordServConf.nLandBreakTimeout, 1, 60);
	ConfigReader.get_section_integer(subkey, "USER_BANKBRUCK_CHIP", m_LandlordServConf.nUserBankbruckChip, 500, 10000);

	char szLevel[32] = {0};
	sprintf(szLevel, "Level%d", m_nLevel);
	ConfigReader.OpenSection(szLevel, subkey);
	ConfigReader.get_section_integer(subkey, "BASE_CHIPS", m_LandlordServConf.nBaseChips, 0, 1000000000);
	ConfigReader.get_section_integer(subkey, "REQUIRE_CHIPS", m_LandlordServConf.nRequireChips, 0, 1000000000);
	ConfigReader.get_section_integer(subkey, "MAXUSER_CHIPS", m_LandlordServConf.nMaxUserChips, 0, 1000000000);
	ConfigReader.get_section_integer(subkey, "CALL_CARD_TIMEOUT", m_LandlordServConf.nCallCardTimeout, 1, 60);
	ConfigReader.get_section_integer(subkey, "START_GAME_TIMEOUT", m_LandlordServConf.nWaitGameTimeout, 1, 60);
	ConfigReader.get_section_integer(subkey, "MAX_HAND_BET", m_LandlordServConf.nMaxHandBet, 0 ,999999999);
	ConfigReader.get_section_integer(subkey, "MAX_CALL_TIME", m_LandlordServConf.nMaxCallTimes, 0 ,999999999);
	ConfigReader.get_section_integer(subkey, "MAX_TABLE_CHIP", m_LandlordServConf.nMaxTableChip, 0 ,999999999);
	ConfigReader.get_section_string(subkey, "TABLENAME", m_LandlordServConf.strName, sizeof(m_LandlordServConf.strName));
	ConfigReader.get_section_integer(subkey, "EXPEND", m_LandlordServConf.nExp, 5, 100);
	ConfigReader.get_section_integer(subkey, "MIN_COMPARE", m_LandlordServConf.nMinCompare, 1, 100);
	ConfigReader.get_section_integer(subkey, "MAX_ALLIN", m_LandlordServConf.nAllIn, 1, 999999999);
	ConfigReader.get_section_integer(subkey, "CREAT_ROBOT_TIMEOUT", m_RobotConf.nCreateRobotTimeout, 1, 10);
	ConfigReader.get_section_long(subkey, "ROBOTMONEY", m_RobotConf.nCreatRobotMoney, 1, 1000000000000);
	ConfigReader.get_section_long(subkey, "ROBOTMONEYLOW", m_RobotConf.nCreateRobotLowMoney, 1, 1000000000000);
	ConfigReader.get_section_long(subkey, "ROBOTMONEYHIGH", m_RobotConf.nCreateRobotHighMoney, 1, 1000000000000);
	ConfigReader.get_section_integer(subkey, "ROBOT_MAX_COUNT", m_RobotConf.nCreateRobotMaxCount, 1, 50);

	int nCount = 0;
	ConfigReader.get_section_integer(subkey, "COUNT", nCount, 0, 9999);
	g_pErrorLog->logMsg(" nCount %d",nCount);
	for( int i = 1; i <= nCount; i++)
	{
		char szKey[128] = {0};
		int  nUserId = 0;
		snprintf(szKey, sizeof(szKey), "USERID%d", i);
		ConfigReader.get_section_integer(subkey, szKey, nUserId, 1, 9999);
		g_pErrorLog->logMsg("key[%s] uid [%d]", szKey,nUserId);
		snprintf(szKey, sizeof(szKey), "ROBORINFO%d", i);
		char szUserInfo[1024] = {0};
		ConfigReader.get_section_string( subkey, szKey, szUserInfo, sizeof(szUserInfo));
		g_pErrorLog->logMsg("key[%s] userinfo [%s]", szKey,szUserInfo);
		string strUserInfo = szUserInfo;
		m_RobotConf.mRobotInfo[nUserId] = strUserInfo;
	}
	
	g_pErrorLog->logMsg("m_RobotConf begin");

	map<int, string>::iterator iter;

	for ( iter=m_RobotConf.mRobotInfo.begin(); iter!=m_RobotConf.mRobotInfo.end(); ++iter)
	{
		g_pErrorLog->logMsg("m_RobotConf first [%d], m_RobotConf second [%s]",iter->first, (iter->second).c_str());
	}

	g_pErrorLog->logMsg("m_RobotConf end");

	m_LandlordServConf.nLevel = m_nLevel;
  
	return 0;
}

int CTeenpattiServer::ReportUserStandTable(CGameUser* pUser)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ReportUserStandTable begin ----------");
	CTeenpattiTable *pLandTable = (CTeenpattiTable*)pUser->GetTable();

	if ( NULL == pLandTable )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ReportUserStandTable end 1 ----------");
		return 0;
	}

	CTeenpattiUser* CTUser = (CTeenpattiUser*)pUser;

	if ( !CTUser->m_bLooker )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ReportUserStandTable end 2 ----------");
		CTUser->m_bLooker = TRUE;
		m_pHallServer->ReportStandRoom(pUser->GetUserId(), pLandTable->GetID());
	}
	

	g_pErrorLog->logMsg("------------ CTeenpattiServer::ReportUserStandTable end ----------");
	return 0;
}

int CTeenpattiServer::ProcUserSit(CGameUser *pUser, BYTE bySeatId)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserSit begin ----------");
	g_pErrorLog->logMsg("CTeenpattiServer::ProcUserSit bySeatId %d",bySeatId);

	if ( !pUser )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserSit end 1 ----------");
		return 0;
	}

	CTeenpattiTable *pLandTable = (CTeenpattiTable*)pUser->GetTable();

	if ( !pLandTable )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserSit end 2 ----------");
		return m_pLandSendPacket->SendUserSitError(pUser->GetHandler(), SIT_TABLE_NOT_FOUND, pUser->m_nMoney);
	}

	int nUserId = pUser->GetUserId();
	g_pErrorLog->logMsg("nUserId : %d",nUserId);

	int memServerId = nUserId%(int)m_MemDataServerMap.size();
	CMemDataServer *pMemServer = GetMemDataServer(memServerId);
	if(pMemServer == NULL)
	{
		g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcUserSit end 3 ---------------");
		return 0;
	}

	USERDATA data;
	if (pMemServer->GetUserInfo(nUserId, data) < 0)
	{
		ReportUserStandTable(pUser);
		g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcUserSit end 4 ---------------");
		return 0;
	}	

	pUser->m_nMoney = data.money;

	g_pErrorLog->logMsg("m_nMoney : %ld",pUser->m_nMoney);
	g_pErrorLog->logMsg("m_nRequireChips : %d",pLandTable->m_nRequireChips);

	if ( pUser->m_nMoney < pLandTable->m_nRequireChips )
	{
		ReportUserStandTable(pUser);
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserSit end 5 ----------");
		return m_pLandSendPacket->SendUserSitError(pUser->GetHandler(), SIT_LOW_REQUEST_MONEY, pUser->m_nMoney);
	}

	if ( m_nLevel < 7 )
	{
		if ( pUser->m_nMoney > pLandTable->m_nMaxUserChips )
		{
			ReportUserStandTable(pUser);
			g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserSit end 6 ----------");
			return m_pLandSendPacket->SendUserSitError(pUser->GetHandler(), SIT_OVER_MAX_MONEY, pUser->m_nMoney);
		}
	}
	
	CTeenpattiUser* pLandlordUser = (CTeenpattiUser*)pUser;

	if(nRetire == 1)
	{
		pLandlordUser->ResetKickUserTimer();
		ReportUserStandTable(pUser);
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserSit end 7 ----------");
		return m_pLandSendPacket->SendUserSitError(pUser->GetHandler(), SIT_UPDATE_SERVER, pUser->m_nMoney);
	}

	if ( bySeatId > 5 || bySeatId < 0 )
	{
		ReportUserStandTable(pUser);
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserSit end 8 ----------");
		return m_pLandSendPacket->SendUserSitError(pUser->GetHandler(), SIT_SEAT_ERROR, pUser->m_nMoney);
	}

	for ( BYTE i=0; i<USER_PLAY_COUNT; i++ )
	{
		CGameUser* pGameUser = (pUser->GetTable())->m_SeatList[i]->m_pUser;
	
		if ( pGameUser != NULL)
		{
			if ( pGameUser->GetUserId() == pUser->GetUserId() )
			{
				ReportUserStandTable(pUser);
				g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserSit end 9 ----------");
				return m_pLandSendPacket->SendUserSitError(pUser->GetHandler(), SIT_AGAIN, pUser->m_nMoney);
			}
		}
	}

	if ( ! (pUser->GetTable())->UserSit(bySeatId, pUser) )
	{
		ReportUserStandTable(pUser);
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserSit end 10 ----------");
		return m_pLandSendPacket->SendUserSitError(pUser->GetHandler(), SIT_NOT_EMPTY, pUser->m_nMoney);
	}

	g_pErrorLog->logMsg(" userid %d",pUser->GetUserId());

	if ( pLandlordUser->m_bLooker )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserSit end 14 ----------");
		pLandlordUser->m_bLooker = FALSE;
		m_pHallServer->StandTableLeaveRoom(nUserId);
	}

	pLandTable->UserReady((CTeenpattiUser*)pUser);
	
	m_pLandSendPacket->BroadcastUserSitSuccess(pLandTable, pUser);
 
	m_pHallServer->UpdateRoomUserCount(pLandTable);
	
	g_pErrorLog->logMsg("pLandTable->GetReadyUserCount %d",pLandTable->GetSitUserCount());

	g_pErrorLog->logMsg("pLandTable->GetGameStatus %d",pLandTable->GetGameStatus());
	if ( pLandTable->GetSitUserCount() >= 2 && ( pLandTable->GetGameStatus() == STATUS_STOP ))	
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserSit end 11 ----------");

		if ( pLandTable->m_bWaitStart == FALSE)
		{
			g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserSit end 12 ----------");
			pLandTable->WaitStartGameTimer(m_LandlordServConf.nWaitGameTimeout);
		}	
	}

	if ( pLandTable->GetSitUserCount() == 1 )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserSit end 13 ----------");
		g_pErrorLog->logMsg("nRobotCount [%d]",nRobotCount);
		if ( nRobotCount < m_RobotConf.nCreateRobotMaxCount )
		{
			pLandTable->ResetCreateRobotTimer(m_RobotConf.nCreateRobotTimeout);
		}
	}

	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserSit end ----------");

	return 0;
}

int CTeenpattiServer::UserCanSit(CTeenpattiTable *pLandTable, CGameUser *pUser)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::UserCanSit begin ----------");

	if ( pUser->m_nMoney < m_LandlordServConf.nUserBankbruckChip )	//玩家破产
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::UserCanSit end 1 ----------");
		m_pLandSendPacket->SendUserBankbruck(pUser->GetHandler());
		((CTeenpattiUser*)pUser)->StartKickBankruptTimer();
		return 0;
	}

	if ( pUser->m_nMoney < pLandTable->m_nRequireChips )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::UserCanSit end 2 ----------");
		m_pLandSendPacket->SendUserSitError(pUser->GetHandler(), SIT_LOW_REQUEST_MONEY, pUser->m_nMoney);
		((CTeenpattiUser*)pUser)->StartKickBankruptTimer();
		return 0;
	}

	if ( m_nLevel < 7 )
	{
		if ( pUser->m_nMoney > pLandTable->m_nMaxUserChips )
		{
			g_pErrorLog->logMsg("------------ CTeenpattiServer::UserCanSit end 3 ----------");
			m_pLandSendPacket->SendUserSitError(pUser->GetHandler(), SIT_OVER_MAX_MONEY, pUser->m_nMoney);
			((CTeenpattiUser*)pUser)->StartKickBankruptTimer();
			return 0;
		}
	}

	if ( ((CTeenpattiUser*)pUser)->m_nTimoutCall >= 3 )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::UserCanSit end 4 ----------");
		m_pLandSendPacket->SendUserTimoutStand(pUser->GetHandler());
		((CTeenpattiUser*)pUser)->StartKickBankruptTimer();
		return 0;
	}

	g_pErrorLog->logMsg("------------ CTeenpattiServer::UserCanSit end  ----------");
	return 0;
}

int CTeenpattiServer::ProcUserWatchCard(CGameUser *pUser)
{
	if ( !pUser )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserWatchCard end 1 ----------");
		return 0;
	}

	CTeenpattiTable *pLandTable = dynamic_cast<CTeenpattiTable *>(pUser->GetTable());

	if ( !pLandTable )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserWatchCard end 2 ----------");
		return m_pLandSendPacket->SendUserWatchCardError(pUser->GetHandler(), WATCH_TABLE_NOT_FOUND);
	}

	if ( pLandTable->GetGameStatus() != STATUS_PLAY )					
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserWatchCard end 3 ----------");
		return m_pLandSendPacket->SendUserWatchCardError(pUser->GetHandler(), WATCH_TABLE_STATUS_ERROR);
	}

	CTeenpattiUser* pLandUser = (CTeenpattiUser*)pUser;

	pLandUser->m_nTimoutCall = 0;
	pLandTable->m_bComapre = FALSE;
	pLandUser->m_bWatchCard = TRUE;
	pLandUser->m_nAttr = 2;
	pLandUser->m_nHandMoney = pLandUser->m_nHandMoney * 2;

	g_pErrorLog->logMsg(" m_nHandMoney %d ",pLandUser->m_nHandMoney);

	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserWatchCard end ----------");

	m_pLandSendPacket->SendUserWatchCardResult(pUser->GetHandler(), pLandUser->m_byHandCardData);

	pLandTable->m_bPockerLogType = 1;		
	pLandTable->LogRecord(pLandUser->GetUserId(), pLandTable->m_bPockerLogType, pLandUser->m_byHandCardData);

	return m_pLandSendPacket->SendUserWatchCard(pLandTable, pUser->GetUserId());
}

int CTeenpattiServer::ProcUserDisCard(CGameUser *pUser)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserDisCard begin ----------");

	if ( !pUser )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserDisCard end 1 ----------");
		return 0;
	}

	CTeenpattiTable *pLandTable = dynamic_cast<CTeenpattiTable *>(pUser->GetTable());

	if ( !pLandTable )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserDisCard end 2 ----------");
		return m_pLandSendPacket->SendUserDisCardError(pUser->GetHandler(), DIS_TABLE_NOT_FOUND);
	}

	if (  pLandTable->GetGameStatus() != STATUS_PLAY )					
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserDisCard end 3 ----------");
		return m_pLandSendPacket->SendUserDisCardError(pUser->GetHandler(), DIS_TABLE_STATUS_ERROR);
	}

	CTeenpattiUser* pLandUser = (CTeenpattiUser*)pUser;

	g_pErrorLog->logMsg("userid : [%d]",pLandUser->GetUserId());

	pLandUser->m_bDisCard = TRUE;
	pLandUser->m_nAttr = 3;

	int nNextOutUserId = 0;  //到玩家自己操作和不是该玩家自己操作

	if( pLandTable->m_nCurCallSeatId != pLandUser->GetSeatId() )
	{
		m_pLandSendPacket->SendUserDisCard(pLandTable, pUser->GetUserId(), nNextOutUserId, pLandTable->m_nCinglTimes);
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserDisCard end 4 ----------");
	}
	else
	{
		nNextOutUserId = pLandTable->GetNextCallUserId();
		g_pErrorLog->logMsg("nNextOutUserId 11 : %d",nNextOutUserId);
		CTeenpattiUser *pNextUser = pLandTable->GetUserByUserId(nNextOutUserId);
		if ( ( pNextUser ) && ( pNextUser->m_bRobot) )
		{
			g_pErrorLog->logMsg(" StartRobotCall  1");
			pLandTable->StartRobotCall();
		}
		else
		{
			pLandTable->ResetCallTimer(m_LandlordServConf.nCallCardTimeout);
		}

		m_pLandSendPacket->SendUserDisCard(pLandTable, pUser->GetUserId(), nNextOutUserId, pLandTable->m_nCinglTimes);
	}

	pLandTable->m_bComapre = FALSE;
	pLandTable->m_bPockerLogType = 2;		
	pLandTable->LogRecord(pLandUser->GetUserId(), pLandTable->m_bPockerLogType, pLandUser->m_byHandCardData);

	if ( pLandTable->IsGameOver() )
	{
		pLandTable->GetWinner();
		StopGame(pLandTable);
	}
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserDisCard end ----------");
	return 0;
}

int CTeenpattiServer::ProcUpdateUserInfo(CGameUser *pUser, string strUserInfo)
{
	pUser->m_strUserInfo = strUserInfo;
	return 0;
}

int CTeenpattiServer::ProcUserCingl(CGameUser* pUser, long nMoney)
{	
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCingl begin ----------");
	g_pErrorLog->logMsg("nMoney : %ld",nMoney);

	if ( !pUser )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCingl end 1 ----------");
		return 0;
	}

	CTeenpattiTable *pLandTable = dynamic_cast<CTeenpattiTable *>(pUser->GetTable());
	g_pErrorLog->logMsg("Cingl userid  : %d",pUser->GetUserId());

	if ( !pLandTable )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCingl end 2 ----------");
		return m_pLandSendPacket->SendUserCinglError(pUser->GetHandler(), CINGL_TABLE_NOT_FOUND);
	}

	if (  pLandTable->GetGameStatus() != STATUS_PLAY )					
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCingl end 3 ----------");
		return m_pLandSendPacket->SendUserCinglError(pUser->GetHandler(), CINGL_TABLE_STATUS_ERROR);
	}

	CTeenpattiUser* pLandUser = (CTeenpattiUser*)pUser;
		
	if( pLandTable->m_nCurCallSeatId != pLandUser->GetSeatId() ) 
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCingl end 4 ----------");
		return m_pLandSendPacket->SendUserCinglError(pUser->GetHandler(), CINGL_SEAT_CANNOT_CALL);
	}
	
	if ( pLandUser->m_bDisCard )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCingl end 5 ----------");
		return m_pLandSendPacket->SendUserCinglError(pUser->GetHandler(), CINGL_DISCARD_CALL);
	}

	g_pErrorLog->logMsg("pUser->m_nMoney : %ld",pUser->m_nMoney);
	if ( nMoney > pUser->m_nMoney )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCingl end 6 ----------");
		return m_pLandSendPacket->SendUserCinglError(pUser->GetHandler(), CINGL_MONEY_LESS_ERROR);
	}

	if  ( pLandUser->m_bWatchCard )
	{
		if ( ( pLandTable->m_nHandBet * 2 != nMoney ) && ( nMoney < pUser->m_nMoney ) )
		{
			g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCingl end 7 ----------");
			return m_pLandSendPacket->SendUserCinglError(pUser->GetHandler(), CINGL_MONEY_ERROR);
		}
		pLandTable->m_nHandBet = nMoney / 2;
	}
	else
	{
		if ( ( pLandTable->m_nHandBet != nMoney ) && ( nMoney < pUser->m_nMoney ) )
		{
			g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCingl end 8 ----------");
			return m_pLandSendPacket->SendUserCinglError(pUser->GetHandler(), CINGL_MONEY_ERROR);
		}
		pLandTable->m_nHandBet = nMoney;
	}

	pLandTable->m_bComapre = FALSE;
	pLandUser->m_nTimoutCall = 0;
	pLandTable->m_nPotTotal += nMoney;
	pLandUser->m_nCostForTable += nMoney;
	pUser->m_nMoney -=  nMoney;
	pLandUser->m_nHandMoney = nMoney;
	g_pErrorLog->logMsg("pLandUser->m_nHandMoney : %d",pLandUser->m_nHandMoney);
	g_pErrorLog->logMsg("pLandTable->m_nPotTotal : %d",pLandTable->m_nPotTotal);
	g_pErrorLog->logMsg("ProcUserCingl CTUser->m_nCostForTable %d",pLandUser->m_nCostForTable);
	g_pErrorLog->logMsg("heve money : %ld",pUser->m_nMoney);
	g_pErrorLog->logMsg("pLandTable->m_nHandBet : %d",pLandTable->m_nHandBet);

	pLandTable->m_bPockerLogType = 4;		
	pLandTable->LogRecord(pLandUser->GetUserId(), pLandTable->m_bPockerLogType, pLandUser->m_byHandCardData, nMoney);

	g_pErrorLog->logMsg("m_nStartCallSeatId : %d",pLandTable->m_nStartCallSeatId);

	if ( 0 >= pUser->m_nMoney )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCingl end 9 ----------");
		pLandTable->m_byOverType = 1;
		pLandTable->m_nCalType = ALL_COMPARE;
		m_pLandSendPacket->BroadcastUserCingl(pLandTable, pUser->GetUserId(), nMoney, 0, 0, pLandTable->m_nCinglTimes);
		StopGame(pLandTable);
	}
	/*else if ( m_LandlordServConf.nMaxTableChip <= pLandTable->m_nPotTotal )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCingl end 10 ----------");
		pLandTable->m_byOverType = 2;
		pLandTable->m_nCalType = ALL_COMPARE;
		m_pLandSendPacket->BroadcastUserCingl(pLandTable, pUser->GetUserId(), nMoney, 0, 0, pLandTable->m_nCinglTimes);
		StopGame(pLandTable);
	}*/
	else if ( pLandTable->m_nCinglTimes >= m_LandlordServConf.nMaxCallTimes )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCingl end 11 ----------");
		pLandTable->m_byOverType = 3;
		pLandTable->m_nCalType = ALL_COMPARE;
		m_pLandSendPacket->BroadcastUserCingl(pLandTable, pUser->GetUserId(), nMoney, 0, 0, pLandTable->m_nCinglTimes);
		StopGame(pLandTable);
	}
	else
	{
		g_pErrorLog->logMsg("m_nStartCallSeatId : %d",pLandTable->m_nStartCallSeatId);
		int nNextOutUserId = pLandTable->GetNextCallUserId();
		g_pErrorLog->logMsg("nNextOutUserId 22 : %d",nNextOutUserId);
		m_pLandSendPacket->BroadcastUserCingl(pLandTable, pUser->GetUserId(), nMoney, 0, nNextOutUserId, pLandTable->m_nCinglTimes);
		CTeenpattiUser *pNextUser = pLandTable->GetUserByUserId(nNextOutUserId);
		if ( ( pNextUser ) && ( pNextUser->m_bRobot) )
		{
			g_pErrorLog->logMsg(" StartRobotCall  2");
			pLandTable->StartRobotCall();
		}
		else
		{
			pLandTable->ResetCallTimer(m_LandlordServConf.nCallCardTimeout);
		}
	}
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCingl end ----------");
	return 0;
}

int CTeenpattiServer::ProcUserAddCingl(CGameUser* pUser, long nAddMoney)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserAddCingl begin ----------");
	g_pErrorLog->logMsg("nAddMoney : %ld",nAddMoney);

	if ( !pUser )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserAddCingl end 1 ----------");
		return 0;
	}

	CTeenpattiTable *pLandTable = dynamic_cast<CTeenpattiTable *>(pUser->GetTable());
	g_pErrorLog->logMsg("AddCingl userid  : %d",pUser->GetUserId());

	if ( !pLandTable )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserAddCingl end 2 ----------");
		return m_pLandSendPacket->SendUserAddCinglError(pUser->GetHandler(), ADDCINGL_TABLE_NOT_FOUND);
	}

	if (  pLandTable->GetGameStatus() != STATUS_PLAY )					
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserAddCingl end 3 ----------");
		return m_pLandSendPacket->SendUserAddCinglError(pUser->GetHandler(), ADDCINGL_TABLE_STATUS_ERROR);
	}

	CTeenpattiUser* pLandUser = (CTeenpattiUser*)pUser;
		
	if( pLandTable->m_nCurCallSeatId != pLandUser->GetSeatId() ) 
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserAddCingl end 4 ----------");
		return m_pLandSendPacket->SendUserAddCinglError(pUser->GetHandler(), ADDCINGL_SEAT_CANNOT_CALL);
	}
	
	if ( pLandUser->m_bDisCard )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserAddCingl end 5 ----------");
		return m_pLandSendPacket->SendUserAddCinglError(pUser->GetHandler(), ADDCINGL_DISCARD_CALL);
	}

	g_pErrorLog->logMsg("pUser->m_nMoney : %ld",pUser->m_nMoney);
	if ( nAddMoney > pUser->m_nMoney )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserAddCingl end 6 ----------");
		return m_pLandSendPacket->SendUserCinglError(pUser->GetHandler(), ADDCINGL_MONEY_ERROR);
	}

	if  ( pLandUser->m_bWatchCard )
	{
		if ((( pLandTable->m_nHandBet * 2 >= nAddMoney ) && ( nAddMoney < pUser->m_nMoney )) || (2*m_LandlordServConf.nMaxHandBet < nAddMoney))
		{
			g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserAddCingl end 7 ----------");
			return m_pLandSendPacket->SendUserCinglError(pUser->GetHandler(), ADDCINGL_MONEY_ERROR);
		}
		pLandTable->m_nHandBet = nAddMoney / 2;
	}
	else
	{
		if ((( pLandTable->m_nHandBet >= nAddMoney ) && ( nAddMoney < pUser->m_nMoney )) || (m_LandlordServConf.nMaxHandBet < nAddMoney))
		{
			g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserAddCingl end 8 ----------");
			return m_pLandSendPacket->SendUserCinglError(pUser->GetHandler(), ADDCINGL_MONEY_ERROR);
		}
		pLandTable->m_nHandBet = nAddMoney;
	}

	g_pErrorLog->logMsg("pLandTable->m_nHandBet %d",pLandTable->m_nHandBet);
	g_pErrorLog->logMsg("pLandUser->m_nHandMoney %d",pLandUser->m_nHandMoney);

	pLandTable->m_bComapre = FALSE;
	pLandUser->m_nTimoutCall = 0;
	pLandUser->m_nHandMoney = nAddMoney;
	pLandTable->m_nPotTotal += nAddMoney;
	pLandUser->m_nCostForTable += nAddMoney;
	g_pErrorLog->logMsg("ProcUserAddCingl CTUser->m_nCostForTable %d",pLandUser->m_nCostForTable);
	pUser->m_nMoney -= nAddMoney;
	g_pErrorLog->logMsg("heve money : %ld",pUser->m_nMoney);

	pLandTable->m_bPockerLogType = 5;		
	pLandTable->LogRecord(pLandUser->GetUserId(), pLandTable->m_bPockerLogType, pLandUser->m_byHandCardData, nAddMoney);

	if ( 0 >= pUser->m_nMoney )  //钱币为0的处理
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserAddCingl end 9 ----------");
		pLandTable->m_byOverType = 1;
		pLandTable->m_nCalType = ALL_COMPARE;
		m_pLandSendPacket->BroadcastUserAddCingl(pLandTable, pUser->GetUserId(), nAddMoney, 0, 0, pLandTable->m_nCinglTimes);
		StopGame(pLandTable);
	}
	/*
	else if ( m_LandlordServConf.nMaxTableChip <= pLandTable->m_nPotTotal )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserAddCingl end 10 ----------");
		pLandTable->m_byOverType = 2;
		pLandTable->m_nCalType = ALL_COMPARE;
		m_pLandSendPacket->BroadcastUserAddCingl(pLandTable, pUser->GetUserId(), nAddMoney, 0, 0, pLandTable->m_nCinglTimes);
		StopGame(pLandTable);
	}
	*/
	else if ( pLandTable->m_nCinglTimes >= m_LandlordServConf.nMaxCallTimes )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserAddCingl end 11 ----------");
		pLandTable->m_byOverType = 3;
		pLandTable->m_nCalType = ALL_COMPARE;
		m_pLandSendPacket->BroadcastUserAddCingl(pLandTable, pUser->GetUserId(), nAddMoney, 0, 0, pLandTable->m_nCinglTimes);
		StopGame(pLandTable);
	}
	else
	{
		g_pErrorLog->logMsg("pLandTable->m_nPotTotal : %d",pLandTable->m_nPotTotal);
		int nNextOutUserId = pLandTable->GetNextCallUserId();
		g_pErrorLog->logMsg("nNextOutUserId 33 : %d",nNextOutUserId);
		m_pLandSendPacket->BroadcastUserAddCingl(pLandTable, pUser->GetUserId(), nAddMoney, 0, nNextOutUserId, pLandTable->m_nCinglTimes);
		CTeenpattiUser *pNextUser = pLandTable->GetUserByUserId(nNextOutUserId);
		if ( ( pNextUser ) && ( pNextUser->m_bRobot) )
		{
			g_pErrorLog->logMsg(" StartRobotCall  3");
			pLandTable->StartRobotCall();
		}
		else
		{
			pLandTable->ResetCallTimer(m_LandlordServConf.nCallCardTimeout);
		}
	}

	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserAddCingl end ----------");
	return 0;
}

//处理玩家比牌
int CTeenpattiServer::ProcUserCompareCard(CGameUser* pUser, int nComparedId, BYTE isAllin)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCompareCard begin ----------");
	g_pErrorLog->logMsg("nComparedId : %d",nComparedId);

	if ( !pUser )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCompareCard end 1 ----------");
		return 0;
	}

	CTeenpattiTable *pLandTable = dynamic_cast<CTeenpattiTable *>(pUser->GetTable());

	if ( !pLandTable )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCompareCard end 2 ----------");
		return m_pLandSendPacket->SendUserCompareCardError(pUser->GetHandler(), COMPARE_TABLE_NOT_FOUND);
	}

	if ( pLandTable->GetGameStatus() != STATUS_PLAY )					
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCompareCard end 3 ----------");
		return m_pLandSendPacket->SendUserCompareCardError(pUser->GetHandler(), COMPARE_TABLE_STATUS_ERROR);
	}

	CTeenpattiUser* pLandUser = (CTeenpattiUser*)pUser;
		
	if( pLandTable->m_nCurCallSeatId != pLandUser->GetSeatId() ) 
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCompareCard end 4 ----------");
		return m_pLandSendPacket->SendUserCompareCardError(pUser->GetHandler(), COMPARE_SEAT_CANNOT);
	}

	CTeenpattiUser* pComparedUser = (CTeenpattiUser*)pLandTable->m_UserManager[nComparedId];

	if 	( !pComparedUser )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCompareCard end 5 ----------");
		return 0;
	}

	if ( pLandTable->m_nCinglTimes < 3 )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCompareCard end 6 ----------");
		return m_pLandSendPacket->SendUserCompareCardError(pComparedUser->GetHandler(), COMPARE_CALL_COUNT_ERROR);
	}

	int nNextOutUserId = 0;
	long nCurMoney = 0;

	if ( isAllin == 1 )
	{
		g_pErrorLog->logMsg("pUserm_nMoney : %d, pComparedUser->m_nMoney %d :",pUser->m_nMoney, pComparedUser->m_nMoney);
		if ( pUser->m_nMoney >= pComparedUser->m_nMoney )
		{
			nCurMoney = pComparedUser->m_nMoney;
		}
		else
		{
			nCurMoney = pUser->m_nMoney;
		}

		if ( m_LandlordServConf.nAllIn <= nCurMoney )
		{
			 nCurMoney = m_LandlordServConf.nAllIn;
		}

		g_pErrorLog->logMsg("nCurMoney[%d]",nCurMoney);
		pUser->m_nMoney -= nCurMoney;
	    ((CTeenpattiUser*)pUser)->m_nCostForTable += nCurMoney;
		pComparedUser->m_nMoney -= nCurMoney;
		pComparedUser->m_nCostForTable += nCurMoney;

		pLandTable->m_nPotTotal += 2*nCurMoney;
	}
	else
	{
		int nHandPush = pLandUser->m_nHandMoney * 2;

		if ( pLandUser->m_bWatchCard )
		{
			if ( nHandPush > pLandTable->m_nHandBet*4)
			{
				nCurMoney = nHandPush;
				g_pErrorLog->logMsg("watch 1");
			}	
			else
			{
				nCurMoney = pLandTable->m_nHandBet*4;
				g_pErrorLog->logMsg("watch 2");
			}
		}
		else
		{
			if ( nHandPush > pLandTable->m_nHandBet*2)
			{
				nCurMoney = nHandPush;
				g_pErrorLog->logMsg("watch 3");
			}
			else
			{
				nCurMoney = pLandTable->m_nHandBet*2;
				g_pErrorLog->logMsg("watch 4");
			}
		}

		pLandUser->m_nHandMoney = nCurMoney;
		g_pErrorLog->logMsg("nCurMoney : %d, pLandUser->m_nHandMoney :",nCurMoney, pLandUser->m_nHandMoney);
		pLandUser->m_nMoney -= nCurMoney;
		pLandTable->m_nPotTotal += nCurMoney;
		pLandUser->m_nCostForTable += nCurMoney;
	}
	
	BYTE byCompResult = pLandTable->UserCompareCard(pLandUser, pComparedUser);
	if ( byCompResult == 2 )   // pLandUser > pComparedUser 
	{
		pComparedUser->m_bDisCard = TRUE;
		pComparedUser->m_nAttr = 4;
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCompareCard end 7 ----------");
		nNextOutUserId = pLandTable->GetNextCallUserId();
		g_pErrorLog->logMsg("nNextOutUserId end 7: %d",nNextOutUserId);
		m_pLandSendPacket->BroadcastUserCompared(pLandTable, pLandUser->GetUserId(), nComparedId, nNextOutUserId, nCurMoney, pLandUser->GetUserId());
	}
	else if ( ( byCompResult == 1 ) || ( byCompResult == 3 ) )  //主动比牌玩家牌一样，主动玩家为输
	{
		pLandUser->m_bDisCard = TRUE;
		pLandUser->m_nAttr = 4;
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCompareCard end 8 ----------");
		nNextOutUserId = pLandTable->GetNextCallUserId();
		g_pErrorLog->logMsg("nNextOutUserId end 8: %d",nNextOutUserId);
		m_pLandSendPacket->BroadcastUserCompared(pLandTable, nComparedId, pLandUser->GetUserId(), nNextOutUserId, nCurMoney, pLandUser->GetUserId());
	}
	pLandUser->m_nTimoutCall = 0;
	pLandTable->m_bComapre = TRUE;
	pLandTable->m_bPockerLogType = 3;		
	pLandTable->LogRecord(pLandUser->GetUserId(), pLandTable->m_bPockerLogType, pLandUser->m_byHandCardData, nCurMoney, pLandUser->GetUserId(),nComparedId);

	if ( pLandTable->IsGameOver() )
	{	
		g_pErrorLog->logMsg("--------------- CTeenpattiServer::ProcUserCompareCard end 9 -------------");
		pLandTable->GetWinner();
		StopGame(pLandTable);
	}
	else
	{
		g_pErrorLog->logMsg("--------------- CTeenpattiServer::ProcUserCompareCard end 10 -------------");
		CTeenpattiUser *pNextUser = pLandTable->GetUserByUserId(nNextOutUserId);
		if ( ( pNextUser ) && ( pNextUser->m_bRobot) )
		{
			g_pErrorLog->logMsg(" StartRobotCall  4");
			pLandTable->StartRobotCall();
		}
		else
		{
			pLandTable->ResetCallTimer(m_LandlordServConf.nCallCardTimeout+START_COMPARE_TIMEOUT);
		}
	}

	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCompareCard end ----------");
	return 0;
}

int CTeenpattiServer::GetNewTableID()
{
    int nNewTableID = 0;
    int nTempUserCount = 10;
    for(TableIdMap::iterator iter=m_TableList.begin(); iter!= m_TableList.end(); iter++)
    {
		CTeenpattiTable* pTable = (CTeenpattiTable*)iter->second;
		if(pTable != NULL)
		{
			int tid = pTable->GetID();
			if((tid>>16) == m_nServerID)
			{
				if(pTable->GetUserCount() == 0)
				{
					return tid;
				}
				else if(pTable->GetUserCount() == 1)
				{
					nNewTableID = tid;
					nTempUserCount = 1;
				}
				else if(pTable->GetUserCount() == 2)
				{
					if(nTempUserCount > 2)
					{
						nNewTableID = tid;
						nTempUserCount = 2;
					}
				}
			}
		}
    }
    return nNewTableID;
}

int CTeenpattiServer::WaiteGameStart(CTeenpattiTable* pLandTable)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::WaiteGameStart begin ----------");

	if (!pLandTable->StartGame())
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::WaiteGameStart end 1 ----------");
		return 0;
	}

	m_pLandSendPacket->BroadcastStartGame(pLandTable);

	m_pLandSendPacket->SendDealCard(pLandTable);

	pLandTable->StartGameTimer();		//等待开始打牌

	g_pErrorLog->logMsg("------------ CTeenpattiServer::WaiteGameStart end ----------");
	return 0;

}

int CTeenpattiServer::WriteInfoActivityServer(CTeenpattiTable *pLandTable)
{
	for(int i=0; i<GAME_PLAYER_COUNT; ++i)
	{
		CTeenpattiUser* pCTUser = (CTeenpattiUser*)pLandTable->GetUserBySeatId(i);

		if( pCTUser == NULL)
		{
			continue;
		}

		if ( pCTUser->m_nStatus == USER_STATUS_PALY )
		{
			int win_times = 0;
			int lose_times = 0;
			int win_money = 0;
			int lose_money = 0;
			int actime = 0;

			if ( pCTUser->m_nCostForTable > 0 )
			{
				pCTUser->m_nWinTimes += 1;
				win_times = 1;
				win_money = pCTUser->m_nCostForTable;
			}
			else
			{
				pCTUser->m_nLoseTimes += 1;
				lose_times = 1;
				lose_money = -pCTUser->m_nCostForTable;
			}

			pLandTable->CalUserCurTime(pCTUser);
			CGameServer::UpdateActiveTime(pCTUser->GetUserId(), pCTUser->m_nActimeTime);
			pCTUser->m_nActimeTime = 0;
			pCTUser->iTempTime = 0;

			actime = Getunixtime1() - pCTUser->m_nStartGameTime;

			g_pErrorLog->logMsg("actime : [%d]",actime);

			if ( actime > 5000)
			{
				actime = 0;
			}

			m_pActivityServer->ReportInfo2ActivityServer(pCTUser->GetUserId(), win_times, lose_times, win_money, lose_money, actime);
		}
	}
}

int CTeenpattiServer::LogoutOfflineUser(CTeenpattiTable* pLandTable)
{
	g_pErrorLog->logMsg("---------------- CTeenpattiServer::LogoutOfflineUser begin -----------------");

	for(int i=0; i<GAME_PLAYER_COUNT; ++i)
	{
		CTeenpattiUser* pCTUser = (CTeenpattiUser*)pLandTable->GetUserBySeatId(i);

		if(pCTUser == NULL)
		{
			continue;
		}

		if ( !pCTUser->m_bRobot )
		{
			int memServerId = pCTUser->GetUserId()%(int)m_MemDataServerMap.size();
			CMemDataServer* pMemServer = GetMemDataServer(memServerId);
			if(pMemServer != NULL)
			{
				pMemServer->UpdateUserInfo(pCTUser);
			}
		}
		
		if(!pCTUser->m_bOnline)
		{
			if ( pCTUser->GetSeatId() != INVAILD_SEAT_ID )
			{
				g_pDebugLog->logMsg("CTeenpattiServer::StopGame end 2 ");
				pLandTable->StandTable(pCTUser);
			}
			m_DisconnectUserList.erase(pCTUser->GetUserId());		 //从断线用户列表中删除该用户
			CGameServer::ProcUserLogout(pCTUser);
		}
	}

	g_pErrorLog->logMsg("---------------- CTeenpattiServer::LogoutOfflineUser end -----------------");
}

int CTeenpattiServer::UserCanNextGame(CTeenpattiTable* pLandTable)
{
	g_pErrorLog->logMsg("--------------- CTeenpattiServer::UserCanNextGame begin ----------------");
	
	for (BYTE i=0; i<GAME_PLAYER_COUNT; i++)
	{
		CTeenpattiUser *pUser = (CTeenpattiUser *)pLandTable->GetUserBySeatId(i);
		
		if ( (pUser != NULL) && ( pUser->m_nStatus == USER_STATUS_PALY ))
		{
			UserCanSit(pLandTable, pUser);
		}
	}
	g_pErrorLog->logMsg("--------------- CTeenpattiServer::UserCanNextGame end ----------------");
}

int CTeenpattiServer::JudgeNeedAddRobot(int nTableId)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::JudgeNeedAddRobot begin --------------");
	g_pErrorLog->logMsg("nTableId : [%d]",nTableId);

	bool bInVec = false;

	for (int i = 0; i < (int)vecRobotTid.size(); ++i)
	{
		if ( nTableId == vecRobotTid[i] )
		{
			bInVec = true;
		}
	}

	CGameTable* pTable = m_TableList[nTableId];

	if ( ( bInVec ) && ( pTable ) )
	{
		ProcTimeoutCreateRobot(pTable);
	}


	g_pErrorLog->logMsg("------------ CTeenpattiServer::JudgeNeedAddRobot end --------------");
}

int CTeenpattiServer::StopGame(CTeenpattiTable* pLandTable)
{
	g_pErrorLog->logMsg("---------------- CTeenpattiServer::StopGame begin -----------------");

	pLandTable->CalcTurningScore();

	WriteInfoActivityServer(pLandTable);

	CTeenpattiUser* pWinUser = (CTeenpattiUser*)pLandTable->GetUserBySeatId(pLandTable->m_nGameWinnerSeatId);

	if ( pWinUser )
	{
		pLandTable->m_bPockerLogType = 7;	
		pLandTable->LogRecord(pWinUser->GetUserId(), pLandTable->m_bPockerLogType, pWinUser->m_byHandCardData);
	}

	g_pErrorLog->logMsg("pLandTable->m_szPokerLog %s",pLandTable->m_szPokerLog);
	
	pLandTable->m_nStopTime = time(NULL);

	pLandTable->m_TableStatus = STATUS_STOP;

	m_pLandSendPacket->BroadcastGameOver(pLandTable);

	m_pLogServer->ReportDBCenterLog(pLandTable);
	m_pLogServer->ReportPokerLog(pLandTable);

	LogoutOfflineUser(pLandTable);

	UserCanNextGame(pLandTable);

	g_pErrorLog->logMsg("nRetire %d",nRetire);

	pLandTable->StopGame();

	int nUserCount = pLandTable->GetSitUserCount();
	g_pErrorLog->logMsg("StopnUserCount %d",nUserCount);
/*
	int nUserCount = pLandTable->GetSitUserCount();
	g_pErrorLog->logMsg("nUserCount %d",nUserCount);
	if ( ( nUserCount > 3 ) || ( nUserCount == 1) )
	{
		g_pErrorLog->logMsg("StartKickRobot");
		pLandTable->StartKickRobotTimer();
	}
*/
	
	if(nRetire == 1)
	{
		m_pLandSendPacket->BroadcastGameUpdate(pLandTable);
		pLandTable->WaitStopGameTimer();
		map<int, CGameUser*>::iterator iter;

		for (iter=pLandTable->m_UserManager.begin(); iter!=pLandTable->m_UserManager.end(); iter++)
		{
			CTeenpattiUser* pLandlordUser = (CTeenpattiUser*)(*iter).second;
			if( pLandlordUser != NULL )
			{
				pLandlordUser->ResetKickUserTimer();
			}
		}

		g_pErrorLog->logMsg("------------ CTeenpattiServer::StopGame end 3 ----------");
	}
	g_pErrorLog->logMsg("---------------- CTeenpattiServer::StopGame end -----------------");
	return 0;
}

int CTeenpattiServer::ProcWriteActivetime(CGameUser *pUser)
{
	if (pUser == NULL)
	{
		return 0;
	}
	int nUserId  = pUser->GetUserId();
	CTeenpattiUser* pCTUser = dynamic_cast<CTeenpattiUser*>(pUser);

	if ( pCTUser->m_nActimeTime )
	{
		CGameServer::UpdateActiveTime(nUserId, pCTUser->m_nActimeTime);
		pCTUser->m_nActimeTime = 0;
	}

	return 0;
}

int CTeenpattiServer::ProcUserTime(CGameUser *pUser)
{
	g_pErrorLog->logMsg("----------- CTeenpattiServer::ProcUserTime begin -------------");
	if (pUser == NULL)
	{
		g_pErrorLog->logMsg("----------- CTeenpattiServer::ProcUserTime end 1 -------------");
		return 0;
	}
	int nUserId  = pUser->GetUserId();

	CTeenpattiUser* pCTUser = dynamic_cast<CTeenpattiUser*>(pUser);

	CTeenpattiTable *pTable = (CTeenpattiTable*)pUser->GetTable();

	if ( pTable == NULL )
	{
		if (pCTUser->m_nActimeTime)
		{
			g_pErrorLog->logMsg("m_nActimeTime[%d]",pCTUser->m_nActimeTime);
			CGameServer::UpdateActiveTime(nUserId, pCTUser->m_nActimeTime);
			pCTUser->m_nActimeTime = 0;
		}
		g_pErrorLog->logMsg("----------- CTeenpattiServer::ProcUserTime end 2 -------------");
		return 0;
	}

	if (pTable->GetGameStatus() != STATUS_STOP)
	{
		int now = Getunixtime1();
		g_pErrorLog->logMsg("iTempTime:[%d],m_nMidTime[%d]",pCTUser->iTempTime,pCTUser->m_nMidTime);
		pCTUser->iTempTime = now - pCTUser->m_nMidTime;
		g_pErrorLog->logMsg("m_nActimeTime[%d]",pCTUser->m_nActimeTime);
		pCTUser->m_nActimeTime = pCTUser->m_nActimeTime + pCTUser->iTempTime;
		g_pErrorLog->logMsg("m_nActimeTime[%d]",pCTUser->m_nActimeTime);
		pCTUser->m_nMidTime = now;

		CGameServer::UpdateActiveTime(nUserId, pCTUser->m_nActimeTime);
		pCTUser->m_nActimeTime = 0;
		pCTUser->iTempTime = 0;
		g_pErrorLog->logMsg("----------- CTeenpattiServer::ProcUserTime end 3 -------------");
	}
	else
	{
		if (pCTUser->m_nActimeTime)
		{
			g_pErrorLog->logMsg("m_nActimeTime[%d]",pCTUser->m_nActimeTime);
			CGameServer::UpdateActiveTime(nUserId, pCTUser->m_nActimeTime);
			pCTUser->m_nActimeTime = 0;
		}
		g_pErrorLog->logMsg("----------- CTeenpattiServer::ProcUserTime end 4 -------------");
	}

	g_pErrorLog->logMsg("----------- CTeenpattiServer::ProcUserTime end 5 -------------");

	return 0;
}

//叫注超时处理
int CTeenpattiServer::ProcTimeoutCall(CTeenpattiTable* pLandTable)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCall begin ----------");
	CTeenpattiUser * pUser = (CTeenpattiUser*)pLandTable->GetUserBySeatId(pLandTable->m_nCurCallSeatId);

	g_pErrorLog->logMsg("pLandTable->m_nCurCallSeatId : %d",pLandTable->m_nCurCallSeatId);

	if ( !pUser )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCall end 1 ----------");
		return StopGame(pLandTable);
	}
	else
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCall end 3 ----------");
		pUser->m_nTimoutCall += 1;
		ProcUserDisCard(pUser);
	}

	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCall end ----------");

	return 0;
}

int CTeenpattiServer::ProcTimeoutRobotCall(CTeenpattiTable* pLandTable)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutRobotCall begin ----------");

	CTeenpattiUser * pUser = (CTeenpattiUser*)pLandTable->GetUserBySeatId(pLandTable->m_nCurCallSeatId);

	g_pErrorLog->logMsg("pLandTable->m_nCurCallSeatId : %d",pLandTable->m_nCurCallSeatId);

	if ( !pUser )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutRobotCall end 1 ----------");
		return StopGame(pLandTable);
	}

	if ( pUser->m_bRobot )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutRobotCall end 2 ----------");
		g_pErrorLog->logMsg("pLandTable->m_nCinglTimes %d",pLandTable->m_nCinglTimes);

		if ( pLandTable->m_nCinglTimes >= 3 )
		{
			pLandTable->ProcRobotCallCard(pUser);
		}
		else
		{
			if ( pUser->m_bWatchCard )
			{
				pUser->m_nHandMoney = pLandTable->m_nHandBet * 2;
			}
			else
			{
				pUser->m_nHandMoney = pLandTable->m_nHandBet;
			}
			ProcUserCingl(pUser, pUser->m_nHandMoney);
		}
	}
	else
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutRobotCall end 3 ----------");
		ProcUserDisCard(pUser);
	}

	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutRobotCall end ----------");
}

int CTeenpattiServer::ProcTimeoutWaitGame(CTeenpattiTable* pLandTable)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutWaitGame begin ------------");

	if ( pLandTable == NULL )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutWaitGame end 1 ----------");
		return 0;
	}

	if ( pLandTable->GetSitUserCount() >= 2 && ( pLandTable->GetGameStatus() == STATUS_STOP ))	
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutWaitGame end 2 ----------");

		pLandTable->WaitStopGameTimer();

		WaiteGameStart(pLandTable);
	}
	else
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutWaitGame end 3 ------------");
		pLandTable->m_bWaitStart = FALSE;
		pLandTable->m_nStartCallSeatId = INVAILD_SEAT_ID;

		g_pErrorLog->logMsg("nRobotCount [%d]",nRobotCount);
/*
		if ( pLandTable->GetReadyUserCount() == 1 )
		{
			for (int i=0; i<USER_PLAY_COUNT; i++)
			{
				CTeenpattiUser* pLandlordUser = (CTeenpattiUser*)pLandTable->GetUserBySeatId(i);

				if ( pLandlordUser )
				{
					if ( pLandlordUser->m_bRobot )
					{
						g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutWaitGame end 4 ------------");
						ProcUserStand(pLandlordUser);
						CGameServer::ProcUserLogout(pLandlordUser);
						return 0;
					}
				}
			}

		}
*/
		if ( ( pLandTable->GetSitUserCount() == 1 ) && ( nRobotCount < m_RobotConf.nCreateRobotMaxCount ) )
		{
			pLandTable->ResetCreateRobotTimer(m_RobotConf.nCreateRobotTimeout);
			g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutWaitGame end 5 ------------");
		}
	}

	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutWaitGame end ------------");
}

BOOL CTeenpattiServer::RobotInVecRobotId(int nId)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::RobotInVecRobotId begin ------------");
	for(int i=0; i<(int)vecRobotId.size(); i++)
	{
		if ( nId == vecRobotId[i] )
		{
			g_pErrorLog->logMsg("------------ CTeenpattiServer::RobotInVecRobotId end 1 ------------");
			return TRUE;
		}
	} 

	g_pErrorLog->logMsg("------------ CTeenpattiServer::RobotInVecRobotId end ------------");
	return FALSE;
}

int CTeenpattiServer::DeleteRobotId(int nUserId)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::DeleteRobotId begin -------------");
	g_pErrorLog->logMsg("nUserId : [%d]",nUserId);
	for (int i = 0; i < (int)vecRobotId.size(); ++i)
	{
		if ( nUserId == vecRobotId[i] )
		{
			g_pErrorLog->logMsg("------------ CTeenpattiServer::DeleteRobotId success -------------");
			vecRobotId.erase(vecRobotId.begin() + i);
			nRobotCount --;
		}
	}

	g_pErrorLog->logMsg("------------ CTeenpattiServer::DeleteRobotId end -------------");
	return 0;
}

//创建机器人
int CTeenpattiServer::ProcTimeoutCreateRobot(CTeenpattiTable* pLandTable)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot begin ------------");

	if ( pLandTable == NULL )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 1 ----------");
		return 0;
	}

	if ( pLandTable->GetSitUserCount() >= 3 )	//达到规定人数，不予分配机器人
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 2 ----------");	
		return 0;
	}
	else
	{
		if ( m_nLevel > 2 )
		{
			g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 100 ----------");	
			return 0;
		}

		if ( pLandTable->m_nRobotCount >= 3 ) 
		{
			g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 3 ----------");	
			return 0;
		}

		if ( nRobotCount >= 10 )
		{
			g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 4 ----------");	
			return 0;
		}

		int nUserId = 0;
		int nMoney = 0;

		if ( m_nLevel == 1 )
		{
			int nCount = 0;
			while(true)
			{
				nUserId = random(19)+480;

				if ( ( !pLandTable->RobotInRobotIdList(nUserId) ) && ( !RobotInVecRobotId(nUserId) ) )
				{
					vecRobotId.push_back(nUserId);
					pLandTable->vec_RobotList.push_back(nUserId);
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 44 ----------");	
					break;
				}
				nCount ++;
				g_pErrorLog->logMsg("nCount[%d]",nCount);
				if ( nCount == 15 )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 33 ----------");	
					return 0;
				}
			}
			
			nMoney = random(1400)+2800;
			g_pErrorLog->logMsg("nUserId 1 : %d",nUserId);
			g_pErrorLog->logMsg("nMoney 1 : %d",nMoney);
		}
		else if ( m_nLevel == 2 )
		{
			int nCount = 0;
			while(true)
			{
				nUserId = random(19)+460;
				if ( ( !pLandTable->RobotInRobotIdList(nUserId) ) && ( !RobotInVecRobotId(nUserId) ) )
				{
					vecRobotId.push_back(nUserId);
					pLandTable->vec_RobotList.push_back(nUserId);
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 444 ----------");	
					break;
				}

				if ( !RobotInVecRobotId(nUserId) )
				{
					vecRobotId.push_back(nUserId);
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 222 ----------");	
					break;
				}
				nCount ++;
				g_pErrorLog->logMsg("nCount[%d]",nCount);
				if ( nCount == 15 )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 333 ----------");	
					return 0;
				}
			}
			//nMoney = random(12600)+26000;

			nMoney = random(5000)+10000;

			g_pErrorLog->logMsg("nUserId 2 : %d",nUserId);
			g_pErrorLog->logMsg("nMoney 2 : %d",nMoney);
		}
		else if ( m_nLevel == 3 )
		{
			int nCount = 0;
			while(true)
			{
				nUserId = random(19)+440;

				if ( ( !pLandTable->RobotInRobotIdList(nUserId) ) && ( !RobotInVecRobotId(nUserId) ) )
				{
					vecRobotId.push_back(nUserId);
					pLandTable->vec_RobotList.push_back(nUserId);
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 444 ----------");	
					break;
				}
				nCount ++;
				g_pErrorLog->logMsg("nCount[%d]",nCount);
				if ( nCount == 15 )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 555 ----------");	
					return 0;
				}
			}
			nMoney = random(137600)+248600;
			g_pErrorLog->logMsg("nUserId 3 : %d",nUserId);
			g_pErrorLog->logMsg("nMoney 3 : %d",nMoney);
		}
		else if ( m_nLevel == 4 )
		{
			int nCount = 0;
			while(true)
			{
				nUserId = random(19)+420;
				if ( ( !pLandTable->RobotInRobotIdList(nUserId) ) && ( !RobotInVecRobotId(nUserId) ) )
				{
					vecRobotId.push_back(nUserId);
					pLandTable->vec_RobotList.push_back(nUserId);
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 444 ----------");	
					break;
				}

				nCount ++;
				g_pErrorLog->logMsg("nCount[%d]",nCount);
				if ( nCount == 15 )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end BBB ----------");	
					return 0;
				}
			}

			
			nMoney = random(140400)+722000;
			g_pErrorLog->logMsg("nUserId 4 : %d",nUserId);
			g_pErrorLog->logMsg("nMoney 4 : %d",nMoney);
		}
		else if ( m_nLevel == 5 )
		{
			int nCount = 0;
			while(true)
			{
				nUserId = random(19)+400;
				if ( ( !pLandTable->RobotInRobotIdList(nUserId) ) && ( !RobotInVecRobotId(nUserId) ) )
				{
					vecRobotId.push_back(nUserId);
					pLandTable->vec_RobotList.push_back(nUserId);
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 444 ----------");	
					break;
				}

				nCount ++;
				g_pErrorLog->logMsg("nCount[%d]",nCount);
				if ( nCount == 15 )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end BBB ----------");	
					return 0;
				}
			}

			nMoney = random(180000)+1680000;
			g_pErrorLog->logMsg("nUserId 5 : %d",nUserId);
			g_pErrorLog->logMsg("nMoney 5 : %d",nMoney);
		}
		else if ( m_nLevel == 6 )
		{
			int nCount = 0;
			while(true)
			{
				nUserId = random(19)+380;
				if ( !pLandTable->RobotInRobotIdList(nUserId) )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 444 ----------");	
					break;
				}

				if ( !RobotInVecRobotId(nUserId) )
				{
					vecRobotId.push_back(nUserId);
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end AAA ----------");	
					break;
				}
				nCount ++;
				g_pErrorLog->logMsg("nCount[%d]",nCount);
				if ( nCount == 15 )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end BBB ----------");	
					return 0;
				}
			}

			pLandTable->vec_RobotList.push_back(nUserId);
			nMoney = random(1490500)+4123000;
			g_pErrorLog->logMsg("nUserId 6 : %d",nUserId);
			g_pErrorLog->logMsg("nMoney 6 : %d",nMoney);
		}
		else if ( m_nLevel == 7 )
		{
			
			int nCount = 0;
			while(true)
			{
				nUserId = random(9)+370;
				if ( !pLandTable->RobotInRobotIdList(nUserId) )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 444 ----------");	
					break;
				}

				if ( !RobotInVecRobotId(nUserId) )
				{
					vecRobotId.push_back(nUserId);
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end AAA ----------");	
					break;
				}
				nCount ++;
				g_pErrorLog->logMsg("nCount[%d]",nCount);
				if ( nCount == 15 )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end BBB ----------");	
					return 0;
				}
			}

			pLandTable->vec_RobotList.push_back(nUserId);
			nMoney = random(1445500)+7235800;
			g_pErrorLog->logMsg("nUserId 7 : %d",nUserId);
			g_pErrorLog->logMsg("nMoney 7 : %d",nMoney);
		}
		else if ( m_nLevel == 8 )
		{
			
			int nCount = 0;
			while(true)
			{
				nUserId = random(9)+360;
				if ( !pLandTable->RobotInRobotIdList(nUserId) )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 444 ----------");	
					break;
				}

				if ( !RobotInVecRobotId(nUserId) )
				{
					vecRobotId.push_back(nUserId);
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end AAA ----------");	
					break;
				}
				nCount ++;
				g_pErrorLog->logMsg("nCount[%d]",nCount);
				if ( nCount == 15 )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end BBB ----------");	
					return 0;
				}
			}

			pLandTable->vec_RobotList.push_back(nUserId);
			nMoney = random(2998760)+14865800;
			g_pErrorLog->logMsg("nUserId 8 : %d",nUserId);
			g_pErrorLog->logMsg("nMoney 8 : %d",nMoney);
		}
		else if ( m_nLevel == 9 )
		{
			
			int nCount = 0;
			while(true)
			{
				nUserId = random(9)+350;
				if ( !pLandTable->RobotInRobotIdList(nUserId) )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 444 ----------");	
					break;
				}

				if ( !RobotInVecRobotId(nUserId) )
				{
					vecRobotId.push_back(nUserId);
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end AAA ----------");	
					break;
				}
				nCount ++;
				g_pErrorLog->logMsg("nCount[%d]",nCount);
				if ( nCount == 15 )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end BBB ----------");	
					return 0;
				}
			}

			pLandTable->vec_RobotList.push_back(nUserId);
			nMoney = random(15784850)+41820300;
			g_pErrorLog->logMsg("nUserId 9 : %d",nUserId);
			g_pErrorLog->logMsg("nMoney 9 : %d",nMoney);
		}
		else if ( m_nLevel == 10 )
		{
			
			int nCount = 0;
			while(true)
			{
				nUserId = random(9)+340;
				if ( !pLandTable->RobotInRobotIdList(nUserId) )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 444 ----------");	
					break;
				}

				if ( !RobotInVecRobotId(nUserId) )
				{
					vecRobotId.push_back(nUserId);
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end AAA ----------");	
					break;
				}
				nCount ++;
				g_pErrorLog->logMsg("nCount[%d]",nCount);
				if ( nCount == 15 )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end BBB ----------");	
					return 0;
				}
			}

			pLandTable->vec_RobotList.push_back(nUserId);
			nMoney = random(10190220)+78451300;
			g_pErrorLog->logMsg("nUserId 10 : %d",nUserId);
			g_pErrorLog->logMsg("nMoney 10 : %d",nMoney);
		}
		else if ( m_nLevel ==11 )
		{
			int nCount = 0;
			while(true)
			{
				nUserId = random(9)+330;
				if ( !pLandTable->RobotInRobotIdList(nUserId) )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 444 ----------");	
					break;
				}

				if ( !RobotInVecRobotId(nUserId) )
				{
					vecRobotId.push_back(nUserId);
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end AAA ----------");	
					break;
				}
				nCount ++;
				g_pErrorLog->logMsg("nCount[%d]",nCount);
				if ( nCount == 15 )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end BBB ----------");	
					return 0;
				}
			}

			pLandTable->vec_RobotList.push_back(nUserId);
			nMoney = random(19970000)+158684500;
			g_pErrorLog->logMsg("nUserId 11 : %d",nUserId);
			g_pErrorLog->logMsg("nMoney 11 : %d",nMoney);
		}
		else 
		{
			int nCount = 0;
			while(true)
			{
				nUserId = random(9)+320;
				if ( !pLandTable->RobotInRobotIdList(nUserId) )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 444 ----------");	
					break;
				}

				if ( !RobotInVecRobotId(nUserId) )
				{
					vecRobotId.push_back(nUserId);
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end AAA ----------");	
					break;
				}
				nCount ++;
				g_pErrorLog->logMsg("nCount[%d]",nCount);
				if ( nCount == 15 )
				{
					g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end BBB ----------");	
					return 0;
				}
			}

			pLandTable->vec_RobotList.push_back(nUserId);
			nMoney = random(83652960)+412801640;
			g_pErrorLog->logMsg("nUserId 12 : %d",nUserId);
			g_pErrorLog->logMsg("nMoney 12 : %d",nMoney);
		}

		nRobotCount ++;
		pLandTable->m_nRobotCount ++;
		g_pErrorLog->logMsg("nRobotCount [%d]",nRobotCount);
		
		string strInfo = m_RobotConf.mRobotInfo[nUserId];
		CGameUser* pNewUser = m_pCreator->CreateUser(this, pLandTable, nUserId, 0, strInfo);

		int nWinTimes = 0;
		int nLoseTimes = 0;

		ParseUserInfo(strInfo, nWinTimes, nLoseTimes);
		g_pErrorLog->logMsg("nMoney[%d]nWinTimes[%d],nLoseTimes[%d]",nMoney,nWinTimes,nLoseTimes);

		if ( nMoney == 0 )
		{
			pNewUser->m_nMoney = m_RobotConf.nCreatRobotMoney;
			pNewUser->m_nWinTimes = 20;
			pNewUser->m_nLoseTimes = 30;
		}
		else
		{
			pNewUser->m_nMoney = nMoney;
			pNewUser->m_nWinTimes = nWinTimes;
			pNewUser->m_nLoseTimes = nLoseTimes;
		}

		RobotLoginRoom(nUserId, pNewUser, pLandTable);
		RobotReadyRoom(pNewUser, pLandTable);

		if ( pLandTable->GetSitUserCount() >= 2 && ( pLandTable->GetGameStatus() == STATUS_STOP ))	
		{
			g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end 5 ----------");

			if ( pLandTable->m_bWaitStart == FALSE)
			{
				g_pErrorLog->logMsg("TimerWaiteStart");
				pLandTable->WaitStartGameTimer(m_LandlordServConf.nWaitGameTimeout);
			}
		}
	}

	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutCreateRobot end ------------");
}


int CTeenpattiServer::ParseUserInfo(string strInfo, int& nWinTimes, int& nLoseTimes)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ParseUserInfo begin ------------");

	if( strInfo == "" )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ParseUserInfo end 1 ------------");
		return 0;
	}

	Json::Reader reader;		
	Json::Value value;		
	if(!reader.parse(strInfo, value))		
	{       
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ParseUserInfo end 2 ------------");
        return 0;		
	}

	if(value.type()==Json::objectValue || value.type()==Json::nullValue)
	{
		if(value.isMember("win")&&value["win"].isString())
		{
			g_pErrorLog->logMsg("------------ CTeenpattiServer::ParseUserInfo end 4 ------------");
			nWinTimes = atoi(value["win"].asString().c_str());
		}
		if(value.isMember("lose")&&value["lose"].isString())
		{
			g_pErrorLog->logMsg("------------ CTeenpattiServer::ParseUserInfo end 5 ------------");
			nLoseTimes = atoi(value["lose"].asString().c_str());
		}
	}

	g_pErrorLog->logMsg("------------ CTeenpattiServer::ParseUserInfo end ------------");
	return 0;
}

//机器人登录房间
int CTeenpattiServer::RobotLoginRoom(int nUserId, CGameUser* pUser, CTeenpattiTable* pLandTable)
{
	g_pErrorLog->logMsg("------------------- CTeenpattiServer::RobotLoginRoom begin ---------------");
	//加入到桌子中
	pLandTable->AddNewUser(pUser);

	//加入在线用户列表中
	m_ServerUserList[nUserId] = pUser;	

	pUser->SetStatus(USER_STATUS_LOGIN);

	((CTeenpattiUser*)pUser)->m_bRobot = TRUE;

	m_pHallServer->UpdateRoomUserCount(pLandTable); //登陆成功向大厅服务器上报房间人数

	((CTeenpattiUser*)pUser)->m_bOnline = TRUE;

	//向该桌子的其他用户广播用户进入房间消息
	m_pSendPacket->BroadcastUserLogin(pLandTable, pUser);
	g_pErrorLog->logMsg("------------------- CTeenpattiServer::RobotLoginRoom end ---------------");
}

//机器人准备
int CTeenpattiServer::RobotReadyRoom(CGameUser* pUser, CTeenpattiTable* pLandTable)
{
	g_pErrorLog->logMsg("------------------- CTeenpattiServer::RobotReadyRoom begin ---------------");

	BYTE bySeatId = pLandTable->GetTableEmptySeat();

	if ( bySeatId == INVAILD_SEAT_ID )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::RobotReadyRoom end 1 ----------");
		return 0;
	}

	if ( ! (pUser->GetTable())->UserSit(bySeatId, pUser) )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::RobotReadyRoom end 2 ----------");
		return 0;
	}

	g_pErrorLog->logMsg("RobotUserId %d",pUser->GetUserId());

	pLandTable->UserReady((CTeenpattiUser*)pUser);

	((CTeenpattiUser*)pUser)->StartSendFaceTimer();
	
	m_pLandSendPacket->BroadcastUserSitSuccess(pLandTable, pUser);

	m_pHallServer->UpdateRoomUserCount(pLandTable);
	g_pErrorLog->logMsg("------------------- CTeenpattiServer::RobotReadyRoom end ---------------");
}

//等待游戏开始
int CTeenpattiServer::ProcTimeoutStartGame(CTeenpattiTable* pLandTable)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutStartGame begin ----------");
	
	CGameTable *pTable = (CGameTable *)pLandTable;

	g_pErrorLog->logMsg("m_nStartCallSeatId %d",pLandTable->m_nStartCallSeatId);

	int nNextOutUserId = pLandTable->GetNextUserBySeatId(pLandTable->m_nStartCallSeatId);

	CTeenpattiUser *pUser = (CTeenpattiUser*)pTable->GetUserByUserId(nNextOutUserId);

	if ( !pUser )
	{
		pLandTable->m_TableStatus = STATUS_STOP;
		pLandTable->StopGame();
		return 0;
	}

	pLandTable->m_nCurCallSeatId = pUser->GetSeatId();
	pLandTable->m_nStartCallSeatId = pUser->GetSeatId();

	if ( pUser->m_bRobot )
	{
		g_pErrorLog->logMsg(" StartRobotCall  5");
		pLandTable->StartRobotCall();
	}
	else
	{
		pLandTable->ResetCallTimer(m_LandlordServConf.nCallCardTimeout);
	}

	g_pErrorLog->logMsg("m_LandlordServConf.nCallCardTimeout 2 -- %d", m_LandlordServConf.nCallCardTimeout);
	g_pErrorLog->logMsg("2 -- uid %d", nNextOutUserId);
	g_pErrorLog->logMsg("2 -- SeatId %d",  pUser->GetSeatId());
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcTimeoutStartGame end ----------");
	return m_pLandSendPacket->BroadcastStartPlayCard(pLandTable, nNextOutUserId);
}

int CTeenpattiServer::PocTimeoutKickUser(CTeenpattiUser* pLandUser)
{
	g_pDebugLog->logMsg("------------------ CTeenpattiServer::PocTimeoutKickUser begin -----------------");
	if(pLandUser == NULL)
	{
		g_pDebugLog->logMsg("------------------ CTeenpattiServer::PocTimeoutKickUser end 1 -----------------");
		return 0;
	}
	CTeenpattiTable *pLandTable = (CTeenpattiTable*)pLandUser->GetTable();
	if (pLandTable == NULL)
	{
		g_pDebugLog->logMsg("------------------ CTeenpattiServer::PocTimeoutKickUser end 2 -----------------");
		CGameServer::ProcUserLogout(pLandUser);
		return 0;
	}

	g_pDebugLog->logMsg("userSeatid %d",pLandUser->GetSeatId());

	if ( pLandUser->GetSeatId() != INVAILD_SEAT_ID )
	{
		ProcUserStand(pLandUser);
		g_pDebugLog->logMsg("------------------ CTeenpattiServer::PocTimeoutKickUser end 2 -----------------");
	}

	CGameServer::ProcUserLogout(pLandUser);
	return 0;
}

int CTeenpattiServer::PocTimeoutRobotSendFace(CTeenpattiUser* pUser)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::PocTimeoutRobotSendFace begin ----------");
	if ( pUser == NULL )
	{
		g_pErrorLog->logMsg("------------- CTeenpattiServer::PocTimeoutRobotSendFace end 1 --------------- ");
		return 0;
	}

	CGameTable* pTable = pUser->GetTable();

	if ( pTable == NULL )
	{
		g_pErrorLog->logMsg("------------- CTeenpattiServer::PocTimeoutRobotSendFace end 2 --------------- ");
		return 0;
	}
	
	int nRand = random(26)+1;

	g_pErrorLog->logMsg("nRand : %d",nRand);

	m_pSendPacket->BroadcastClientSendFace(pUser->GetUserId(), nRand, pTable);


	g_pErrorLog->logMsg("------------ CTeenpattiServer::PocTimeoutRobotSendFace end ----------");
}

int CTeenpattiServer::PocTimeoutKickBankrupt(CTeenpattiUser* pUser)
{
	g_pErrorLog->logMsg("-------------- CTeenpattiServer::PocTimeoutKickBankrupt begin --------------");

	if ( NULL == pUser )
	{
		g_pErrorLog->logMsg("-------------- CTeenpattiServer::PocTimeoutKickBankrupt end 1 --------------");
		return 0;
	}

	g_pErrorLog->logMsg("userid [%d]",pUser->GetUserId());
	if ( pUser->m_bRobot )
	{
		g_pErrorLog->logMsg("-------------- CTeenpattiServer::PocTimeoutKickBankrupt end 2 --------------");
		ProcUserStand(pUser);
		CGameServer::ProcUserLogout(pUser);
	}
	else
	{
		g_pErrorLog->logMsg("-------------- CTeenpattiServer::PocTimeoutKickBankrupt end 3 --------------");
		ProcUserStand(pUser);
	}


	g_pErrorLog->logMsg("-------------- CTeenpattiServer::PocTimeoutKickBankrupt end --------------");
	return 0;
}

int CTeenpattiServer::PocTimeoutRobotAllMoney(CTeenpattiUser* pUser)
{
	g_pErrorLog->logMsg("------------- CTeenpattiServer::PocTimeoutRobotAllMoney begin --------------");

	if ( NULL == pUser )
	{
		g_pErrorLog->logMsg("------------- CTeenpattiServer::PocTimeoutRobotAllMoney end 1 --------------");
		return 0;
	}

	CTeenpattiTable *pTable = (CTeenpattiTable*)pUser->GetTable();

	if ( NULL == pTable )
	{
		g_pErrorLog->logMsg("------------- CTeenpattiServer::PocTimeoutRobotAllMoney end 2 --------------");
		return 0;
	}

	if ( pTable->GetGameStatus() != STATUS_PLAY )
	{
		g_pErrorLog->logMsg("------------- CTeenpattiServer::PocTimeoutRobotAllMoney end 3 --------------");
		return 0;
	}

	ProcAcceptAllInMoney(pUser, 0);

	g_pErrorLog->logMsg("------------- CTeenpattiServer::PocTimeoutRobotAllMoney end --------------");
}

//处理玩家跟到底
int CTeenpattiServer::ProcUserCallDown(CGameUser *pUser, BYTE byType)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCallDown begin ----------");
	g_pErrorLog->logMsg("byType : %d",byType);

	//BOOL bCallDown = (byType == 0) ? FALSE : TRUE;

	if ( !pUser )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCallDown end 1 ----------");
		return 0;
	}

	CTeenpattiTable *pLandTable = dynamic_cast<CTeenpattiTable *>(pUser->GetTable());

	if ( !pLandTable )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCallDown end 2 ----------");
		return m_pLandSendPacket->SendUserCallDownError(pUser->GetHandler(), CALLDOWN_TABLE_NOT_FOUND);
	}

	if (  pLandTable->GetGameStatus() != STATUS_PLAY )					
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCallDown end 3 ----------");
		return m_pLandSendPacket->SendUserCallDownError(pUser->GetHandler(), CALLDOWN_TABLE_STATUS_ERROR);
	}

	//CTeenpattiUser *pLandUser = (CTeenpattiUser*)pUser;

	//pLandUser->m_bCallDownUser = bCallDown;

	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserCallDown end ----------");

	return m_pLandSendPacket->BroadcastUserCallDown(pLandTable, pUser->GetUserId(), byType);

}

int CTeenpattiServer::ProcUserStand(CGameUser *pUser)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserStand begin ----------");
	if ( NULL == pUser )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserStand end 1 ----------");
		return 0;
	}

	CTeenpattiTable *pLandTable = dynamic_cast<CTeenpattiTable *>(pUser->GetTable());

	if ( !pLandTable )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserStand end 2 ----------");
		return m_pLandSendPacket->SendUserStandError(pUser->GetHandler(), STAND_TABLE_NOT_FOUND);
	}

	CTeenpattiUser *pCTUser = (CTeenpattiUser*)pUser;

	if ( pLandTable->GetGameStatus() == STATUS_PLAY )		
	{
		if ( ( pUser->m_nStatus == USER_STATUS_PALY ) && ( !pCTUser->m_bDisCard ) )
		{
			pCTUser->m_bDisCard = TRUE;
			g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserStand end 3 ----------");

			pLandTable->m_bPockerLogType = 6;		
			pLandTable->LogRecord(pCTUser->GetUserId(), pLandTable->m_bPockerLogType, pCTUser->m_byHandCardData);

			int nNextOutUserId = 0;  //到玩家自己操作和不是该玩家自己操作

			if( pLandTable->m_nCurCallSeatId != pCTUser->GetSeatId() )
			{
				m_pLandSendPacket->SendUserDisCard(pLandTable, pUser->GetUserId(), nNextOutUserId, pLandTable->m_nCinglTimes);
			}
			else
			{
				if ( !pLandTable->IsGameOver() )
				{
					nNextOutUserId = pLandTable->GetNextCallUserId();
					g_pErrorLog->logMsg("nNextOutUserId stand : %d",nNextOutUserId);
					CTeenpattiUser *pNextUser = pLandTable->GetUserByUserId(nNextOutUserId);
					if ( ( pNextUser ) && ( pNextUser->m_bRobot) )
					{
						g_pErrorLog->logMsg(" StartRobotCall  6");
						pLandTable->StartRobotCall();
					}
					else
					{
						pLandTable->ResetCallTimer(m_LandlordServConf.nCallCardTimeout);
					}

					m_pLandSendPacket->SendUserDisCard(pLandTable, pUser->GetUserId(), nNextOutUserId, pLandTable->m_nCinglTimes);
				}
			}
		}

		if ( pLandTable->IsGameOver() )
		{
			g_pErrorLog->logMsg(" Stand over over  ");
			pLandTable->GetWinner();
			StopGame(pLandTable);
		}
		else
		{
			pCTUser->m_nUpdateMoney = -pCTUser->m_nCostForTable;
			if ( !pCTUser->m_bRobot )
			{
				int memServerId = pCTUser->GetUserId()%(int)m_MemDataServerMap.size();
				g_pErrorLog->logMsg("MdataServer size : %d",(int)m_MemDataServerMap.size());
				CMemDataServer* pMemServer = GetMemDataServer(memServerId);
				if(pMemServer != NULL)
				{
					pMemServer->UpdateUserInfo(pCTUser);
				}
			}
			
			pLandTable->m_bComapre = FALSE;

			int now = Getunixtime1();
			g_pErrorLog->logMsg("iTempTime:[%d],m_nMidTime[%d]",pCTUser->iTempTime,pCTUser->m_nMidTime);
			pCTUser->iTempTime = now - pCTUser->m_nMidTime;
			g_pErrorLog->logMsg("m_nActimeTime:[%d]",pCTUser->m_nActimeTime);
			pCTUser->m_nActimeTime = pCTUser->m_nActimeTime + pCTUser->iTempTime;
			g_pErrorLog->logMsg("m_nActimeTime:[%d]",pCTUser->m_nActimeTime);
			CGameServer::UpdateActiveTime(pCTUser->GetUserId(), pCTUser->m_nActimeTime);
			pCTUser->m_nActimeTime = 0;
			pCTUser->iTempTime = 0;

			int actime = Getunixtime1() - pCTUser->m_nStartGameTime;

			g_pErrorLog->logMsg("actime : [%d]",actime);

			if ( actime > 5000)
			{
				actime = 0;
			}

			m_pActivityServer->ReportInfo2ActivityServer(pUser->GetUserId(), 0, 0, 0, 0, actime);
		}
	}
	else
	{
		if (pCTUser->m_nActimeTime)
		{
			CGameServer::UpdateActiveTime(pCTUser->GetUserId(), pCTUser->m_nActimeTime);
			pCTUser->m_nActimeTime = 0;
		}
		
		if ( !pCTUser->m_bRobot )
		{
			int memServerId = pCTUser->GetUserId()%(int)m_MemDataServerMap.size();
			g_pErrorLog->logMsg("MdataServer size : %d",(int)m_MemDataServerMap.size());
			CMemDataServer* pMemServer = GetMemDataServer(memServerId);
			if(pMemServer != NULL)
			{
				pMemServer->UpdateUserInfo(pCTUser);
			}
		}
		
		BYTE byPlayCount = pLandTable->GetSitUserCount(); 
		g_pErrorLog->logMsg("Stop WaitStopGameTimer byPlayCount[%d]",byPlayCount);
		if ( byPlayCount < 3 )
		{
			pLandTable->m_bWaitStart = FALSE;
			g_pErrorLog->logMsg("Stop WaitStopGameTimer ");
		}
	}
	
	pLandTable->StandTable(pUser);
	pCTUser->ResetUser();
	pCTUser->m_nTimoutCall = 0;

	g_pErrorLog->logMsg("userid : %d, SeatId : %d",pUser->GetUserId(),pUser->GetSeatId());

	m_pLandSendPacket->BroadcastUserStand(pLandTable, pUser->GetUserId());

	m_pHallServer->UpdateRoomUserCount(pLandTable);

	if ( !pCTUser->m_bRobot )
	{
		ReportUserStandTable(pUser);
	}
	else
	{
		DeleteRobotId(pCTUser->GetUserId());
		pLandTable->DeleteRobotIdInList(pCTUser->GetUserId());
		g_pErrorLog->logMsg("pLandTable->m_nRobotCount %d, nRobotCount %d",pLandTable->m_nRobotCount,nRobotCount);
	}
/*
	int nUserCount = pLandTable->GetSitUserCount();
	g_pErrorLog->logMsg("nUserCount %d",nUserCount);
	if ( ( nUserCount > 3 ) || ( nUserCount == 1) )
	{
		g_pErrorLog->logMsg("StartKickRobot");
		pLandTable->StartKickRobotTimer();
	}
*/
	int nUserCount = pLandTable->GetSitUserCount();
	g_pErrorLog->logMsg("StandnUserCount %d",nUserCount);
	if ( nUserCount == 0 )
	{
		JudgeNeedAddRobot(pLandTable->GetID());
	}

	if ( pUser->m_nStatus == USER_STATUS_PALY )
	{
		if ( pLandTable->IsGameOver() )
		{	
			pLandTable->GetWinner();
			StopGame(pLandTable);
		}
	}

	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcUserStand end ----------");
	return 0;
}

int CTeenpattiServer::ProcLogoutRobot(CTeenpattiTable *pLandTable)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcLogoutRobot begin ------------");

	int nUserCount = pLandTable->GetSitUserCount();
	g_pErrorLog->logMsg("nUserCount %d",nUserCount);

	if ( nUserCount > 3 )
	{
		g_pErrorLog->logMsg("------------ KickRobot ------------");
		for (BYTE i=0; i<GAME_PLAYER_COUNT; i++)
		{
			CTeenpattiUser *pUser = (CTeenpattiUser *)pLandTable->GetUserBySeatId(i);
			if ( pUser == NULL )
			{
				continue;
			}
			if ( pUser->m_bRobot )
			{
				pUser->StopSendFaceTimer();
				if ( pLandTable->m_nRobotCount > 0 )
				{
					nRobotCount --;
					pLandTable->m_nRobotCount --;
				}
				
				g_pDebugLog->logMsg("CTeenpattiServer::StopGame RobotLogout nRobotCount[%d],m_nRobotCount[%d]",nRobotCount,pLandTable->m_nRobotCount);
				pLandTable->StandTable(pUser);
				CGameServer::ProcUserLogout(pUser);
			}
		}
	}

	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcLogoutRobot end ------------");
}

int CTeenpattiServer::ProcUserBreakTime(CGameUser *pUser)
{
	g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcUserBreakTime begin ------------ ");

	if (pUser == NULL)
	{
		return 0;
	}

	short nTime = m_LandlordServConf.nLandBreakTimeout;

	g_pErrorLog->logMsg("nTime [%d]", nTime);

	g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcUserBreakTime end ------------ ");

	return m_pLandSendPacket->ServerSendBreakTime(pUser->m_pSocket, nTime);
}

int CTeenpattiServer::ProcUserUpdateMoney(int nUserId)
{
	g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcUserUpdateMoney begin ---------------");
	g_pErrorLog->logMsg("nUserId : %d",nUserId);

	CGameUser *pUser = NULL;
	UserIdMap::iterator iter = m_ServerUserList.find(nUserId);
	if (iter != m_ServerUserList.end())
	{
		pUser = iter->second;
	}

	if ( pUser == NULL )
	{	
		g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcUserUpdateMoney end 1 ---------------");
		return 0;
	}

	int memServerId = nUserId%(int)m_MemDataServerMap.size();
	CMemDataServer *pMemServer = GetMemDataServer(memServerId);
	if(pMemServer == NULL)
	{
		g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcUserUpdateMoney end 2 ---------------");
		return 0;
	}

	USERDATA data;
	if (pMemServer->GetUserInfo(nUserId, data) < 0)
	{
		g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcUserUpdateMoney end 3 ---------------");
		return 0;
	}	

	g_pErrorLog->logMsg("data.money:[%d], m_nMoney:%d",data.money,pUser->m_nMoney);

	CTeenpattiTable* pTable = (CTeenpattiTable*)pUser->GetTable();

	if ( pTable == NULL )
	{
		g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcUserUpdateMoney end 4 ---------------");
		return 0;
	}

	CTeenpattiUser *CTUser = (CTeenpattiUser*)pUser;

	if ( ( pTable->GetGameStatus() == STATUS_PLAY ) && ( pUser->m_nStatus == USER_STATUS_PALY ) )
	{
		g_pErrorLog->logMsg("user play game");
		pUser->m_nMoney = data.money - CTUser->m_nCostForTable;
	}
	else
	{
		pUser->m_nMoney = data.money;
	}

	g_pErrorLog->logMsg("pUser->m_nMoney : [%d]",pUser->m_nMoney);

	m_pLandSendPacket->BroadcastUserMoney(pTable, nUserId, pUser->m_nMoney);

	g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcUserUpdateMoney end ---------------");

	return 0;
}

int CTeenpattiServer::ProcUserAllInMoney(CGameUser *pUser)
{
	g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcUserAllInMoney begin ---------------");

	if ( NULL == pUser )
	{
		g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcUserAllInMoney end 1 ---------------");
		return 0;
	}

	g_pErrorLog->logMsg("nActiveUserId : %d",pUser->GetUserId());

	CTeenpattiTable* pTable = (CTeenpattiTable*)pUser->GetTable();

	if ( NULL == pTable )
	{
		g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcUserAllInMoney end 2 ---------------");
		return 0;
	}

	int nCount = 0;

	for (int i=0; i<USER_PLAY_COUNT; i++)
	{
		CTeenpattiUser* pLandlordUser = (CTeenpattiUser*)(pTable->GetUserBySeatId(i));

		if ( pLandlordUser )
		{
			if ( ( pLandlordUser->m_nStatus == USER_STATUS_PALY ) && (!pLandlordUser->m_bDisCard ))
			{
				nCount ++ ;
			}
		}
	}
	
	g_pErrorLog->logMsg("nCount [%d]",nCount);
	if ( nCount != 2 )
	{
		g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcUserAllInMoney end 3 ---------------");
		m_pLandSendPacket->SendUserAllInError(pUser->GetHandler(), ALLIN_USER_COUNT_ERROR);
		return 0;
	}

	if ( pUser->m_nMoney < 2*m_LandlordServConf.nMaxHandBet )
	{
		g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcUserAllInMoney end 4 ---------------");
		m_pLandSendPacket->SendUserAllInError(pUser->GetHandler(), ALLIN_MONEY_ERROR);
		return 0;
	}

	pTable->m_nAllIn = 1;

	int nNextOutUserId = pTable->GetAllInNextUserId();
	g_pErrorLog->logMsg("nNextOutUserId [%d]",nNextOutUserId);
	pTable->ResetCallTimer(m_LandlordServConf.nCallCardTimeout);

	m_pLandSendPacket->BroadcastUserAllInMoney(pTable, pUser->GetUserId(), nNextOutUserId);

	CTeenpattiUser *pNextUser = pTable->GetUserByUserId(nNextOutUserId);
	if ( pNextUser )
	{
		if ( pNextUser->m_bRobot )
		{
			g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcUserAllInMoney end 5 ---------------");
			pNextUser->StartRobotAllMoney();
		}
	}

	g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcUserAllInMoney end ---------------");
	return 0;
}

int CTeenpattiServer::ProcAcceptAllInMoney(CGameUser *pUser,BYTE byAccpt)
{
	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcAcceptAllInMoney begin --------------");

	if ( NULL == pUser )
	{
		g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcAcceptAllInMoney end 1 --------------");
		return 0;
	}

	g_pErrorLog->logMsg("nActiveUserId : %d, byAccpt: %d",pUser->GetUserId(),byAccpt);

	CTeenpattiTable* pTable = (CTeenpattiTable*)pUser->GetTable();

	if ( NULL == pTable )
	{
		g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcAcceptAllInMoney end 2 ---------------");
		return 0;
	}

	int nNextOutUserId = pTable->GetAllInNextUserId();
	g_pErrorLog->logMsg("nNextOutUserId [%d]",nNextOutUserId);
	CTeenpattiUser *pNextUser = pTable->GetUserByUserId(nNextOutUserId);
	pTable->ResetCallTimer(m_LandlordServConf.nCallCardTimeout);

	if ( NULL == pNextUser )
	{
		g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcAcceptAllInMoney end 3 ---------------");
		return 0;
	}

	if ( byAccpt == 0 )
	{
		pTable->m_nAllIn = 0;
		g_pErrorLog->logMsg("m_nHandMoney [%d]",pNextUser->m_nHandMoney);

		if ( pNextUser->m_bWatchCard )
		{
			pNextUser->m_nHandMoney = 2 * pTable->m_nHandBet;
		}
		else
		{
			pNextUser->m_nHandMoney = pTable->m_nHandBet;
		}

		m_pLandSendPacket->BroadcastAcceptAllInMoney(pTable, pUser->GetUserId(), byAccpt, pNextUser->m_nHandMoney);
		g_pErrorLog->logMsg("------------- CTeenpattiServer::ProcAcceptAllInMoney end 4 ---------------");
		ProcUserCingl(pNextUser, pNextUser->m_nHandMoney);
	}
	else
	{
		g_pErrorLog->logMsg("pUserm_nMoney : %ld, pNextUser->m_nMoney %ld :",pUser->m_nMoney, pNextUser->m_nMoney);
		long nCurMoney = 0;
		if ( pNextUser->m_nMoney >= pUser->m_nMoney )
		{
			g_pErrorLog->logMsg("11");
			nCurMoney = pUser->m_nMoney;
		}
		else
		{
			g_pErrorLog->logMsg("22");
			nCurMoney = pNextUser->m_nMoney;
		}

		if ( m_LandlordServConf.nAllIn <= nCurMoney )
		{
			g_pErrorLog->logMsg("33");
			nCurMoney = m_LandlordServConf.nAllIn;
		}

		g_pErrorLog->logMsg("nCurMoney[%d]",nCurMoney);
		m_pLandSendPacket->BroadcastAcceptAllInMoney(pTable, pUser->GetUserId(), byAccpt, nCurMoney);
		ProcUserCompareCard(pNextUser, pUser->GetUserId(), 1);
	}
	

	g_pErrorLog->logMsg("------------ CTeenpattiServer::ProcAcceptAllInMoney end --------------");
	return 0;
}

int CTeenpattiServer::ProcAcceptOperAllIn(CGameUser *pUser, BYTE byOperAllIn)
{
	g_pErrorLog->logMsg("----------------- CTeenpattiServer::ProcAcceptOperAllIn begin --------------");
	if ( NULL == pUser )
	{
		g_pErrorLog->logMsg("----------------- CTeenpattiServer::ProcAcceptOperAllIn end 1 --------------");
		return 0;
	}

	g_pErrorLog->logMsg("userid : %d",pUser->GetUserId());

	CTeenpattiTable* pTable = (CTeenpattiTable*)pUser->GetTable();

	if ( NULL == pTable )
	{
		g_pErrorLog->logMsg("----------------- CTeenpattiServer::ProcAcceptOperAllIn end 2 --------------");
		return 0;
	}

	m_pLandSendPacket->BroadcastUserOperAllIn(pTable, pUser->GetUserId(), byOperAllIn);

	g_pErrorLog->logMsg("----------------- CTeenpattiServer::ProcAcceptOperAllIn end --------------");
	return 0;
}