./LandlordServer -p 4650 -h 192.168.100.142 -s 1000 -l 0 -d
./LandlordServer -p 4651 -h 192.168.100.142 -s 2000 -l 11 -d
./LandlordServer -p 4652 -h 192.168.100.142 -s 3000 -l 12 -d
./LandlordServer -p 4653 -h 192.168.100.142 -s 4000 -l 13 -d
./LandlordServer -p 4654 -h 192.168.100.142 -s 5000 -l 14 -d
./LandlordServer -p 4655 -h 192.168.100.142 -s 6000 -l 15 -d
./LandlordServer -p 4656 -h 192.168.100.142 -s 7000 -l 16 -d
./LandlordServer -p 4657 -h 192.168.100.142 -s 8000 -l 20 -d
