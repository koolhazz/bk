#include "TeenpattiSendPacket.h"
#include "TeenpattiUser.h"
#include "TeenpattiTable.h"
#include "GameCmd.h"
#include "GameServer.h"
#include "TeenpattiServer.h"

#include "clib_log.h"
extern clib_log* g_pErrorLog;
extern clib_log* g_pDebugLog;

#include <math.h>

#ifndef WIN32
#include <time.h>
#include <sys/time.h>

DWORD GetTickCount2()
{
	timeval timesnow;
	struct timezone tmpzone;
	gettimeofday(&timesnow,&tmpzone);
	return ((DWORD)(timesnow.tv_sec*1000) + (DWORD)(timesnow.tv_usec/1000));
}
int Getunixtime2()
{
	timeval timesnow;
	struct timezone tmpzone;
	gettimeofday(&timesnow,&tmpzone);
	return ((int)(timesnow.tv_sec));
}
#else
#include<stdlib.h>
int Getunixtime2()
{
	DWORD start = GetTickCount2();
	int time = (int)start / 1000;
	return time;
}
#endif


CTeenpattiSendPacket::CTeenpattiSendPacket(UserIdMap &list, CGameServer* pServer):CSendPacket(list, pServer) 
{

}

CTeenpattiSendPacket::~CTeenpattiSendPacket(void)
{

}


int CTeenpattiSendPacket::SendUserLoginSuccess(SocketHandler* pHandler, CGameUser* pUser)
{
	g_pDebugLog->logMsg("--------- CTeenpattiSendPacket::SendUserLoginSuccess begin ------------");
	CGameTable* pTable = pUser->GetTable();
	CTeenpattiTable *pTStable = (CTeenpattiTable *)pTable;

	CTeenpattiServer *CTServer = (CTeenpattiServer *)m_pGameServer;

	NETOutputPacket response; 
	response.Begin(SERVER_COMMAND_LOGIN_SUCCESS);
	response.WriteInt(pTable->m_nTableId);
	response.WriteInt(CTServer->m_LandlordServConf.nBaseChips);
	response.WriteInt(CTServer->m_LandlordServConf.nRequireChips);
	response.WriteInt(CTServer->m_LandlordServConf.nMaxUserChips);
	response.WriteInt(CTServer->m_LandlordServConf.nMaxHandBet);
	response.WriteInt(CTServer->m_LandlordServConf.nMaxTableChip);
	response.WriteByte(CTServer->m_LandlordServConf.nMinCompare);
	response.WriteByte(CTServer->m_LandlordServConf.nMaxCallTimes);
	response.WriteByte(CTServer->m_LandlordServConf.nCallCardTimeout);
	response.WriteString(CTServer->m_LandlordServConf.strName);
	response.WriteByte(START_COMPARE_TIMEOUT);
	response.WriteByte(CTServer->m_LandlordServConf.nWaitGameTimeout);
	response.WriteByte(pTStable->GetGameStatus());
	response.WriteByte(pTStable->m_nAllIn);

	g_pDebugLog->logMsg("pTable->m_nTableId [%d] ",pTable->m_nTableId);
	g_pDebugLog->logMsg("m_LandlordServConf.nRequireChips [%d] ",CTServer->m_LandlordServConf.nRequireChips);
	g_pDebugLog->logMsg("m_LandlordServConf.nMaxUserChips [%d] ",CTServer->m_LandlordServConf.nMaxUserChips);
	g_pDebugLog->logMsg("m_LandlordServConf.nBaseChips [%d] ",CTServer->m_LandlordServConf.nBaseChips);
	g_pDebugLog->logMsg("m_LandlordServConf.nMaxHandBet [%d] ",CTServer->m_LandlordServConf.nMaxHandBet);
	g_pDebugLog->logMsg("m_LandlordServConf.nMaxTableChip [%d] ",CTServer->m_LandlordServConf.nMaxTableChip);
	g_pDebugLog->logMsg("m_LandlordServConf.nCallCardTimeout [%d] ",CTServer->m_LandlordServConf.nCallCardTimeout);
	g_pDebugLog->logMsg("name [%s] ",CTServer->m_LandlordServConf.strName);
	g_pDebugLog->logMsg("pTStable->GetGameStatus() [%d] ", pTStable->GetGameStatus());
	g_pDebugLog->logMsg("START_COMPARE_TIMEOUT [%d] ", START_COMPARE_TIMEOUT);
	g_pDebugLog->logMsg("nWaitGameTimeout [%d] ", CTServer->m_LandlordServConf.nWaitGameTimeout);
	g_pDebugLog->logMsg("m_nAllIn [%d] ", pTStable->m_nAllIn);

	CTeenpattiUser *pTSUser = (CTeenpattiUser *)pUser;

	BYTE byPlayCount = pTStable->GetSitUserCount();

	g_pDebugLog->logMsg("pUser->m_strUserInfo 11 [%s] ",(pUser->m_strUserInfo).c_str());

	g_pDebugLog->logMsg("CSendPacket::SendUserLoginSuccess end 111 ");

	if ( pTStable->GetGameStatus() == STATUS_PLAY )
	{
		response.WriteLong(pTStable->m_nHandBet);
		g_pDebugLog->logMsg("pTStable->m_nHandBet [%d] ",pTStable->m_nHandBet);
		g_pDebugLog->logMsg("pTStable->m_nCurCallSeatId [%d] ",pTStable->m_nCurCallSeatId);

		CGameUser *pCurUser = pTable->GetUserBySeatId(pTStable->m_nCurCallSeatId);
		if ( pCurUser )
		{
			response.WriteInt(pCurUser->GetUserId());
			g_pDebugLog->logMsg("uid [%d] ",pCurUser->GetUserId());
		}
		else
		{
			response.WriteInt(0);
		}

		BYTE nLeftTime = 0;

		if ( pTStable->m_bComapre )
		{
			g_pDebugLog->logMsg("m_bComapre 1");
			nLeftTime = CTServer->m_LandlordServConf.nCallCardTimeout + START_COMPARE_TIMEOUT - ((GetTickCount() - pTStable->m_dwGameTickCount)/1000);
		}
		else
		{
			g_pDebugLog->logMsg("m_bComapre 2");
			nLeftTime = CTServer->m_LandlordServConf.nCallCardTimeout - ((GetTickCount() - pTStable->m_dwGameTickCount)/1000);
		}
		
		response.WriteByte(nLeftTime);
		g_pDebugLog->logMsg("nLeftTime [%d] ",nLeftTime);

		response.WriteLong(pTStable->m_nPotTotal);
		response.WriteShort(pTStable->m_nCinglTimes);
		g_pDebugLog->logMsg("pTStable->m_nPotTotal [%d] ",pTStable->m_nPotTotal);
		g_pDebugLog->logMsg("pTStable->m_nCinglTimes [%d] ",pTStable->m_nCinglTimes);

		if (( !pTSUser->m_bDisCard ) && ( pTSUser->m_bWatchCard ))
		{
			response.WriteByte(3);
			for (int i = 0; i < 3; ++i)
			{
				g_pDebugLog->logMsg("pTSUser->m_byHandCardData [%d] ",pTSUser->m_byHandCardData[i]);
				response.WriteByte(pTSUser->m_byHandCardData[i]);
			}
		}
		else
		{
			response.WriteByte(0);
		}

		
		int now = time(NULL);
		g_pErrorLog->logMsg("now[%d],iTempTime:[%d],m_nMidTime[%d]",now,pTSUser->iTempTime,pTSUser->m_nMidTime);
		pTSUser->iTempTime = now - pTSUser->m_nMidTime;
		g_pErrorLog->logMsg("iTempTime:[%d]",pTSUser->iTempTime);
		
		if ( pTSUser->iTempTime > 200 )
		{
			response.WriteShort(0);
		}
		else
		{
			response.WriteShort(pTSUser->iTempTime);
		}
	}
	else
	{
		BYTE byLeftTime = 0;
		g_pDebugLog->logMsg("byLeftTimebyPlayCount [%d] ",byPlayCount);
		if (byPlayCount > 1 )
		{
			byLeftTime = CTServer->m_LandlordServConf.nWaitGameTimeout - ((GetTickCount() - pTStable->m_dwWaitStartTickCount)/1000);
			response.WriteByte(byLeftTime);
		}
		else
		{
			response.WriteByte(byLeftTime);
		}

		g_pDebugLog->logMsg("byLeftTime [%d] ",byLeftTime);
	}
	
	g_pDebugLog->logMsg("byPlayCount [%d] ",byPlayCount);
	response.WriteByte(byPlayCount);

	for ( BYTE i=0; i<USER_PLAY_COUNT; i++ )
	{
		CGameUser *pUser = pTable->GetUserBySeatId(i);

		if ( pUser )
		{
			CTeenpattiUser *pTUser = (CTeenpattiUser *)pUser;
			response.WriteInt(pUser->GetUserId());
			g_pDebugLog->logMsg("uid [%d] ",pUser->GetUserId());
			response.WriteLong(pUser->m_nMoney);
			g_pDebugLog->logMsg("pUser->m_nMoney [%ld] ",pUser->m_nMoney);
			response.WriteInt(0);
			g_pDebugLog->logMsg("pUser->m_nLevel");
			response.WriteString(pUser->m_strUserInfo);
			g_pDebugLog->logMsg("pUser->m_strUserInfo [%s] ",(pUser->m_strUserInfo).c_str());
			response.WriteByte(i);
			g_pDebugLog->logMsg("I [%d] ",i);
			response.WriteLong(pTUser->m_nCostForTable);
			g_pDebugLog->logMsg("pTUser->m_nCostForTable [%ld] ",pTUser->m_nCostForTable);
			response.WriteByte(pUser->m_nStatus);
			g_pDebugLog->logMsg("pUser->m_nStatus [%d] ",pUser->m_nStatus);
			BYTE byCallStatus = pTUser->m_bCallDownUser == TRUE ? 1 : 0;
			response.WriteByte(byCallStatus);
			g_pDebugLog->logMsg("byCallStatus [%d] ",byCallStatus);
			response.WriteByte(pTUser->m_nAttr);
			g_pDebugLog->logMsg("m_nAttr [%d] ",pTUser->m_nAttr);
		}
	}

	response.End();
	g_pDebugLog->logMsg("--------- CTeenpattiSendPacket::SendUserLoginSuccess end ------------");
	return SendPackage(&response, pHandler);
}

int CTeenpattiSendPacket::BroadcastUserLogin(CGameTable* pTable, CGameUser* pUser)
{	
	NETOutputPacket response;
	BuildPackage(&response, SERVER_BROADCAST_USER_LOGIN, "%d,%s", pUser->GetUserId(), pUser->m_strUserInfo.c_str());
	BroadcastTablePackage(pTable, &response, pUser);
	return 0;
}

int CTeenpattiSendPacket::SendDealCard(CTeenpattiTable* pTable)
{
	NETOutputPacket response;
	response.Begin(SERVER_COMMAND_DEAL_CARD);
	response.End();

	return BroadcastTablePackage(pTable, &response, NULL);
}

int CTeenpattiSendPacket::BroadcastStartGame(CGameTable* pTable)
{
	NETOutputPacket response;	
	BuildPackage(&response, SERVER_BROADCAST_START_GAME);
	BroadcastTablePackage(pTable, &response, NULL);
	return 0;	
}

int CTeenpattiSendPacket::BroadcastStartPlayCard(CGameTable* pTable, int nStartCallUserId)
{
	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_START_CALL);
	response.WriteInt(nStartCallUserId);
	response.End();
	return BroadcastTablePackage(pTable, &response, NULL); 
}

int CTeenpattiSendPacket::BroadcastUserCingl( CGameTable* pTable, int nUserId, long nMoney, BYTE IsFull, int nNextOutUserId, short byCallTimes)
{
	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_CING);
	response.WriteInt(nUserId);
	response.WriteLong(nMoney);
	response.WriteByte(IsFull);
	response.WriteInt(nNextOutUserId);
	response.WriteShort(byCallTimes);
	g_pErrorLog->logMsg("BroadcastUserCingl byCallTimes [%d]",byCallTimes);
	response.End();
	return BroadcastTablePackage(pTable, &response, NULL); 
}

int CTeenpattiSendPacket::BroadcastUserAddCingl(CGameTable* pTable, int nUserId, long nMoney, BYTE IsFull, int nNextOutUserId, short byCallTimes)
{
	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_AddCING);
	response.WriteInt(nUserId);
	response.WriteLong(nMoney);
	response.WriteByte(IsFull);
	response.WriteInt(nNextOutUserId);
	response.WriteShort(byCallTimes);
	g_pErrorLog->logMsg("BroadcastUserAddCingl nUserId[%d]nMoney[%ld]IsFull[%d]nNextOutUserId[%d]byCallTimes[%d]",nUserId,nMoney,IsFull,nNextOutUserId,byCallTimes);
	response.End();
	return BroadcastTablePackage(pTable, &response, NULL); 
}

int CTeenpattiSendPacket::BroadcastGameOver(CTeenpattiTable* pTable)
{
	g_pErrorLog->logMsg("---------------- CTeenpattiSendPacket::BroadcastGameOver begin -------------");
	BYTE byUserCount = pTable->GetPlaySitUserCount();

	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_GAME_OVER);
	response.WriteByte(pTable->m_byOverType);
	response.WriteByte(byUserCount);			
	g_pErrorLog->logMsg("m_byOverType %d",pTable->m_byOverType);
	g_pErrorLog->logMsg("byUserCount %d",byUserCount);

	for (BYTE i=0; i<GAME_PLAYER_COUNT; i++)
	{
		CGameUser *pUser = pTable->GetUserBySeatId(i);
		
		if ( (pUser != NULL) && ( pUser->m_nStatus == USER_STATUS_PALY ))
		{
			CTeenpattiUser* pTempUser = (CTeenpattiUser*)pUser;
			response.WriteInt(pTempUser->GetUserId());
			response.WriteLong(pTempUser->m_nMoney);
			response.WriteInt(0);
			response.WriteLong(pTempUser->m_nCostForTable);
			response.WriteByte(3);
			g_pErrorLog->logMsg("GetUserId %d",pTempUser->GetUserId());
			g_pErrorLog->logMsg("m_nMoney %ld",pTempUser->m_nMoney);
			g_pErrorLog->logMsg("m_nLevel ");
			g_pErrorLog->logMsg("m_nCostForTable %d",pTempUser->m_nCostForTable);
			for( BYTE j=0; j<3; j++ )
			{
				response.WriteByte(pTempUser->m_byHandCardData[j]);
				g_pErrorLog->logMsg("m_byHandCardData 0x%x",pTempUser->m_byHandCardData[j]);
			}
		}
	}

	response.End();
	g_pErrorLog->logMsg("---------------- CTeenpattiSendPacket::BroadcastGameOver end -------------");
	return BroadcastTablePackage(pTable, &response, NULL);
}

int CTeenpattiSendPacket::BroadcastGameUpdate(CTeenpattiTable* pLandTable)
{
	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_UPDATE_SERVER);
	response.End();
	return BroadcastTablePackage(pLandTable, &response, NULL);
}

int CTeenpattiSendPacket::SendUserSitError(SocketHandler* pHandler, BYTE nErrType, long nMoney)
{
	NETOutputPacket response;
	response.Begin(SERVER_COMMAND_SIT_ERROR);
	response.WriteByte(nErrType);
	response.WriteLong(nMoney);
	response.End();

	SendPackage(&response, pHandler);
	return 0;
}

int CTeenpattiSendPacket::BroadcastUserSitSuccess(CTeenpattiTable* pTable,  CGameUser* pUser)
{
	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_USER_SIT_SUCCESS);
	response.WriteInt(pUser->GetUserId());
	response.WriteLong(pUser->m_nMoney);
	g_pErrorLog->logMsg("pUser->m_nMoney %ld",pUser->m_nMoney);
	response.WriteInt(0);
	response.WriteString(pUser->m_strUserInfo);
	response.WriteByte(pUser->GetSeatId());
	response.End();

	return BroadcastTablePackage(pTable, &response, NULL);
}

int CTeenpattiSendPacket::SendUserWatchCardError(SocketHandler* pHandler, BYTE nErrType)
{
	NETOutputPacket response;
	response.Begin(SERVER_COMMAND_WATCH_CARD_ERROR);
	response.WriteByte(nErrType);
	response.End();

	return SendPackage(&response, pHandler);
}

int CTeenpattiSendPacket::SendUserWatchCardResult(SocketHandler* pHandler, BYTE * m_byCardData)
{
	NETOutputPacket response;
	response.Begin(SERVER_COMMAND_WATCH_CARD_RESULT);
	response.WriteByte(3);
	for ( int i=0; i<3; i++ )
	{
		g_pErrorLog->logMsg("m_byCardData[i] 0x%x",m_byCardData[i]);
		response.WriteByte(m_byCardData[i]);
	}
	
	response.End();

	return SendPackage(&response, pHandler);
}

int CTeenpattiSendPacket::SendUserWatchCard(CTeenpattiTable *pTable, int nUserId)
{
	g_pErrorLog->logMsg("watch nUserId %d",nUserId);
	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_WATCH_CARD);
	response.WriteInt(nUserId);
	response.End();

	return BroadcastTablePackage(pTable, &response, NULL);
}

int CTeenpattiSendPacket::SendUserDisCardError(SocketHandler* pHandler, BYTE nErrType)
{
	NETOutputPacket response;
	response.Begin(SERVER_COMMAND_DIS_CARD_ERROR);
	response.WriteByte(nErrType);
	response.End();

	return SendPackage(&response, pHandler);
}

int CTeenpattiSendPacket::SendUserDisCard(CTeenpattiTable *pTable, int nUserId, int nNextId, short byCallTimes)
{
	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_DIS_CARD);
	response.WriteInt(nUserId);
	response.WriteInt(nNextId);
	response.WriteShort(byCallTimes);
	response.End();

	return BroadcastTablePackage(pTable, &response, NULL);
}

int CTeenpattiSendPacket::SendUserCinglError(SocketHandler* pHandler, BYTE nErrType)
{
	NETOutputPacket response;
	response.Begin(SERVER_COMMAND_CING_ERROR);
	response.WriteByte(nErrType);
	response.End();

	return SendPackage(&response, pHandler);
}

int CTeenpattiSendPacket::SendUserAddCinglError(SocketHandler* pHandler, BYTE nErrType)
{
	NETOutputPacket response;
	response.Begin(SERVER_COMMAND_ADDCING_ERROR);
	response.WriteByte(nErrType);
	response.End();

	return SendPackage(&response, pHandler);
}

int CTeenpattiSendPacket::SendUserCompareCardError(SocketHandler* pHandler, BYTE nErrType)
{
	NETOutputPacket response;
	response.Begin(SERVER_COMMAND_COMPARECARD_ERROR);
	response.WriteByte(nErrType);
	response.End();

	return SendPackage(&response, pHandler);
}

int CTeenpattiSendPacket::BroadcastUserCompared(CTeenpattiTable *pLandTable, int nLargerId, int nLessId, int nNextId, long nMoney, int CurId)
{
	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_COMPARECARD_RESULT);
	response.WriteInt(nLargerId);
	response.WriteInt(nLessId);
	response.WriteInt(nNextId);
	response.WriteLong(nMoney);
	response.WriteInt(CurId);
	response.WriteShort(pLandTable->m_nCinglTimes);
	g_pDebugLog->logMsg("pLandTable->m_nCinglTimes 33 [%d] ",pLandTable->m_nCinglTimes);
	response.End();

	return BroadcastTablePackage(pLandTable, &response, NULL);
}

int CTeenpattiSendPacket::SendUserCallDownError(SocketHandler* pHandler, BYTE nErrType)
{
	NETOutputPacket response;
	response.Begin(SERVER_COMMAND_CALLDOWN_ERROR);
	response.WriteByte(nErrType);
	response.End();

	return SendPackage(&response, pHandler);
}

int CTeenpattiSendPacket::BroadcastUserCallDown(CTeenpattiTable *pLandTable, int nUserId, BYTE byType)
{
	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_CALLDOWN);
	response.WriteInt(nUserId);
	response.WriteByte(byType);
	response.End();

	return BroadcastTablePackage(pLandTable, &response, NULL);
}

int CTeenpattiSendPacket::SendUserStandError(SocketHandler* pHandler, BYTE nErrType)
{
	NETOutputPacket response;
	response.Begin(SERVER_COMMAND_STAND_ERROR);
	response.WriteByte(nErrType);
	response.End();

	return SendPackage(&response, pHandler);
}

int CTeenpattiSendPacket::BroadcastUserStand(CTeenpattiTable *pLandTable, int nUserId)
{
	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_STAND);
	response.WriteInt(nUserId);
	response.End();

	return BroadcastTablePackage(pLandTable, &response, NULL);
}

int CTeenpattiSendPacket::SendUserLogoutError(SocketHandler* pHandler, BYTE nErrType)
{
	NETOutputPacket response;
	response.Begin(SERVER_COMMAND_LOGOUT_ERROR);
	response.WriteByte(nErrType);
	response.End();

	return SendPackage(&response, pHandler);
}

int CTeenpattiSendPacket::ServerSendBreakTime(SocketHandler* pHandler, short nTime)
{
	NETOutputPacket response;
	response.Begin(SERVER_COMMAND_PANT_PACK);
	response.WriteShort(nTime);
	response.End();

	return SendPackage(&response, pHandler);
}

int CTeenpattiSendPacket::SendUserBankbruck(SocketHandler* pHandler)
{
	NETOutputPacket response;
	response.Begin(SERVER_COMMAND_USER_BANKRUPT);
	response.End();

	return SendPackage(&response, pHandler);
}

int CTeenpattiSendPacket::BroadcastUserMoney(CTeenpattiTable* pTable, int nUserId, long nMoney)
{
	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_USER_MONEY);
	response.WriteInt(nUserId);
	response.WriteLong(nMoney);
	response.End();

	return BroadcastTablePackage(pTable, &response, NULL);
}

int CTeenpattiSendPacket::SendUserAllInError(SocketHandler* pHandler, BYTE nErrType)
{
	NETOutputPacket response;
	response.Begin(SERVER_COMMAND_ALLIN_ERROR);
	response.WriteByte(nErrType);
	response.End();

	return SendPackage(&response, pHandler);
}

int CTeenpattiSendPacket::SendUserTimoutStand(SocketHandler* pHandler)
{
	NETOutputPacket response;
	response.Begin(SERVER_COMMAND_TIMOUT_STAND);
	response.End();

	return SendPackage(&response, pHandler);
}

int CTeenpattiSendPacket::BroadcastUserAllInMoney(CTeenpattiTable* pTable, int nActiveUserId, int nUserId)
{
	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_USER_ALLIN_MONEY);
	response.WriteInt(nActiveUserId);
	response.WriteInt(nUserId);
	response.End();

	return BroadcastTablePackage(pTable, &response, NULL);
}

int CTeenpattiSendPacket::BroadcastAcceptAllInMoney(CTeenpattiTable* pTable, int nUserId, BYTE byAccpt, long nMoney)
{
	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_USER_ACCEPT_ALLIN);
	response.WriteInt(nUserId);
	response.WriteByte(byAccpt);
	response.WriteLong(nMoney);
	response.End();

	return BroadcastTablePackage(pTable, &response, NULL);
}

int CTeenpattiSendPacket::BroadcastUserOperAllIn(CTeenpattiTable* pTable, int nUserId, BYTE byOperAllIn)
{
	NETOutputPacket response;
	response.Begin(SERVER_BROADCAST_OPER_ALLIN);
	response.WriteInt(nUserId);
	response.WriteByte(byOperAllIn);
	response.End();

	return BroadcastTablePackage(pTable, &response, NULL);
}