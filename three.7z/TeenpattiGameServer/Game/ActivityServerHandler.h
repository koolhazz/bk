#ifndef BOYAA_CORESERVERHANDLER_H_2011014_ACTIVITY
#define BOYAA_CORESERVERHANDLER_H_2011014_ACTIVITY

#include "ICHAT_TCP_Handler.h"
#include "ICHAT_PacketBase.h"
#include "wtypedef.h"

typedef InputPacket<ICHAT_TCP_DEFAULT_BUFFER>	ActivityServerInputPacket;
typedef OutputPacket<ICHAT_TCP_DEFAULT_BUFFER>	ActivityServerOutputPacket;



class CActivityServer;

class CActivityServerHandler:public ICHAT_TCP_Handler<>,
	public ICHAT_PacketParser<ActivityServerInputPacket>
{ 
public:
	CActivityServerHandler(void);
	CActivityServerHandler(CActivityServer* pActivityServer);

	virtual ~CActivityServerHandler(void);
public:
	int Send(ActivityServerOutputPacket *pPacket, int delete_buffer = 0, int close_flag = 0);
	//�ر�
	int OnClose(void);
	//�������
	int OnConnected(void);
	//��Ӧ
	int OnParser(char *buf, int nLen);
	//OnTimer
	int OnTimer(const void *);
	//�Ƿ�����
	bool IsConnected(void)	{return m_bConntected;}
	//�������ӵ�ַ
	ACE_INET_Addr &Addr(void) {return m_remote;}
	void Addr(ACE_INET_Addr &addr) { m_remote = addr;}

	ActivityServerInputPacket *GetPacket(void)
	{
		return &m_Packet;
	}
private:
	ActivityServerInputPacket m_Packet;
	//��ַ
	ACE_INET_Addr m_remote;
	//�ص�proxyManager
	CActivityServer *m_pActivityServer;
	//����״̬
	bool m_bConntected;
	//packet
	int OnPacketComplete(ActivityServerInputPacket *);

	int ProcessPacket(ActivityServerInputPacket* pPacket);
};

#endif

