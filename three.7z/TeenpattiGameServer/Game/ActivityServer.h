#ifndef BOYAA_LANDLORD_CORESERVER_H_20110113_ACTIVITY
#define BOYAA_LANDLORD_CORESERVER_H_20110113_ACTIVITY

#include "ActivityServerHandler.h"
#include "ACE_Application.h"
#include "TeenpattiTable.h"

typedef ACE_Connector<CActivityServerHandler, ACE_SOCK_CONNECTOR> ActivityServerConnector;

class CTeenpattiServer;
class CActivityServer
{
public:
	CActivityServer(CTeenpattiServer* pServer);
	~CActivityServer();

	//��ʼ������
	int	InitConnect(const char * strPath = "GameServer.ini");

	//Coreserver�ر��Զ�����
	void Reconnect(void);
	//��������״̬
	bool IsConnected(void){return m_SocketHandler.IsConnected();}

    void ReportInfo2ActivityServer(int uid, int win, int lost, int win_money, int lost_money, int active_time);

private:
	//��ʼ������
	int	InitConnect(ACE_INET_Addr &, ACE_Reactor * = ACE_Reactor::instance());

private:
	ActivityServerConnector	m_Connector;
	CActivityServerHandler m_SocketHandler;
	CTeenpattiServer* m_pLandServer;
};
#endif



