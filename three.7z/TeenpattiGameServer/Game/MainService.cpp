// GuessDrawServer.cpp : �������̨Ӧ�ó������ڵ㡣
//
#include "ServerManager.h"
#include "TeenpattiServer.h"
#include "TeenpattiCreator.h"
#include "TeenpattiHallServer.h"
#include "ActivityServer.h"


#ifndef WIN32
#include <sys/time.h>
#include <sys/resource.h>
#include <unistd.h>
#endif

CGameServer* g_pServer = NULL;

//��׽SIGSEGV�źŵĴ���
static void SignalHandler(int signo)
{

	ACE_DEBUG ((LM_ERROR, ACE_TEXT ("[%D]Signal SIGSEGV\n")));
#ifndef WIN32
	signal(signo, SIG_DFL);				//��������coredump
	kill(getpid(), signo);
#else
	exit(1);
#endif

}

int main(int argc, char *argv[])
{
	ACE_OS::signal (SIGSEGV, (ACE_SignalHandler) SignalHandler);
	ACE_OS::signal (SIGTERM, (ACE_SignalHandler) SignalHandler);

	g_pServer = new CTeenpattiServer();
	CCreator* pCreator = new CLandlordCreator();
	CTeenpattiHallServer* pHallServer = new CTeenpattiHallServer((CTeenpattiServer*)g_pServer);
	CActivityServer * pActivityServer = new CActivityServer((CTeenpattiServer*)g_pServer);

	if (StartServer(g_pServer, pHallServer, pActivityServer, pCreator, argc, argv) == -1)
	{
		ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT("StartServer failed\n")), -1);
		return -1;
	}

	getchar();
	return 0;
}

