#include "MemSvrSocketHandler.h"
#include "TeenpattiCmd.h"
#include "MemDataServer.h"
MemSvrSocketHandler::MemSvrSocketHandler(void)
{
    m_reconnect_timer.SetTimeEventObj(this,0);
	m_bConntected = false;
}

MemSvrSocketHandler::MemSvrSocketHandler(CMemDataServer* memSvr)
{
    m_reconnect_timer.SetTimeEventObj(this,0);
	m_pMemServer = memSvr;
}


MemSvrSocketHandler::~MemSvrSocketHandler(void)
{
}

int MemSvrSocketHandler::Send(MemNETOutputPacket *pPacket, int delete_buffer, int close_flag)
{
	return ICHAT_TCP_Handler<>::Send(pPacket->packet_buf(), pPacket->packet_size(), delete_buffer, close_flag);
}
////////////////////////////////////////////////////////////////////////////////
// OnParser(char *buf, int nLen)
////////////////////////////////////////////////////////////////////////////////
int MemSvrSocketHandler::OnParser(char *buf, int nLen)
{
	return ParsePacket(buf, nLen);
}
////////////////////////////////////////////////////////////////////////////////
// OnPacketComplete ��Ӧ���
////////////////////////////////////////////////////////////////////////////////
int MemSvrSocketHandler::OnPacketComplete(MemNETInputPacket *pPacket)
{
	(void)pPacket;
	//return ProcessPacket(pPacket);
	return 0;
}

int MemSvrSocketHandler::ProcessPacket(MemNETInputPacket* pPacket)
{
	switch (pPacket->GetCmdType())
	{
	default:
		return 0;
	}
	return 0;
}

////////////////////////////////////////////////////////////////////////////////
// OnClose(void)
////////////////////////////////////////////////////////////////////////////////
int MemSvrSocketHandler::OnClose(void)
{
	//����״̬��0 ����������ʱ����
	if(m_bConntected)	
	{
		m_bConntected = false;
		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]:(%P|%t) MemDataServer close.Trying to reconnect\r\n")));
	}
	m_reconnect_timer.StopTimer();
    m_reconnect_timer.StartTimer(1);
	return 1;  //only close , but not remove Reactor
}

////////////////////////////////////////////////////////////////////////////////
int MemSvrSocketHandler::OnConnected(void)
{
	m_bConntected = true;
	m_reconnect_timer.StopTimer();
	ACE_DEBUG((LM_DEBUG, ACE_TEXT("[%D]:(%P|%t) MemDataServerServer Connect ok\r\n")));

/*
    MemNETOutputPacket outPkg;
    outPkg.Begin(0x1001);
    outPkg.WriteInt(93);
    outPkg.WriteInt(1);
    outPkg.WriteInt(2);
    outPkg.WriteInt(132);

    outPkg.WriteInt(1);
    outPkg.WriteInt(1);
    outPkg.WriteInt(1);

    outPkg.WriteShort(0);
    outPkg.WriteShort(10);
    outPkg.End();
    
    Send(&outPkg);

    MemNETOutputPacket outPkg1;
    outPkg1.Begin(0x1001);
    outPkg1.WriteInt(1);
    outPkg1.WriteInt(1);
    outPkg1.WriteInt(0);
    outPkg1.WriteInt(132);

    outPkg1.WriteInt(1);
    outPkg1.WriteInt(1);
    outPkg1.WriteInt(1);

    outPkg1.WriteShort(1);
    outPkg1.WriteShort(1);
    outPkg1.End();
    
    Send(&outPkg1);

     MemNETOutputPacket outPkg2;
    outPkg2.Begin(0x1001);
    outPkg2.WriteInt(96);
    outPkg2.WriteInt(1);
    outPkg2.WriteInt(2);
    outPkg2.WriteInt(132);

    outPkg2.WriteInt(1);
    outPkg2.WriteInt(0);
    outPkg2.WriteInt(1);

    outPkg2.WriteShort(1);
    outPkg2.WriteShort(1);
    outPkg2.End();
    
    Send(&outPkg2);
***********/
	return 0;
}

int MemSvrSocketHandler::OnTimer(const void *)
{
	if(m_pMemServer == NULL)
	{
		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]:(%P|%t) MemDataServer\r\n")));
		return -1;
	}
	ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]:(%P|%t) connecting MemDataServer\r\n")));
 	m_pMemServer->Reconnect();
	return 0;
}

int MemSvrSocketHandler::ProcessOnTimerOut(int Timerid)
{
	(void)Timerid;
	if(m_pMemServer == NULL)
	{
		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]:(%P|%t) MemDataServer\r\n")));
		return -1;
	}
	ACE_DEBUG((LM_DEBUG, ACE_TEXT("[%D]:(%P|%t) connecting MemDataServer\r\n")));
 	m_pMemServer->Reconnect();
	return 0;
}

