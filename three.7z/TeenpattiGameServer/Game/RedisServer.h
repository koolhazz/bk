#ifndef __REDIS_SERVER_H
#define __REDIS_SERVER_H
#include <string>
#include <string.h>
#include <stdlib.h>
#include <iostream>
using std::string;
using namespace std;
#include "hiredis.h"
#include "json.h"
#include "ICHAT_Timer_Handler.h"
#include "TimerOutEvent.h"

#define _int64_ long long
struct TABLEDATA
{
	int tid;
	short type;
	short landScore;
	int baseChip;
};

#define REDIS_CONNECT_TIMER 1

class CRedisServer : public TimerOutEvent
{
public:
	CRedisServer();
	virtual ~CRedisServer() ;
	int Connect(string& ip, int port);
	int Reconnect();
	int CheckConnect();
	int PushRecord(char* key, char* value);
	int DelRecord(char* key);
	int SetExpire(char* key, int expire);
	redisReply * RedisCommand(const char * command);
private:
	int IncrRecord(int uid, const char* key, int expire=-1);
public:
	int ProcessOnTimerOut(int timerId);
private:
	string m_strIp;
	int m_nPort;
	redisContext *m_pRedisConn;		//����hiredis
	redisReply *m_pRedisReply;		//�ظ�hiredis 
	ICHAT_Timer_Handler m_ConnectTimer;
};
#endif

