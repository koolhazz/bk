#include "TeenpattiHallServer.h"
#include "TeenpattiServer.h"
#include "ICHAT_HTTP_Config.h"

#include "clib_log.h"
extern clib_log* g_pErrorLog;
extern clib_log* g_pDebugLog;

inline int GetAllocFromSid(int sid)
{
	return int(sid/200);
}

CTeenpattiHallServer::CTeenpattiHallServer(CTeenpattiServer* pServer):m_SocketHandler(this), m_pLandlordServer(pServer)
{

}

CTeenpattiHallServer::~CTeenpattiHallServer()
{

}

////////////////////////////////////////////////////////////////////////////////
// ��ʼ��proxy����
////////////////////////////////////////////////////////////////////////////////
int	CTeenpattiHallServer::InitConnect(ACE_INET_Addr &remote, ACE_Reactor *pReactor)
{
	m_Connector.open(pReactor, ACE_NONBLOCK);
	HallSocketHandler *pHandler = &m_SocketHandler;
	pHandler->Addr(remote);    //��������
	int nRet = m_Connector.connect(pHandler, remote, ACE_Synch_Options::synch);
	return nRet;
}

int CTeenpattiHallServer::InitConnect( const char * strPath /*= "GameServer.ini"*/ )
{
	ICHAT_HTTP_Config ConfigReader;
	int nRet = ConfigReader.Open(strPath);
	if(nRet == -1)
	{
		return FALSE;
	}

	ACE_Configuration_Section_Key subkey;
	char chHall[32] = {0};
	sprintf(chHall, "ALLOC%d", GetAllocFromSid(m_pLandlordServer->m_nServerID));

	ACE_DEBUG((LM_INFO, " AllocServer %d\n", GetAllocFromSid(m_pLandlordServer->m_nServerID)));

	ConfigReader.OpenSection(chHall, subkey);
	char strHost[256] = {0};
	ConfigReader.get_section_string(subkey, "HOST", strHost, 256);
	char strPort[256] = {0};
	ConfigReader.get_section_string(subkey, "PORT", strPort, 256);

	ACE_DEBUG((LM_INFO, "%D Connect AllocServer,HOST:[%s], PORT:[%s]\n", strHost, strPort));

	ACE_INET_Addr hallAddr(strPort, strHost);
	InitConnect(hallAddr);

	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////
// proxyserver�ر��Զ�����
////////////////////////////////////////////////////////////////////////////////
void CTeenpattiHallServer::Reconnect(void)  //EWOULDBLOCK
{
	HallSocketHandler *pClient = &m_SocketHandler;
	m_Connector.connect(pClient, pClient->Addr(), ACE_Synch_Options::synch);
}

void CTeenpattiHallServer::ReportServerData()
{
	if (!IsConnected())
	{
		return;
	}
	
	int nServerId = m_pLandlordServer->m_nServerID;
	int nLevel = m_pLandlordServer->m_nLevel;
	int nRoomCount = (int)m_pLandlordServer->m_TableList.size();
	int nUserCount = m_pLandlordServer->m_ServerUserList.size();
	
	HallOutputPacket OutPkg;

	OutPkg.Begin(REPORT_SERVER_DATA);

	OutPkg.WriteShort(nServerId);
	OutPkg.WriteShort(nLevel);
	OutPkg.WriteInt(nUserCount);
	OutPkg.WriteInt(nRoomCount);
	OutPkg.WriteString(m_pLandlordServer->m_LandlordServConf.strName);
	OutPkg.WriteInt(m_pLandlordServer->m_LandlordServConf.nRequireChips);
	OutPkg.WriteInt(m_pLandlordServer->m_LandlordServConf.nBaseChips);

	g_pErrorLog->logMsg("m_nServerID %hd",nServerId);
	g_pErrorLog->logMsg("nLevel %hd",nLevel);
	g_pErrorLog->logMsg("nUserCount %d",nUserCount);
	g_pErrorLog->logMsg("nRoomCount %d",nRoomCount);
	g_pErrorLog->logMsg("strName %s",m_pLandlordServer->m_LandlordServConf.strName);
	g_pErrorLog->logMsg("nRequireChips %d",m_pLandlordServer->m_LandlordServConf.nRequireChips);
	g_pErrorLog->logMsg("nBaseChips %d",m_pLandlordServer->m_LandlordServConf.nBaseChips);

	TableIdMap::iterator iter;
	for (iter=m_pLandlordServer->m_TableList.begin(); iter!=m_pLandlordServer->m_TableList.end(); ++iter)
	{
		int nTableId = iter->first;
		CTeenpattiTable* pTable = (CTeenpattiTable*)iter->second;
		OutPkg.WriteInt(nTableId);
		OutPkg.WriteShort(pTable->GetSitUserCount());		//������������
		OutPkg.WriteByte(pTable->GetOnlookerCount());   
		g_pErrorLog->logMsg("tid %hd",nTableId);
		g_pErrorLog->logMsg("GetSitUserCount %hd",pTable->GetSitUserCount());
		g_pErrorLog->logMsg("GetOnlookerCount %d",pTable->GetOnlookerCount());
	}

	OutPkg.End();
	m_SocketHandler.Send(&OutPkg);
}

void CTeenpattiHallServer::SendPortIPToHall()
{
	char chIp[32] = {0};
	int iPort = m_pLandlordServer->m_nPort;
	strcpy(chIp, m_pLandlordServer->chIP);
	int iServerId = m_pLandlordServer->m_nServerID;

	HallOutputPacket OutPkg;
	OutPkg.Begin(SEND_SERVER_PORTIP);
	OutPkg.WriteString(chIp);
	OutPkg.WriteInt(iPort);
	OutPkg.WriteShort(iServerId);
	OutPkg.End();
	m_SocketHandler.Send(&OutPkg);
}

int CTeenpattiHallServer::ReportSelfRetireStatus()
{
	if( !IsConnected() || m_pLandlordServer==NULL)
		return 0;
	HallOutputPacket outPkg;
	outPkg.Begin(SERVER_SEND_RETIRE);
	outPkg.WriteShort(m_pLandlordServer->nRetire);
	outPkg.WriteShort(1);
	outPkg.WriteShort(m_pLandlordServer->m_nServerID);
	outPkg.End();
	m_SocketHandler.Send(&outPkg);
	ACE_DEBUG((LM_INFO, "[%D]%s||Server Retired[%d] mServerId[%d]\n", __FUNCTION__, m_pLandlordServer->nRetire, m_pLandlordServer->m_nServerID));
	return 0;
}


void CTeenpattiHallServer::SendRetireToHall(int nRetire)
{
	m_pLandlordServer->nRetire = nRetire;
}

void CTeenpattiHallServer::UpdateRoomUserCount(CTeenpattiTable* pLandlordTable)
{
	g_pErrorLog->logMsg("--------- CTeenpattiHallServer::UpdateRoomUserCount begin -----");
	if (!IsConnected())
	{
		g_pErrorLog->logMsg("--------- CTeenpattiHallServer::UpdateRoomUserCount end 1 -----");
		return;
	}
		
	int nUserCount = m_pLandlordServer->m_ServerUserList.size();
	HallOutputPacket OutPkg;
	OutPkg.Begin(UPDATE_ROOM_USER_COUNT);
	OutPkg.WriteShort(m_pLandlordServer->m_nServerID);
	OutPkg.WriteInt(pLandlordTable->GetID());
	OutPkg.WriteShort(m_pLandlordServer->m_nLevel);
	OutPkg.WriteShort(pLandlordTable->GetSitUserCount());
	OutPkg.WriteInt(nUserCount);
	OutPkg.WriteByte(pLandlordTable->GetOnlookerCount());
	OutPkg.WriteString(m_pLandlordServer->m_LandlordServConf.strName);
	OutPkg.WriteInt(m_pLandlordServer->m_LandlordServConf.nRequireChips);
	OutPkg.WriteInt(m_pLandlordServer->m_LandlordServConf.nBaseChips);
	g_pErrorLog->logMsg("m_nServerID %hd",m_pLandlordServer->m_nServerID);
	g_pErrorLog->logMsg("tid %d",pLandlordTable->GetID());
	g_pErrorLog->logMsg("m_nLevel %hd",m_pLandlordServer->m_nLevel);
	g_pErrorLog->logMsg("GetSitUserCount %hd",pLandlordTable->GetSitUserCount());
	g_pErrorLog->logMsg("nUserCount %d",nUserCount);
	g_pErrorLog->logMsg("GetOnlookerCount %d",pLandlordTable->GetOnlookerCount());
	g_pErrorLog->logMsg("strName %s",m_pLandlordServer->m_LandlordServConf.strName);
	g_pErrorLog->logMsg("nRequireChips %d",m_pLandlordServer->m_LandlordServConf.nRequireChips);
	g_pErrorLog->logMsg("nBaseChips %d",m_pLandlordServer->m_LandlordServConf.nBaseChips);
	OutPkg.End();
	g_pErrorLog->logMsg("--------- CTeenpattiHallServer::UpdateRoomUserCount end  -----");
	m_SocketHandler.Send(&OutPkg);
}

void CTeenpattiHallServer::ReportEnterRoom(int uid, int tid)
{
	if(!IsConnected())
		return;
	HallOutputPacket OutPkg;
	OutPkg.Begin(SYS_USER_ENTER_ROOM);
	OutPkg.WriteInt(uid);
	OutPkg.WriteInt(tid);
	OutPkg.End();
	m_SocketHandler.Send(&OutPkg);
}

void CTeenpattiHallServer::ReportStandRoom(int uid, int tid)
{
	if(!IsConnected())
		return;
	HallOutputPacket OutPkg;
	OutPkg.Begin(SYS_USER_STAND_ROOM);
	OutPkg.WriteInt(uid);
	OutPkg.WriteInt(tid);
	OutPkg.End();
	m_SocketHandler.Send(&OutPkg);
}

void CTeenpattiHallServer::ReportLeaveRoom(int uid)
{
	if(!IsConnected())
		return;
	HallOutputPacket OutPkg;
	OutPkg.Begin(SYS_USER_LEAVE_ROOM);
	OutPkg.WriteInt(uid);
	OutPkg.End();
	m_SocketHandler.Send(&OutPkg);
}

void CTeenpattiHallServer::StandTableLeaveRoom(int nUserId)
{
	if(!IsConnected())
		return;
	HallOutputPacket OutPkg;
	OutPkg.Begin(SYS_STAND_LEAVE_ROOM);
	OutPkg.WriteInt(nUserId);
	OutPkg.End();
	m_SocketHandler.Send(&OutPkg);
}

int CTeenpattiHallServer::CreatePrivateRoom( int nRoomId, int nRoomType, int nBaseChip, string sRoomName, string sPassword )
{
	m_pLandlordServer->CheckAndAddTable(nRoomId, nRoomType, nBaseChip, sRoomName, sPassword);
	return 0;
}

