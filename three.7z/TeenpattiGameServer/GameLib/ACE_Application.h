#pragma once
#include <fstream>
#include "Global.h"
#include "SocketServer.h"

class ACE_Application
{
public:
	ACE_Application(SocketServer* pServer)
	{
		m_pSocketSever = pServer;
	}
	virtual ~ACE_Application()
	{
		m_pSocketSever = NULL;
	}

	////////////////////////////////////////////////////////////////////////////////
	// waitForShutdown
	////////////////////////////////////////////////////////////////////////////////
	virtual int waitForShutdown(void)
	{
		//ACE_Time_Value timeout(10);
		return ACE_Reactor::instance()->run_reactor_event_loop();
	}
	////////////////////////////////////////////////////////////////////////////////
	// waitForShutdown
	////////////////////////////////////////////////////////////////////////////////
	virtual int waitForShutdown(ACE_Time_Value &tv)
	{
		return ACE_Reactor::instance()->run_reactor_event_loop(tv);
	}
	// ��ʼ��
	virtual int init()
	{
/*		//��Զ�cpu �������
#ifndef WIN32
		int num = rand()%8;
		cpu_set_t mask;
		__CPU_ZERO(&mask);
		__CPU_SET(num, &mask);
		sched_setaffinity(0,sizeof(cpu_set_t),&mask);
#endif */
		ACE_Reactor * pMyReacotr = new ACE_Reactor(new PLAT_ACE_REACTOR, 1);
		pMyReacotr->restart(1);
		ACE_Reactor::instance(pMyReacotr);
		disable_sigpipe();
		return 0;
	}
	// ���������
	virtual int run(int nPort)
	{
		ACE_INET_Addr listen(nPort);

		if(m_pSocketSever->open(listen, ACE_Reactor::instance(), ACE_NONBLOCK) == -1)
			ACE_ERROR_RETURN((LM_ERROR, ACE_TEXT("[%D]%p\r\n"), ACE_TEXT("port err")), -1);
		ACE_DEBUG((LM_INFO, ACE_TEXT("[%D]Server have been started,listen port:%d...\r\n"), nPort));

		return 0;
	}

protected:
	virtual void disable_sigpipe(void)
	{
		sigset_t sigsetNew[1];
		sigset_t sigsetOld[1];
		ACE_OS::sigemptyset (sigsetNew);
		ACE_OS::sigaddset (sigsetNew, SIGPIPE);
		ACE_OS::sigprocmask (SIG_BLOCK, sigsetNew, sigsetOld);
	}

protected:
	SocketServer* m_pSocketSever;
} ;



