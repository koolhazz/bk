#include "SocketServer.h"
#include "SystemCmd.h"

SocketServer::SocketServer(void)
{
	m_dwHandlerID = 0;
}

SocketServer::~SocketServer(void)
{
}

////////////////////////////////////////////////////////////////////////////////
// �̳���ICHAT_TCP_Server, ������HANDLERʱ��
////////////////////////////////////////////////////////////////////////////////
ICHAT_TCP_Handler<> * SocketServer::CreateHandler(void)
{
	SocketHandler *pNewHandler;
	ACE_NEW_RETURN(pNewHandler, SocketHandler(++m_dwHandlerID), 0);
	return pNewHandler;
}
////////////////////////////////////////////////////////////////////////////////
// ��ʱ
////////////////////////////////////////////////////////////////////////////////
int 
SocketServer::ProcessOnTimer(SocketHandler *pHandler)
{
	if(pHandler->GetChunkStatus() == SocketHandler::CONNECT)
	{
		return -1;
	}
	return 0;
}
////////////////////////////////////////////////////////////////////////////////
// ���������� ����map
////////////////////////////////////////////////////////////////////////////////
int SocketServer::ProcessConnected(SocketHandler *pHandler)
{
	DWORD id = pHandler->GetHandlerID();
	if(m_HandlerMap.find(id) == m_HandlerMap.end())
	{
		m_HandlerMap[id] = pHandler;
	}
	else
	{
		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]SocketServer::ProcessConnected Error %d\r\n"), pHandler->GetHandlerID()));
	}
	return 0;
}
////////////////////////////////////////////////////////////////////////////////
// ����Handler�ر�
////////////////////////////////////////////////////////////////////////////////
int SocketServer::ProcessClose(SocketHandler *pHandler)
{
	DWORD id = pHandler->GetHandlerID();
	map<DWORD, SocketHandler*>::iterator iter = m_HandlerMap.find(id);
	if(iter != m_HandlerMap.end())
	{
		m_HandlerMap.erase(iter);
	}
	else
	{
		ACE_DEBUG((LM_ERROR, ACE_TEXT("[%D]SocketServer::ProcessClose Error %d\r\n"), pHandler->GetHandlerID()));
	}
	return 0;
}
////////////////////////////////////////////////////////////////////////////////
// FindHandler
////////////////////////////////////////////////////////////////////////////////
SocketHandler * SocketServer::FindHandler(DWORD dwHandlerID)
{
	map<DWORD, SocketHandler*>::iterator iter = m_HandlerMap.find(dwHandlerID);

	if(iter != m_HandlerMap.end())
	{
		return iter->second;
	}
	return NULL;
}

DWORD SocketServer::GetHandlerID(void)
{
	return ++m_dwHandlerID;
}

//��������ͻ���
int SocketServer::SendCmdToClient(int nCmdType, SocketHandler *pHandler)
{
	NETOutputPacket outPkg;
	BuildPackage(&outPkg, nCmdType);
	if (pHandler != NULL)
	{
		return pHandler->Send(&outPkg);
	}
	return -1;
}

//�����ݰ����ͻ���
int SocketServer::SendPackageToClient(NETOutputPacket* pPackage, SocketHandler *pHandler)
{
	if (pHandler != NULL)
	{
		return pHandler->Send(pPackage);
	}
	return -1;	
}

//////////////////////////////////////////////////////////////////////////
//ʵ�ֹ���һ��NETOutputPacket���ݰ�,�����ɱ䳤
//֧�ֵ�������int,DWORD,short,char*,
//��Ӧ����Ϊ %d====int, %u====DWORD, %h=====short, %s=====char*
//pszFmtΪ����Ҫ���͵������ֶεĸ�ʽ��ɵ��ַ���,���Բ����ò���,Ҳ���Դ�.��"%d,%u,%h,%s"
//Ҳ���Լ���һЩע����Ϣ,��:"id:%d ntype:%h key:%u name:%s"
//////////////////////////////////////////////////////////////////////////
void SocketServer::BuildPackage(NETOutputPacket* pOutPack, short nCmdType, const char* pszFmt, ...)
{
	pOutPack->Begin(nCmdType);

	if (pszFmt == NULL)	//����Ϊ�յ�,��ֱ�ӹ���һ��ֻ������ͷ�����ݰ�
	{
		pOutPack->End();
		return;
	}

	va_list ap; 
	va_start (ap, pszFmt); 
	const char* p = NULL;

	for (p= pszFmt; *p; p++) 
	{ 
		if (*p != '%') 
		{
			continue; 
		}

		switch (*++p) 
		{ 
		case 'd':	//int
			{
				int nVal= va_arg(ap, int);
				pOutPack->WriteInt(nVal);
				break;
			}
		case 'h':	//short
			{
				short shVal = va_arg(ap, short);
				pOutPack->WriteShort(shVal);
				break;
			}
		case 'u':	//unsigned long
			{
				unsigned long dwVal = va_arg(ap, unsigned long);
				pOutPack->WriteULong(dwVal);
				break;
			}
		case 's':	//char*
			{
				char* pVal = va_arg(ap, char*);
				pOutPack->WriteString(pVal);
				break;
			}
		}
	}
	pOutPack->End();
}

void SocketServer::SetPacketVersion(short version, short subVersion)
{
	SocketHandler::m_packetVer = version;
	SocketHandler::m_packetSubVer = subVersion;
	
	m_DetectConnTimer.SetTimeEventObj(this, DETECT_CONN_TIMER);
	m_DetectConnTimer.StartTimer(0, DETECT_INTERVAL);
}

int SocketServer::ProcessOnTimerOut(int Timerid)
{
	ACE_UNUSED_ARG(Timerid);
	switch (Timerid)
	{
	case DETECT_CONN_TIMER://����Ƿ���������Ч
		CheckHandler();
		break;
	}
	return 0;
}


void SocketServer::CheckHandler(void)
{
	map<DWORD, SocketHandler*>::iterator iter;
	ACE_Time_Value step(DETECT_CONN_TIME);
	for(iter = m_HandlerMap.begin(); iter!=m_HandlerMap.end(); iter++)
	{
		if(iter->second->m_DiffConBrokenTime > step)
		{
			iter->second->close();
		}
	}
}
