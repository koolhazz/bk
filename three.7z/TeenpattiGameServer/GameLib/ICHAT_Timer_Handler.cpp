#include "ICHAT_Timer_Handler.h"
//#include "TimerServer.h"
//#include "CommandMsg.h"	


ICHAT_Timer_Handler::ICHAT_Timer_Handler(void)
{
	m_nId = 0;
	m_TimeEvent = NULL;
	//this->reactor(ACE_Reactor::instance());
}

ICHAT_Timer_Handler::~ICHAT_Timer_Handler(void)
{
}

int ICHAT_Timer_Handler::handle_timeout(const ACE_Time_Value & /*time*/, const void *p)
{
	(void)p;
	return m_TimeEvent->ProcessOnTimerOut(m_nId);
}

void ICHAT_Timer_Handler::SetTimeEventObj(TimerOutEvent * obj, int id)
{
	m_nId = id;
	m_TimeEvent = obj;
}
////////////////////////////////////////////////////////////////////////////////
// // ��ʼ��ʱ��(��ʼ��ʱnSecond��, ���interval��
////////////////////////////////////////////////////////////////////////////////
void ICHAT_Timer_Handler::StartTimer(long nSecond, long interval)
{
	this->reactor(ACE_Reactor::instance());
	if(interval == 0)
		this->reactor()->schedule_timer(this, 0, ACE_Time_Value(nSecond));
	else
		this->reactor()->schedule_timer(this, 0, ACE_Time_Value(nSecond), ACE_Time_Value(interval));
}
void ICHAT_Timer_Handler::StopTimer(void)
{
	if (this->reactor() == NULL)
	{
		return;
	}

	this->reactor()->cancel_timer(this);
}
