#ifndef BOYAA_SERVER_RESPONSE_H_20091111
#define BOYAA_SERVER_RESPONSE_H_20091111

#include "GameTable.h"
#include "GameUser.h"
#include "ICHAT_PacketBase.h"
#include "TeenpattiTable.h"

typedef struct		//��½�û������ݽṹ
{
	int nUserId;
	int nSeatId;
	BOOL bReadyStart;
	string strUserInfo;
}TLoginUserInfo;

class SocketHandler;
class CSendPacket
{
protected:		
	UserIdMap &m_ServerUserList;			//�����û��б�
	CGameServer* m_pGameServer;

public:

	CSendPacket(UserIdMap &list, CGameServer* pServer):m_ServerUserList(list), m_pGameServer(pServer)
	{
	}

	virtual ~CSendPacket(void)
	{
	}
	
	virtual int SendUserLoginSuccess(SocketHandler* pHandler, CGameUser* pUser);
	virtual int SendLoginError(SocketHandler* pHandler, BYTE nErrNo);
	virtual int SendErrResponse(SocketHandler* pSocket);
	virtual int BroadcastUserLogin(CGameTable* pTable, CGameUser* pUser);
	virtual int BroadcastUserLogout(CGameTable* pTable, CGameUser* pUser);
	virtual int BroadcastSysCmdMsg(string &strMsg);
	virtual int BroadcastClientChat(int nUserId, string strMsg, CGameTable* pTable);
	virtual int BroadcastClientSendFace(int nUserId, int nType, CGameTable* pTable);

public:
	int SendCmdToClient(int nCmdType, SocketHandler *pHandler);
	int SendCmdToClient(SocketHandler *pHandler,short nCmdType,const char* pszFmt, ...);
	int SendPackage(NETOutputPacket* pPackage, SocketHandler* pHandler);
	int SendPackage(NETOutputPacket* pPackage, CGameUser* pUser);
	int BroadcastTablePackage(CGameTable* pTable, NETOutputPacket* pPackage, CGameUser* pUser = NULL);
	int BroadcastAllPackage(NETOutputPacket* pPackage, CGameUser* pUser = NULL);
protected:
	
	//*********************************************/
	// Method:    BuildPackage
	// Returns:   void
	// Parameter: NETOutputPacket * pOutPack
	// Parameter: short nCmdType
	// Parameter: const char * pszFmt
	// Parameter: ...
	// Description: ����NETOutputPacket���ݰ�,�����ɱ䳤
	//				֧�ֵ�������int,DWORD,short,char*,
	//				��Ӧ����Ϊ %d====int, %u====DWORD, %h=====short, %s=====char*
	//				pszFmtΪ����Ҫ���͵������ֶεĸ�ʽ��ɵ��ַ���,���Բ����ò���,Ҳ���Դ�.��"%d,%u,%h,%s"
	//				Ҳ���Լ���һЩע����Ϣ,��:"id:%d ntype:%h key:%u name:%s"
	//*********************************************/
	void BuildPackage(NETOutputPacket* pOutPack, short nCmdType, const char* pszFmt = NULL, ...);

};

#endif
