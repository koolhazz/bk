#pragma once
#include "ichatlib.h"
#include "ICHAT_TCP_Server.h"
#include "SocketHandler.h"
#include "ICHAT_Timer_Handler.h"


class SocketServer:public ICHAT_TCP_Server, public TimerOutEvent
{
public:
	SocketServer(void);
	virtual ~SocketServer(void);

public:
	//*********************************************/
	// Method:    CreateHandler
	// Returns:   ICHAT_TCP_Handler<> *
	// Parameter: void
	// Description: ����һ��Handle����
	//*********************************************/
	ICHAT_TCP_Handler<> * CreateHandler(void);

	//*********************************************/
	// Method:    ProcessConnected
	// Returns:   int
	// Parameter: SocketHandler *
	// Description: ����������
	//*********************************************/
	virtual int ProcessConnected(SocketHandler *);

	//*********************************************/
	// Method:    ProcessClose
	// Returns:   int
	// Parameter: DWORD dwHanlerID
	// Description: ����Handler�ر�
	//*********************************************/
	virtual int ProcessClose(SocketHandler *);

	//*********************************************/
	// Method:    ProcessOnTimer
	// Returns:   int
	// Parameter: DWORD dwHanlerID
	// Description: ����OnTimer
	//*********************************************/
	virtual int ProcessOnTimer(SocketHandler *);

	//*********************************************/
	// Method:    ProcessPacket
	// Returns:   int
	// Parameter: NETInputPacket * pPacket
	// Parameter: DWORD dwHanlerID
	// Description: ������ʱ���¼�
	//*********************************************/
	virtual int ProcessPacket(NETInputPacket *pPacket, SocketHandler *pHandler, DWORD dwSessionID) = 0;

	//*********************************************/
	// Method:    FindHandler
	// Returns:   SocketHandler *
	// Parameter: DWORD
	// Description: ����Handler
	//*********************************************/
	SocketHandler *FindHandler(DWORD);

	//*********************************************/
	// Method:    GetHandlerID
	// Returns:   unsigned int
	// Parameter: void
	// Description: ȡһ��HandlerID
	//*********************************************/
	DWORD GetHandlerID(void);
	
	//*********************************************/
	// Method:    SendCmdToClient
	// Returns:   int
	// Parameter: int nCmdType
	// Parameter: DWORD dwHanlerID
	// Description: ��������ͻ���
	//*********************************************/
	int SendCmdToClient(int nCmdType, SocketHandler *pHandler);

	//*********************************************/
	// Method:    SendPackageToClient
	// Returns:   int
	// Parameter: NETOutputPacket * pPackage
	// Parameter: DWORD dwHanlerID
	// Description: �����ݰ����ͻ���
	//*********************************************/
	int SendPackageToClient(NETOutputPacket* pPackage, SocketHandler *pHandler);

	//*********************************************/
	// Method:    BuildPackage
	// Returns:   void
	// Parameter: NETOutputPacket * pOutPack
	// Parameter: short nCmdType
	// Parameter: const char * pszFmt
	// Parameter: ...
	// Description: ����NETOutputPacket���ݰ�,�����ɱ䳤
	//				֧�ֵ�������int,DWORD,short,char*,
	//				��Ӧ����Ϊ %d====int, %u====DWORD, %h=====short, %s=====char*
	//				pszFmtΪ����Ҫ���͵������ֶεĸ�ʽ��ɵ��ַ���,���Բ����ò���,Ҳ���Դ�.��"%d,%u,%h,%s"
	//				Ҳ���Լ���һЩע����Ϣ,��:"id:%d ntype:%h key:%u name:%s"
	//*********************************************/
	void BuildPackage(NETOutputPacket* pOutPack, short nCmdType, const char* pszFmt = NULL, ...);


	//*********************************************/
	// Method:    SetPacketVersion
	// Returns:   void
	// Parameter: short version
	// Parameter: short subVersion
	// Description: �������ݰ��İ汾��,�����øú�������Ĭ�ϵİ汾���Ӱ汾����1
	//*********************************************/
	void SetPacketVersion(short version, short subVersion);
	

	//*********************************************/
	// Method:    ProcessOnTimerOut
	// Returns:   int
	// Parameter: int Timerid
	// Description: �û��Ķ�ʱ���¼�
	//*********************************************/
	int ProcessOnTimerOut(int Timerid);
private:
	void CheckHandler(void);
public:
	DWORD m_dwHandlerID;							//�����Handler��Ψһ��ʶ

protected:
	//ICHAT_Hash_Map<int, SocketHandler*> m_HandlerMap; 	//HandlerMap
	map<DWORD, SocketHandler*>	m_HandlerMap;

private:
	ICHAT_Timer_Handler m_DetectConnTimer;

};
