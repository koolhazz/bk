#ifndef BOYAA_PROCESS_PACKET_20091113
#define	BOYAA_PROCESS_PACKET_20091113

//#include "SocketHandler.h"
#include "wtypedef.h"
#include "ICHAT_PacketBase.h"

class CGameServer;
class SocketHandler;
//class InputPacket<>;
//typedef InputPacket<8192>	NETInputPacket;

class CProcessPacket
{
protected:
	CGameServer* m_pGameServer;
public:

	CProcessPacket(CGameServer* pService)
	{
		m_pGameServer = pService;
	}

	virtual ~CProcessPacket(void)
	{
	}
	
	//*********************************************/
	// Method:    ProcessPacket
	// Returns:   int
	// Parameter: NETInputPacket * pPackage
	// Parameter: SocketHandler * pSocket
	// Parameter: DWORD dwSessionID
	// Description: �������ݰ�
	//*********************************************/
	virtual int ProcessPacket(NETInputPacket *pPackage, SocketHandler *pSocket, DWORD dwSessionID);

protected:
	//*********************************************/
	// Method:    ProcExtendCmd
	// Returns:   int
	// Parameter: NETInputPacket * pPackage
	// Parameter: SocketHandler * pSocket
	// Parameter: DWORD dwSessionID
	// Description: ������Ϸ�߼�����
	//*********************************************/
	virtual int ProcExtendCmd(NETInputPacket *pPackage, SocketHandler *pSocket) = 0;

protected:
	virtual int OnUserLogin(NETInputPacket *pPackage, SocketHandler *pSocket, DWORD dwSessionID);	
	virtual int OnUserLogout(NETInputPacket *pPackage, SocketHandler *pSocket);
	virtual int OnUserChat(NETInputPacket *pPackage, SocketHandler *pSocket);
	virtual int OnUserSendFace(NETInputPacket *pPackage, SocketHandler *pSocket);
	virtual int OnSysCmdStopServer(NETInputPacket *pPackage, SocketHandler *pSocket);
	virtual int OnSysCmdBroadcastCmd(NETInputPacket *pPackage, SocketHandler *pSocket);
	virtual int OnSysCmdResetConfig(NETInputPacket *pPackage, SocketHandler *pSocket);
	virtual int OnSysCmdCtrlServer(NETInputPacket *pPackage, SocketHandler *pSocket);
	virtual int OnSysCmdDebugLog(NETInputPacket *pPackage, SocketHandler *pSocket);
	virtual int OnSetClientInfo(NETInputPacket *pPackage,SocketHandler *pSocket);	
};

#endif
