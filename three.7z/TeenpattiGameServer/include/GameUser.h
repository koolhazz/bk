#ifndef BOYAA_GAME_USER_H_20090707
#define BOYAA_GAME_USER_H_20090707

#include "wtypedef.h"
#include "ICHAT_Timer_Handler.h"
#include <map>
using namespace std;

enum UserStatus
{
	USER_STATUS_LOGIN,		//�ѵ�¼
	USER_STATUS_READY,		//׼��
	USER_STATUS_PALY,		//��Ϸ��
};

#define INVAILD_SEAT_ID			100
#define DISCONNECT_USER_TIME	10

class SocketHandler;
class CGameTable;
class CGameSeat;
class CGameServer;
class CGameUser: public TimerOutEvent
{
public:
	CGameUser(CGameServer* pServer, CGameTable *pTable, int nUserID,  DWORD dwSessionID, string strUserInfo);
	virtual ~CGameUser(void);

public:
	int  GetUserId() const { return m_nUserID; }
	void SetUserId(int nUserID) { m_nUserID = nUserID; }
	int GetIP() { return m_dwPeerIP;}
	void SetIP(DWORD dwIP) { m_dwPeerIP=dwIP;}
	int  GetStatus()	const { return m_nStatus; }
	void SetStatus(int nStatus)	{ m_nStatus = nStatus; }
	CGameTable *  GetTable() const { return m_pTable; }
	void SetTable(CGameTable *pTable) { m_pTable = pTable; }
	SocketHandler * GetHandler() { return m_pSocket; }
	void SetHandler(SocketHandler * pSocket) { m_pSocket = pSocket; }
	int ProcessOnTimerOut(int Timerid);
	void Sit(CGameSeat *pSeat);
	void Ready();
	void Stand();
	CGameSeat* GetSeat();
	BYTE GetSeatId();

public:
	DWORD m_dwSessionID;		//ʹ��sessionid�ǿ��ǵ��Ժ���չ��proxy�����
	SocketHandler *m_pSocket;	//socketָ��
	string m_strUserInfo;		//�û���Ϣ
    long m_nMoney;              //�û�Ǯ��
	int m_nWinTimes;			//Ӯ�Ĵ���
	int m_nLoseTimes;			//��Ĵ���
	int m_nStatus;				//�û�״̬
protected:			
	int m_nUserID;				//�û�ID
	CGameTable *m_pTable;		//���Ӷ���
	CGameServer* m_pGameServer;	//gameserverָ��
	CGameSeat *m_pSeat;			//��λ����
	DWORD	m_dwPeerIP;			//��HallServer��������client����IP
};

typedef map<DWORD, CGameUser*> UserIdMap;			//�û��б�, �û�idΪkey,gameuserָ��Ϊvalue
#endif
