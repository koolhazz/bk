#ifndef BOYAA_GAME_SEAT_H_20091111
#define BOYAA_GAME_SEAT_H_20091111

#include "wtypedef.h"
#include "GameUser.h"
#include <vector>
using namespace std;

class CGameUser;
class CGameSeat
{
public:

	CGameSeat(BYTE id);

	~CGameSeat(void);

public:
	BYTE m_nSeatID;			//��λID
	CGameUser* m_pUser;		//����λ�û�ָ��
};

typedef	vector<CGameSeat*>	SeatList;

#endif
