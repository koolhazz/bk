#ifndef BOYAA_SERVER_MANAGER_H_20091114
#define BOYAA_SERVER_MANAGER_H_20091114

#include "GameServer.h"
#include "TeenpattiHallServer.h"

//*********************************************/
// Method:    StartServer
// Returns:   int
// Parameter: CGameServer * pServer
// Parameter: CTeenpattiHallServer* pHallServer
// Parameter: CCreator * pCreator
// Parameter: int argc
// Parameter: char * argv[]
// Description: ��ʼ��,����server
//*********************************************/
int StartServer(CGameServer* pServer, CTeenpattiHallServer* pHallServer, CActivityServer * pActivityServer, CCreator* pCreator, int argc, char* argv[]);


#endif
