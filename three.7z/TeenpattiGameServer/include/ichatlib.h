////////////////////////////////////////////////////////////////////////////////
// ichatlib.h
// 
// Global Macro define header file
//
// Zhang Wei modifyed 2006-10-24
////////////////////////////////////////////////////////////////////////////////
#pragma once

#ifndef USE_ICHAT_NAMESPACE	
#	define	USE_ICHAT_NAMESPACE
#endif

#ifndef USE_ICHAT_NAMESPACE
#	define	BEGIN_ICHAT_NAMESPACE
#	define	END_ICHAT_NAMESPACE
#	define USING_ICHAT_NAMESPACE
#else
#	define	BEGIN_ICHAT_NAMESPACE	namespace ichat {
#	define	END_ICHAT_NAMESPACE		};
#	define USING_ICHAT_NAMESPACE	using namespace ichat;
#endif


#ifndef	ICHAT_DEBUG_IO		// IO�������Ϣ
#	define ICHAT_DEBUG_IO	ACE_DEBUG//ACE_TRACE
#endif

#ifndef	ICHAT_DEBUG_HTTP	// HTTPЭ�������Ϣ
#	define	ICHAT_DEBUG_HTTP	ACE_TRACE
#endif

#ifndef ICHAT_TCP_MIN_BUFFER	//TCP socket ȱʡ���� Buffer Size
#	define	ICHAT_TCP_MIN_BUFFER	1024
#endif

#ifndef ICHAT_TCP_DEFAULT_BUFFER	//TCP socket ȱʡ���� Buffer Size
#	define	ICHAT_TCP_DEFAULT_BUFFER	8192
#endif

#ifndef ICHAT_TCP_MAX_BUFFER	//TCP socket ������ Buffer Size
#	define	ICHAT_TCP_MAX_BUFFER	1024*16
#endif

#ifndef ICHAT_UDP_DEFAULT_BUFFER	//TCP socket ȱʡ���� Buffer Size
#	define	ICHAT_UDP_DEFAULT_BUFFER	1024*8
#endif
// Ĭ��HTTP������󳤶�
#ifndef MAX_HTTP_REQUEST_SIZE
#	define		MAX_HTTP_REQUEST_SIZE		ICHAT_TCP_DEFAULT_BUFFER
#endif

// Ĭ��HTTP���Head����
#ifndef MAX_HTTP_REQUEST_FIELDS
#	define		MAX_HTTP_REQUEST_FIELDS		100
#endif

#ifndef _WINDEF_
typedef unsigned char       BYTE;
#endif
//�����ڴ�
#ifndef WIN32
#define CopyMemory(Destination,Source,Length) memcpy((Destination),(Source),(Length))
#endif
//��������ά��
#define CountArray(Array) (sizeof(Array)/sizeof(Array[0]))

//�����ַ�����
#define CountString(String) ((UINT)((lstrlen(String)+1)*sizeof(TCHAR)))

//��ȫɾ��ָ��
#define  SafeDelete(pData)	{ try { delete pData; } catch (...) { } pData=NULL; } 

//��ȫɾ��ָ��
#define  SafeDeleteArray(pData)	{ try { delete [] pData; } catch (...) { } pData=NULL; } 

// STLͷ�ļ�����
#include <string>
#include <queue>
#include <vector>
#include <deque>
#include <list>
#include <iostream>
#include <assert.h>
using namespace std;

void globalbreak(void);
