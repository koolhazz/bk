#ifndef _BOYAA_CREATE_H_20091111
#define _BOYAA_CREATE_H_20091111

#include "GameTable.h"
#include "GameUser.h"
#include "SendPacket.h"
#include "ProcessPacket.h"

/************************************************************************/
/* ������Ϸ��չ�Զ�����ĳ������										*/
/* ����table,user, SendPacket, processPacket, dbpart					*/
/************************************************************************/
class CCreator
{

public:
	virtual ~CCreator(){}
	//*********************************************/
	// Method:    CreateTable
	// Returns:   CGameTable*
	// Description: ��������
	//*********************************************/
	virtual CGameTable* CreateTable(CGameServer* pServer, TableData *info, int nId) = 0;

	//*********************************************/
	// Method:    CreateTable
	// Returns:   CGameTable*
	// Description: ������������
	//*********************************************/

	//*********************************************/
	// Method:    CreateUser
	// Returns:   CGameUser*
	// Parameter: CGameTable * pTable
	// Parameter: int nUserID
	// Parameter: DWORD dwSessionID
	// Parameter: string strUserInfo
	// Description: �����û�
	//*********************************************/
	virtual CGameUser* CreateUser(CGameServer* pServer, CGameTable *pTable, int nUserID,  DWORD dwSessionID, string strUserInfo) = 0;

	//*********************************************/
	// Method:    CreateSendPacket
	// Returns:   CSendPacket*
	// Description: ����SendPacket��
	//*********************************************/
	virtual CSendPacket* CreateSendPacket(UserIdMap &list, CGameServer* pServer) = 0;

	//*********************************************/
	// Method:    CreateProcessPacket
	// Returns:   CProcessPacket*
	// Description: ����CProcessPacket
	//*********************************************/
	virtual CProcessPacket* CreateProcessPacket(CGameServer* pServer) = 0;

	//*********************************************/
	// Method:    CreateDbHandle
	// Returns:   CDbPart*
	// Description: ����CDbPart
	//*********************************************/
	//virtual CDbPart* CreateDbHandle() = 0;
};

#endif

