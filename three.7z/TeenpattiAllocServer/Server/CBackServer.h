#ifndef CLOGSERVER_H_
#define CLOGSERVER_H_


#include "ICC_Timer_Handler.h" 
#include "CCSocketHandler.h" 
#include "BoyaaDecoder.h"
#include "Packet.h"
#include "GameCmd.h"


class CGameTable;

class CBackServer : public CCSocketHandler, public CCTimer
{

public:
	CBackServer(string strFlag);
	virtual ~CBackServer();

	virtual int Init();
	int OnConnected();
    int OnClose();
    int OnPacketComplete(const char* data, int len);
	ICC_Decoder* CreateDecoder()
    {
		return BoyaaDecoder::getInstance();
    }
	virtual int ProcessOnTimerOut();

	int reConnect();

	int Send(OutputPacket *pPakcet);
	InputPacket	pPacket;
private:
	string strServer_flag;
	bool   m_bIsConnected;

	int ProcessPacket(InputPacket *pPacket);
public:
	int InitConnect(const char *ip, int port);
};

#endif

