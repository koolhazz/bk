#include "LogicServer.h"

#include "ClientHandler.h"
#include "GameTable.h"

#define CORE_CHECK 1

const int CHECK_CORE_TIME = 10;

CLogicServer::CLogicServer(short serverId, int userCount, int tableCount, short level, ClientHandler *pHandler)
{
	m_nServerId = serverId;
	m_nUserCount = userCount;
	m_nTableCount = tableCount;
	m_nLevel = level;
	m_pSocketHandler = pHandler;
	m_strIp = "";
	m_nPort = 0;
	m_nRetire = 0;
	m_nServerType = 0;
}

CLogicServer::~CLogicServer()
{
}

CGameTable* CLogicServer::GetTable(int tid)
{
	CGameTable *pTable = NULL;
	map<int, CGameTable*>::iterator iter = m_TableList.find(tid);
	if(iter != m_TableList.end())
	{
		pTable = iter->second;
	}
	return pTable;
}

void CLogicServer::StartCheckCoreTimer()
{
	StartTimer(CHECK_CORE_TIME*1000);
}

void CLogicServer::StopCheckCoreTimer()
{
	StopTimer();
}

int CLogicServer::ProcessOnTimerOut()
{
	Options::instance()->ProcessLogicCore(this);
	return 0;
}


	
