#ifndef __LOGIC_SERVER_H
#define __LOGIC_SERVER_H

#include "ICC_Timer_Handler.h" 
#include "CCSocketHandler.h" 
#include "Options.h"


#include <string>
using std::string;
#include <map>
using std::map;

class CGameTable;
class ClientHandler;

class CLogicServer : public CCTimer
{
public:
	CLogicServer(short serverId, int userCount, int tableCount, short level, ClientHandler *pHandler);
	~CLogicServer(void);
	CGameTable* GetTable(int tid);
public:
	virtual int ProcessOnTimerOut();
	void StartCheckCoreTimer();
	void StopCheckCoreTimer();
public:
	short m_nServerId;
	string m_strIp;
	int m_nPort;
	int m_nUserCount;
	int m_nTableCount;
	short m_nRetire;
	short m_nLevel;
	ClientHandler *m_pSocketHandler;
	map<int, CGameTable*> m_TableList;
	int m_nServerType;//����3�˳���4�˳�

private:
};
#endif
