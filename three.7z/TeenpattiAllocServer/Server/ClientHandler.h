#ifndef SOCKET_HANDLER_H
#define SOCKET_HANDLER_H


#include "CCSocketServer.h"
#include "CCSocketHandler.h"
#include "CCStreamDecoder.h"
#include "Packet.h"
#include "BoyaaDecoder.h"
#include "HallServer.h"
#include "LogicServer.h"
#include "GameTable.h"
#include <string>
#include <vector>

using namespace std;

class ClientHandler: public CCSocketHandler
{

public:
	ClientHandler();
	virtual ~ClientHandler();

	string m_addrRemote;
	int    m_nPort;

	int Send(OutputPacket * packet, bool encode = false)
	{
		if( encode)
			packet->EncryptBuffer();

		return CCSocketHandler::Send(packet->packet_buf(), packet->packet_size())>0 ?0: -1;
	}

	int OnConnected(void); 
	int OnClose();

private:
	int OnPacketComplete(const char * data,int len);
	int ProcessPacket(InputPacket *pPacket);
	ICC_Decoder* CreateDecoder()
	{
		return BoyaaDecoder::getInstance();

	}

	void GetRemoteAddr(void);
	InputPacket	pPacket;

public:
	CHallServer *m_pHallServer;
	CLogicServer *m_pLogicServer;

private:
	//ҵ���߼�����
	int ProcessClientPacketReady(InputPacket *pPacket);					//��ɿͻ��˵İ���ʼ����
	int ProcessClientPacket(int uid,int svid, int appIp, short api, InputPacket * pPacket); //�����ͻ��˵İ�
	int ProcessTransferPacket(int uid, InputPacket *pPacket);			//ת����UserServer
	int	ProcessReportServerData(InputPacket *pPacket);
	int ProcessUpdateRoomUserCount(InputPacket *pPacket);
	int ProcessSendServerPortIp(InputPacket *pPacket);
	int ProcessSetServerRetired(InputPacket *pPacket);
	void ProcessResetFillFlag(InputPacket *pPacket);
	void ProcessTransPacket(InputPacket *pPacket);
	int ProcessSysGetTablelistBySvid(InputPacket* pPacket);
	
	int ProcessGetNewRoom(int uid, int svid, int appIp, InputPacket *pPacket);
	int ProcessRequireIpAndPort(int uid, int svid, InputPacket *pPacket);

	int ProcessListRoom(int uid, int svid, InputPacket *pPacket);
	int ProcessUserEnterRoom(int uid, int svid, InputPacket *pPacket);

	void UpdateTableUserCountToLogic(int nTid, int nTableUserCount, BYTE nOnLooker, CLogicServer *pLogicServer, int nServerId, int nLevel, string strtabname, int nRequireChip, int Basechip);

	int ProcessLogicClose(CLogicServer *pLogicServer);
	int ProcessHallClose(CHallServer* pHallServer);


	int GetRoomList(TableList &list);

	int CheckPacketComplete(const char *pData,const int &nLen);

public:
	int SendClientPacket(int uid, int svid, OutputPacket *pPacket);
	
};



#endif


