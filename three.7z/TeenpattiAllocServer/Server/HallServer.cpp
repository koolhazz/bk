#include "HallServer.h"
#include "ClientHandler.h"

CHallServer::CHallServer(int nServerId, ClientHandler *pHandler)
{
	m_nServerID = nServerId;
	m_pSocketHandler = pHandler;
}

CHallServer::~CHallServer()
{
	
}

int CHallServer::ProcessOnTimerOut()
{
	Options::instance()->ProcessHallCore(this);
	return 0;
}

void CHallServer::StartCheckCoreTimer()
{
	StartTimer(10*1000);
}

void CHallServer::StopCheckCoreTimer()
{
	StopTimer();
}



