#include <stdio.h>
#include "ICC_Timer_Handler.h"
#include "CCStreamDecoder.h"
#include "CCSocketHandler.h"
#include "CCSocketServer.h"
#include "CCReactor.h"
#include "ClientHandler.h"
#include "Packet.h"
#include <signal.h>
#include "Options.h"


#include "clib_log.h"

clib_log	*g_pDebugLog = NULL;
clib_log	*g_pErrorLog = NULL;


void registerSignal()
{
	signal(SIGHUP, SIG_IGN);
    signal(SIGPIPE, SIG_IGN);
    signal(SIGTTOU, SIG_IGN);
    signal(SIGTTIN, SIG_IGN);
    signal(SIGCHLD, SIG_IGN);
} 

int readSysCfg(int argc, char *argv[])
{
    if (Options::instance()->parse_args(argc, argv) != 0)
        return -1;
	if (Options::instance()->read_conf("../conf/config.ini") != 0)
        return -2;
	
	Options::instance()->printConf();
	init_log(Options::instance()->szLogName, Options::instance()->strLogDir.c_str(), Options::instance()->nNum, Options::instance()->nSize);
	set_log_level(Options::instance()->nLogLevel);

    return 0;
}

int InitBackServer()
{
	if( Options::instance()->InitMeCached() != 0)
		return -1;

	if( Options::instance()->InitBackServer("../conf/config.ini") != 0)
		return -2;

	return 0;


}

void InitLog(const char *szPrefixName)
{
	char szDebugLogFile[256] = {0};
	snprintf(szDebugLogFile, sizeof(szDebugLogFile), "%s.debug.%u", szPrefixName, getpid());
	g_pDebugLog = new clib_log();
    g_pDebugLog->set_file(szDebugLogFile);
    g_pDebugLog->set_level(5);
    g_pDebugLog->set_maxfile(5);
    g_pDebugLog->set_maxsize(10240000);
    g_pDebugLog->set_timeformat(CLIB_LOG_TFORMAT_0);


	char szErrorLogFile[256] = {0};
	snprintf(szErrorLogFile, sizeof(szErrorLogFile), "%s.error.%u", szPrefixName, getpid());
	g_pErrorLog = new clib_log();
    g_pErrorLog->set_file(szErrorLogFile);
    g_pErrorLog->set_level(5);
    g_pErrorLog->set_maxfile(5);
    g_pErrorLog->set_maxsize(10240000);
    g_pErrorLog->set_timeformat(CLIB_LOG_TFORMAT_0);
}


int main(int argc, char *argv[])
{
	CCReactor::Instance()->Init();

	srand((unsigned int)time(0));
	registerSignal();

	if(readSysCfg(argc,argv) < 0)
	{
		return -1;
	}

	InitLog(argv[0]);
	
/**
*	������������SocketServerģ���࣬����һ������ļ���server����
*   ��ģ�����Ϊ���ǵڶ���������ɵ�SocketHandler��
**/
	SocketServer<ClientHandler> example_server("0.0.0.0", Options::instance()->listen_port);
	
/**
*	���Ĳ��� ע��example_server����Ӧ��CCReactorʵ����
**/
	if(CCReactor::Instance()->RegistServer(&example_server) == -1)
	{
		log_error("RegistServer fail");

		return -1;
	}
	if( InitBackServer() < 0)
	{
		log_error("InitBackServer fail");
		return -1;

	}
	log_boot("Server have been started, listen port:%d...",Options::instance()->listen_port);
	
/**
*	���岽�� ������Ӧ���¼�ѭ��
**/
	CCReactor::Instance()->RunEventLoop();
	
	return 0;
}
