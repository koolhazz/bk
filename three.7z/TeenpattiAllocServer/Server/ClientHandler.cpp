#include "ClientHandler.h"
#include "Global.h"
#include "GameCmd.h"
#include "Options.h"
using namespace std;

#include "clib_log.h"
extern clib_log *g_pDebugLog;
extern clib_log *g_pErrorLog;

static string ToLower(const string & str) {
	if(str.length() == 0)
		return "";

	char buf[512] = {0};
	snprintf(buf, sizeof(buf), "%s", str.c_str());
	int len = strlen(buf);
	for(int i=0; i<len; ++i)
	{
		if(buf[i] >= 'A' && buf[i] <= 'Z')
			buf[i] += ('a'-'A');
	}

	return string(buf);
}


void GetTime(string& strTm)
{
	time_t now = time(NULL);
	struct tm tm;
	localtime_r(&now, &tm);
	char szTm[100] = {0};
	snprintf(szTm, sizeof(szTm), "[%04d-%02d-%02d %02d:%02d:%02d]", tm.tm_year+1900, tm.tm_mon+1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
	strTm = szTm;
}

static int split_str(const char* ps_str , char* ps_sp , vector<std::string> &v_ret)
{    
	char* ps_temp;    
	char* p;    
	int i_len = (int)strlen(ps_str);    
	std::string st_str;    
	ps_temp = new char[i_len+2];    
	snprintf(ps_temp , i_len+1 , "%s" , ps_str);    
	char *last = NULL;    
	p = strtok_r(ps_temp , ps_sp , &last);    
	if(NULL == p)
	{        
		delete ps_temp;        
		return 0;    
	}    
	st_str = (std::string)p;    
	v_ret.push_back(st_str);    
	while( NULL != ( p=strtok_r(NULL , ps_sp , &last) ) )
	{        
		st_str = (std::string)p;        
		v_ret.push_back(st_str);    
	}    
	delete ps_temp;    
	return 0;
}


ClientHandler::ClientHandler()
{
	m_pHallServer = NULL;
	m_pLogicServer = NULL;


}

ClientHandler::~ClientHandler()
{
	this->_decode = NULL;

}

int ClientHandler::OnClose()
{
	DebugMsg("ip[%s] port[%d] fd[%d] close", m_addrRemote.c_str(), m_nPort, netfd);
	if(this->m_pLogicServer != NULL)
	{

		ProcessLogicClose(m_pLogicServer);
		m_pLogicServer = NULL;	
	}
	else if( this->m_pHallServer != NULL)
	{

		ProcessHallClose(m_pHallServer);
		m_pHallServer = NULL;	
	}
	return 0;

}

int ClientHandler::OnConnected(void)
{
	GetRemoteAddr();
	DebugMsg("ip[%s] port[%d] fd[%d] connect", m_addrRemote.c_str(), m_nPort, netfd);
	return 0;

}

void ClientHandler::GetRemoteAddr(void)
{
	struct in_addr sin_addr;
	sin_addr.s_addr = this->_ip;
	char * addr = inet_ntoa(sin_addr);
	m_nPort = this->_port;
	
	if(addr)
		m_addrRemote = string(addr);
	else
		m_addrRemote = "NULL";
}


int ClientHandler::ProcessHallClose(CHallServer* pHallServer)//´¦ÀíÄ³¸ö´óÌü¶Ï¿ªÁ¬½Ó
{
	if(pHallServer == NULL)
		return 0;
	//Æô¶¯Ò»¸ö¶¨Ê±Æ÷È¥¼ì²âHallServerÓÐÃ»ÓÐ¹Ò
	pHallServer->m_pSocketHandler = NULL;//ÖÃÁ´½ÓÎª¿Õ
	pHallServer->StartCheckCoreTimer();
	return 0;
}

int ClientHandler::ProcessLogicClose(CLogicServer *pLogicServer)
{
	if(pLogicServer == NULL)
		return 0;
	pLogicServer->m_pSocketHandler = NULL;//ÖÃÁ´½ÓÎª¿Õ
	//Æô¶¯¶¨Ê±Æ÷È¥¼ì²âGameServerÓÐÃ»ÓÐ¹Ò
	pLogicServer->StartCheckCoreTimer();
	return 0;
}



int ClientHandler::OnPacketComplete(const char * data,int len)
{
	pPacket.Copy(data,len);
	//*****´¦Àí°ü****/
	return ProcessPacket(&pPacket);

}

int ClientHandler::ProcessPacket(InputPacket * pPacket)
{
	short nCmd = pPacket->GetCmdType();
	DebugMsg("CMD[%x]", nCmd);
	switch(nCmd)
	{
	case CLIENT_PACKET:
	case CLIENT_PACKET2:
		ProcessClientPacketReady(pPacket);
		break;		
	case SYS_REPORT_SERVER_DATA:
		ProcessReportServerData(pPacket);
		break;
	case SYS_UPDATE_ROOM_USER_COUNT:
		ProcessUpdateRoomUserCount(pPacket);
		break;
	case SYS_REPORT_SERVER_PORTIP:
		ProcessSendServerPortIp(pPacket);
		break;
	case CMD_SET_SERVER_RETIRED:
		ProcessSetServerRetired(pPacket);
		break;
	case CLIENT_CLOSE_PACKET:
	case SYS_USER_LEAVE_ROOM:
	case SYS_USER_ENTER_ROOM:
	case SYS_USER_STAND_ROOM:
	case SYS_STAND_LEAVE_ROOM:
		ProcessTransPacket(pPacket);
		break;
	case SYS_CTRL_GET_ALL_TABLES:
		ProcessSysGetTablelistBySvid(pPacket);
		break;
	default:
		g_pErrorLog->logMsg("%s||Invalid cmd:[%d]", __FUNCTION__,nCmd);
		break;
	}
	return 0;

}


void ClientHandler::ProcessTransPacket(InputPacket * pPacket)
{
	int uid = pPacket->ReadInt();
	ProcessTransferPacket(uid, pPacket);
}

int ClientHandler::ProcessSysGetTablelistBySvid(InputPacket * pPacket)
{
	
	string str = pPacket->ReadString();
	if(str != SYS_CTRL_KEY)
	{
		DebugMsg("[check Code error %s]", str.c_str());
		return 0;
	}
	//tablelistÓÐ¿ÉÄÜ´æÔÚ´íÎótidµÄÇé¿ö,´íÎóµÄtid·ÅÇ°Ãæ
	short gsSvid=pPacket->ReadShort();
	CLogicServer *gsServer=Options::instance()->GetLogicServer(gsSvid);
	NETOutputPacket reqPacket;
	if(NULL == gsServer )
	{
		reqPacket.Begin(SYS_CTRL_GET_ALL_TABLES);
		reqPacket.WriteInt(0);
		reqPacket.WriteInt(0);
		reqPacket.WriteInt(0);
		reqPacket.End();	
		DebugMsg("Send size[%d]", reqPacket.packet_size());
		if(-1 == Send(&reqPacket) )
		{
			DebugMsg("Send -1");	
		}
		return 0;
	}
	int rightTidCount=0;
	int errTidCount=0;
	const map<int, CGameTable*> &tableList = gsServer->m_TableList;
	map<int, CGameTable*>::const_iterator rightBegin=tableList.begin(); //¼ÇÂ¼ÕýÈ·tidµÄbeginÎ»ÖÃ
	map<int, CGameTable*>::const_iterator rightEnd=tableList.end();		//¼ÇÂ¼ÕýÈ·tidµÄendÎ»ÖÃ
	map<int, CGameTable*>::const_iterator preRight=tableList.end();		//rightEndµÄÇ°Ò»¸öÎ»ÖÃ
	--preRight;
	for(;rightBegin!=tableList.end() && (rightBegin->second->m_nTid >> 16) != gsSvid ;++rightBegin,++errTidCount);
	for(;rightEnd!=tableList.begin() && (preRight->second->m_nTid >> 16) != gsSvid ;rightEnd=preRight--,++errTidCount);

	rightTidCount=tableList.size() - errTidCount;
	
	reqPacket.Begin(SYS_CTRL_GET_ALL_TABLES);
	reqPacket.WriteInt(gsServer->m_nUserCount); //µ±Ç°gameServerµÄÈËÊý
	
	reqPacket.WriteInt(errTidCount);
	map<int, CGameTable*>::const_iterator cit;
	//1)¼ÇÂ¼´íÎótid Ê¹ÓÃintÐÍ
	for(cit=tableList.begin();cit!=rightBegin;++cit)
	{
		reqPacket.WriteInt(cit->first);
		reqPacket.WriteByte(cit->second->m_nUserCount & 0xFF);
	}
	for(cit=rightEnd;cit!=tableList.end();++cit)
	{
		reqPacket.WriteInt(cit->first);
		reqPacket.WriteByte(cit->second->m_nUserCount & 0xFF);
	}
	//2)¼ÇÂ¼ÕýÈ·tid,Ê¹ÓÃshort±£´æºó16Î»¼´¿É
	reqPacket.WriteInt(rightTidCount);
	for(cit=rightBegin;cit!=rightEnd;++cit)
	{
		reqPacket.WriteShort(cit->first & 0xFFFF);
		reqPacket.WriteByte(cit->second->m_nUserCount & 0xFF);
	}
	reqPacket.End();	
	Send(&reqPacket);
	DebugMsg("Tid Send size[%d]", reqPacket.packet_size());
	return 0;

}

int ClientHandler::CheckPacketComplete(const char * pData,const int & nLen)
{
	if( NULL == pData)
	{
		return 0;

	}

	int nHeadLen = sizeof(struct TPkgHeader);
	if(nLen < nHeadLen)
	{
		g_pErrorLog->logMsg("%s||Invalid Packet nLen[%d] HeadLen[%d]", __FUNCTION__, nLen, nHeadLen);
		return 0;
	}

	TPkgHeader *pHeader = (struct TPkgHeader*)pData;
	if(pHeader->flag[0]!='B' || pHeader->flag[1]!='Y')
	{
		g_pErrorLog->logMsg("%s||Invalid Packet", __FUNCTION__);
		return 0;

	}
	int pkglen = sizeof(short) + ntohs(pHeader->length);	//×ª»»³É´ó¶Ë
	if(pkglen<0 || pkglen>8*1024)
	{
		g_pErrorLog->logMsg("%s||Invalid packet, pkglen:[%d]", __FUNCTION__, pkglen);
		return 0;
	}
//	g_pDebugLog->logMsg("%s||Len[%d] pkgLen[%d]", __FUNCTION__, nLen, pkglen);
	if(nLen != pkglen)
	{
		g_pErrorLog->logMsg("%s||Len[%d] pkgLen[%d]", __FUNCTION__, nLen, pkglen);
		return 0;
	}
	return 1;
	
}

int ClientHandler::ProcessClientPacketReady(InputPacket * pPacket)
{
	short nCmd = pPacket->GetCmdType();
	char szTemp[10240];
	int uid, svid, nLen;
	int appIp = 0;	
	short api;

	g_pErrorLog->logMsg(" ProcessClientPacketReady Cmd 0x%x",nCmd);

	if(nCmd == CLIENT_PACKET)
	{
		uid  = pPacket->ReadInt();
				//ÓÃ»§ id
		svid = pPacket->ReadInt();				//´óÌü id
		g_pErrorLog->logMsg("uid[%d],svid[%d]",uid,svid);
		nLen = pPacket->ReadBinary(szTemp, sizeof(szTemp));
	}
	else if(nCmd == CLIENT_PACKET2)
	{
		uid  = pPacket->ReadInt();
		svid = pPacket->ReadInt();				//´óÌü id	
		appIp = pPacket->ReadInt();
		api = pPacket->ReadShort();
		nLen = pPacket->ReadBinary(szTemp, sizeof(szTemp));
		g_pErrorLog->logMsg("uid[%d],svid[%d],appIp[%d]api[%d]",uid,svid,appIp,api);
	}
	else
	{
		g_pErrorLog->logMsg("%s||Unknow Packet Cmd",__FUNCTION__);
		return 0;
	}

	if( nLen < 0)
	{
		g_pErrorLog->logMsg("%s||pPacket->ReadBinary error, nLen<0",__FUNCTION__);
		return 0;

	}

	if( !CheckPacketComplete(szTemp, nLen))
	{
		g_pErrorLog->logMsg("CheckPacketComplete error");
		return 0;
	}
	
	InputPacket tempPacket;
	if( !tempPacket.Copy(szTemp, nLen))
	{
		g_pErrorLog->logMsg("%s||tempPacket.Copy error",__FUNCTION__);

		return 0;
	}
	DebugMsg("UID[%d] SVID[%d]", uid, svid);
	THallServerList::iterator iter = Options::instance()->HallServerList.find(svid);
	if( iter == Options::instance()->HallServerList.end() )
	{
		CHallServer *pHallServer = new CHallServer(svid, this);
		if( NULL == pHallServer)
		{
			g_pErrorLog->logMsg("pHallServer error");
			return 0;

		}
		Options::instance()->HallServerList[svid] = pHallServer;

		this->m_pHallServer = pHallServer;
	}
	else
	{
		CHallServer* pHallServer = iter->second;
		if( NULL != pHallServer)
		{
			if( pHallServer->m_pSocketHandler != NULL)
			{
				pHallServer->m_pSocketHandler->m_pHallServer = NULL;	

			}
			pHallServer->m_pSocketHandler = this;
			this->m_pHallServer = pHallServer;
			pHallServer->StopCheckCoreTimer();

		}

	}
	short cmd = tempPacket.GetCmdType();
	DebugMsg("CMD[%x]",cmd);
	g_pErrorLog->logMsg("%s||CMD [0x%x]",__FUNCTION__,cmd);
	if(CMD_GET_NEW_ROOM 					== cmd ||
	   CMD_REQUIRE_IP_PORT 					== cmd ||
	   CLIENT_CMD_LIST_ROOM 				== cmd || 
	   CLIENT_CMD_ENTER_ROOM 				== cmd)
	{

		ProcessClientPacket(uid,svid,appIp,api,&tempPacket);
	}
	else
	{
		//转发二级包
		ProcessTransferPacket(uid, pPacket);
	}
	return 0;
}


void  ClientHandler::UpdateTableUserCountToLogic(int nTid, int nTableUserCount, BYTE nOnLooker, CLogicServer * pLogicServer, int nServerId,int nLevel, string strtabname, int nRequireChip, int Basechip)
{
	g_pDebugLog->logMsg("------------------ ClientHandler::UpdateTableUserCountToLogic begin -------------");
	CGameTable *pTable = pLogicServer->GetTable(nTid);
	if(pTable != NULL)
	{
		if(pTable->m_nUserCount != nTableUserCount)//如果当前桌子人数和上报人数不同，那就更新以usercount和键值的列表
		{
			TCountTableList::iterator iterCount = Options::instance()->CountTableList.find(pTable->m_nUserCount);
			if(iterCount != Options::instance()->CountTableList.end())
			{
				TableList& tableMap = iterCount->second;
				TableList::iterator iterTable = tableMap.find(nTid);
				if(iterTable != tableMap.end())
				{
					tableMap.erase(iterTable);
				}
			}
		
			TCountTableList::iterator iterNewCount = Options::instance()->CountTableList.find(nTableUserCount);
			if(iterNewCount != Options::instance()->CountTableList.end())
			{
				TableList& tableMap = iterNewCount->second;
				tableMap[nTid] = pTable;
			}
			else
			{
				TableList& tableMap = Options::instance()->CountTableList[nTableUserCount];
				tableMap[nTid] = pTable;
			}
			pTable->m_nUserCount = nTableUserCount;
			pTable->m_byOnLooker = nOnLooker;
			pTable->m_strRoomName = strtabname;
			pTable->m_nRequire = nRequireChip;
			pTable->m_nBaseChip = Basechip;
		}
		pTable->m_byOnLooker = nOnLooker;
		
	}
	else
	{
		//TableInfo::iterator iter = Options::instance()->m_TableInfo.find(nLevel);
		//TABLE tableinfo;

		//if(iter != Options::instance()->m_TableInfo.end())
		//{
		//	tableinfo = iter->second;
		//}

		//g_pDebugLog->logMsg("tableinfo.strName[%s], tableinfo.nBaseChip[%d], tableinfo.nRequire[%d]",tableinfo.strName,tableinfo.nBaseChip, tableinfo.nRequire);

		//pTable = new CGameTable(nTid, nServerId, nLevel, tableinfo.strName, tableinfo.nBaseChip, tableinfo.nRequire);
		pTable = new CGameTable(nTid, nServerId, nLevel);
		if(pTable != NULL)
		{
			pLogicServer->m_TableList[nTid] = pTable;
			pLogicServer->m_nTableCount++;
			TCountTableList::iterator iterCount = Options::instance()->CountTableList.find(nTableUserCount);
			if(iterCount != Options::instance()->CountTableList.end())
			{
				TableList& tableMap = iterCount->second;
				tableMap[nTid] = pTable;
			}
			else
			{
				TableList& tableMap = Options::instance()->CountTableList[nTableUserCount];
				tableMap[nTid] = pTable;
			}
			pTable->m_nUserCount = nTableUserCount;
			pTable->m_byOnLooker = nOnLooker;
			pTable->m_strRoomName = strtabname;
			pTable->m_nRequire = nRequireChip;
			pTable->m_nBaseChip = Basechip;
		}
	}
}


int ClientHandler::ProcessReportServerData(InputPacket * pPacket)
{
	short serverId 	= pPacket->ReadShort();
	short level 	= pPacket->ReadShort();
	int userCount 	= pPacket->ReadInt();
	int tableCount	= pPacket->ReadInt();
	string tablename = pPacket->ReadString();
	int requirechip = pPacket->ReadInt();
	int basechip = pPacket->ReadInt();

	g_pErrorLog->logMsg("instance level %d", Options::instance()->server_level);

	g_pErrorLog->logMsg("%s||serverId:[%hd],level:[%hd],userCount:[%d],tableCount:[%d],tablename[%s],requirechip:[%d],basechip:[%d]",__FUNCTION__,serverId, level, userCount, tableCount,tablename.c_str(),requirechip,basechip);
	if(level != Options::instance()->server_level)
	{
		g_pErrorLog->logMsg("%s||server level error, serverId:[%hd], level:[%hd], serverLv:[%hd]", __FUNCTION__,serverId, level, Options::instance()->server_level);
		return 0;
	}

	CLogicServer *pLogicServer = Options::instance()->GetLogicServer(serverId);
	if(pLogicServer != NULL)
	{
		if(pLogicServer->m_pSocketHandler != NULL)
		{
			pLogicServer->m_pSocketHandler->m_pLogicServer = NULL;
		}
		
		pLogicServer->m_nLevel 			= level;
		pLogicServer->m_nUserCount 		= userCount;
		pLogicServer->m_nTableCount 	= tableCount;
		pLogicServer->m_pSocketHandler 	= this;
		this->m_pLogicServer 			= pLogicServer;
		pLogicServer->StopCheckCoreTimer();
	}
	else
	{
		pLogicServer = new CLogicServer(serverId, userCount, tableCount, level, this);
		if(pLogicServer != NULL)
		{
			Options::instance()->ServerList[serverId] = pLogicServer;
			m_pLogicServer = pLogicServer;
		}
	}
	if(pLogicServer != NULL)
	{
		pLogicServer->m_nRetire = 0;
		for(int i=0; i<tableCount; i++)
		{
			int 	tid 			= pPacket->ReadInt();
			short 	tableUserCount 	= pPacket->ReadShort();
			BYTE    onlooker 		= pPacket->ReadByte();
			g_pErrorLog->logMsg("ProcessReportServerData||serverId:[%d],level:[%d],tid:[%d],tableUserCount:[%d]", serverId, level, tid, tableUserCount);

			if((tid>>16) == serverId)//½â¾öserverÉÏ±¨´íÎó×À×ÓÐÅÏ¢
			{
				UpdateTableUserCountToLogic(tid, tableUserCount, onlooker, pLogicServer,serverId,level, tablename, requirechip, basechip);
			}
		}
	}
	return 0;
}

int ClientHandler::ProcessUpdateRoomUserCount(InputPacket * pPacket)
{
	if(m_pLogicServer == NULL)
		return 0;
	short 	serverId 		= pPacket->ReadShort();
	int 	tid 			= pPacket->ReadInt();
	short 	level 			= pPacket->ReadShort();
	short 	tableUserCount 	= pPacket->ReadShort();
	int 	userCount 		= pPacket->ReadInt();
	BYTE    onlooker 		= pPacket->ReadByte();
	string  tablename 		= pPacket->ReadString();
	int 	requirechip 	= pPacket->ReadInt();
	int 	basechip 		= pPacket->ReadInt();

	if(level != Options::instance()->server_level)
	{
		g_pErrorLog->logMsg("%s||server level error, serverId:[%hd], level:[%hd], serverLv:[%hd], tableUserCount:[%hd], userCount:[%hd], onlooker:[%hd], tablename:[%s],requirechip:[%d], basechip:[%d]",
		 __FUNCTION__,serverId, level, Options::instance()->server_level, tableUserCount,userCount,onlooker,tablename.c_str(),requirechip, basechip);
		return 0;
	}

	if(userCount <= Options::instance()->nMaxTableUserCount)
	{
		g_pDebugLog->logMsg("%s||serverId:[%d],tid:[%d],level:[%d],tableUserCount:[%d],userCount:[%d]", __FUNCTION__,serverId, tid, level, tableUserCount, userCount);
	}
	
	CLogicServer *pLogicServer = Options::instance()->GetLogicServer(serverId);
	if(pLogicServer != NULL)
	{
		pLogicServer->m_nUserCount = userCount;
		if((tid>>16) == serverId)//Âú×ãserverIdÓëtidÆ¥Åä
		{
			UpdateTableUserCountToLogic(tid, tableUserCount, onlooker, pLogicServer, serverId, level, tablename, requirechip, basechip);
			//pLogicServer->m_nTableCount++;
		}
	}
	return 0;

}

int ClientHandler::ProcessSendServerPortIp(InputPacket * pPacket)
{
	if(m_pLogicServer == NULL)
		return 0;
	string 	ip 			= pPacket->ReadString();
	int 	port 		= pPacket->ReadInt();
	short 	serverId 	= pPacket->ReadShort();
	CLogicServer *pLogicServer = Options::instance()->GetLogicServer(serverId);
	if(pLogicServer != NULL)
	{
		pLogicServer->m_strIp = ip;
		pLogicServer->m_nPort = port;
		//Ð´Èëmc
		char szKey[10]={0};
		snprintf(szKey, sizeof(szKey), "%d", serverId);
		char szValue[100]={0};
		snprintf(szValue, sizeof(szValue), "%d,%s,%d", pLogicServer->m_nLevel, ip.c_str(), port);
		g_pErrorLog->logMsg("key:[%s], value:[%s]", szKey,szValue);
		if(!Options::instance()->m_MemCacheClient.SetRecord(szKey, szValue, strlen(szValue)))
		{
			g_pErrorLog->logMsg("ProcessSendServerPortIp||SetRecord error, serverId:[%d]", serverId);
		}
		g_pDebugLog->logMsg("ProcessSendServerPortIp||serverId:[%d],ip:[%s],port:[%d]", serverId, ip.c_str(), port);
	}
	return 0;

}

int ClientHandler::ProcessSetServerRetired(InputPacket * pPacket)
{
	g_pErrorLog->logMsg("-------------- ClientHandler::ProcessSetServerRetired begin ------------");
	short flag 			= pPacket->ReadShort();
	short serverIdCount = pPacket->ReadShort();
	g_pDebugLog->logMsg("flagflag:[%d],serverIdCount:[%d]", flag, serverIdCount);
	for(int i=0; i<serverIdCount; i++)
	{
		short serverId = pPacket->ReadShort();
		CLogicServer *pServer = Options::instance()->GetLogicServer(serverId);
		if(pServer != NULL)
		{
			pServer->m_nRetire = flag;
			g_pDebugLog->logMsg("ProcessSetServerRetired||flag:[%d],serverId:[%d]", flag, serverId);
			if(pServer->m_pSocketHandler != NULL)
			{
				//Ôö¼ÓÍ¨ÖªserverÍËÐÝ
				NETOutputPacket reqPacket;
				reqPacket.Begin(CMD_SET_SERVER_RETIRED);
				reqPacket.WriteShort(flag);
				reqPacket.End();
				pServer->m_pSocketHandler->Send(&reqPacket);
			}
		}
	}
	g_pErrorLog->logMsg("-------------- ClientHandler::ProcessSetServerRetired end ------------");
	return 0;	

}

int ClientHandler::ProcessClientPacket(int uid,int svid, int appIp,short api,InputPacket * pPacket)
{
	g_pErrorLog->logMsg("----------------- ClientHandler::ProcessClientPacket begin --------------");
	g_pErrorLog->logMsg("uid:[%d],svid:[%d],api:[%d]",uid,svid,api);
	if( pPacket->CrevasseBuffer() <0)
	{
		g_pErrorLog->logMsg("%s||CrevasseBuffer error", __FUNCTION__);	
		return -1;

	}
	int cmd = pPacket->GetCmdType();
	DebugMsg("CMD[%x]", cmd);
	g_pErrorLog->logMsg("%s||CMD [0x%x]",__FUNCTION__,cmd);
	switch(cmd)
	{
	case CMD_GET_NEW_ROOM:
		ProcessGetNewRoom(uid,svid,appIp,pPacket);
		break;
	case CMD_REQUIRE_IP_PORT:
		ProcessRequireIpAndPort(uid, svid, pPacket);
		break;
	case CLIENT_CMD_LIST_ROOM:
		ProcessListRoom(uid, svid, pPacket);
		break;
	case CLIENT_CMD_ENTER_ROOM:
		ProcessUserEnterRoom(uid, svid, pPacket);
		break;
	default:
		{
			g_pErrorLog->logMsg("%s||Invalid cmd:[%d]", __FUNCTION__,cmd);

		}
		break;
	}
	return 0;
}



int ClientHandler::ProcessTransferPacket(int uid, InputPacket * pPacket)
{
	OutputPacket transPacket;
	transPacket.Copy(pPacket->packet_buf(), pPacket->packet_size());
	int userServerId = uid%(int)Options::instance()->UserServerList.size();
	g_pErrorLog->logMsg("userServerId %d",userServerId);
	CBackServer* pUserServer = Options::instance()->GetUserServer(userServerId);
	if(pUserServer != NULL)
	{
		g_pErrorLog->logMsg("send ok ");
		pUserServer->Send(&transPacket);
	}
	else
	{
		g_pErrorLog->logMsg("pUserServer NULL");
	}
	
	return 0;
}


int ClientHandler::SendClientPacket(int uid,int svid,OutputPacket * pPacket)
{
	pPacket->EncryptBuffer();

	NETOutputPacket resPacket;
	resPacket.Begin(CLIENT_PACKET);
	resPacket.WriteInt(uid);
	resPacket.WriteInt(svid);
	resPacket.WriteBinary(pPacket->packet_buf(), pPacket->packet_size());
	resPacket.End();
	Send(&resPacket);
	return 0;
}

int ClientHandler::GetRoomList(TableList &list)
{
	int index = 0;
	TServerList::iterator iterServer = Options::instance()->ServerList.begin();

	for(; iterServer!= Options::instance()->ServerList.end(); iterServer++)
	{
		CLogicServer *pServer = iterServer->second;
		if(pServer!=NULL && pServer->m_nRetire==0)
		{
			TableList::iterator iterTable = pServer->m_TableList.begin();
			for(; iterTable!=pServer->m_TableList.end(); iterTable++)
			{
				CGameTable * pTable = iterTable->second;
				if(pTable != NULL)
				{					
					if(pTable->m_nUserCount>=0 && pTable->m_nUserCount <= Options::instance()->nMaxSitTableUserCount)
					{
						list[pTable->m_nTid] = pTable;		
						index++;
						if(index >= Options::instance()->nMaxListPriRoomCount)
							break;
					}
				}
			}
		}

		if(index >= Options::instance()->nMaxListPriRoomCount )
			break;

	}
	return 0;

}

int ClientHandler::ProcessGetNewRoom(int uid, int svid, int appIp, InputPacket * pPacket)
{
	short level 	= pPacket->ReadShort();
	short serverId 	= pPacket->ReadShort();

	CLogicServer *pServer = Options::instance()->GetLogicServer(serverId);
	int tid = 0;
	if(pServer != NULL)
	{
		if(pServer->m_nRetire == 0)
		{
			CGameTable *pTable = NULL;
			pTable = Options::instance()->GetGameRoom(pServer, uid, level);
			if(pTable != NULL)
			{
				tid = pTable->m_nTid;
				pTable->m_nUserCount++;
			}
		}

		NETOutputPacket resPacket;
		resPacket.Begin(CMD_GET_NEW_ROOM);
		resPacket.WriteInt(tid);
		resPacket.WriteString(pServer->m_strIp.c_str());
		resPacket.WriteInt(pServer->m_nPort);
		resPacket.End();
		SendClientPacket(uid, svid, &resPacket);
	}
	return 0;
}



int ClientHandler::ProcessRequireIpAndPort(int uid,int svid,InputPacket * pPacket)
{
	short serverId			= pPacket->ReadShort();
	CLogicServer *pServer 	= Options::instance()->GetLogicServer(serverId);
	if(pServer != NULL)
	{
		NETOutputPacket resPacket;
		resPacket.Begin(CMD_REQUIRE_IP_PORT);
		resPacket.WriteString(pServer->m_strIp.c_str());
		resPacket.WriteInt(pServer->m_nPort);
		resPacket.WriteInt(pServer->m_nLevel);
		resPacket.End();
		SendClientPacket(uid, svid, &resPacket);

		g_pDebugLog->logMsg("ProcessRequireIpAndPort||uid:[%d],serverId:[%hd],ip:[%s],port:[%d]", uid, serverId, pServer->m_strIp.c_str(), pServer->m_nPort);
	}
	else
	{
		NETOutputPacket resPacket;
		resPacket.Begin(CMD_REQUIRE_IP_PORT);
		resPacket.WriteString("");
		resPacket.WriteInt(0);
		resPacket.End();
		SendClientPacket(uid, svid, &resPacket);
	}
	return 0;

}

int ClientHandler::ProcessListRoom(int uid,int svid,NETInputPacket * pPacket)
{
	g_pErrorLog->logMsg("------------- ClientHandler::ProcessListRoom begin ---------------");

	int nLevel = pPacket->ReadInt();
	g_pErrorLog->logMsg("nLevel : [%d]",nLevel);
	g_pErrorLog->logMsg("Options::instance()->server_level : [%d]",Options::instance()->server_level);
	if(Options::instance()->server_level != nLevel)
	{
		g_pErrorLog->logMsg("Level error");
		return 0;
	}

	g_pErrorLog->logMsg("%s|| uid:[%d] ", __FUNCTION__,uid);

	(void)pPacket;
	TableList list;
	GetRoomList(list);

	//int nListCount = (int)list.size();

	//g_pErrorLog->logMsg("nListCount 1 [%d]",nListCount);

	//while( nListCount < 5 )
	//{
	//	g_pErrorLog->logMsg("CreatTable begin ------- 1 [%d]",nListCount);
	//	Options::instance()->CreatTable(svid, nLevel);
	//	nListCount ++ ;
	//}
	//g_pErrorLog->logMsg("nListCount 2 [%d]",nListCount);

	OutputPacket resPacket;
	resPacket.Begin(SERVER_CMD_LIST_ROOM);
	resPacket.WriteInt(nLevel);
	resPacket.WriteInt((int)list.size());

	g_pErrorLog->logMsg("table count [%d]",(int)list.size());

	TableList::iterator iterTable = list.begin();
	for(; iterTable!=list.end(); iterTable++)
	{
		CGameTable *pTable = iterTable->second;
		if(pTable != NULL)
		{
			resPacket.WriteInt(pTable->m_nTid);
			resPacket.WriteString(pTable->m_strRoomName.c_str());
			resPacket.WriteInt(pTable->m_nBaseChip);
			resPacket.WriteShort(pTable->m_nUserCount);
			resPacket.WriteInt(pTable->m_nRequire);
			resPacket.WriteByte(pTable->m_byOnLooker);
			g_pErrorLog->logMsg("table id [%d],m_nBaseChip[%d],m_nUserCount[%d],RoomName [%s],m_nRequire[%d],m_byOnLooker [%d]", 
				pTable->m_nTid,pTable->m_nBaseChip,pTable->m_nUserCount,pTable->m_strRoomName.c_str(),pTable->m_nRequire,pTable->m_byOnLooker);
		}
	}
	resPacket.End();
	SendClientPacket(uid, svid, &resPacket);
	g_pErrorLog->logMsg("------------- ClientHandler::ProcessListRoom end ---------------");
	return 0;	

}

int ClientHandler::ProcessUserEnterRoom(int uid,int svid,InputPacket * pPacket)
{
	g_pErrorLog->logMsg("---------------- ClientHandler::ProcessUserEnterRoom ------------ ");
	g_pErrorLog->logMsg("uid [%d], svid [%d]",uid, svid);

	int level = pPacket->ReadInt();
	int tid = pPacket->ReadInt();

	if(Options::instance()->server_level != level)
	{
		g_pErrorLog->logMsg("%s||level error, uid:[%d], level:[%hd]", __FUNCTION__,uid, Options::instance()->server_level);
		return 0;
	}

	g_pErrorLog->logMsg("level [%d], tid [%d]",level,tid);

	short serverId 	= (tid>>16);
	g_pErrorLog->logMsg("serverId [%d]",serverId);
	CLogicServer *pServer = Options::instance()->GetLogicServer(serverId);

	short errorCode = 0;

	if(pServer != NULL)
	{
		CGameTable *pTable = pServer->GetTable(tid);
		
		if(pTable != NULL)
		{
			if(pTable->m_nUserCount == Options::instance()->nMaxTableUserCount/*MAX_TABLE_USER_COUNT*/)
			{
				g_pErrorLog->logMsg("---------------- ClientHandler::ProcessUserEnterRoom end 1------------ ");
				errorCode = ERROR_MAX_USERCOUNT;
			}
		}
		else
		{
			g_pErrorLog->logMsg("---------------- ClientHandler::ProcessUserEnterRoom end 2 ------------ ");
			errorCode = ERROR_ROOM_NOT_EXIST;
		}
		g_pErrorLog->logMsg("errorCode [%d]",errorCode);
		if(errorCode)
		{
			g_pErrorLog->logMsg("---------------- ClientHandler::ProcessUserEnterRoom end 3 ------------ ");
			OutputPacket resPacket;
			resPacket.Begin(SERVER_CMD_ENTER_ROOM);
			resPacket.WriteShort(0);
			resPacket.WriteShort(errorCode);
			resPacket.End();
			SendClientPacket(uid, svid, &resPacket);
		}
		else
		{
			g_pErrorLog->logMsg("---------------- ClientHandler::ProcessUserEnterRoom end 4 ------------ ");
			string ip = "";
			int port = 0;
			OutputPacket resPacket;
			if(pServer->m_nRetire == 0)
			{
				ip 		= pServer->m_strIp;
				port 	= pServer->m_nPort;

				resPacket.Begin(SERVER_CMD_ENTER_ROOM);
				resPacket.WriteShort(1);
				resPacket.WriteString(ip.c_str());
				resPacket.WriteInt(port);
				resPacket.WriteInt(tid);//ÐÂÔötid×Ö¶Î

				g_pErrorLog->logMsg("ip[%s],port[%d],tid[%d]",ip.c_str(), port, tid);
				g_pErrorLog->logMsg("---------------- ClientHandler::ProcessUserEnterRoom end 5 ------------ ");
			}
			else
			{
				resPacket.Begin(SERVER_CMD_ENTER_ROOM_ERROR);
				g_pErrorLog->logMsg("---------------- ClientHandler::ProcessUserEnterRoom end 6 ------------ ");
			}
			
			
			resPacket.End();
			SendClientPacket(uid, svid, &resPacket);
		}
	}
	else
	{
		errorCode = ERROR_ROOM_NOT_EXIST;
		g_pErrorLog->logMsg("---------------- ClientHandler::ProcessUserEnterRoom end 7 ------------ ");
		OutputPacket resPacket;
		resPacket.Begin(SERVER_CMD_ENTER_ROOM_ERROR);
		resPacket.End();
		SendClientPacket(uid, svid, &resPacket);
	}
	return 0;	
}
