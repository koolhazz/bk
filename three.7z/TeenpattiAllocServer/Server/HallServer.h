#ifndef _HALLSERVER_H__
#define _HALLSERVER_H__

#include "ICC_Timer_Handler.h" 
#include "CCSocketHandler.h" 
#include "Options.h"

class ClientHandler;

class CHallServer:public CCTimer
{
public:
	CHallServer(int nServerId, ClientHandler *pHandler);
	virtual ~CHallServer();

public:
	virtual int ProcessOnTimerOut();
	void StartCheckCoreTimer();
	void StopCheckCoreTimer();

public:
	int m_nServerID;
	ClientHandler *m_pSocketHandler;
};



#endif


