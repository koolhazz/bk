#ifndef __GAME_TABLE_H
#define __GAME_TABLE_H
#include <string>
#include <map>
#include <set>
using std::string;
using std::map;
using std::set;

typedef unsigned char BYTE;

class CGameTable
{
public:
	CGameTable(int tid, short svid, short level);
	~CGameTable();
public:
	int		m_nTid;
	short	m_nServerId;
	short	m_nLevel;
	short	m_nUserCount;
	int		m_nOwnerUid;
	string	m_strRoomName;
	int		m_nBaseChip;
	BYTE    m_byOnLooker;
	int     m_nRequire;
};
#endif
