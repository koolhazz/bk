#include "GameTable.h"

CGameTable::CGameTable(int tid, short svid, short level)
{
	m_nTid = tid;
	m_nServerId = svid;
	m_nLevel = level;
	m_nUserCount = 0;
	m_nOwnerUid = 0;
	m_strRoomName = "";
	m_nBaseChip = 0;
	m_nRequire = 0;
	m_byOnLooker = 0;
}

CGameTable::~CGameTable()
{

}
