#include <sys/stat.h> 
#include <signal.h> 
#include "IniFile.h"
#include "Options.h"


#ifndef WIN32
#include <sys/time.h>
#include <sys/resource.h>
#include <unistd.h>
#include <getopt.h>

#endif

static bool More_ServerUserCount(const SERVERINFO &s1, const SERVERINFO &s2)
{
	return s1.userCount > s2.userCount;
}

static bool Less_ServerUserCount(const SERVERINFO &s1, const SERVERINFO &s2)
{
	return s1.userCount < s2.userCount;
}

static bool Less_TableUserCount(const TABLEINFO &t1, const TABLEINFO &t2)
{
	return t1.userCount > t2.userCount;
}



static int split_str(const char* ps_str , char* ps_sp , vector<std::string> &v_ret)
{    
	char* ps_temp;    
	char* p;    
	int i_len = (int)strlen(ps_str);    
	std::string st_str;    
	ps_temp = new char[i_len+2];    
	snprintf(ps_temp , i_len+1 , "%s" , ps_str);    
	char *last = NULL;    
	p = strtok_r(ps_temp , ps_sp , &last);    
	if(NULL == p)
	{        
		delete ps_temp;        
		return 0;    
	}    
	st_str = (std::string)p;    
	v_ret.push_back(st_str);    
	while( NULL != ( p=strtok_r(NULL , ps_sp , &last) ) )
	{        
		st_str = (std::string)p;        
		v_ret.push_back(st_str);    
	}    
	delete ps_temp;    
	return 0;
}



void daemonize()
{
#ifndef WIN32
	pid_t pid, sid;

	/* already a daemon */
	if ( getppid() == 1 ) return;

	/* Fork off the parent process */
	pid = fork();
	if (pid < 0) {
		exit(EXIT_FAILURE);
	}
	/* If we got a good PID, then we can exit the parent process. */
	if (pid > 0) {
		exit(EXIT_SUCCESS);
	}

	/* At this point we are executing as the child process */

	/* Change the file mode mask */
	umask(0);

	/* Create a new SID for the child process */
	sid = setsid();
	if (sid < 0) {
		exit(EXIT_FAILURE);
	}

	/* Redirect standard files to /dev/null */
	freopen( "/dev/null", "r", stdin);
	freopen( "/dev/null", "w", stdout);
	freopen( "/dev/null", "w", stderr);
#endif 
}  

Options::Options()
{
	listen_port = 0;
	server_id	= 0;
	server_level= 0;
	nMaxTableUserCount  = 0;
	nMaxSitTableUserCount = 5;
	nMaxServerUserCount = 0;
	nFillFlag = 0;
	nMaxListPriRoomCount = 100;
	UserServerList.clear();
	ServerList.clear();

	m_readMcFlag = 0;
	m_debugLogFlag = 0;
}

const char* const short_options = "p:s:l:u:m:f:vdh";  
struct option long_options[] = {  
     { "port",		1,   NULL,    'p'     },  
     { "sid",		1,   NULL,    's'     }, 
     { "level",		1,	 NULL,	  'l'	  },
     { "UserCount",	1,	 NULL,	  'u'	  },	//һ���������ɵ�����
     { "MaxCount",	1,	 NULL,	  'm'	  },	//һ��server������ɵ�����
     { "FillFlag",	0,	 NULL,	  'f'	  },	//�Ƿ�����һ��server�и�
     { "daemon",	0,   NULL,    'd'     },
	 { "version",   0,   NULL,    'v'     },
     { "help",		0,   NULL,    'h'     },  
     {      0,     0,     0,     0        },  
}; 

void printHelp()
{
        printf("-%s %-10s %-15s %s\n",                "p","--port","<port>","tcp port number to listen on");
        printf("-%s %-10s %-15s %s\n",                "s","--sid","<sid>","server id ");
		printf("-%s %-10s %-15s %s\n",                "l","--level","<level>","server level ");
		printf("-%s %-10s %-15s %s\n",                "u","--User","<User>","UserCount");
		printf("-%s %-10s %-15s %s\n",                "m","--MaxCount","<MaxCount>","Server Max Count ");
		printf("-%s %-10s %-15s %s\n",                "f","--FillFlag","<Fill>","Fill");
        printf("-%s %-10s %-15s %s\n",                "d","--daemonize","","run as a daemon");
		printf("-%s %-10s %-15s %s\n",                "v","--version","","print version info");
        printf("-%s %-10s %-15s %s\n",                "h","--help","","print this help and exit");
        printf("\n");
}

int Options::parse_args(int argc, char *argv[]) 
{
	if(argc==1)
	{
		 printHelp();
		 return -1;
	}

	int opt;
	while ((opt = getopt_long (argc, argv, short_options, long_options, NULL)) != -1)  
	{
		switch (opt) 
		{      
		case 'p':
			listen_port = atoi(optarg);
			break;
		case 's':
			server_id = atoi(optarg);
			break;
		case 'l':
			server_level = atoi(optarg);
			break;
		case 'u':
			nMaxTableUserCount = atoi(optarg);
			break;
		case 'm':
			nMaxServerUserCount = atoi(optarg);
			break;
		case 'f':
			nFillFlag = atoi(optarg);
			break;
		case 'd': 
			{
				signal(SIGINT,  SIG_IGN);
				signal(SIGTERM, SIG_IGN);
				daemonize();
			}
			break;
		case 'h':
			printHelp();
			return -1; 
		default:
			printHelp();
			printf("Parse error.\n");
			return -1;
		}
	}
   
   if(listen_port==0)
	{
	    printf("Please Input server_port: -p port\n");
		printHelp();
		return -1;
   }

	if(server_id==0)
	{
		printf("Please Input Hall ID: -s id\n");
        printHelp();
        return -1;
	}
	
	return 0;
}

int Options::read_conf(char file[256])
{
	IniFile iniFile(file);
	if(!iniFile.IsOpen())
	{ 
		printf("Open IniFile Error:[%s]\n",file);
		return -1;
	}
	strLogDir		= iniFile.ReadString("LOG", "LOGDIR", "./");
	nNum			= iniFile.ReadInt("LOG", "LOGNUM", 10);
	nSize			= iniFile.ReadInt("LOG", "LOGSIZE", 10 * 1024 * 1024);
	nLogLevel   	= iniFile.ReadInt("LOG", "LOGLEVEL", 0);
	strMcAddr		= iniFile.ReadString("MEMCACHED","SERVER_MC","0.0.0.0:0");
	
	snprintf(szLogName, sizeof(szLogName), "CCReactor.log.%d", getpid());

	return 0;
	
}

int Options::InitMeCached()
{
	string strAddr = strMcAddr;

	log_boot("strMcAddr [%s]", strMcAddr.c_str());

	if( !m_MemCacheClient.Init(strAddr.c_str()))
	{
		log_error("Init Mc[%s] Fail", strMcAddr.c_str());
		return -1;

	}
	log_boot("Init Mc[%s] Success", strMcAddr.c_str());

	return 0;
}

int Options::InitBackServer(char file [256])
{
	IniFile iniFile(file);
	if(!iniFile.IsOpen())
	{ 
		log_boot(" InitBackServer file error ");
		return -1;
	}
	int nServerCount = 0;
	nServerCount = iniFile.ReadInt("UserServer", "ServerCount", 0);
	log_boot("ServerCount = [%d]", nServerCount);
	char szKey[100] = {0};
	for(int i=0; i<nServerCount; i++)
	{
		memset(szKey, 0, sizeof(szKey));
		snprintf(szKey, sizeof(szKey), "UserServer_%d", i);
		string strTemp;
		strTemp = iniFile.ReadString("UserServer",szKey,"");
		vector<string> v;
		split_str(strTemp.c_str(), ":", v);
		CBackServer * pUserServer = new CBackServer("UserServer");
		if( pUserServer != NULL)
		{
			pUserServer->InitConnect(v[0].c_str(), atoi(v[1].c_str()));

		 	UserServerList[i] = pUserServer;
			log_boot("UserServer[%s]...",strTemp.c_str());
		}
	}

	return 0;	
}

int Options::ProcessLogicCore(CLogicServer * pLogicServer)
{
	if(pLogicServer == NULL)
		return 0;
	pLogicServer->StopCheckCoreTimer();
	//�����server�е�������Ϣ
	TableList::iterator iterTable = pLogicServer->m_TableList.begin();
	for(; iterTable!=pLogicServer->m_TableList.end(); iterTable++)
	{
		CGameTable *pTable = iterTable->second;
		if(pTable != NULL)
		{
			//���server�ң�Ϊ�˱��գ���ֹ����Ұָ�룬������ÿ��CountTableList������Ҳ���ȥ��ȥ������
			for(int i=0; i<= nMaxServerUserCount/*MAX_TABLE_USER_COUNT*/; i++)
			{
				TCountTableList::iterator iterCount = CountTableList.find(i);
				if(iterCount != CountTableList.end())
				{
					TableList& tableMap = iterCount->second;
					TableList::iterator iter = tableMap.find(pTable->m_nTid);
					if(iter != tableMap.end())
					{
						g_pDebugLog->logMsg("%s||ServerId[%d] Remove table, tid:[%d], userCount:[%d]", __FUNCTION__,pLogicServer->m_nServerId,pTable->m_nTid, i);
						tableMap.erase(iter);
					}
				}
			}
			delete pTable;
			pTable = NULL;
		}
	}

	pLogicServer->m_TableList.clear();
	
	//�����û�server���߼�server�Ͽ�������
	NETOutputPacket reqPacket;
	reqPacket.Begin(SYS_LOGIC_CORE);
	reqPacket.WriteShort(pLogicServer->m_nServerId);
	reqPacket.End();
	TUserServerList::iterator iter = UserServerList.begin();
	for(; iter!=UserServerList.end(); iter++)
	{
		CBackServer* pUserServer = iter->second;
		if(pUserServer != NULL)
		{
			pUserServer->Send(&reqPacket);
		}
	}
	
	TServerList::iterator iterServer = ServerList.find(pLogicServer->m_nServerId);
	if(iterServer != ServerList.end())
	{
		ServerList.erase(iterServer);
	}
	delete pLogicServer;
	pLogicServer = NULL;
	return 0;	
}

int Options::ProcessHallCore(CHallServer * pHallServer)
{
	if(pHallServer == NULL)
		return 0;
	pHallServer->StopCheckCoreTimer();

	NETOutputPacket reqPacket;
	reqPacket.Begin(SYS_HALL_CORE);
	reqPacket.WriteInt(pHallServer->m_nServerID);
	reqPacket.End();
	//�㲥������UserServer,����server����
	TUserServerList::iterator iter = UserServerList.begin();
	for(; iter != UserServerList.end(); iter++)
	{
		CBackServer* pUserServer = iter->second;
		if(pUserServer != NULL)
		{
			pUserServer->Send(&reqPacket);
		}
	}

	THallServerList::iterator iterHall = HallServerList.find(pHallServer->m_nServerID);
	if(iterHall != HallServerList.end())
	{
		HallServerList.erase(iterHall);
	}
	delete pHallServer;
	pHallServer = NULL;
	return 0;
}

CLogicServer* Options::GetLogicServer(short serverId)
{
	g_pDebugLog->logMsg("----------- Options::GetLogicServer begin ---------");
	CLogicServer *pServer = NULL;
	TServerList::iterator iterServer = ServerList.find(serverId);
	if(iterServer != ServerList.end())
	{
		g_pDebugLog->logMsg(" find server");
		pServer = iterServer->second;
	}
	return pServer;
}

CHallServer* Options::GetHallServer(short serverId)
{
	CHallServer* pServer = NULL;
	THallServerList::iterator 
iterServer = HallServerList.find(serverId);
	if( iterServer != HallServerList.end())
	{
		pServer = iterServer->second;
	}
	return pServer;
}

CGameTable* Options::GetGameRoom(int uid, short level)
{
	CGameTable *pTable = NULL;

	for( int i = 1; i<nMaxTableUserCount; i++ )
	{
		pTable = GetTable(i, uid, level);
		if(pTable != NULL)
		{
			return pTable;
		}
	}

	vector<SERVERINFO> vecServer;
	TServerList::iterator iterServer = ServerList.begin();
	for(; iterServer!= ServerList.end(); iterServer++)
	{
		CLogicServer *pLogicServer =  iterServer->second;
		if(pLogicServer != NULL)
		{
			if(pLogicServer->m_nRetire==0 && pLogicServer->m_nUserCount< nMaxServerUserCount)//����server�������޿���
			{
				SERVERINFO serverInfo;
				serverInfo.serverId = pLogicServer->m_nServerId;
				serverInfo.userCount = pLogicServer->m_nUserCount;
				vecServer.push_back(serverInfo);
			}
		}
		
	}
	
	if(vecServer.size() > 0)
	{
		std::sort(vecServer.begin(), vecServer.end(), Less_ServerUserCount);
		SERVERINFO &sInfo = vecServer[0];
		CLogicServer *pServer = GetLogicServer(sInfo.serverId);		
		if(pServer != NULL)
		{
			int sid = sInfo.serverId;

			//TableInfo::iterator iter = m_TableInfo.find(level);
			//TABLE tableinfo;

			//if(iter != m_TableInfo.end())
			//{
			//	tableinfo = iter->second;
			//}

			//g_pDebugLog->logMsg("tableinfo.strName[%s], tableinfo.nBaseChip[%d], tableinfo.nRequire[%d]",tableinfo.strName,tableinfo.nBaseChip, tableinfo.nRequire);

			int newTableId = (sid<<16) + pServer->m_nTableCount;
			//pTable = new CGameTable(newTableId, sInfo.serverId, pServer->m_nLevel, tableinfo.strName, tableinfo.nBaseChip, tableinfo.nRequire);
			pTable = new CGameTable(newTableId, sInfo.serverId, pServer->m_nLevel);
			if(pTable != NULL)
			{
				pServer->m_TableList[newTableId] = pTable;
				pServer->m_nTableCount++;
				pServer->m_nUserCount++;	
				TCountTableList::iterator iterCount = CountTableList.find(1);
				if(iterCount != CountTableList.end())
				{
					TableList& tableMap = iterCount->second;
					tableMap[newTableId] = pTable;
				}
				else
				{
					TableList& tableMap = CountTableList[1];
					tableMap[newTableId] = pTable;
				}
			}
		}
	}
	return pTable;	

}

CGameTable* Options::GetGameRoom(CLogicServer* pServer, int uid, short level)
{
	if(pServer == NULL)
	{
		return NULL;
	}
	CGameTable *pTable = NULL;
	vector<TABLEINFO> vecTable;
	TableList::iterator iterTable = pServer->m_TableList.begin();
	for(; iterTable!=pServer->m_TableList.end(); iterTable++)
	{
		CGameTable *pTempTable = iterTable->second;
		if(pTempTable != NULL)
		{
			if(pTempTable->m_nUserCount < nMaxTableUserCount)
			{
				TABLEINFO tableInfo;
				tableInfo.tid = pTempTable->m_nTid;
				tableInfo.userCount = pTempTable->m_nUserCount;
				vecTable.push_back(tableInfo);
			}
		}
	}
	
	if(vecTable.size() > 0)
	{
		std::sort(vecTable.begin(), vecTable.end(), Less_TableUserCount);

		TABLEINFO &tInfo = vecTable[0];
		pTable = pServer->GetTable(tInfo.tid);
		return pTable;
	}

	int sid = pServer->m_nServerId;
	int newTableId = (sid<<16) + pServer->m_nTableCount;


	//TableInfo::iterator iter = m_TableInfo.find(level);
	//TABLE tableinfo;

	//if(iter != m_TableInfo.end())
	//{
	//	tableinfo = iter->second;
	//}

	//g_pDebugLog->logMsg("tableinfo.strName[%s], tableinfo.nBaseChip[%d], tableinfo.nRequire[%d]",tableinfo.strName,tableinfo.nBaseChip, tableinfo.nRequire);
	pTable = new CGameTable(newTableId, pServer->m_nServerId, pServer->m_nLevel);
	//pTable = new CGameTable(newTableId, pServer->m_nServerId, pServer->m_nLevel, tableinfo.strName, tableinfo.nBaseChip, tableinfo.nRequire);
	if(pTable != NULL)
	{
		pServer->m_TableList[newTableId] = pTable;
		pServer->m_nTableCount++;
		pServer->m_nUserCount++;
		TCountTableList::iterator iterCount = CountTableList.find(1);
		if(iterCount != CountTableList.end())
		{
			TableList& tableMap = iterCount->second;
			tableMap[newTableId] = pTable;
		}
		else
		{
			TableList& tableMap = CountTableList[1];
			tableMap[newTableId] = pTable;
		}
	}
	return pTable;
}

int Options::CreatTable(int nServerId, int nLevel)
{
	g_pDebugLog->logMsg("----------------- Options::CreatTable begin --------------");
	g_pDebugLog->logMsg("nServerId:[%d],nLevel:[%d]",nServerId, nLevel);
	short serverId = (short)nServerId;
	CLogicServer *pLogicServer = Options::instance()->GetLogicServer(nServerId);

	if ( pLogicServer == NULL )
	{
		g_pDebugLog->logMsg("pLogicServer is null");
	}

	CGameTable *pTable = NULL;

	int newTableId = (nServerId<<16) + pLogicServer->m_nTableCount;

	//TableInfo::iterator iter = m_TableInfo.find(nLevel);
	//TABLE tableinfo;

	//if(iter != m_TableInfo.end())
	//{
	//	tableinfo = iter->second;
	//}

	//g_pDebugLog->logMsg("tableinfo.strName[%s], tableinfo.nBaseChip[%d], tableinfo.nRequire[%d]",tableinfo.strName.c_str(),tableinfo.nBaseChip, tableinfo.nRequire);
	//pTable = new CGameTable(newTableId, pServer->m_nServerId, pServer->m_nLevel);
	//pTable = new CGameTable(newTableId, pLogicServer->m_nServerId, pLogicServer->m_nLevel, tableinfo.strName, tableinfo.nBaseChip, tableinfo.nRequire);
	if(pTable != NULL)
	{
		pLogicServer->m_TableList[newTableId] = pTable;
		pLogicServer->m_nTableCount++;
		TCountTableList::iterator iterCount = CountTableList.find(nLevel);
		if(iterCount != CountTableList.end())
		{
			TableList& tableMap = iterCount->second;
			tableMap[newTableId] = pTable;
		}
		else
		{
			TableList& tableMap = CountTableList[1];
			tableMap[newTableId] = pTable;
		}
	}

	g_pDebugLog->logMsg("----------------- Options::CreatTable end --------------");

	return 0;
}


CGameTable* Options::GetTable(int count, int uid, short level)
{
	CGameTable *pTable = NULL;
	TCountTableList::iterator iterCount = CountTableList.find(count);
	if(iterCount != CountTableList.end())
	{
		TableList& tableMap = iterCount->second;
		TableList::iterator iterTable = tableMap.begin();

		for(; iterTable!=tableMap.end(); )
		{
			CGameTable* pTempTable = iterTable->second;
			if(pTempTable != NULL)
			{
				CLogicServer *pServer = GetLogicServer(pTempTable->m_nServerId);
				if(pServer != NULL)
				{
					if(pServer->m_nRetire==1 || pServer->m_nUserCount>=nMaxServerUserCount)
					{
						iterTable++;
					}
					else
					{
						pTable = pTempTable;
						tableMap.erase(iterTable++);
						pTable->m_nUserCount = count+1;
						pServer->m_nUserCount++;
						TableList& tableNewMap = CountTableList[pTable->m_nUserCount];
						tableNewMap[pTable->m_nTid] = pTable;
						break;
					}
				}
				else
				{
					tableMap.erase(iterTable++);
				}
			}
			else
			{
				tableMap.erase(iterTable++);
			}
		}
	}
	return pTable;	

}

CBackServer* Options::GetUserServer(int id)
{
	CBackServer* pServer = NULL;
	TUserServerList::iterator iter = UserServerList.find(id);
	if(iter != UserServerList.end())
	{
		pServer = iter->second;
	}
	return pServer;		

}

void Options::printConf()
{
	printf("==============SysConfig=================\n");
	printf("listen_port   =[%u]\n",listen_port);
	printf("server_id     =[%u]\n",server_id);
	printf("server_level  =[%u]\n",server_level);
	printf("MaxTableUser  =[%u]\n",nMaxTableUserCount);
	printf("MaxServerUser =[%u]\n",nMaxServerUserCount);
	printf("Log Dir	      =[%s]\n",strLogDir.c_str());
	printf("Log Num       =[%d]\n",nNum);
	printf("Log Size      =[%d]\n",nSize);
	printf("Log Level     =[%d]\n",nLogLevel);
	printf("Log Name      =[%s]\n",szLogName);
	printf("ServerMcAddr  =[%s]\n",strMcAddr.c_str());
	printf("=====================================\n");
}

