#include "CBackServer.h"
#include "CCReactor.h"
#include "HallServer.h"
#include "GameTable.h"
#include "ClientHandler.h"


CBackServer::CBackServer(string strFlag)
{
	EnableReconnect();

	strServer_flag = strFlag;
	m_bIsConnected = false;
}

CBackServer::~CBackServer()
{
	

}

int CBackServer::Init()
{
	CCSocketHandler::Init();

//	OnConnected();
	return 0;
}

static int split_str(const char* ps_str , char* ps_sp , vector<std::string> &v_ret)
{    
	char* ps_temp;    
	char* p;    
	int i_len = (int)strlen(ps_str);    
	std::string st_str;    
	ps_temp = new char[i_len+2];    
	snprintf(ps_temp , i_len+1 , "%s" , ps_str);    
	char *last = NULL;    
	p = strtok_r(ps_temp , ps_sp , &last);    
	if(NULL == p)
	{        
		delete ps_temp;        
		return 0;    
	}    
	st_str = (std::string)p;    
	v_ret.push_back(st_str);    
	while( NULL != ( p=strtok_r(NULL , ps_sp , &last) ) )
	{        
		st_str = (std::string)p;        
		v_ret.push_back(st_str);    
	}    
	delete ps_temp;    
	return 0;
}

int CBackServer::OnConnected()
{
	if( m_bIsConnected == false)
	{
		m_bIsConnected = true;
		log_boot("Connect %s[%s:%d] Success Fd[%d]", strServer_flag.c_str(),GetSIP().c_str(), GetPort(),netfd);
	}
	StopTimer();
	return 0;

}

int CBackServer::OnClose()
{
	m_bIsConnected = false;
	log_boot("%s[%s:%d] Closed", strServer_flag.c_str(),GetSIP().c_str(), GetPort());
	StartTimer(5000,true);
	return 0;
	

}

int CBackServer::OnPacketComplete(const char * data,int len)
{
//	DebugMsg("%s len[%d]",data, len);
	pPacket.Copy(data,len);
	//*****������****/
	return ProcessPacket(&pPacket);

}

int CBackServer::ProcessPacket(InputPacket * pPacket)
{
	g_pErrorLog->logMsg(" - --------------- CBackServer::ProcessPacket begin ----------------");
	int cmd = pPacket->GetCmdType();
	g_pErrorLog->logMsg("CMD[%x]", cmd);

	int uid = pPacket->ReadInt();
	int svid = pPacket->ReadInt();//����serverId

	g_pErrorLog->logMsg("uid[%d], svid[%d]", uid,svid);
	CHallServer *pHallServer = Options::instance()->GetHallServer(svid);
	if(pHallServer != NULL)
	{
		if(pHallServer->m_pSocketHandler != NULL)
		{
			if(cmd == CLIENT_PACKET)
			{
				char szTemp[10240];
				int rLen = pPacket->ReadBinary(szTemp, sizeof(szTemp));
				if(rLen != -1)
				{
					InputPacket tempPacket;
					tempPacket.Copy(szTemp, rLen);
					g_pErrorLog->logMsg("rLen [%d]", rLen);
					if(tempPacket.CrevasseBuffer() < 0)
					{
						g_pErrorLog->logMsg("%s||CrevasseBuffer error", __FUNCTION__);						
						return 0;
					}
					int subCmd = tempPacket.GetCmdType();
					g_pErrorLog->logMsg("subCmd [0x%x]", subCmd);
					if(subCmd == SERVER_CMD_LOGIN_SUCCESS)
					{							
						OutputPacket outTemp;
						outTemp.Begin(SERVER_CMD_LOGIN_SUCCESS);
						int levelCount = tempPacket.ReadInt();
						g_pErrorLog->logMsg("levelCount [%d]", levelCount);
						outTemp.WriteInt(levelCount);
						for(int i=0; i<levelCount; ++i)
						{
							int userCount = tempPacket.ReadInt();
							outTemp.WriteInt(userCount);
							g_pErrorLog->logMsg("userCount [%d]", userCount);
						}
				
						int tid = tempPacket.ReadInt();
						outTemp.WriteInt(tid);

						g_pErrorLog->logMsg("tid [%d]", tid);
							
						string strIP = tempPacket.ReadString();
						outTemp.WriteString(strIP.c_str());

						g_pErrorLog->logMsg("strIP [%s]", strIP.c_str());
							
						int port = tempPacket.ReadInt();
						outTemp.WriteInt(port);	

						g_pErrorLog->logMsg("port [%d]", port);	
									
						outTemp.End();
						outTemp.EncryptBuffer();
				
						OutputPacket resPacket;
						resPacket.Begin(CLIENT_PACKET);
						resPacket.WriteInt(uid);
						resPacket.WriteInt(svid);
						resPacket.WriteBinary(outTemp.packet_buf(), outTemp.packet_size());		
						resPacket.End();							
						pHallServer->m_pSocketHandler->Send(&resPacket);						
						return 0;
					}
				}
				OutputPacket resPacket;
				resPacket.Copy(pPacket->packet_buf(), pPacket->packet_size());
				pHallServer->m_pSocketHandler->Send(&resPacket);
				 return 0;
			}

			else
			{
				NETOutputPacket resPacket;
				resPacket.Copy(pPacket->packet_buf(), pPacket->packet_size());
				pHallServer->m_pSocketHandler->Send(&resPacket);

			}
		}
	}

	return 0;
}

int CBackServer::ProcessOnTimerOut()
{
	log_boot("TimeOut Reconncet %s", strServer_flag.c_str());
	reConnect();
	return 0;

}

int CBackServer::reConnect()
{
	log_boot("try connect %s[%s:%d]", strServer_flag.c_str(),GetSIP().c_str(), GetPort());
	Connect();
	return 0;	

}

int CBackServer::InitConnect(const char * ip,int port)
{
	SetSIP(ip);
	SetPort(port);
	if( Connect()< 0)
	{
	
		StopTimer();
		StartTimer(5000,true);		//����ʧ��������ʱ��
		return -1;
	}
	return 0;		

}


int CBackServer::Send(OutputPacket* pPacket)
{
	int len = CCSocketHandler::Send(pPacket->packet_buf(), pPacket->packet_size());

	log_boot(" len %d", len);

	return len;
}
