#ifndef OPTIONS_H
#define OPTIONS_H

#include <time.h>
#include <unistd.h>
#include <string>
#include "MemCacheClient.h"
#include "log.h"
#include "CBackServer.h"
#include <map>
#include <set>
#include <vector>
#include "HallServer.h"
#include "LogicServer.h"
#include "GameTable.h"
using namespace std;

class CHallServer;
class CLogicServer;

typedef map<int, CBackServer *>  	TUserServerList;
typedef map<int, CHallServer *>  	THallServerList;
typedef map<short, CLogicServer*> 	TServerList;

typedef map<int, CGameTable*> 		TableList;
typedef map<short, TableList> 		TCountTableList;


#pragma pack(1)
struct SERVERINFO
{
	short serverId;
	int userCount;
};
#pragma pack()


struct TABLEINFO
{
	int tid;
	short userCount;
};

struct TABLE
{
	string strName;
	int nBaseChip;
	int nRequire;
};

typedef map<int, TABLE> 			TableInfo;

class Options
{
public:

	static Options* instance() {
		static Options options;
		return &options;
	}

	int parse_args(int argc, char *argv[]);

	int read_conf(char file[256]);

	int InitMeCached();

	int InitBackServer(char file[256]);
	
	void printConf();

//***********************************************************
public:
	//Server ��Ϣ
	short	listen_port;			//�˿�
	int		server_id;				//sid
	int		server_level;			//level
	int		nMaxTableUserCount;		//һ�����������ɵ�����
	int		nMaxServerUserCount;	//һ��GameServer�����ɵ�����
	int		nFillFlag;				//�Ƿ��û�����һ��server�ı�־
	int 	nMaxListPriRoomCount;	//����˽�˷��б��ĸ���
	int 	nMaxSitTableUserCount;	//�������µ��������ֵ
	
	//��־��Ϣ
	string	strLogDir;			//��ŵ�ַ
	int	   	nNum;				//��־����
	int	  	nSize;				//��־��С
	char	szLogName[256];		//��־�ļ���
	int		nLogLevel;			//��־�ȼ�

	
	//Mc
	CMemcacheClient	m_MemCacheClient;
	CMemcacheClient m_cheatMcClient;
	string strMcAddr;			//Mc��ַ

	set<int> 		prvtRoomBaseChip;

	TUserServerList UserServerList;
	THallServerList HallServerList;
	TServerList		ServerList;

	TableInfo m_TableInfo;

	TABLE StrTable;

	TCountTableList	CountTableList;

	int					 m_readMcFlag;	  //�Ƿ��жϺ�������ʶȥ��MC�Ŀ���
	int 				 m_debugLogFlag;  //debug��־����
	
private:
	Options();
public:

	int ProcessLogicCore(CLogicServer *pLogicServer);
	int ProcessHallCore(CHallServer *pHallServer);

	CLogicServer* GetLogicServer(short serverId);
	CHallServer*  GetHallServer(short serverId);
	CBackServer*  GetUserServer(int id);

	CGameTable* GetGameRoom(int uid, short level);
	CGameTable* GetGameRoom(CLogicServer* pServer, int uid, short level);
	CGameTable* GetTable(int count, int uid, short level);

	int CreatTable(int ServerId, int nLevel);
};

#endif

