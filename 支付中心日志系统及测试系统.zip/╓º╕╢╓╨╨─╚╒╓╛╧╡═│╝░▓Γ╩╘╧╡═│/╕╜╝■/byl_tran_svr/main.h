#ifndef _MAIN_H_
#define _MAIN_H_

#include <sys/types.h>
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <pthread.h>
//#include <semaphore.h>
#include <sys/time.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>


#include "log.h"

using namespace std;

class appBase {
public:
    string conf_file;
    int is_daemonize;
    string log_file;
    int level;
    int consloe;
    int rotate;
    uint64_t log_max_size;
    string pid_file;
    
	string host;
	int port;
	string output;
	int workers;
	
	ThreadPool *tp;
};

class RecvTask : public Task {
public:
    RecvTask();
    RecvTask(int fd, string remote_addr);
    ~RecvTask();
    virtual void run(void);
	int file_is_exist(string &path, string &md5);
	int recvfile_tcp(int remote_fd, string path, int64_t size);
private:
    int             _fd;
	string 			_remote_addr;
};

#endif    /* _CPPBASE_H_ */
