#ifndef _THREADPOOL_H_
#define _THREADPOOL_H_

#include <deque>
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
//#include <semaphore.h>
#include <sys/time.h>
#include <errno.h>

#include <iostream>
#include <string>
#include <vector>

using namespace std;

#define MAX_THREAD_NUM		512

class Task {
public:
    Task()
    {
    
    }
    
    virtual ~Task()
    {
    
    }

    virtual void run(void)
    {
        cout << "task is runing." << endl;
    }
};

class ThreadPool
{
public:
    ThreadPool(int nthread);    
	virtual ~ThreadPool();
	void start(void);
	void stop(void);
	void join(void);
	virtual void finish_handler();
	static void *process_task(void *args);

	int put_task(Task *task);
	int get_task(Task* &task);
	int get_task(Task* &task, int sec);
	
private:
	int					_run;
	int      			_nthread;
    int                 _nready;
	pthread_mutex_t		_mutex;
	pthread_cond_t      _cond;
	vector<pthread_t>	_pid;
    deque<Task*>     	_queue;
};

#endif    /* _THREADPOOL_H_ */
