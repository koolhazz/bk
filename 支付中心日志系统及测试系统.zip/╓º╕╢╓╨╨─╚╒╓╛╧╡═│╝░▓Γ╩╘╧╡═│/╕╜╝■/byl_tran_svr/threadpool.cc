#include "log.h"
#include "threadpool.h"

using namespace std;

extern Log log;

ThreadPool::ThreadPool(int nthread)
{
	_nready = 0;
	if (nthread > MAX_THREAD_NUM || nthread <= 0)
		_nthread = MAX_THREAD_NUM;
	else
		_nthread = nthread;
	pthread_mutex_init(&_mutex, NULL);
	pthread_cond_init(&_cond, NULL);
}

ThreadPool::~ThreadPool()
{   
	pthread_mutex_lock(&_mutex); 
	_queue.clear();
	pthread_mutex_unlock(&_mutex);
	
	pthread_mutex_destroy(&_mutex);
	pthread_cond_destroy(&_cond);
}

void ThreadPool::start()
{
	int retval;
    pthread_attr_t attr;
	
	_run = 1;
	pthread_attr_init(&attr);
	for (int i = 0; i < _nthread; i++) {
        pthread_t tid = 0;
		retval = pthread_create(&tid, &attr, process_task, (void*)this);
		if (retval  < 0) {
			log.error("File[%s] Line[%d]: pthread_create failed: %s\n",
							__FILE__, __LINE__, strerror(errno));
			exit(1);
		}
        _pid.push_back(tid);
	}
}

void ThreadPool::stop(void)
{
	_run = 0;
}

void ThreadPool::join(void)
{
    vector<pthread_t>::iterator iter = _pid.begin();   
    while(iter != _pid.end()) {   
        // pthread_cancel(*iter);   
        pthread_join(*iter, NULL);   
        iter++;   
    }
}


void ThreadPool::finish_handler()
{

}

void *ThreadPool::process_task(void *args)
{
	ThreadPool *self = (ThreadPool*)args;
	
	Task *task;
	while (self->_run) {
        self->get_task(task);
		task->run();
        delete task;
	}
	
    pthread_exit((void*)0);
}
  
int ThreadPool::put_task(Task *task)
{
	pthread_mutex_lock(&_mutex);
	_queue.push_back(task);
	_nready++;
	pthread_mutex_unlock(&_mutex);
    pthread_cond_signal(&_cond);
    
	return 0;
}

int ThreadPool::get_task(Task* &task)
{
	pthread_mutex_lock(&_mutex); 
	while (_nready == 0)
		  pthread_cond_wait(&_cond, &_mutex);
	_nready--;
	task = _queue.front();
	_queue.pop_front();
	pthread_mutex_unlock(&_mutex);
	return 0;
}

int ThreadPool::get_task(Task* &task, int sec)
{
	timeval now;
	struct timespec timeout;
	int retval = 0;
	
	pthread_mutex_lock(&_mutex); 
	while (_nready == 0) {
		gettimeofday(&now, NULL);
		timeout.tv_sec = now.tv_sec + sec;
		timeout.tv_nsec = now.tv_usec * 1000;
		retval = pthread_cond_timedwait(&_cond, &_mutex, &timeout);
		if (retval == ETIMEDOUT) {
			pthread_mutex_unlock(&_mutex);
			return -1;
		}
	}
	_nready--;
	task = _queue.front();
	_queue.pop_front();
	pthread_mutex_unlock(&_mutex);
	return 0;
}

#ifdef THREADPOOL_DEBUG
class pingTask : public Task {
public:
    pingTask(int id)
    {
        _id = id;
    }
    
    void run(void)
    {
        cout << "thread " << _id << " is runing." << endl;
    }
private:
    int _id;
};

int main()
{
	Task *task;
	ThreadPool *tp = new ThreadPool(200);
	tp->start();
	for (int i = 0; i < 100; i++) {
        task = new pingTask(i);
        tp->put_task(task);
	}
	tp->join();
	delete tp;
	
	return 0;
}
#endif
