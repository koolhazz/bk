#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/epoll.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include "conf.h"
#include "daemonize.h"
#include "epoll.h"
#include "network.h"
#include "protocol.h"
#include "threadpool.h"
#include "md5.h"
#include "io.h"
#include "main.h"

using namespace std;

static int parse_arg(int argc, char **argv);
static int init_conf();
static int launch_server();
static int set_rlimit(int n);
static int do_accept(int listen_fd);

appBase app_base;
Log log;

int main(int argc, char **argv)
{
    int ret;
    ret = parse_arg(argc, argv);
    if (ret < 0) {
        log.fatal("File: %s Func: %s Line: %d => parse_arg fatal error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
        exit(1);
    }
    ret = init_conf();
    if (ret < 0) {
        log.fatal("File: %s Func: %s Line: %d => init_conf fatal error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
        exit(1);
    }
    
    if (app_base.is_daemonize == 1)
        daemonize();
    
    ret = single_instance_running(app_base.pid_file.c_str());
    if (ret < 0) {
        log.fatal("File: %s Func: %s Line: %d => single_instance_running fatal error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
        exit(1);
    }
	
	log.start(app_base.log_file, app_base.level, app_base.consloe, app_base.rotate, app_base.log_max_size);
	
	app_base.tp = new ThreadPool(app_base.workers);
	app_base.tp->start();
    launch_server(); 
    app_base.tp->join();
    
    return 0;
}

static int parse_arg(int argc, char **argv)
{
    int flag = 0;
    int oc; /* option chacb. */
    char ic; /* invalid chacb. */
    
    app_base.is_daemonize = 0;
    while((oc = getopt(argc, argv, "Df:")) != -1) {
        switch(oc) {
            case 'D':
                app_base.is_daemonize = 1;
                break;
            case 'f':
                flag = 1;
                app_base.conf_file = string(optarg);
                break;
            case '?':
                ic = (char)optopt;
                printf("invalid \'%c\'\n", ic);
                break;
            case ':':
                printf("lack option arg\n");
                break;
        }
    }
    
    if (flag == 0)
        return -1;
        
    return 0;
}

static int init_conf()
{
    map<string, string> result;
    
    int ret = Conf::parse(app_base.conf_file, result);
    if (ret < 0)
        return -1;
    
    for (map<string, string>::iterator iter = result.begin(); iter != result.end(); ++iter) {
        cout << iter->first << "<==>" << iter->second << endl;
    }
    
    // app_base.is_daemonize;
    app_base.log_file = result["log_file"];
    app_base.level = atoi(result["level"].c_str());
    app_base.consloe = atoi(result["consloe"].c_str());
    app_base.rotate = atoi(result["rotate"].c_str());
    app_base.log_max_size = atol(result["log_max_size"].c_str());
    app_base.pid_file = result["pid_file"];
    app_base.host = result["host"];
    app_base.port = atoi(result["port"].c_str());
    app_base.output = result["output"];
    app_base.workers = atoi(result["workers"].c_str());
	
    return 0;
}

static int launch_server()
{
    int retval;
    int listen_fd;
    struct spec_event st;
    
    // set resource limit.
    set_rlimit(50000);
    
    listen_fd = Network::listen_sock((char*)(app_base.host.c_str()), app_base.port);
    if (listen_fd == -1) {
        log.error("File: %s Func: %s Line: %d => listen_sock error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
        return -1;
    }
    
    retval = epoll_init();
    if (retval == -1) {
        log.error("File: %s Func: %s Line: %d => epoll_init error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
        close(listen_fd);
        return -1;
    }
    Network::set_nonblocking(listen_fd);
    
    retval = add_read_event(&st, listen_fd, (handler_t)do_accept);
    if (retval == -1) {
        log.error("File: %s Func: %s Line: %d => add_read_event error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
        close(listen_fd);
        return -1;
    }
    
    log.info("|*************launch server successful*************|\n");
    do_events_loop();
    epoll_deinit();
    close(listen_fd);
    
    return 0;
}

static int set_rlimit(int n)
{
    struct rlimit rt;
  
    rt.rlim_max = rt.rlim_cur = n;
    if (setrlimit(RLIMIT_NOFILE, &rt) == -1) {
        log.error("File: %s Func: %s Line: %d => setrlimit %s.\n",
                            __FILE__, __FUNCTION__, __LINE__, strerror(errno));
        perror("setrlimit");   
        return -1;   
    }
    
    return 0;
}

static int do_accept(int listen_fd)
{
    int fd;
    socklen_t len;
    struct sockaddr_in client_addr;
    
    len = sizeof(struct sockaddr_in);
    fd = accept(listen_fd, (struct sockaddr *)&client_addr, &len);
    if (fd < 0) {
        log.error("File: %s Func: %s Line: %d => accept %s.\n",
                            __FILE__, __FUNCTION__, __LINE__, strerror(errno));
        return -1;
    }
    
	log.info("The new connection: %s\n", inet_ntoa(client_addr.sin_addr));
	
    RecvTask *task = new RecvTask(fd, inet_ntoa(client_addr.sin_addr));
    if (!task) {
        return -1;
    }
    app_base.tp->put_task(task);
	
    return 0;
}

RecvTask::RecvTask()
{
    _fd = -1;
}

RecvTask::RecvTask(int fd, string remote_addr)
{
    _fd = fd;
	_remote_addr = remote_addr;
}

RecvTask::~RecvTask()
{
    if (_fd != -1) {
        close(_fd);
        _fd = -1;
    }
}

void RecvTask::run()
{
	int ret;
	string buf;
	vector<string> data;
	string	file_name;
	string	md5;
	string	tmp_dir;
	string	dst_dir;

	
	Network::set_recv_timeout(_fd, 60);
	Network::set_send_timeout(_fd, 60);
	
	ret = IO::read_to_string(_fd, buf);
	if (ret < 0) {
        log.error("File: %s Func: %s Line: %d => read_to_string error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
		return;
	}
	data.clear();
	ret = Protocol::unpack_cmd(buf, data);
	if (ret < 0 || data.size() != 2) {
        log.error("File: %s Func: %s Line: %d => unpack_cmd error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
		return;
	}
	file_name = data[0];
	md5 = data[1];
	
	tmp_dir.clear();
	tmp_dir.append(app_base.output);
	tmp_dir.append("/.");
	tmp_dir.append(file_name);
	
	dst_dir.clear();
	dst_dir.append(app_base.output);
	dst_dir.append("/");
	dst_dir.append(file_name);
	
	
	data.clear();
	ret = file_is_exist(dst_dir, md5);
	if (ret == 0) {
		// no need to send
		data.push_back("304");
		Protocol::pack_cmd(data, buf);
		ret = IO::write_from_string(_fd, buf);
		if (ret != (int)buf.length()) {
			log.error("File: %s Func: %s Line: %d => write_from_string error.\n",
								__FILE__, __FUNCTION__, __LINE__);
			return;
		}
		return;
	}
	
	// need to send
	data.push_back("200");
	Protocol::pack_cmd(data, buf);
	ret = IO::write_from_string(_fd, buf);
	if (ret != (int)buf.length()) {
		log.error("File: %s Func: %s Line: %d => write_from_string error.\n",
							__FILE__, __FUNCTION__, __LINE__);
		return;
	}
	
    int64_t size;
	int len = IO::safe_readn(_fd, (char*)&size, sizeof(int64_t));
    if (len < 0) {
        log.error("File: %s Func: %s Line: %d => safe_readn error.\n",
                                __FILE__, __FUNCTION__, __LINE__);
		return;
    }
	
	ret = recvfile_tcp(_fd, tmp_dir, size);
    if (ret < 0) {
        log.error("File: %s Func: %s Line: %d => recvfile_tcp error.\n",
                                __FILE__, __FUNCTION__, __LINE__);
		return;
    }
    
	data.clear();
	string current_md5;
    MD5::MD5Cal(tmp_dir, current_md5);
    if (md5.compare(current_md5) != 0) {
        cout << "md5 no match: " << current_md5  << " " << md5 << endl;
        log.error("File: %s Func: %s Line: %d => Md5 No Match %s [%s VS %s].\n",
                            __FILE__, __FUNCTION__, __LINE__,
                            tmp_dir.c_str(), current_md5.c_str(), md5.c_str());
        unlink(tmp_dir.c_str());
		data.push_back("400");
    } else {
		rename(tmp_dir.c_str(), dst_dir.c_str());
		data.push_back("200");
	}
	
    Protocol::pack_cmd(data, buf);
    ret = IO::write_from_string(_fd, buf);
    if (ret != (int)buf.length()) {
        log.error("File: %s Func: %s Line: %d => write_from_string error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
		return;
    }
	
	log.info("Receive File: %s [ok].\n",
						dst_dir.c_str());
}

int RecvTask::file_is_exist(string &path, string &md5)
{
	int ret;
	string current_md5;
	
	ret = MD5::MD5Cal(path, current_md5);
	if (ret < 0) {
		return -1;
	}
	
	if (md5.compare(current_md5) != 0) {
		return -1;
	}
	
	return 0;
}

int RecvTask::recvfile_tcp(int remote_fd, string path, int64_t size)
{
    int fd;
    int64_t ret, len, sum = 0;
    char buf[4096];
    
    fd = open(path.c_str(), O_RDWR | O_TRUNC | O_CREAT | O_LARGEFILE, 0644);
    if (fd < 0) {
        log.error("File: %s Func: %s Line: %d => open error.\n",
                                __FILE__, __FUNCTION__, __LINE__);
        return -1;
    }
    
    while (sum != size) {
        len = IO::safe_read(remote_fd, buf, sizeof(buf));
        if (len < 0) {
            close(fd);
            log.error("File: %s Func: %s Line: %d => safe_read error.\n",
                                    __FILE__, __FUNCTION__, __LINE__);
            return -1;
        } else if (len == 0) {
            close(fd);
            log.error("File: %s Func: %s Line: %d => safe_read error.\n",
                                    __FILE__, __FUNCTION__, __LINE__);
            return -1;
        }
        
        ret = write(fd, buf, len);
        if (ret != len) {
            close(fd);
            log.error("File: %s Func: %s Line: %d => write error.\n",
                                    __FILE__, __FUNCTION__, __LINE__);
            return -1;
        }
        
        sum += len;
    }
    
    close(fd);
    
    return sum;
}
