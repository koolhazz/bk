package main

//放在生产服务器，负责转发通道和接收udp
import (
	"flag"
	"fmt"
	"github.com/jimlawless/cfg"
	daemon "github.com/xgdapg/daemon"
	"log"
	"net"
	"os"
	"strings"
	"time"
)

var cfg_map map[string]string

var config string

var logger *log.Logger

var logfile *os.File

func init() {
	daemon.Exec(daemon.Daemon)

	flag.StringVar(&config, "config", "./svrConf.cfg", "Input the config file name use --config=filename")
	flag.Parse()

	//日志初始化
	logfile, _ = os.OpenFile("testChannelSvr.log", os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)

	logger = log.New(logfile, "\r\n", log.Ldate|log.Ltime|log.Llongfile)
}

func main() {
	//日志
	defer logfile.Close()

	//配置文件svrConf.cfg
	cfg_map = make(map[string]string)

	cfg_err := cfg.Load(config, cfg_map)
	fmt.Println(cfg_map)
	if cfg_err != nil {
		logger.Panic(cfg_err)
	}

	//创建通道
	ch := make(chan string, 10000)
	defer close(ch)

	listener, err := net.Listen("tcp", ":19010") //侦听在19010端口
	if err != nil {
		panic("error listening:" + err.Error())
	}

	udpListener, err := net.ListenUDP("udp4", &net.UDPAddr{
		IP:   net.IPv4(0, 0, 0, 0),
		Port: 7777,
	})

	if err != nil {
		panic("error listening:" + err.Error())
	}

	go udpServer(udpListener, ch)

	logger.Println("Starting the server")

	tcpLock := make(chan int) //tcp链接锁
	defer close(tcpLock)

	for {
		//做阻塞，每次只接收一个连接

		conn, err := listener.Accept() //接受连接

		if err != nil {
			logger.Panic("Error accept:" + err.Error())
		}

		//检查ip来路，仅接收来自公司出口的ip
		checkAddr := conn.RemoteAddr().String()
		checkAddrArr := strings.Split(checkAddr, ":")

		//todo:
		logger.Println(cfg_map["connip"])
		logger.Println(cfg_map)
		if checkAddrArr[0] != cfg_map["connip"] {
			//丢弃
			logger.Println("Abandon the Connection :", checkAddrArr[0])

			continue
		}

		logger.Println("Accepted the Connection :", conn.RemoteAddr())

		go EchoServer(conn, ch, logger, tcpLock)

		//阻塞
		select {
		case <-tcpLock:
			continue
		}
	}
}

//接收udp数据包
func udpServer(udpListener *net.UDPConn, ch chan string) {
	defer udpListener.Close()
	buf := make([]byte, 256)

	for {
		read, _, err := udpListener.ReadFromUDP(buf)

		if err != nil {
			panic("Error accept:" + err.Error())
		}

		logger.Println("udp write:", string(buf[:read]))
		//fmt.Println("Accepted the Connection :", arr.IP)
		go inputServer(string(buf[:read]), ch)
		time.Sleep(time.Duration(5) * time.Second)

	}
}

//udp数据包入队列
func inputServer(data string, ch chan string) {
	ch <- data
}

//发送tcp数据包,todo:需要做重发
func EchoServer(conn net.Conn, ch chan string, logger *log.Logger, tcpLock chan int) {
	defer conn.Close()

	//心跳包
	pingLock := make(chan int) //tcp链接锁
	go pingTickerFuc(conn, tcpLock, pingLock)
	//buf := make([]byte, 1024)
	var str string

	for {
		//接收udp或心跳包发现连接已中断处理
		select {
		case str = <-ch:
			logger.Println(str)
		case <-pingLock:
			//心跳包终止
			logger.Println("close the tcp conn for ", conn.RemoteAddr())
			return
		}

		if len(str) == 0 {
			time.Sleep(time.Duration(5) * time.Second)
			continue
		}
		n, err := conn.Write([]byte(str))
		logger.Println(n)
		if err != nil {
			logger.Println("tcp write err:", err)
			//重发
			ch <- str
			break
		}
		if n == 0 {
			logger.Println("tcp close:", conn.RemoteAddr())
			//重发
			ch <- str
			break
		}
		/*//todo:需要心跳包判断中断，锁加在心跳包上
		_, err = conn.Read(buf)
		if err != nil {
			logger.Println("Read Buffer Error:", err.Error())
			break
		}*/
		time.Sleep(time.Duration(5) * time.Second)
	}
	logger.Println("close the tcp conn for ", conn.RemoteAddr())

	//释放连接锁
	tcpLock <- 1
}

/**
 * 心跳包,30秒一次
 */
func pingTickerFuc(conn net.Conn, tcpLock chan int, pingLock chan int) {
	pingTicker := time.NewTicker(30 * time.Second)
	for {
		<-pingTicker.C
		n, err := conn.Write([]byte("ping"))
		if n == 0 {
			logger.Println("ping found tcp close:", conn.RemoteAddr())
			//解锁
			tcpLock <- 1
			pingLock <- 1
			break
		}
		if err != nil {
			logger.Println("ping tcp write err:", conn.RemoteAddr())
			//解锁
			tcpLock <- 1
			pingLock <- 1
			break
		}
	}
}
