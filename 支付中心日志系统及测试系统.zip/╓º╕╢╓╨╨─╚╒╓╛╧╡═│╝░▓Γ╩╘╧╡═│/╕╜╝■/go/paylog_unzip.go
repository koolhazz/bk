package main

import (
	"bufio"
	"compress/gzip"
	"fmt"
	daemon "github.com/xgdapg/daemon"
	"log"
	"os"
	"path/filepath"
	"time"
)

var logger *log.Logger

var logfile *os.File

func gzipList(dir string) (files []string, err error) {
	match := fmt.Sprintf("%s/[0-9]*_*_*.gz", dir)
	//fmt.Println(match)
	files, err = filepath.Glob(match)
	if err != nil {
		fmt.Println(files)
		return
	}
	return
}

func init() {
	daemon.Exec(daemon.Daemon) // send the process to the background

	//日志初始化
	logfile, _ = os.OpenFile("paylog.log", os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)

	logger = log.New(logfile, "\r\n", log.Ldate|log.Ltime|log.Llongfile)
}

/*func daemonRun() {
	daemon.Exec(daemon.Daemon | daemon.Monitor)
}*/

func main() {
	logger.Println("Starting the unzip")
	//read the gz file
	for {
		files, err := gzipList("/data/paylog_incoming")
		if err == nil {
			readGz(files)

		} else {
			fmt.Println(err)
		}
		time.Sleep(time.Duration(5) * time.Second)
	}

}

func readGz(files []string) {
	//goadf, err := os.Create("test.log")
	today := time.Now().Format("2006-01-02")
	goadf, err := os.OpenFile("/data/paylogs/"+today+".log", os.O_APPEND|os.O_CREATE|os.O_RDWR, 0666)
	if err != nil {
		logger.Println("openfile err:", err)
		return
	}
	defer goadf.Close()

	var br *bufio.Reader

	for i := 0; i < len(files); i++ {
		//logger.Println(files[i] + "\n")
		file, fileEr := os.Open(files[i])
		if fileEr != nil {
			logger.Println("file read error:", fileEr)
			return
		}

		defer file.Close()

		fz, gzErr := gzip.NewReader(file)
		if gzErr != nil {
			//解压失败
			//br = bufio.NewReader(file)
			continue
		} else {
			br = bufio.NewReader(fz)
		}

		for {
			//line, _, err1 := br.ReadLine()
			line, err1 := br.ReadString('\n')
			if err1 != nil {
				//logger.Println("ReadString err", err1)
				break
			}
			if line == "" {
				continue
			}
			//fmt.Println(string(line) + "\n")
			_, werr := goadf.WriteString(line)
			if werr != nil {
				logger.Println("writeString err", werr)
			}

		}
	}
	delGz(files)
}

func delGz(files []string) {
	for _, v := range files {
		//logger.Println("delGz :", v)
		err := os.Remove(v)
		if err != nil {
			logger.Println("delGz err:", err)
		}
	}
}
