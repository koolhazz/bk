package main

//放在测试服务器，负责回调
import (
	//"encoding/json"
	"flag"
	"fmt"
	sjson "github.com/bitly/go-simplejson"
	"github.com/jimlawless/cfg"
	daemon "github.com/xgdapg/daemon"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"strings"
	"time"
)

const RECV_BUF_LEN = 1024

var cfg_map map[string]string

var logger *log.Logger

var logfile *os.File

var config string

func init() {
	daemon.Exec(daemon.Daemon)

	//日志初始化
	logfile, _ = os.OpenFile("testChannelClient.log", os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)

	logger = log.New(logfile, "\r\n", log.Ldate|log.Ltime|log.Llongfile)

	flag.StringVar(&config, "config", "./clientConf.cfg", "Input the config file name use --config=filename")
	flag.Parse()
}

func main() {
	defer logfile.Close()
	ch := make(chan int)
	defer close(ch)

	logger.Println("Test Channel Client Starting")

	//配置文件
	cfg_map = make(map[string]string)

	cfg_err := cfg.Load(config, cfg_map)
	fmt.Println(cfg_map)
	if cfg_err != nil {
		logger.Panic(cfg_err)
	}

	for _, v := range cfg_map {
		go tcpDial(v)
	}

	ch <- 1

}

//连接tcp，需要做重连
func tcpDial(config string) {
	logger.Println("testst")
	fmt.Println(config)
	configArr := strings.Split(config, "|")
	conn, err := net.Dial("tcp", configArr[0]+":19010")

	if err != nil {
		logger.Panic(err.Error())
	}
	defer conn.Close()

	buf := make([]byte, RECV_BUF_LEN)

	for {
		//从服务器端收字符串
		n, err := conn.Read(buf)
		if err != nil {
			logger.Println("Read Buffer Error:", err.Error())
			logger.Println("Retry Connect:" + configArr[0])
			//重连
			go tcpDial(config)
			break
		}
		fmt.Println(string(buf[0:n]))

		if string(buf[0:n]) == "ping" {
			//丢弃
			continue
		}

		data := PostWebService(string(buf[0:n]), configArr[1])

		logger.Printf("result----%s", data)

		/*//响应服务端已接收
		n, err = conn.Write([]byte("1"))
		if err != nil {
			logger.Println("write Buffer Error:", err.Error())
			logger.Println("Retry Connect:" + configArr[0])
			//重连
			go tcpDial(config)
			break
		}*/

		//等一秒钟
		time.Sleep(time.Second)
	}
}

/**
 * 回调函数
 * @param value回调数据
 * @param addr 回调地址
 */
func PostWebService(value string, addr string) string {
	postUrlValue := url.Values{}

	//解析json
	js, err := sjson.NewJson([]byte(value))
	if err != nil {

		//panic("json format error")
	}

	logger.Println("原始url", value)
	logger.Println("解析json", js)

	//取url
	postUrl, err := js.Get("url").String()
	if err != nil {
		logger.Println(err)
	}
	//取post
	postData, err := js.Get("post").String()
	if err != nil {
		logger.Println("post json错误", err)
	}

	postDataJson, err := sjson.NewJson([]byte(postData))
	if err != nil {
		logger.Println("postDataJson 错误", err)
	} else {
		postDataJsonMap, err := postDataJson.Map()
		if err != nil {
			logger.Println("postDataJsonMap json错误", err)
		}

		fmt.Println("postDataJsonMap:", postDataJsonMap)
		for k, v := range postDataJsonMap {
			b, _ := v.(string)
			postUrlValue.Set(k, b)
		}
	}

	postUrlValue.Set("test", "test")
	fmt.Println(addr + postUrl)
	fmt.Println(postUrlValue)
	res, err := http.PostForm(addr+postUrl, postUrlValue)
	defer res.Body.Close()

	if err != nil {
		logger.Println("post error", err)
	}
	data, err := ioutil.ReadAll(res.Body)
	//取出主体的内容
	if err != nil {
		logger.Println("read error", err)
	}
	//logger.Println(string(data))
	return string(data)
}
