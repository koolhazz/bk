<?php
/**
 * log udp传送管道sdk
 * RexQiu
 */


class Bylog{

	//传送方式
	const STYPE = "udp";
	/**
	 * 传送host地址
	 */
	const HOST = "127.0.0.1";

	//传送端口
	const PORT = "1108";

	/**
	 * socket错误码
	 * @var integer
	 */
	public $error_code = 0;

	/**
	 * socket错误信息
	 * @var string
	 */
	public $error_message = '';

	/**
	 * log sdk 实例
	 */
	private static $instance;

	/**
	 * udp socket
	 */
	private static $socket;

	/**
	 * 构造函数
	 */
	public function __construct()
	{
		$error_code = 0;

		$error_message = '';

		if (!isset(self::$socket) || empty(self::$socket)) {
			self::$socket = stream_socket_client(self::STYPE.'://'.self::HOST.':'.self::PORT, $this->error_code, $this->error_message, 30);
		}
	}

	public function __destruct()
	{
		if (self::$socket) {
			fclose(self::$socket);
			self::$socket = null;
		}
	}

	/**
	 * 获得实例
	 * @return [type]
	 */
	public static function getInstance()
	{
		if (!isset(self::$instance) || empty(self::$instance)) {
			self::$instance = new Bylog();
		}
		return self::$instance;
	}

	/**
	 * 外部调用写
	 * @param  string $str 写入内容
	 * @return array array('ret' => boolean,'msg'=>'结果') ret为false失败
	 */
	public static function write($str)
	{
		$Bylog = Bylog::getInstance();

		$ret = $Bylog->_writeUDP($str);

		return array('ret' => $ret, 'msg'=> $Bylog->error_message);
	}

	/**
	 * 写UDP
	 * @param  string $str
	 * @return [type]
	 */
	public function _writeUDP($str)
	{
		if (empty(self::$socket)) {
			return FALSE;
		}

		$ret = fwrite(self::$socket, $str);

		//写入成功判断
		if ($ret > 0) {
			return TRUE;
		}else{
			return FALSE;
		}
	}
}