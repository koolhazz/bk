#ifndef _MAIN_H_
#define _MAIN_H_

#include <sys/types.h>
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <pthread.h>
//#include <semaphore.h>
#include <sys/time.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>


#include "log.h"

using namespace std;

class appBase {
public:
    string conf_file;
    int is_daemonize;
    string log_file;
    int level;
    int consloe;
    int rotate;
    uint64_t log_max_size;
    string pid_file;
    
	string host;
	string input;
	int workers;
	string mode;
	string remote_host;
	
	//--
	string remote_host_bak;
	int remote_port;
	
	ThreadPool *tp;
};

class SendTask : public Task {
public:
    SendTask();
    SendTask(string file_name);
    ~SendTask();
    virtual void run(void);
	int send_file(string &file_name);
	int64_t sendfile_tcp(int fd, fstream &ifs, int64_t size);
private:
	string 			_file_name;
};

#endif    /* _CPPBASE_H_ */
