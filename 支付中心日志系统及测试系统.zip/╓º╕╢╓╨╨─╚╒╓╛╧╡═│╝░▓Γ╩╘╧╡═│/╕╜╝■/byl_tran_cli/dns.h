#ifndef _DNS_H_
#define _DNS_H_

#include <iostream>
#include <fstream>
#include <string>

#include <time.h>

using namespace std;

class Dns {
public:
    Dns();
    ~Dns();
	
	static int host2ip(string &host, string &ip);
};

#endif
