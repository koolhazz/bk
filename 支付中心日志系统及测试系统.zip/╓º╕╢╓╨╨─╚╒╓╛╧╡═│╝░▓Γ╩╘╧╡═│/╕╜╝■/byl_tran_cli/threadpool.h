#ifndef _THREADPOOL_H_
#define _THREADPOOL_H_

#include <deque>
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
//#include <semaphore.h>
#include <sys/time.h>
#include <errno.h>

#include <iostream>
#include <string>
#include <vector>

using namespace std;

#define MAX_THREAD_NUM		512

class Task {
public:
    Task()
    {
    
    }
    
    virtual ~Task()
    {
    
    }

    virtual void run(void)
    {
        cout << "task is runing." << endl;
    }
};

class ThreadPool
{
public:
    ThreadPool(int nthread);    
	virtual ~ThreadPool();
	void start(void);
	void stop(void);
	void join(void);
	virtual void finish_handler();
	static void *process_task(void *args);

	int put_task(int thread_no, Task *task);
	int get_task(int thread_no, Task* &task);
	int get_task(int thread_no, Task* &task, int sec);
	
private:
	int					_run;
	int      			_nthread;
    int                 _nready[MAX_THREAD_NUM];
	pthread_mutex_t		_mutex[MAX_THREAD_NUM];
	pthread_cond_t      _cond[MAX_THREAD_NUM];
	vector<pthread_t>	_pid;
    deque<Task*>     	_queue[MAX_THREAD_NUM];
};

class Arg {
public:
	ThreadPool *tp;
	int thread_no;
	
	Arg(ThreadPool *p, int i)
	{
		tp = p;
		thread_no = i;
	}
};

#endif    /* _THREADPOOL_H_ */
