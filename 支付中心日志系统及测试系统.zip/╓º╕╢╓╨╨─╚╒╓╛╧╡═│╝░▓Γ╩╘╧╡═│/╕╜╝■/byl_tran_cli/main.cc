#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <errno.h>

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include "conf.h"
#include "daemonize.h"
#include "network.h"
#include "protocol.h"
#include "threadpool.h"
#include "md5.h"
#include "io.h"
#include "dns.h"
#include "main.h"

using namespace std;

static int parse_arg(int argc, char **argv);
static int init_conf();
static int app_loop();
static int process_dir();
static int get_dst(int threads, char *name);
static int simple_hash(int threads, void* key, int key_size);

appBase app_base;
Log log;

int main(int argc, char **argv)
{
    int ret;
    ret = parse_arg(argc, argv);
    if (ret < 0) {
        log.fatal("File: %s Func: %s Line: %d => parse_arg fatal error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
        exit(1);
    }
    ret = init_conf();
    if (ret < 0) {
        log.fatal("File: %s Func: %s Line: %d => init_conf fatal error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
        exit(1);
    }
    
    if (app_base.is_daemonize == 1)
        daemonize();
    
    ret = single_instance_running(app_base.pid_file.c_str());
    if (ret < 0) {
        log.fatal("File: %s Func: %s Line: %d => single_instance_running fatal error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
        exit(1);
    }
	
	log.start(app_base.log_file, app_base.level, app_base.consloe, app_base.rotate, app_base.log_max_size);
	
	app_base.tp = new ThreadPool(app_base.workers);
	app_base.tp->start();
    app_loop(); 
    app_base.tp->join();
    
    return 0;
}

static int parse_arg(int argc, char **argv)
{
    int flag = 0;
    int oc; /* option chacb. */
    char ic; /* invalid chacb. */
    
    app_base.is_daemonize = 0;
    while((oc = getopt(argc, argv, "Df:")) != -1) {
        switch(oc) {
            case 'D':
                app_base.is_daemonize = 1;
                break;
            case 'f':
                flag = 1;
                app_base.conf_file = string(optarg);
                break;
            case '?':
                ic = (char)optopt;
                printf("invalid \'%c\'\n", ic);
                break;
            case ':':
                printf("lack option arg\n");
                break;
        }
    }
    
    if (flag == 0)
        return -1;
        
    return 0;
}

static int init_conf()
{
    map<string, string> result;
    
    int ret = Conf::parse(app_base.conf_file, result);
    if (ret < 0)
        return -1;
    
    for (map<string, string>::iterator iter = result.begin(); iter != result.end(); ++iter) {
        cout << iter->first << "<==>" << iter->second << endl;
    }
    
    // app_base.is_daemonize;
    app_base.log_file = result["log_file"];
    app_base.level = atoi(result["level"].c_str());
    app_base.consloe = atoi(result["consloe"].c_str());
    app_base.rotate = atoi(result["rotate"].c_str());
    app_base.log_max_size = atol(result["log_max_size"].c_str());
    app_base.pid_file = result["pid_file"];
	
    app_base.host = result["host"];
    app_base.input = result["input"];
    app_base.workers = atoi(result["workers"].c_str());
    app_base.mode = result["mode"];
    app_base.remote_host = result["remote_host"];
	
	//--
	app_base.remote_host_bak = result["remote_host_bak"];
	app_base.remote_port = atoi(result["remote_port"].c_str());
    
    return 0;
}

static int app_loop()
{
	while (1) {
		process_dir();
		sleep(5);
	}
	
	return 0;
}

static int process_dir()
{
    struct dirent *pentry;
    DIR *dir;
    int thread_no;

    dir = opendir(app_base.input.c_str());
    if (dir == NULL)
        return (-1);
    
    while ((pentry = readdir(dir)) != NULL) {
		if (strncmp(pentry->d_name, ".", 1) == 0)
			continue;
        
        thread_no = get_dst(app_base.workers, pentry->d_name);
		SendTask *task = new SendTask(pentry->d_name);
		if (!task) {
			continue;
		}
		log.info("thread no: %d, file: %s\n", thread_no, pentry->d_name);
		app_base.tp->put_task(thread_no, task);
    }
    
    closedir(dir);

    return 0;
}

static int get_dst(int threads, char *name)
{
    int ret;

    ret = simple_hash(threads, name, strlen(name));
    return ret;    
}

static int simple_hash(int threads, void* key, int key_size)
{
   unsigned long hash = 5381;
   char *str = (char *)key;
   int i;

   for (i = 0; i < key_size; i++)
      hash = ((hash << 5) + hash) + ((int)str[i]); /* hash * 33 + c */

   return hash % threads;
}

SendTask::SendTask()
{

}

SendTask::SendTask(string file_name)
{
	_file_name = file_name;
}

SendTask::~SendTask()
{

}

void SendTask::run()
{
    struct stat st;
	string file_name;
	
	file_name.clear();
	file_name.append(app_base.input);
	file_name.append("/");
	file_name.append(_file_name);
	
	log.info("%s\n", file_name.c_str());
	if (stat(file_name.c_str(), &st) < 0) {
        log.error("File: %s Func: %s Line: %d => stat error.\n",
                                __FILE__, __FUNCTION__, __LINE__);
		return;
	}
			
	if (!(st.st_mode & S_IFREG)) {
        log.error("File: %s Func: %s Line: %d => is dir error.\n",
                                __FILE__, __FUNCTION__, __LINE__);
		return;
	}
	
	send_file(file_name);
}

int SendTask::send_file(string &file_name)
{
	string buf;
	string md5;
	string ip;
	int ret;
	int fd;
	
	//--
	string ip_bak;
	
	ret = Dns::host2ip(app_base.remote_host, ip);
    fd = Network::tcp_connect(ip.c_str(), app_base.remote_port, 10);
    if (fd < 0) {
        log.error("File: %s Func: %s Line: %d => tcp_connect error.\n",
                                __FILE__, __FUNCTION__, __LINE__);
        //return -1;
		//--
		ret = Dns::host2ip(app_base.remote_host_bak, ip_bak);
		fd = Network::tcp_connect(ip_bak.c_str(), app_base.remote_port, 15);
		if ( fd < 0 ) {
			return -1;
		}
    }
	
    vector<string> data;
    data.push_back(_file_name);
	MD5::MD5Cal(file_name, md5);
    data.push_back(md5);
    Protocol::pack_cmd(data, buf);
	
	Network::set_recv_timeout(fd, 60);
	Network::set_send_timeout(fd, 60);
	
    ret = IO::write_from_string(fd, buf);
    if (ret != (int)buf.length()) {
        log.error("File: %s Func: %s Line: %d => write_from_string error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
		close(fd);
        return -1;
    }
    
	ret = IO::read_to_string(fd, buf);
	if (ret < 0) {
        log.error("File: %s Func: %s Line: %d => read_to_string error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
		close(fd);
		return -1;
	}
	data.clear();
	ret = Protocol::unpack_cmd(buf, data);
	if (ret < 0 || data.size() != 1) {
        log.error("File: %s Func: %s Line: %d => unpack_cmd error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
		close(fd);
		return -1;
	}
	
	if (data[0].compare("304") == 0) {
		log.info("%s 304 no modify\n", file_name.c_str());
		close(fd);
		return 0;
	}

    // open the file
    fstream ifs(file_name.c_str(), ios::in | ios::binary);
    if (!ifs) {
		log.error("File: %s Func: %s Line: %d => fstream %s.\n",
							__FILE__, __FUNCTION__, __LINE__, strerror(errno));
        close(fd);
        return -1;
    }

    ifs.seekg(0, ios::end);
    int64_t size = ifs.tellg();
    ifs.seekg(0, ios::beg);
	ret = IO::safe_writen(fd, (char*)&size, sizeof(int64_t));
	if (ret != sizeof(int64_t)) {
		log.error("File: %s Func: %s Line: %d => fstream %s.\n",
							__FILE__, __FUNCTION__, __LINE__, strerror(errno));
        close(fd);
        return -1;
	}
    // send the file
    ret = sendfile_tcp(fd, ifs, size);
    if (ret < 0) {
		log.error("File: %s Func: %s Line: %d => sendfile_tcp error.\n",
							__FILE__, __FUNCTION__, __LINE__);
        ifs.close();
        close(fd);
        return -1;
    }
    ifs.close();
	
	ret = IO::read_to_string(fd, buf);
	if (ret < 0) {
        log.error("File: %s Func: %s Line: %d => read_to_string error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
		close(fd);
		return -1;
	}
	data.clear();
	ret = Protocol::unpack_cmd(buf, data);
	if (ret < 0 || data.size() != 1) {
        log.error("File: %s Func: %s Line: %d => unpack_cmd error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
		close(fd);
		return -1;
	}
	
	if (data[0].compare("400") == 0) {
        log.error("File: %s Func: %s Line: %d => file send error.\n",
                            __FILE__, __FUNCTION__, __LINE__);
		close(fd);
		return -1;
	}
	
    close(fd);
	
	unlink(file_name.c_str());
    
    return 0;
}

int64_t SendTask::sendfile_tcp(int fd, fstream &ifs, int64_t size)
{
    int n, ret;
    char buf[4096];
	int64_t nsize = 0;
	
    while (!ifs.eof()) {
		n = ifs.read(buf, sizeof(buf)).gcount();
		if (n == 0)
			break;
		ret = IO::safe_writen(fd, buf, n);
		if (ret != n) {
			log.error("File: %s Func: %s Line: %d => safe_writen %s.\n",
								__FILE__, __FUNCTION__, __LINE__, strerror(errno));
			break;
		}
		nsize += ret;
    }
	
	if (size != nsize)
		return -1;

	return 0;
}
