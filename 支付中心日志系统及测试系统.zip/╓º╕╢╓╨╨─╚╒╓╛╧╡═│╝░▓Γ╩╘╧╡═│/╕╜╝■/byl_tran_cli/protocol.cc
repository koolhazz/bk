#include "protocol.h"

Protocol::Protocol()
{

}

Protocol::~Protocol()
{

}

int Protocol::pack_cmd(vector<string>& items, string &result)
{
    char size[11];
    string data;

	result.clear();
    for (vector<string>::iterator item = items.begin(); item != items.end(); ++item) {
        snprintf(size, sizeof(size), "%08d", (int)((*item).length()));
        data.append(size);
        data.append(*item);
    }
    
    //snprintf(size, sizeof(size), "%010d", (int)data.length());
    //result.append(size);
    result.append(data);

    return 0;
}

int Protocol::unpack_cmd(string &data, vector<string>& result)
{
    int left, len;
    const char* p;
    char buf[ITEM_LENGTH + 1];
    string item;
    
    p = data.c_str();
    left = data.length();
    
    for (;;) {
        item.clear();
        if (left == 0)
            break;
        if (left < ITEM_LENGTH && left > 0)
            return -1;
        memcpy(buf, p, ITEM_LENGTH);
        buf[ITEM_LENGTH] = '\0';
        len = atoi(buf);
        left -= ITEM_LENGTH;
        if (left < len)
            return -1;
        
        p += ITEM_LENGTH;
        item.append(p, len);
        result.push_back(item);
        left -= len;
        p += len;
    }
    
    return 0;
}
