#ifndef _PROTOCOL_H_
#define _PROTOCOL_H_

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#define ITEM_LENGTH 8

using namespace std;

class Protocol {
public:
    Protocol();
    ~Protocol();
    
    static int pack_cmd(vector<string>& items, string &result);
    static int unpack_cmd(string &data, vector<string>& result);
};

#endif
