#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <signal.h>
#include <time.h>
#include <errno.h>
#include <assert.h>
#include <syslog.h>
#include <fcntl.h>

#include "io.h"

IO::IO()
{

}

IO::~IO()
{

}

/* safe read "n" bytes from a descriptor. */
ssize_t IO::safe_readn(int fd, void *buf, size_t n)
{
    size_t nleft;
    ssize_t nread;
    char *ptr;

    ptr = (char*)buf;
    nleft = n;
    
    while (nleft > 0) {
        nread = read(fd, ptr, nleft);
        if (nread < 0) {
            if (errno == EINTR)
                nread = 0; /* and call read() again */
            else
                return -1;
        } else if (nread == 0)
            break; /* EOF */

        nleft -= nread;
        ptr += nread;
    }
    
    return (n - nleft); /* return >= 0 */
}

/*
 * If an EINTR occurs, pick up and try again.
 */
ssize_t IO::safe_read(int fd, char *buf, size_t n)
{
    ssize_t nread;
    
    do {
        nread = read(fd, buf, n);
    } while (nread < 0 && errno == EINTR);
    
    return nread;
}

/* safe write "n" bytes to a descriptor. */
ssize_t IO::safe_writen(int fd, const void* buf, size_t n)
{
    size_t nleft;
    ssize_t nwritten;
    const char *ptr;

    ptr = (char*)buf;
    nleft = n;
    
    while (nleft > 0) {
        nwritten = send(fd, ptr, nleft, MSG_NOSIGNAL);
        if (nwritten <= 0) {
            if (errno == EINTR)
                nwritten = 0;
            else
                return -1;
        }
        nleft -= nwritten;
        ptr += nwritten;
    }

    return n;
}

ssize_t IO::write_from_string(int fd, string &buffer)
{
    size_t nleft;
    ssize_t nwritten;
    const char *ptr;
    char size[11];
    string result;

    snprintf(size, sizeof(size), "%010d", (int)buffer.length());
    result.append(size);
    result.append(buffer);
    ptr = result.c_str();
    nleft = result.length();
    
    while (nleft > 0) {
        nwritten = send(fd, ptr, nleft, MSG_NOSIGNAL);
        if (nwritten <= 0) {
            if (errno == EINTR)
                nwritten = 0;
            else
                return -1;
        }
        nleft -= nwritten;
        ptr += nwritten;
    }

    return result.length() - 10;
}

int IO::read_to_string(int fd, string &buffer)
{
    int ret;
    char ch;
    int len;
    char buf[11];
    
    ret = safe_readn(fd, buf, 10);
    if (ret <= 0)
        return -1;
    if (ret != 10)
        return -1;
    
    buf[10] = '\0';
    
    len = atoi(buf);
    
    buffer.clear();
    for (;;) {
        ret = read(fd, &ch, 1);
        if (ret <= 0) {
            if (errno == EINTR)
                continue;
            else {
                return -1;
            }
        }
        
        buffer.append(1, ch);
        if ((int)(buffer.length()) == len)
            break;
    }
    
    return buffer.length();
}
