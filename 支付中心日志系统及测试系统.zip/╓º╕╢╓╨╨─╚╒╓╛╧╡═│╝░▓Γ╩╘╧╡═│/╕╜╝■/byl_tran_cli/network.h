#ifndef _NETWORK_H_
#define _NETWORK_H_

#include <iostream>
#include <fstream>
#include <string>

#define MAXLISTEN 0

using namespace std;

class Network {
public:
    Network();
    ~Network();
    
    static int connect_nonb(int sockfd, const struct sockaddr *saptr, socklen_t salen, int nsec);
    static int tcp_connect(const char *ip, int port, char *host_ip, int host_port, int sec);
    static int tcp_connect(const char *ip, int port, int sec);
    static int listen_sock(int port);
    static int listen_sock(const char *ip, int port);
    static int set_linger(int fd, int l_onoff, int l_linger);
    static int set_nonblocking(int fd);
    static int set_blocking(int fd);
    static int set_keepalive(int fd, int keep_alive, int keep_idle, int keep_interval, int keep_count);
    static int set_send_buf(int fd, int size);
    static int set_recv_buf(int fd, int size);
	static int set_recv_timeout(int fd, int sec);
	static int set_send_timeout(int fd, int sec);
};

#endif
