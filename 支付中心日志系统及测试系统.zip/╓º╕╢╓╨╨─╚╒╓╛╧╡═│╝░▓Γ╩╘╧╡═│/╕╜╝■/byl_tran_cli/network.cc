#include <iostream>
#include <fstream>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/tcp.h>
#include <fcntl.h>
#include <signal.h>
#include <assert.h>
#include <errno.h>
#include <syslog.h>

#include "log.h"
#include "network.h"

extern Log log;

Network::Network()
{

}

Network::~Network()
{

}

/* below code copy from UNP */
int Network::connect_nonb(int sockfd, const struct sockaddr *saptr, socklen_t salen, int nsec)
{
    int flags, n, error;
    socklen_t len;
    fd_set  rset, wset;
    struct timeval  tval;

    flags = fcntl(sockfd, F_GETFL, 0);
    fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);
	
    error = 0;
    if ((n = connect(sockfd, (struct sockaddr *)saptr, salen)) < 0) {
        if (errno != EINPROGRESS) {
            return -1;
        }
    }
    /* Do whatever we want while the connect is taking place. */
    if (n == 0)
        goto done;    /* connect completed immediately */

    FD_ZERO(&rset);
    FD_SET(sockfd, &rset);
    wset = rset;
    tval.tv_sec = nsec;
    tval.tv_usec = 0;

    if ((n = select(sockfd + 1, &rset, &wset, NULL,
                     nsec ? &tval : NULL)) == 0) {
        /* timeout */
        errno = ETIMEDOUT;
        return -1;
    }

    if (FD_ISSET(sockfd, &rset) || FD_ISSET(sockfd, &wset)) {
        len = sizeof(error);
        if (getsockopt(sockfd, SOL_SOCKET, SO_ERROR, &error, &len) < 0) {
            return -1;            /* Solaris pending error */
        }
    } else {
        log.error("File[%s] Line[%d]: select failed: %s\n",
                        __FILE__, __LINE__, strerror(errno));
	}

done:
    fcntl(sockfd, F_SETFL, flags);    /* restore file status flags */

    if (error) {
        errno = error;
        return -1;
    }
    return 0;
}

int Network::tcp_connect(const char *ip, int port, char *host_ip, int host_port, int sec)
{
    int ret;
    int fd;
    struct sockaddr_in addr;
    struct sockaddr_in host_addr;
    
    memset(&addr, 0, sizeof(struct sockaddr_in));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(ip);
    
    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        log.error("File[%s] Line[%d]: socket failed: %s\n",
                        __FILE__, __LINE__, strerror(errno));
        return -1;
    }
    
    if (host_ip) {
        memset(&host_addr, 0, sizeof(struct sockaddr_in));
        host_addr.sin_family = AF_INET;
        host_addr.sin_port = htons(host_port);
        host_addr.sin_addr.s_addr = inet_addr(host_ip);

        if (bind(fd, (struct sockaddr *) &host_addr, sizeof(host_addr)) < 0) {
			log.error("File[%s] Line[%d]: bind failed: %s\n",
							__FILE__, __LINE__, strerror(errno));
            close(fd);
            return -1;
        }
    }
    
    ret = connect_nonb(fd, (struct sockaddr*)&addr, sizeof(struct sockaddr_in), sec);
    if (ret < 0) {
		log.error("File[%s] Line[%d]: connect_nonb failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
        close(fd);
        return -1;
    }
	
	log.info("Connected to %s OK.\n", inet_ntoa(addr.sin_addr));
	
    return fd;
}

int Network::tcp_connect(const char *ip, int port, int sec)
{
    int ret;
    int fd;
    struct sockaddr_in addr;
    
    memset(&addr, 0, sizeof(struct sockaddr_in));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(ip);
    
    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        log.error("File[%s] Line[%d]: socket failed: %s\n",
                        __FILE__, __LINE__, strerror(errno));
        return -1;
    }
    
    ret = connect_nonb(fd, (struct sockaddr*)&addr, sizeof(struct sockaddr_in), sec);
    if (ret < 0) {
		log.error("File[%s] Line[%d]: connect_nonb failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
        close(fd);
        return -1;
    }
	
	log.info("Connected to %s OK.\n", inet_ntoa(addr.sin_addr));
	
    return fd;
}

int Network::listen_sock(int port)
{
    int fd;
    const int on = 1;
    struct sockaddr_in addr;
    
    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
		log.error("File[%s] Line[%d]: socket failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
        return -1;
    }
    
    if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0) {
		log.error("File[%s] Line[%d]: setsockopt failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
        close(fd);
        return -1;
    }

    memset(&addr, 0, sizeof(struct sockaddr_in));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr("0.0.0.0");

    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		log.error("File[%s] Line[%d]: bind failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
        close(fd);
        return -1;
    }

    if (listen(fd, MAXLISTEN) < 0) {
		log.error("File[%s] Line[%d]: listen failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
        close(fd);
        return -1;
    }
	
	log.info("The server is bind on %s:%d.\n", inet_ntoa(addr.sin_addr), port);
    
    return fd;
}

int Network::listen_sock(const char *ip, int port)
{
    int fd;
    const int on = 1;
    struct sockaddr_in addr;
    
    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
		log.error("File[%s] Line[%d]: socket failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
        return -1;
    }
    
    if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0) {
		log.error("File[%s] Line[%d]: setsockopt failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
        close(fd);
        return -1;
    }

    memset(&addr, 0, sizeof(struct sockaddr_in));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(ip);

    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		log.error("File[%s] Line[%d]: bind failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
        close(fd);
        return -1;
    }

    if (listen(fd, MAXLISTEN) < 0) {
		log.error("File[%s] Line[%d]: listen failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
        close(fd);
        return -1;
    }
	
	log.info("The server is bind on %s:%d.\n", inet_ntoa(addr.sin_addr), port);
    
    return fd;
}

int Network::set_linger(int fd, int l_onoff, int l_linger)
{
    int ret;
    struct linger so_linger;
    
    bzero(&so_linger, sizeof(struct linger));
    so_linger.l_onoff = l_onoff;
    so_linger.l_linger = l_linger;
    
    ret = setsockopt(fd, SOL_SOCKET, SO_LINGER, (const void*)&so_linger, sizeof(struct linger));
    if (ret < 0) {
		log.error("File[%s] Line[%d]: setsockopt failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
        return -1;
    }
    
    return 0;
}

int Network::set_nonblocking(int fd)
{
    int flags;

    flags = fcntl(fd, F_GETFL);
    if(flags < 0) {
		log.error("File[%s] Line[%d]: fcntl failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
        return -1;
    }

    flags = flags | O_NONBLOCK;
    if(fcntl(fd, F_SETFL, flags) < 0) {
		log.error("File[%s] Line[%d]: fcntl failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
        return -1;
    }
    
    return 0;
}

int Network::set_blocking(int fd)
{
    int flags;

    flags = fcntl(fd, F_GETFL);
    if(flags < 0) {
		log.error("File[%s] Line[%d]: fcntl failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
        return -1;
    }

    flags = flags & ~O_NONBLOCK;
    if(fcntl(fd, F_SETFL, flags) < 0) {
		log.error("File[%s] Line[%d]: fcntl failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
        return -1;
    }
    
    return 0;
}

/* Setting SO_TCP KEEPALIVE */
//int keep_alive = 1;//�趨KeepAlive
//int keep_idle = 5;//��ʼ�״�KeepAlive̽��ǰ��TCP�ձ�ʱ��
//int keep_interval = 5;//����KeepAlive̽����ʱ����
//int keep_count = 3;//�ж��Ͽ�ǰ��KeepAlive̽�����
int Network::set_keepalive(int fd, int keep_alive, int keep_idle, int keep_interval, int keep_count)
{
    if (keep_alive) {
        if (setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE,
                            (void*)&keep_alive, sizeof(keep_alive)) == -1) {
			log.error("File[%s] Line[%d]: setsockopt failed: %s\n",
							__FILE__, __LINE__, strerror(errno));
            return -1;
        }
        
        if (setsockopt(fd, SOL_TCP, TCP_KEEPIDLE,
                            (void *)&keep_idle,sizeof(keep_idle)) == -1) {
			log.error("File[%s] Line[%d]: setsockopt failed: %s\n",
							__FILE__, __LINE__, strerror(errno));
            return -1;
        }
		
        if (setsockopt(fd,SOL_TCP,TCP_KEEPINTVL,
                            (void *)&keep_interval, sizeof(keep_interval)) == -1) {
			log.error("File[%s] Line[%d]: setsockopt failed: %s\n",
							__FILE__, __LINE__, strerror(errno));
            return -1;
        }
		
        if (setsockopt(fd,SOL_TCP,TCP_KEEPCNT,
                            (void *)&keep_count,sizeof(keep_count)) == -1) {
			log.error("File[%s] Line[%d]: setsockopt failed: %s\n",
							__FILE__, __LINE__, strerror(errno));
            return -1;
        }
    }
    
    return 0;
}

int Network::set_send_buf(int fd, int size)
{
    int ret;
	
	ret = setsockopt(fd, SOL_SOCKET, SO_SNDBUF, (char *)&size, sizeof(size));
	if (ret < 0) {
		log.error("File[%s] Line[%d]: setsockopt failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
		return -1;
	}
	
	return 0;
}

int Network::set_recv_buf(int fd, int size)
{
	int ret;
	
    ret = setsockopt(fd, SOL_SOCKET, SO_RCVBUF, (char *)&size, sizeof(size));
	if (ret < 0) {
		log.error("File[%s] Line[%d]: setsockopt failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
		return -1;
	}
	
	return 0;
}

int Network::set_recv_timeout(int fd, int sec)
{
    int ret;
    struct timeval tv;
    
    tv.tv_sec = sec;
    tv.tv_usec = 0;
    ret = setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, (struct timeval *)&tv, sizeof(struct timeval));
	if (ret < 0) {
		log.error("File[%s] Line[%d]: setsockopt failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
		return -1;
	}
    
    return 0;
}

int Network::set_send_timeout(int fd, int sec)
{
    int ret;
    struct timeval tv;
    
    tv.tv_sec = sec;
    tv.tv_usec = 0;
    ret = setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, (struct timeval *)&tv, sizeof(struct timeval));
	if (ret < 0) {
		log.error("File[%s] Line[%d]: setsockopt failed: %s\n",
						__FILE__, __LINE__, strerror(errno));
		return -1;
	}
    
    return 0;
}
