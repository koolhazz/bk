#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>

#include "dns.h"

static struct hostent *gethostbyname_reentrant(const char *host, struct hostent *hostbuf, char **tmphstbuf, size_t *hstbuflen);

static struct hostent *gethostbyname_reentrant(const char *host, struct hostent *hostbuf, char **tmphstbuf, size_t *hstbuflen)
{
    struct hostent *hptr;
    int herr, res;

    if (*hstbuflen == 0) {
        *hstbuflen = 1024;
        *tmphstbuf = (char *)malloc(*hstbuflen);
    }

    while (( res = 
			gethostbyname_r(host, hostbuf, *tmphstbuf, *hstbuflen, &hptr, &herr))
            && (errno == ERANGE)) {
        /* Enlarge the buffer. */
        *hstbuflen *= 2;
        *tmphstbuf = (char*)realloc(*tmphstbuf, *hstbuflen);
    }
    
    if (res)
        return NULL;
	
    return hptr;
}

Dns::Dns()
{

}

Dns::~Dns()
{

}

int Dns::host2ip(string &host, string &ip)
{
    struct hostent hostbuf,*hptr;
    char *tmphstbuf = NULL;
    size_t hstbuflen = 0;
    char **pptr;
    char str[32];
    int err = -1;
	
    hptr = gethostbyname_reentrant(host.c_str(), &hostbuf, &tmphstbuf, &hstbuflen);
    if (hptr == NULL)
        printf("gethostbyname_reentrant error\n");
    else {
#if 0
        printf("canonical hostname:%s\n",hptr->h_name);
        for(pptr = hptr->h_aliases; *pptr != NULL; pptr++)
            printf("  alias:%s\n",*pptr);
        switch(hptr->h_addrtype) {
        case AF_INET:
        case AF_INET6:
            pptr = hptr->h_addr_list;
            for(; *pptr != NULL; pptr++)
                printf("  address:%s\n", inet_ntop(hptr->h_addrtype, *pptr, str, sizeof(str)));
            break;
        default:
            printf("unknown address type\n");
            break;
        }
#endif
        switch(hptr->h_addrtype) {
        case AF_INET:
        case AF_INET6:
            pptr = hptr->h_addr_list;
            if (pptr == NULL) {
                err = -1;
                break;
            }
			ip.clear();
			ip.append(inet_ntop(hptr->h_addrtype, *pptr, str, sizeof(str)));
            err = 0;
            break;
        default:
            printf("unknown address type\n");
            err = -1;
            break;
        }
    }
    
    if (hstbuflen)
        free(tmphstbuf);
    
    return err;
}
