#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/epoll.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <signal.h>
#include <assert.h>
#include <errno.h>
#include <syslog.h>

#include "log.h"
#include "epoll.h"

extern Log log;

int ep_fd;

int epoll_init(void)
{
    ep_fd = epoll_create(256);
    if (ep_fd < 0) {
        log.error("File[%s] Line[%d]: epoll_create failed: %s\n",
                        __FILE__, __LINE__, strerror(errno)); 
        return -1;
    }
    
    return ep_fd;
}

void epoll_deinit(void)
{
    close(ep_fd);
}

int add_read_event(struct spec_event *st, int fd, handler_t handler)
{
    int ret;
    struct epoll_event ev;
    
    st->fd = fd;
    st->handler = handler;
    
    ev.data.ptr = (void *)st;
    ev.events = EPOLLIN | EPOLLET;
    ret = epoll_ctl(ep_fd, EPOLL_CTL_ADD, fd, &ev);
    if (ret < 0) {
        log.error("File[%s] Line[%d]: epoll_ctl failed: %s [%d]\n",
                        __FILE__, __LINE__, strerror(errno), errno); 
        return -1;
    }
    
    return 0;
}

int mod_read_event(struct spec_event *st, int fd, handler_t handler)
{
    int ret;
    struct epoll_event ev;
    
    st->fd = fd;
    st->handler = handler;
    
    ev.data.ptr = (void *)st;
    ev.events = EPOLLIN | EPOLLET;
    ret = epoll_ctl(ep_fd, EPOLL_CTL_MOD, fd, &ev);
    if (ret < 0) {
        log.error("File[%s] Line[%d]: epoll_ctl failed: %s [%d]\n",
                        __FILE__, __LINE__, strerror(errno), errno); 
        return -1;
    }
    
    return 0;
}

int add_write_event(struct spec_event *st, int fd, handler_t handler)
{
    int ret;
    struct epoll_event ev;
    
    st->fd = fd;
    st->handler = handler;
    
    ev.data.ptr = (void *)st;
    ev.events = EPOLLOUT | EPOLLET;
    ret = epoll_ctl(ep_fd, EPOLL_CTL_ADD, fd, &ev);
    if (ret < 0) {
        log.error("File[%s] Line[%d]: epoll_ctl failed: %s [%d]\n",
                        __FILE__, __LINE__, strerror(errno), errno); 
        return -1;
    }
    
    return 0;
}

int mod_write_event(struct spec_event *st, int fd, handler_t handler)
{
    int ret;
    struct epoll_event ev;
    
    st->fd = fd;
    st->handler = handler;
    
    ev.data.ptr = (void *)st;
    ev.events = EPOLLOUT | EPOLLET;
    ret = epoll_ctl(ep_fd, EPOLL_CTL_MOD, fd, &ev);
    if (ret < 0) {
        log.error("File[%s] Line[%d]: epoll_ctl failed: %s [%d]\n",
                        __FILE__, __LINE__, strerror(errno), errno); 
        return -1;
    }
    
    return 0;
}

int del_event(int fd)
{
    int ret;
    struct epoll_event ev;
    
    //ev.data.fd = 0;
    ev.data.ptr = NULL;
    ev.events = 0;
    
    ret = epoll_ctl(ep_fd,  EPOLL_CTL_DEL, fd, &ev);
    if (ret < 0) {
        log.error("File[%s] Line[%d]: epoll_ctl failed: %s\n",
                        __FILE__, __LINE__, strerror(errno)); 
        return -1;
    }
    
    return 0;
}

int do_events_loop(void)
{
    int n;
    int nfds;
    static struct epoll_event events[1000];
    struct spec_event *st;
    int fd;
    handler_t handler;

    while (1) {
        nfds = epoll_wait(ep_fd, events, 1000, -1);
        if (nfds < 0) {
            log.error("File[%s] Line[%d]: epoll_wait failed: %s[%d]\n",
                        __FILE__, __LINE__, strerror(errno), errno); 
        }
        for(n = 0; n < nfds; n++) {
            st = (struct spec_event *)events[n].data.ptr;
            if (st) {
                fd = st->fd;
                handler = st->handler;
                if (handler) {
                    handler(fd);
                } else {
                    close(fd);
                }
            }
        }
    }
}
