#ifndef _IO_H_
#define _IO_H_

#include <iostream>
#include <fstream>
#include <string>

#include <time.h>

using namespace std;

class IO {
public:
    IO();
    ~IO();
	
    static ssize_t safe_readn(int fd, void *buf, size_t n);
    static ssize_t safe_read(int fd, char *buf, size_t n);
    static ssize_t safe_writen(int fd, const void* buf, size_t n);
    static ssize_t write_from_string(int fd, string &buffer);
    static int read_to_string(int fd, string &buffer);
};

#endif
