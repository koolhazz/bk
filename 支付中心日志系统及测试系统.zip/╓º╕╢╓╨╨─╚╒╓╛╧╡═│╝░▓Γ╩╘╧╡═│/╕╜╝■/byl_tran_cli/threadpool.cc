#include "log.h"
#include "threadpool.h"

using namespace std;

extern Log log;

ThreadPool::ThreadPool(int nthread)
{
	if (nthread > MAX_THREAD_NUM || nthread <= 0)
		_nthread = MAX_THREAD_NUM;
	else
		_nthread = nthread;
	
	for (int i = 0; i < _nthread; i++) {
		_nready[i] = 0;
		pthread_mutex_init(&_mutex[i], NULL);
		pthread_cond_init(&_cond[i], NULL);
		_queue[i].clear();
	}
}

ThreadPool::~ThreadPool()
{
	for (int i = 0; i < _nthread; i++) {
		pthread_mutex_lock(&_mutex[i]); 
		_queue[i].clear();
		pthread_mutex_unlock(&_mutex[i]);
		
		pthread_mutex_destroy(&_mutex[i]);
		pthread_cond_destroy(&_cond[i]);
	}
}

void ThreadPool::start()
{
	int retval;
    pthread_attr_t attr;
	
	_run = 1;
	pthread_attr_init(&attr);
	for (int i = 0; i < _nthread; i++) {
        pthread_t tid = 0;
		Arg *arg = new Arg(this, i);
		retval = pthread_create(&tid, &attr, process_task, (void*)arg);
		if (retval  < 0) {
			log.error("File[%s] Line[%d]: pthread_create failed: %s\n",
							__FILE__, __LINE__, strerror(errno));
			exit(1);
		}
        _pid.push_back(tid);
	}
}

void ThreadPool::stop(void)
{
	_run = 0;
}

void ThreadPool::join(void)
{
    vector<pthread_t>::iterator iter = _pid.begin();   
    while(iter != _pid.end()) {   
        // pthread_cancel(*iter);   
        pthread_join(*iter, NULL);   
        iter++;   
    }
}


void ThreadPool::finish_handler()
{

}

void *ThreadPool::process_task(void *args)
{
	Arg *arg = (Arg*)args;
	ThreadPool *self = arg->tp;
	int thread_no = arg->thread_no;
	delete arg;
	
	Task *task;
	while (self->_run) {
        self->get_task(thread_no, task);
		// log.info("thread no: %d\n", thread_no);
		task->run();
        delete task;
	}
	
    pthread_exit((void*)0);
}
  
int ThreadPool::put_task(int thread_no, Task *task)
{
	pthread_mutex_lock(&_mutex[thread_no]);
	_queue[thread_no].push_back(task);
	_nready[thread_no]++;
	pthread_mutex_unlock(&_mutex[thread_no]);
    pthread_cond_signal(&_cond[thread_no]);
    
	return 0;
}

int ThreadPool::get_task(int thread_no, Task* &task)
{
	pthread_mutex_lock(&_mutex[thread_no]); 
	while (_nready[thread_no] == 0)
		  pthread_cond_wait(&_cond[thread_no], &_mutex[thread_no]);
	_nready[thread_no]--;
	task = _queue[thread_no].front();
	_queue[thread_no].pop_front();
	pthread_mutex_unlock(&_mutex[thread_no]);
	return 0;
}

int ThreadPool::get_task(int thread_no, Task* &task, int sec)
{
	timeval now;
	struct timespec timeout;
	int retval = 0;
	
	pthread_mutex_lock(&_mutex[thread_no]); 
	while (_nready[thread_no] == 0) {
		gettimeofday(&now, NULL);
		timeout.tv_sec = now.tv_sec + sec;
		timeout.tv_nsec = now.tv_usec * 1000;
		retval = pthread_cond_timedwait(&_cond[thread_no], &_mutex[thread_no], &timeout);
		if (retval == ETIMEDOUT) {
			pthread_mutex_unlock(&_mutex[thread_no]);
			return -1;
		}
	}
	_nready[thread_no]--;
	task = _queue[thread_no].front();
	_queue[thread_no].pop_front();
	pthread_mutex_unlock(&_mutex[thread_no]);
	return 0;
}
