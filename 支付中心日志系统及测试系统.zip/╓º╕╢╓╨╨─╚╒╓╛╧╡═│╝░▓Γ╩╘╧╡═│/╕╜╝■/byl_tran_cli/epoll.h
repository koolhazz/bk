#ifndef _EPOLL_H_
#define _EPOLL_H_

#ifdef    __cplusplus
extern "C" {
#endif

typedef int (*handler_t)(int);

struct spec_event {
    int fd;
    int flags;
    handler_t handler;
};

int epoll_init(void);
void epoll_deinit(void);
int add_read_event(struct spec_event *st, int fd, handler_t handler);
int mod_read_event(struct spec_event *st, int fd, handler_t handler);
int add_write_event(struct spec_event *st, int fd, handler_t handler);
int mod_write_event(struct spec_event *st, int fd, handler_t handler);
int del_event(int fd);
int do_events_loop(void);

#ifdef    __cplusplus
}
#endif

#endif    /* _EPOLL_H_ */
