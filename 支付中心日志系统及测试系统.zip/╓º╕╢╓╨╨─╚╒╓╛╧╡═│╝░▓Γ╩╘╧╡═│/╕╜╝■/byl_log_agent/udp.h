#ifndef _UDP_H_
#define _UDP_H_

#include <string>
#include <iostream>

using namespace std;

int bind_udp(string host, int port);

#endif
