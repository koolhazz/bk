#ifndef _SPLIT_H_
#define _SPLIT_H_

#include <string>
#include <vector>
#include <iostream>

using namespace std;

int split(const string& src, const char s, vector<string> &result);

#endif
