#include "Crypto.h"
#include <openssl/md5.h>
#include <stdio.h>
#include <string.h>

int
md5(const char* src, char* dest, unsigned short len)
{
	 unsigned char md5_str[16] = {0};
	 
	 MD5((unsigned char*)src, strlen(src), md5_str);
	 
	 for(int i = 0; i < sizeof(md5_str); i++)
	 {
	     snprintf(dest + (i * 2), 3, "%02X", md5_str[i]);
	 }
 
	 return 0;
}
