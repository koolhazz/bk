#include "Request.h"
#include "HttpRequest.h"
#include "RedisHelper.h"
#include "Log.h"
#include "ConfigDef.h"
#include "Crypto.h"

#include <stdio.h>
#include <unistd.h>
#include <libgen.h>
#include <limits.h>
#include <stdlib.h>

using namespace Helper;

static const char* const CONFIG_FILE = "../etc/server.ini";
static const unsigned short SLEEP_TIME = 30; // second

bool is_daemon = false;

static ERedisConf redis_conf;
static EInterfaceConf interface_conf;
static EQueueConf queue_conf;

static
void
print_conf();

static
void 
CDWorkDir(const char * path);

#ifdef _DAEMON_
	#define printf(fmt, args...) log_debug(fmt, ##args)
#endif

int
main(int argc, char** argv)
{
    CDWorkDir(argv[0]);
	 
#ifdef _DAEMON_
    if (daemon(1, 0) == 0)
    {
        is_daemon = true;
    }
#endif

    char log_name[30] = {0};

    snprintf(log_name, 30, "Log_%d", getpid());

    init_log(log_name, "../log");
	 
    printf("server running...\n");
	 	 
    GetRedisConf(&redis_conf, CONFIG_FILE);
    GetInterfaceConf(&interface_conf, CONFIG_FILE);
    GetQueueConf(&queue_conf, CONFIG_FILE);

    print_conf();

    HttpRequest request;
    Helper::CRedisHelper redis(redis_conf.host, redis_conf.port);

	while (1) 
	{
		string json; //= "{\"game_id\":1, \"lang\":1, \"level\":50, \"online_time\":1000, \"platform_id\":1, \"play_rounds\":10, \"userid\":\"8268e2a88f3bd6866559d658d8aa3ea6\", \"win_rounds\":5}";

		if (!redis.IsActived()) 
		{
			printf("redis reconnect.\n");
			redis.Connect();
		}

		json = redis.Dequeue(queue_conf.name, json);

		printf("JSON: %s\n", json.c_str());

		if (json.size() == 0) 
		{
			sleep(SLEEP_TIME);
			continue;
		}

		char md5_str[33] = {0};

		md5((json + interface_conf.md5).c_str(),  md5_str, 33);

		//printf("Prepare MD5: %s\n", (json + interface_conf.md5).c_str());

		printf("MD5: %s\n", md5_str);

		char complate_url[500] = {0};

		snprintf(complate_url, 500, interface_conf.url, json.c_str(), md5_str);
		 
		printf("URL: %s\n", complate_url);

		int ret = BonusProcessReq(&request, complate_url);

		log_debug("Request Return: %d\n", ret);

		sleep(SLEEP_TIME);
		 
	}
    return 0;
}

void print_conf()
{
	 printf("----------------------------------------\n");
	 printf("redis->host: %s\n", redis_conf.host);
	 printf("redis->port: %d\n", redis_conf.port);
	 printf("----------------------------------------\n");
	 printf("interface->url: %s\n", interface_conf.url);
	 printf("----------------------------------------\n");
	 printf("queue->name: %s\n", queue_conf.name);
	 printf("----------------------------------------\n");
}

void CDWorkDir(const char * path)
{
	char* rpath = realpath(path, NULL);

	char* p = dirname(rpath);

	int i = chdir(p);

	free(rpath);
}
