#include "Request.h"
#include "HttpRequest.h"


int 
BonusProcessReq(HttpRequest* request, const string& url)
{
	 if (!request)
	 {
	    return 99;
	 }

	 int ret = request->Get(url);
	 
	 return ret;
}


