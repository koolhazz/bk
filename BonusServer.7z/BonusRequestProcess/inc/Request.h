#ifndef __REQUEST_H__
#define __REQUEST_H__
#include <string>

using namespace std;

class HttpRequest;

extern 
int 
BonusProcessReq(HttpRequest* request, const string& url);

#endif
