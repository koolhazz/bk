#ifndef __HTTP_REQUEST_H_
#define __HTTP_REQUEST_H_
	
#include <string>
#include <curl/curl.h>

using namespace std;

class HttpRequest
{
public:
    HttpRequest() {}
    ~HttpRequest() {}
public:
	 int Get(const string& url);
	 string& Get(const string& url, string& result);
private:
	 CURL* m_curl;
	 CURLcode m_res;
private:
	 HttpRequest(const HttpRequest& rsh) {}
	 HttpRequest& operator =(const HttpRequest& rsh) { return *this; }
};

	
#endif
