#ifndef __RULE_DEF_H_
#define __RULE_DEF_H_

#include "BonusDef.h"
 
typedef enum
{
	OP_PLUS = 	1,
	OP_MINUS = 	2,
	OP_MULTI = 	3,
	OP_DIV = 	4
}ERuleOperation;


typedef enum
{
	RT_DIR = 0,
	RT_LOGIN = 1,
	RT_WIN = 2,
	RT_ROUND = 3,
	RT_INVITE = 4,
	RT_FEED = 5,
	RT_FEED_CK = 6,
	RT_CHARGE = 7,
	RT_CG_NUMS = 8,
	RT_ONLINE = 9
}ERuleType;
 
typedef struct tagRuleItem
{
	 unsigned int 	rid;
	 unsigned short level;
	 unsigned short	type;
	 unsigned char	lang;
	 unsigned int	basic_value;
	 ERuleOperation	op;
	 unsigned int	bonus_value;
	 unsigned short	game_id;
	 unsigned short	platform_id;
	 bool			is_open;
	 unsigned int   end_date;
}ERuleItem,*pERuleItem;

typedef struct tagRuleList
{
	 pERuleItem 	item;
	 unsigned short nums; 
}ERuleList, *pERuleList;

namespace Helper
{
	class CMysqlHelper;
}

using namespace Helper;

extern ERuleList g_RuleList;

extern
int
GetRuleList(CMysqlHelper* mysql, pERuleList list, pEBonusItem item);

extern
int
Find_Rule(pERuleList list, const unsigned short type, const unsigned short level, const unsigned short value);

extern
short 
NextType(pERuleList list, const unsigned short prev = 0);

#endif
