#ifndef __BONUS_DEF_H_
#define __BONUS_DEF_H_
	 
static const unsigned short MAX_LEVEL_NUMS = 10;	 
	 
typedef struct
{
	unsigned short 	platform_id;	// 来源平台ID
	unsigned short 	game_id;		// 游戏ID	
	unsigned short 	level;
	char			userid[33];
	unsigned int	online_time;
	unsigned short	lang;
	//unsigned short	play_rounds[MAX_LEVEL_NUMS]; //保存所有级别房间玩的回合
	//unsigned short	win_rounds[MAX_LEVEL_NUMS];  //保存所有级别房间赢的回合数
	unsigned short 	play_rounds;
	unsigned short 	win_rounds;	
}EBonusItem, *pEBonusItem;


#endif
