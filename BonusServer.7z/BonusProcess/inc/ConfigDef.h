#ifndef __CONFIG_DEF_H_
#define __CONFIG_DEF_H_

typedef struct 
{
	 char		host[15];
	 unsigned short port;
}ERedisConf, *pERedisConf;

typedef struct
{
	 char	name[50];
}EQueueConf, *pEQueueConf;

typedef struct
{
    char		host[15];
    unsigned short port;
    char		db[50];
    char		user[50];
    char		password[50];
}EMysqlConf, *pEMysqlConf;

extern ERedisConf redis_conf;
extern EMysqlConf mysql_conf;
extern EQueueConf queue_conf;

extern
int
GetRedisConf(pERedisConf conf, const char* file);

extern
int
GetQueueConf(pEQueueConf conf, const char* file);

extern
int
GetMysqlConf(pEMysqlConf conf, const char* file);

#endif
