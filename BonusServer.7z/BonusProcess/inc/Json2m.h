#ifndef __JSON2M_H_
#define __JSON2M_H_

#include "BonusDef.h"
#include <string>

using namespace std;


extern 
int
Json2EBonusItem(const string& json, pEBonusItem item);

#endif
