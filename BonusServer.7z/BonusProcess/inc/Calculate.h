#ifndef __CALCULATE_H_
#define __CALCULATE_H_

#include "RuleDef.h"
#include "BonusDef.h"

namespace Helper
{
	 class CMysqlHelper;
}

using namespace Helper;


/*
 *Function Name:bonus_calc
 *
 *Parameters:	list	item	user_value
 *
 *Description: 计算积分
 *
 *Returns:	0: success 
 *			1: failed 
 *
 */
extern
int 
bonus_calc(CMysqlHelper* mysql, pERuleList list, pEBonusItem item, unsigned int user_value);


/*
 *Function Name:bonus_write
 *
 *Parameters: mysql	userid	sid	value
 *
 *Description: 积分入库, 并写积分日志
 *
 *Returns:	0: success 
 *			1: failed 
 *
 */
extern
int
bonus_write(CMysqlHelper* mysql, const pERuleItem rule, const pEBonusItem item, int value);


/*
 *Function Name:bonus_read
 *
 *Parameters:	mysql	userid	sid
 *
 *Description:	获取用户积分
 *
 *Returns:	0: success 
 *			1: failed 
 *
 */
extern
int
bonus_read(CMysqlHelper* mysql, const char* userid, const int sid);

#endif
