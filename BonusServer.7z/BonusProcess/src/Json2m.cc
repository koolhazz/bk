#include "Json2m.h"
#include <json/json.h>


int
Json2EBonusItem(const string& json, pEBonusItem item)
{
	Json::Value value;
	Json::Reader reader;

	if (reader.parse(json, value)) 
	{
		item->game_id = value["game_id"].asInt();
		item->platform_id = value["platform_id"].asInt();
		strncpy(item->userid, value["userid"].asString().c_str(), 32);
		item->level = value["level"].asInt();
		item->win_rounds = value["win_rounds"].asInt();
		item->play_rounds = value["play_rounds"].asInt();
		item->lang = value["lang"].asInt();
		item->online_time = value["online_time"].asInt();

		return 0;
	}

	return 1;
}
