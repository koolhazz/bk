#include "Calculate.h"
#include "MysqlHelper.h"
#include "RuleDef.h"
#include "ConfigDef.h"
#include "Log.h"

#include <string>
#include <stdio.h>

using namespace std;
using namespace Helper;

extern EMysqlConf mysql_conf;

static
bool
IsLimited(CMysqlHelper* mysql, const pERuleItem rule, const char* user_id);

int 
bonus_calc(CMysqlHelper* mysql, pERuleList list, pEBonusItem item, unsigned int user_value)
{
	int user_bonus = 0;

	short curr_type = 0;

	int rule_pos = 0;

	while((curr_type = NextType(list, curr_type)) >= 0)
	{
		switch(curr_type)
		{
		case RT_ONLINE: 
			rule_pos = Find_Rule(list, curr_type, item->level, item->online_time);

			if (rule_pos < 0)
			{
				user_bonus = 0;
			}

			switch((list->item + rule_pos)->op)
			{
				case OP_PLUS:
					user_bonus = (list->item + rule_pos)->bonus_value;
					break;

				case OP_MINUS:
					user_bonus = user_value - (list->item + rule_pos)->bonus_value;
					break;

				case OP_MULTI:
					user_bonus = user_value * (list->item + rule_pos)->bonus_value;
					break;

				case OP_DIV:
					user_bonus = user_value / (list->item + rule_pos)->bonus_value;
					break;
			}

			break;

		case RT_ROUND:
			rule_pos = Find_Rule(list, curr_type, item->level, item->online_time);

			if (rule_pos < 0)
			{
				user_bonus = 0;
			}

			switch((list->item + rule_pos)->op)
			{
				case OP_PLUS:
					user_bonus = (list->item + rule_pos)->bonus_value;
					break;

				case OP_MINUS:
					user_bonus = user_value - (list->item + rule_pos)->bonus_value;
					break;

				case OP_MULTI:
					user_bonus = user_value * (list->item + rule_pos)->bonus_value;
					break;

				case OP_DIV:
					user_bonus = user_value / (list->item + rule_pos)->bonus_value;
					break;
			}
			break;

		case RT_WIN:
			rule_pos = Find_Rule(list, curr_type, item->level, item->online_time);

			if (rule_pos < 0)
			{
				user_bonus = 0;
			}

			switch((list->item + rule_pos)->op)
			{
				case OP_PLUS:
					user_bonus = (list->item + rule_pos)->bonus_value;
					break;

				case OP_MINUS:
					user_bonus = user_value - (list->item + rule_pos)->bonus_value;
					break;

				case OP_MULTI:
					user_bonus = user_value * (list->item + rule_pos)->bonus_value;
					break;

				case OP_DIV:
					user_bonus = user_value / (list->item + rule_pos)->bonus_value;
					break;
			}
			break;
		default:
			user_bonus = 0;

			break;
		}

		log_debug("User_Bonus: %d RuleID: %d\n", user_bonus, (list->item + rule_pos)->rid);

		//积分为零的话，就计算下一条
		if (user_bonus == 0) 
		{
			continue;
		}

		// 判断限制并将积分写入数据库
		if (!IsLimited(mysql, list->item + rule_pos, item->userid)) 
		{
			log_debug("write %s--%d bonus %d with rule: %d \n", item->userid, item->platform_id, user_bonus, (list->item + rule_pos)->rid);
			bonus_write(mysql, list->item + rule_pos, item, user_bonus);
		}
		else
		{
			log_debug("type limited with %d\n", (list->item + rule_pos)->type);
		}
	}

	return user_bonus;
}


int
bonus_write(CMysqlHelper* mysql, const pERuleItem rule, const pEBonusItem item, int value)
{
    //string sql_temp = "update shopuser set money = money + %d where sitemid='%s' and sid=%d";

	string sql_temp = "call p_Upd_User_Money('%s', %d, %d)";

    char sql_str[200] = {0};

    //snprintf(sql_str, 200, sql_temp.c_str(), value, item->userid, item->platform_id);
    snprintf(sql_str, 200, sql_temp.c_str(), item->userid, item->platform_id, value);

    if(!mysql->IsConnected())
	{
		mysql->Connect();
		mysql->UseDB(mysql_conf.db);
	}

	log_debug("SQL: %s\n", sql_str);

    int ret = mysql->ExecuteNonQuery(sql_str);

    string sql_temp_2 = "call p_Add_Money_Log('%s', %d, %d, %d, %d, %d)";

    memset(sql_str, 0, 200);

    snprintf(sql_str, 200, sql_temp_2.c_str(), item->userid, item->platform_id, rule->rid, rule->type, value, rule->op);

    if(!mysql->IsConnected())
	{
		mysql->Connect();
		mysql->UseDB(mysql_conf.db);
	}

	ret = mysql->ExecuteNonQuery(sql_str);

	return ret;
}

int
bonus_read(CMysqlHelper* mysql, const char* userid, const int sid)
{
	string sql_temp = "select money from shopuser where sitemid = '%s' and sid=%d";

	char sql_str[200] = {0};
	
	snprintf(sql_str, 200, sql_temp.c_str(), userid, sid);

	if (!mysql->IsConnected())
	{
		mysql->Connect();
		mysql->UseDB(mysql_conf.db);
	}

	log_debug("SQL: %s\n", sql_str);

	int user_value = 0;

	CMysqlResult* ret = mysql->ExecuteQuery(sql_str);

	if (ret->HasNext()) 
	{
		user_value = ret->GetInt(0);
	}

	return user_value;
}

bool
IsLimited(CMysqlHelper* mysql, const pERuleItem rule, const char* user_id)
{
	log_debug("---------- IsLimited begin ----------");
	if (!mysql) 
	{
		log_error("mysql is null\n");

		log_debug("---------- IsLimited end 1 ----------");
		return false;
	}

	string sql_temp = "call p_Is_Limited(%d, %d, %d, '%s', %d)";

	char sql_str[300] = {0};

	int ret = 0;
	snprintf(sql_str, 300, sql_temp.c_str(), rule->type, rule->game_id, rule->lang, user_id, rule->platform_id);

	log_debug("SQL: %s\n", sql_str);

	CMysqlResult* result  = mysql->ExecuteQuery(sql_str);

	if (result) 
	{
		while (result->HasNext()) 
		{
			ret = result->GetInt(0);

			log_debug("ret: %d\n", ret);
		}
	}

	log_debug("---------- IsLimited end 2 ----------");
	return ret ? true : false;
}
