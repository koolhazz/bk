#include "ConfigDef.h"
#include "IniFile.h"

int
GetRedisConf(pERedisConf conf, const char* file)
{
	 read_profile_string("redis", "host", conf->host, sizeof(conf->host), "", file);
	 conf->port =  read_profile_int("redis", "port", 6370, file);
	 
	 return 0;
}

int
GetMysqlConf(pEMysqlConf conf, const char* file)
{
	 read_profile_string("mysql", "host", conf->host, sizeof(conf->host), "", file);
	 read_profile_string("mysql", "db", conf->db, sizeof(conf->db), "", file);
	 conf->port = read_profile_int("mysql", "port", 3308, file);
	 read_profile_string("mysql", "user", conf->user, sizeof(conf->user), "", file);
	 read_profile_string("mysql", "password", conf->password, sizeof(conf->password), "", file);

	 return 0;
}

int
GetQueueConf(pEQueueConf conf, const char* file)
{
	return read_profile_string("queue", "key", conf->name, sizeof(conf->name), "", file);
}
