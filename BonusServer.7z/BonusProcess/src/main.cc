#include "Log.h"
#include "ConfigDef.h"
#include "RuleDef.h"
#include "MysqlHelper.h"
#include "RedisHelper.h"
#include "Json2m.h"
#include "Calculate.h"

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <libgen.h>

static
void
Init(int argc, char** argv);

static
void
Process();

static
void
print_conf();

static
void 
ChCurrDir(const char* path);

static const char* const CONFIG_FILE = "../etc/server.ini";
static const unsigned short SLEEP_TIME = 30; // second

bool is_daemon = false;


#ifdef _DAEMON_
	#define printf(fmt, arg...) log_debug(fmt, ##arg)
#endif

ERedisConf redis_conf;
EMysqlConf mysql_conf;
EQueueConf queue_conf;



int
main(int argc, char** argv)
{
	Init(argc, argv);

    Process();

	return 0;
}

void 
Init(int argc, char** argv)
{
	ChCurrDir(argv[0]);

#ifdef _DAEMON_
    if (daemon(1, 0) == 0)
    {
        is_daemon = true;
    }
#endif

	char log_name[100];

	snprintf(log_name, 100, "Log_%d", getpid());

	init_log(log_name, "../log");

	GetMysqlConf(&mysql_conf, CONFIG_FILE);
	GetRedisConf(&redis_conf, CONFIG_FILE);
	GetQueueConf(&queue_conf, CONFIG_FILE);

	print_conf();
}

void 
print_conf()
{
    printf("----------------------------------------\n");
    printf("redis->host: %s\n", redis_conf.host);
    printf("redis->port: %d\n", redis_conf.port);
    printf("----------------------------------------\n");
    printf("mysql->host: %s\n", mysql_conf.host);
    printf("mysql->port: %d\n", mysql_conf.port);
    printf("mysql->db: %s\n", mysql_conf.db);
    printf("mysql->user: %s\n", mysql_conf.user);
    printf("mysql->password: %s\n", mysql_conf.password);
    printf("----------------------------------------\n");
    printf("queue->name: %s\n", queue_conf.name);
    printf("----------------------------------------\n");
}

void
Process()
{
    Helper::CRedisHelper redis(redis_conf.host, redis_conf.port);

	Helper::CMysqlHelper mysql(mysql_conf.host, mysql_conf.port, mysql_conf.user, mysql_conf.password);

    while(1)
	{
		if (!redis.IsActived()) 
		{
			printf("redis reconnect.\n");
			redis.Connect();
		}

		string json;
		json = redis.Dequeue(queue_conf.name, json);

		//json = "{\"game_id\":1, \"lang\":1, \"level\":50, \"online_time\":1000, \"platform_id\":1, \"play_rounds\":10, \"userid\":\"8268e2a88f3bd6866559d658d8aa3ea6\", \"win_rounds\":5}";

		printf("JSON: %s\n", json.c_str());

		if (json.size())
		{
			EBonusItem item = {0};
			ERuleList rule_list = {0};

			if (!Json2EBonusItem(json, &item))
			{
				printf("item->level: %d\n", item.level);
			}
			else
			{
				printf("json parse error.");
				sleep(SLEEP_TIME);
				continue;
			}

			mysql.Connect();
			if(mysql.IsConnected())
			{
				mysql.UseDB(mysql_conf.db);
			}

			GetRuleList(&mysql, &rule_list, &item);

			int user_value  = bonus_read(&mysql, item.userid, item.platform_id);

			printf("Org: %d\n", user_value);

			int ret = bonus_calc(&mysql, &rule_list, &item, user_value);

			free(rule_list.item);
	    }

		sleep(SLEEP_TIME);
	 }

}

void
ChCurrDir(const char* path)
{
    char* pReal = realpath(path, NULL);

    char* p = dirname(pReal);

    int i;
    
    i = chdir(p);

    free(pReal);
}
