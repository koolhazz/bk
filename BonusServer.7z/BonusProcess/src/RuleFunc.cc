#include "RuleDef.h"
#include "MysqlHelper.h"
#include "ConfigDef.h"
#include "Log.h"

#include <string>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

ERuleList g_RuleList = {0};


static
void
Print_RuleList(pERuleList list);


int
GetRuleList(CMysqlHelper* mysql, pERuleList list, pEBonusItem item)
{
	if (!mysql)
	{
		return 1;
	}

	string sql_temp = "select id, type, term, base, oper, price, app, site, lang, status, expiry from codex " \
			   "where app=%d and site=%d and lang=%d and status=1 and type in (2, 3, 9) and expiry>=unix_timestamp(now()) order by type, term desc, base desc";

	char sql_str[500] = {0};

	snprintf(sql_str, 500, sql_temp.c_str(), item->game_id, item->platform_id, item->lang);

	log_debug("SQL: %s\n", sql_str);

	if (!mysql->IsConnected())
	{
		mysql->Connect();
		mysql->UseDB(mysql_conf.db);
	}

	CMysqlResult* query_result = mysql->ExecuteQuery(sql_str);

	if (!query_result)
	{
		log_debug("query_result is null.\n");
		return -1;
	}

	int rc_nums = query_result->GetRows();

	list->item = (pERuleItem)malloc(sizeof(ERuleItem) * rc_nums);

	list->nums = rc_nums;

	int i = 0;

	while(query_result->HasNext())
	{
		(list->item + i)->rid = query_result->GetInt(0);
		(list->item + i)->type = query_result->GetInt(1);
		(list->item + i)->level = query_result->GetInt(3);
		(list->item + i)->basic_value = query_result->GetInt(2);
		(list->item + i)->op = (ERuleOperation)query_result->GetInt(4);
		(list->item + i)->bonus_value = query_result->GetInt(5);
		(list->item + i)->game_id = query_result->GetInt(6);
		(list->item + i)->platform_id = query_result->GetInt(7);
		(list->item + i)->lang = query_result->GetInt(8);
		(list->item + i)->is_open = query_result->GetInt(9) == 1 ? true : false;
		(list->item + i)->end_date = query_result->GetInt(10);

		i++;
	}

	Print_RuleList(list);

	return 0; 
}

int
Find_Rule(pERuleList list, const unsigned short type, const unsigned short level, const unsigned short value)
{
	for (int i = 0; i < list->nums; i++)
	{
		if ((list->item + i)->type == type)
		{
			if ((list->item + i)->basic_value <= value && (list->item + i)->level == level)
			{
				return i;
			}
		}
	}

	//判断没有对应级别的规则是，要判断全级别的规则
	for(int i = 0; i < list->nums; i++)
	{
		if ((list->item + i)->type == type)
		{
			if ((list->item + i)->basic_value <= value && (list->item + i)->level == 0)
			{
				return i;
			}
		}
	}

	return -1;
}

short 
NextType(pERuleList list, const unsigned short prev)
{
	log_debug("Prev Type: %d\n", prev);

	for(int i = 0; i < list->nums; i++)
	{
		if ((list->item + i)->type > prev)
		{
			log_debug("Next Type: %d\n", (list->item + i)->type);
			return (list->item + i)->type;
		}
	}

	log_debug("Next Type: %d\n", -1);
	return -1;
}

void
Print_RuleList(pERuleList list)
{
    pERuleItem item = list->item;

	for (int i = 0; i < list->nums; i++)
	{
		log_debug("ID: %d Type: %d \n", (item + i)->rid, (item + i)->type);
	}
}
