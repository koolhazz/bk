delimiter ;//

drop procedure if exists p_Is_Limited;

create procedure p_Is_Limited
(
	in r_type_id	int,
	in user_id		char(32),
	in site_id		int
)
begin
	declare user_mid int;
	declare user_money int;
	declare type_limit int;
	declare is_limited tinyint;
	
	select ifnull(mid, 0) 
	into user_mid 
	from shopuser 
	where sitemid = user_id 
	and	sid = site_id;
	
	if user_mid = 0 then
		set is_limited = 0;
	else
		select ifnull(money, 0)
		into user_money
		from log
		where mid = user_mid
		and ruletypeid = r_type_id
		and datediff(curdate(), from_unixtime(maketime)) = 0;

		if user_money = 0 then 
			set is_limited = 0;
		else # get day of limit with type
			select limitmoney
			into type_limit
			from codex
			where type = r_type_id
			limit 1;

			if user_money >= type_limit and type_limit >= 0 then
				set is_limited = 1;
			else
				set is_limited = 0;
			end if;
		end if;
			
	end if;

	select is_limited;
end;//