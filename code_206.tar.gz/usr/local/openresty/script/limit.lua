local ip = ngx.var.binary_remote_addr
local limit = ngx.shared.limit
local req,_=limit:get(ip)
if req then
        if req > 20 then
                ngx.exit(503)
        else
                limit:incr(ip,1)
        end
else
        limit:set(ip,1,10)
end

-- ngx.say(ngx.var.uri)
ngx.exec("@cc")
