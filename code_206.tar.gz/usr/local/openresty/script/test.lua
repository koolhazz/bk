local redis = require "resty.redis"
local cache = redis.new()
cache.connect(cache, '192.168.100.167', '4501')
local res = cache:get("foo")
if res==ngx.null then
    ngx.say("This is Null")
	return
end

ngx.say(res)
